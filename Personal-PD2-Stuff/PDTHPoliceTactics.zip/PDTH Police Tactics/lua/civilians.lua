if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics

Hooks:PostHook(CivilianDamage, "die", "PDTHTactics_civ_killed", function(self, attack_data)
	if not T.active() then return end
	local attacker = attack_data and attack_data.attacker_unit
	if alive(attacker) and attacker:base() and (attacker:base().is_local_player or attacker:base().is_husk_player) then
		T.civ_kills = (T.civ_kills or 0) + 1
	end
end)
