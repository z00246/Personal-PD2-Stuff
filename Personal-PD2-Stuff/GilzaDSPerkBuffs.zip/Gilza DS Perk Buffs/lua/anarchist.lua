GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

B.ANARCHIST = {
	deck = 15,
	riot = 0.10,
	riot_ds = 0.15,
	unrest = 1.15,
	bloc = 0.25,
	bloc_ds = 0.35,
	bloc_time = 4,
	uprising = 1
}
local C = B.ANARCHIST

function B.anar_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == C.deck) then
		return 0
	end
	return st:get_specialization_value(C.deck, "tiers", "current_tier") or 0
end

local function player_dmg()
	local unit = managers.player and managers.player:player_unit()
	return alive(unit) and unit:character_damage() or nil
end

function B.anar_armor_ratio()
	local dmg = player_dmg()
	if not dmg then return 1 end
	local max = dmg:_max_armor()
	return max > 0 and dmg:get_real_armor() / max or 0
end

function B.anar_riot()
	return B.anar_tier() >= 3 and B.anar_armor_ratio() >= 0.999
end

function B.anar_unrest()
	return B.anar_tier() >= 5 and B.anar_armor_ratio() < 0.5
end

function B.anar_bloc()
	return B.anar_tier() >= 7 and Application:time() < (B.anar_bloc_until or 0)
end

-- seconds left on the armor-break immunity cooldown
function B.anar_invuln_cd()
	local pm = managers.player
	local data = pm and pm._temporary_upgrades and pm._temporary_upgrades.temporary and pm._temporary_upgrades.temporary.armor_break_invulnerable
	if not (data and data.expire_time) then return 0 end
	return math.max(data.expire_time - Application:time(), 0)
end

if script == "lib/managers/playermanager" then
	-- Uprising: kills during Black Bloc shorten the immunity cooldown
	Hooks:PostHook(PlayerManager, "on_killshot", "GilzaDSBuffs_anar_uprising", function(self)
		pcall(function()
			if B.anar_tier() < 9 or not B.anar_bloc() then return end
			local data = self._temporary_upgrades and self._temporary_upgrades.temporary and self._temporary_upgrades.temporary.armor_break_invulnerable
			if data and data.expire_time then
				data.expire_time = data.expire_time - C.uprising
			end
		end)
	end)

elseif script == "lib/units/beings/player/playerdamage" then
	-- Black Bloc: armor breaking gives a damage boost
	Hooks:PreHook(PlayerDamage, "_calc_armor_damage", "GilzaDSBuffs_anar_pre", function(self)
		B._anar_pre_armor = self:get_real_armor()
	end)
	Hooks:PostHook(PlayerDamage, "_calc_armor_damage", "GilzaDSBuffs_anar_post", function(self)
		local before = B._anar_pre_armor
		B._anar_pre_armor = nil
		if before and before > 0 and self:get_real_armor() <= 0 and B.anar_tier() >= 7 then
			B.anar_bloc_until = Application:time() + C.bloc_time
		end
	end)

elseif script == "lib/units/enemies/cop/copdamage" then
	local function bonus(self, attack_data)
		if not attack_data or type(attack_data.damage) ~= "number" then return end
		local player = managers.player and managers.player:player_unit()
		if not (alive(player) and attack_data.attacker_unit == player) then return end
		if B.anar_tier() < 3 then return end
		local mul = 1
		if B.anar_riot() then mul = mul + (B.on and C.riot_ds or C.riot) end
		if B.anar_bloc() then mul = mul + (B.on and C.bloc_ds or C.bloc) end
		if mul ~= 1 then attack_data.damage = attack_data.damage * mul end
	end
	for _, fn in ipairs({ "damage_bullet", "damage_melee" }) do
		Hooks:PreHook(CopDamage, fn, "GilzaDSBuffs_anar_" .. fn, function(self, attack_data)
			pcall(bonus, self, attack_data)
		end)
	end

elseif script == "lib/units/weapons/newraycastweaponbase" then
	-- Unrest: faster reloads with low armor
	local orig_reload = NewRaycastWeaponBase.reload_speed_multiplier
	function NewRaycastWeaponBase:reload_speed_multiplier(...)
		local m = orig_reload(self, ...)
		if type(m) == "number" then
			local ok, unrest = pcall(B.anar_unrest)
			if ok and unrest then return m * C.unrest end
		end
		return m
	end
end
