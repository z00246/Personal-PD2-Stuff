if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics
local script = RequiredScript and RequiredScript:lower() or ""

if script == "lib/managers/localizationmanager" then
	local orig_text = LocalizationManager.text
	function LocalizationManager:text(id, ...)
		if T.hrt_banner and id == "hud_assault_assault" then
			return T.HRT_TEXT
		end
		return orig_text(self, id, ...)
	end

elseif script == "lib/managers/hudmanagerpd2" then
	Hooks:PostHook(HUDManager, "sync_start_assault", "PDTHTactics_hrt_banner_start", function()
		if T.hrt_banner then T.set_hrt_banner(true) end
	end)
	Hooks:PostHook(HUDManager, "sync_end_assault", "PDTHTactics_hrt_banner_end", function()
		if T.hrt_banner then T.set_hrt_banner(false) end
	end)
end
