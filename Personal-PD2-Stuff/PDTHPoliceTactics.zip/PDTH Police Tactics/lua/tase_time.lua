if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics

-- Tazers put you down faster: being tased downs you after 6 seconds instead of the base game's 10.
-- Runs on the tased player's own game, so it applies to the host and to clients who have this mod.
T.TASED_TIME = 6

Hooks:PreHook(PlayerTased, "enter", "PDTHTactics_tase_time_pre", function()
	if not (T.active() or T.client_on()) then return end
	local dmg = tweak_data.player and tweak_data.player.damage
	if dmg and type(dmg.TASED_TIME) == "number" then
		T._tased_orig = dmg.TASED_TIME
		dmg.TASED_TIME = math.min(dmg.TASED_TIME, T.TASED_TIME)
	end
end)

Hooks:PostHook(PlayerTased, "enter", "PDTHTactics_tase_time_post", function()
	local dmg = tweak_data.player and tweak_data.player.damage
	if T._tased_orig and dmg then
		dmg.TASED_TIME = T._tased_orig
		T._tased_orig = nil
	end
end)
