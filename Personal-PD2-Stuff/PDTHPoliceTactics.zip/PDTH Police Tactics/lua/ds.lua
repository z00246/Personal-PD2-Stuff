if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics

T.DS = {
	damage = 0.92,
	reload = 1.3,
	tank_health = 0.75,
	important_cops = 6,
	dropoff = { { 1000, 1 }, { 2000, 0.8 }, { 3000, 0.62 }, { math.huge, 0.5 } }
}

Hooks:PostHook(CharacterTweakData, "_set_sm_wish", "PDTHTactics_ds_rework", function(self)
	local seen = {}
	for name, data in pairs(self) do
		if type(data) == "table" and name ~= "presets" then
			if type(data.weapon) == "table" then
				for _, usage in pairs(data.weapon) do
					if type(usage) == "table" and not seen[usage] then
						seen[usage] = true
						if type(usage.RELOAD_SPEED) == "number" then
							T.set_client(usage, "RELOAD_SPEED", usage.RELOAD_SPEED * T.DS.reload)
						end
						for _, falloff in ipairs(usage.FALLOFF or {}) do
							if type(falloff) == "table" and type(falloff.dmg_mul) == "number" and not seen[falloff] then
								seen[falloff] = true
								local drop = 1
								for _, step in ipairs(T.DS.dropoff) do
									if (falloff.r or 0) <= step[1] then drop = step[2] break end
								end
								T.set_client(falloff, "dmg_mul", falloff.dmg_mul * T.DS.damage * drop)
							end
						end
					end
				end
			end
			if T.has(data.tags, "tank") and type(data.HEALTH_INIT) == "number" then
				T.set(data, "HEALTH_INIT", data.HEALTH_INIT * T.DS.tank_health)
			end
		end
	end
end)

table.insert(T.on_apply, function(on)
	if not GroupAIStateBase then return end
	T._important_default = T._important_default or GroupAIStateBase._nr_important_cops or 3
	GroupAIStateBase._nr_important_cops = (on and T.is_ds()) and T.DS.important_cops or T._important_default
end)
