if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics
local script = RequiredScript and RequiredScript:lower() or ""

-- Only units that spawned as part of a Hostage Rescue Team squad may free hostages.
-- (Regular FBI agents share the HRT's unit type, so the character flag alone isn't enough.)
function T.is_hrt(unit)
	local state = managers.groupai and managers.groupai:state()
	local u_data = state and state._police and alive(unit) and state._police[unit:key()]
	return u_data and u_data.tactics_map and u_data.tactics_map.pdth_hrt and true or false
end

local function gate(cls)
	local orig = cls and cls.rescue_SO_verification
	if not orig then return end
	cls.rescue_SO_verification = function(self, params, unit, ...)
		if T.active() and not T.is_hrt(unit) then
			return false
		end
		return orig(self, params, unit, ...)
	end
end

if script == "lib/units/civilians/logics/civilianlogicflee" then
	gate(CivilianLogicFlee)

elseif script == "lib/units/enemies/cop/logics/coplogicintimidated" then
	gate(CopLogicIntimidated)

elseif script == "lib/managers/group_ai_states/groupaistatebesiege" then
	-- the "pick up a nearby rescue on the way" path checks the character flag; hide it from non-HRT units
	Hooks:PreHook(GroupAIStateBesiege, "on_objective_complete", "PDTHTactics_rescue_gate_pre", function(self, unit)
		if not (T.active() and alive(unit) and unit:base()) or T.is_hrt(unit) then return end
		local tweak = tweak_data.character[unit:base()._tweak_table]
		if tweak and tweak.rescue_hostages then
			T._rescue_hidden = tweak
			tweak.rescue_hostages = false
		end
	end)
	Hooks:PostHook(GroupAIStateBesiege, "on_objective_complete", "PDTHTactics_rescue_gate_post", function()
		if T._rescue_hidden then
			T._rescue_hidden.rescue_hostages = true
			T._rescue_hidden = nil
		end
	end)
end
