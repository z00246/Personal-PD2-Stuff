GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

B.ANARCHIST = {
	deck = 15,
	riot = 0.10,
	riot_ds = 0.15,
	unrest = 1.15,
	bloc = 0.25,
	bloc_ds = 0.35,
	bloc_time = 4,
	uprising = 1,
	-- (7.24) Sydney's signature (card 9, only as Sydney): Mosh Pit - each enemy within 8 m (up to 5) makes your armor
	-- regenerate 20% more; with 5, Black Bloc's damage bonus stays on
	mosh_range = 800, mosh_max = 5, mosh_regen = 0.2, mosh_every = 0.25
}
local C = B.ANARCHIST

-- (7.24) Sydney's Mosh Pit: enemies within 8 m (0 to 5; 0 when the signature is off), counted at most 4 times a second
local function count_mosh()
	if not (B.sig_active and B.sig_active(C.deck)) then return 0 end
	local unit = managers.player and managers.player:player_unit()
	if not (alive(unit) and managers.slot) then return 0 end
	local n = 0
	local units = World:find_units_quick("sphere", unit:position(), C.mosh_range, managers.slot:get_mask("enemies")) or {}
	for _, u in ipairs(units) do
		local d = alive(u) and u:character_damage()
		if d and not d._dead then
			local brain = u.brain and u:brain()
			if not (brain and brain.is_hostage and brain:is_hostage()) then
				n = n + 1
				if n >= C.mosh_max then break end
			end
		end
	end
	return n
end

function B.anar_mosh()
	local now = Application:time()
	if B._anar_mosh_t and now >= B._anar_mosh_t and now - B._anar_mosh_t < C.mosh_every then return B._anar_mosh_n or 0 end
	B._anar_mosh_t = now
	local n = count_mosh()
	B._anar_mosh_n = n
	return n
end

function B.anar_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == C.deck) then
		return 0
	end
	return st:get_specialization_value(C.deck, "tiers", "current_tier") or 0
end

local function player_dmg()
	local unit = managers.player and managers.player:player_unit()
	return alive(unit) and unit:character_damage() or nil
end

function B.anar_armor_ratio()
	local dmg = player_dmg()
	if not dmg then return 1 end
	local max = dmg:_max_armor()
	return max > 0 and dmg:get_real_armor() / max or 0
end

function B.anar_riot()
	return B.anar_tier() >= 3 and B.anar_armor_ratio() >= 0.999
end

function B.anar_unrest()
	return B.anar_tier() >= 5 and B.anar_armor_ratio() < 0.5
end

function B.anar_bloc()
	return B.anar_tier() >= 7 and Application:time() < (B.anar_bloc_until or 0)
end

-- seconds left on the armor-break immunity cooldown
function B.anar_invuln_cd()
	local pm = managers.player
	local data = pm and pm._temporary_upgrades and pm._temporary_upgrades.temporary and pm._temporary_upgrades.temporary.armor_break_invulnerable
	if not (data and data.expire_time) then return 0 end
	return math.max(data.expire_time - Application:time(), 0)
end

if script == "lib/managers/playermanager" then
	-- Uprising: kills during Black Bloc shorten the immunity cooldown
	Hooks:PostHook(PlayerManager, "on_killshot", "GilzaDSBuffs_anar_uprising", function(self)
		if B.anar_tier() < 9 or not B.anar_bloc() then return end
		local data = self._temporary_upgrades and self._temporary_upgrades.temporary and self._temporary_upgrades.temporary.armor_break_invulnerable
		if data and data.expire_time then
			data.expire_time = data.expire_time - C.uprising
		end
	end)

elseif script == "lib/units/beings/player/playerdamage" then
	-- Black Bloc: armor breaking gives a damage boost
	Hooks:PreHook(PlayerDamage, "_calc_armor_damage", "GilzaDSBuffs_anar_pre", function(self)
		B._anar_pre_armor = self:get_real_armor()
	end)
	Hooks:PostHook(PlayerDamage, "_calc_armor_damage", "GilzaDSBuffs_anar_post", function(self)
		local before = B._anar_pre_armor
		B._anar_pre_armor = nil
		if before and before > 0 and self:get_real_armor() <= 0 and B.anar_tier() >= 7 then
			B.anar_bloc_until = Application:time() + C.bloc_time
		end
	end)

	-- (7.24) Sydney's Mosh Pit: each enemy close by makes every armor tick 20% bigger
	local orig_grind = PlayerDamage._update_armor_grinding
	if orig_grind then
		function PlayerDamage:_update_armor_grinding(t, dt, ...)
			local g = self._armor_grinding
			local n = B.anar_mosh()
			if not (type(n) == "number" and n > 0 and g and type(g.armor_value) == "number") then
				return orig_grind(self, t, dt, ...)
			end
			local base = g.armor_value
			g.armor_value = base * (1 + C.mosh_regen * n)
			local a, b = orig_grind(self, t, dt, ...)
			g.armor_value = base
			B.sig_live("mosh pit regen", "%d enemies close by: armor ticks x%.1f", n, 1 + C.mosh_regen * n)
			return a, b
		end
	end

elseif script == "lib/units/enemies/cop/copdamage" then
	local function bonus(self, attack_data)
		if not attack_data or type(attack_data.damage) ~= "number" then return end
		local player = managers.player and managers.player:player_unit()
		if not (alive(player) and attack_data.attacker_unit == player) then return end
		if B.anar_tier() < 3 then return end
		local mul = 1
		if B.anar_riot() then mul = mul + (B.on and C.riot_ds or C.riot) end
		-- (7.24) Sydney's Mosh Pit: with 5 enemies close by, Black Bloc's bonus stays on
		local mosh = B.anar_tier() >= 9 and B.anar_mosh() >= C.mosh_max
		if B.anar_bloc() or mosh then
			mul = mul + (B.on and C.bloc_ds or C.bloc)
			if mosh and not B.anar_bloc() then B.sig_live("mosh pit bloc", "5 enemies close by: Black Bloc's damage bonus is on") end
		end
		if mul ~= 1 then attack_data.damage = attack_data.damage * mul end
	end
	for _, fn in ipairs({ "damage_bullet", "damage_melee" }) do
		Hooks:PreHook(CopDamage, fn, "GilzaDSBuffs_anar_" .. fn, function(self, attack_data)
			bonus(self, attack_data)
		end)
	end

elseif script == "lib/units/weapons/newraycastweaponbase" then
	-- Unrest: faster reloads with low armor
	local orig_reload = NewRaycastWeaponBase.reload_speed_multiplier
	function NewRaycastWeaponBase:reload_speed_multiplier(...)
		local m = orig_reload(self, ...)
		if type(m) == "number" then
			if B.anar_unrest() then return m * C.unrest end
		end
		return m
	end
end
