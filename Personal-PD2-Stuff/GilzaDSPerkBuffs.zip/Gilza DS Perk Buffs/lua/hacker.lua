GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

B.HACKER = {
	deck = 21,
	mark_every = 3,
	mark_type = "mark_enemy_damage_bonus"
}
local C = B.HACKER

function B.hacker_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == C.deck) then
		return 0
	end
	return st:get_specialization_value(C.deck, "tiers", "current_tier") or 0
end

local function unit_tier(unit)
	local me = managers.player and managers.player:player_unit()
	if unit == me then return B.hacker_tier() end
	local session = managers.network and managers.network:session()
	local peer = session and session:peer_by_unit(unit)
	local skills = peer and peer.unpacked_skills and peer:unpacked_skills()
	local spec = skills and skills.specializations
	if spec and tonumber(spec[1]) == C.deck then
		return tonumber(spec[2]) or 0
	end
	return 0
end

function B.hacker_feedback_active()
	local unit = managers.player and managers.player:player_unit()
	local inv = alive(unit) and unit:inventory()
	local data = inv and inv._jammer_data
	return data and data.effect == "feedback" or false
end

if script == "lib/managers/playermanager" then
	-- Overclock: enemies inside your feedback get marked for the whole crew
	B._hacker_marked = B._hacker_marked or {}
	local function overclock()
		if B.hacker_tier() < 5 or not B.hacker_feedback_active() then return end
		local unit = managers.player:player_unit()
		local inv = unit:inventory()
		local _, range = inv:get_feedback_values()
		if not range or range <= 0 then return end
		local pos = unit:position()
		local now = Application:time()
		for key, u_data in pairs(managers.enemy:all_enemies() or {}) do
			local enemy = u_data.unit
			if alive(enemy) and enemy:in_slot(managers.slot:get_mask("enemies")) and now >= (B._hacker_marked[key] or 0) then
				local dmg = enemy:character_damage()
				if dmg and not dmg._dead and mvector3.distance(enemy:position(), pos) <= range then
					local contour = enemy:contour()
					if contour then
						contour:add(C.mark_type, true, 1)
						B._hacker_marked[key] = now + C.mark_every
					end
				end
			end
		end
	end

	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_hacker_update", function()
		local now = Application:time()
		if now < (B._hacker_next or 0) then return end
		B._hacker_next = now + 0.5
		pcall(overclock)
	end)

elseif script == "lib/units/beings/player/playerinventory" then
	-- Firewall (host): while a Hacker with card 7 has feedback running, Tazers and Cloakers in range
	-- can't tase or charge/kick (an attempt in progress gets cancelled). They can still shoot.
	local function block(enemy, until_t)
		local brain = enemy:brain()
		local data = brain and brain._logic_data
		if not data then return end
		local my_data = data.internal_data
		local tweak = enemy:base()._tweak_table or ""
		if string.find(tweak, "spooc", 1, true) then
			data.spooc_attack_timeout_t = math.max(data.spooc_attack_timeout_t or 0, until_t)
			if my_data and my_data.spooc_attack and SpoocLogicAttack and SpoocLogicAttack._cancel_spooc_attempt then
				SpoocLogicAttack._cancel_spooc_attempt(data, my_data)
			end
		elseif string.find(tweak, "taser", 1, true) then
			data.tase_delay_t = math.max(data.tase_delay_t or -1, until_t)
			if my_data and my_data.tasing and TaserLogicAttack and TaserLogicAttack._cancel_tase_attempt then
				TaserLogicAttack._cancel_tase_attempt(data, my_data)
			end
		end
	end

	local function is_special(enemy)
		local tweak = enemy:base() and enemy:base()._tweak_table or ""
		return string.find(tweak, "taser", 1, true) or string.find(tweak, "spooc", 1, true)
	end

	Hooks:PreHook(PlayerInventory, "_do_feedback", "GilzaDSBuffs_hacker_firewall", function(self)
		pcall(function()
			if not Network:is_server() or not alive(self._unit) then return end
			local data = self._jammer_data
			if not (data and data.range) then return end
			if unit_tier(self._unit) < 7 then return end
			local pos = self:_get_feedback_pos()
			local until_t = TimerManager:game():time() + (data.interval or 1.5) + 1
			for _, u_data in pairs(managers.enemy:all_enemies() or {}) do
				local enemy = u_data.unit
				local dmg = alive(enemy) and enemy:character_damage()
				if dmg and not dmg._dead and enemy:in_slot(managers.slot:get_mask("enemies")) and is_special(enemy)
					and mvector3.distance(enemy:movement():m_head_pos(), pos) <= data.range then
					pcall(block, enemy, until_t)
				end
			end
		end)
	end)

elseif script == "lib/tweak_data/skilltreetweakdata" then
	-- Overclock and Firewall replace the flat dodge on cards 5 and 7
	Hooks:PostHook(SkillTreeTweakData, "init", "GilzaDSBuffs_hacker_cards", function(self)
		local deck = self.specializations and self.specializations[C.deck]
		for _, card in ipairs({ 5, 7 }) do
			local ups = deck and deck[card] and deck[card].upgrades
			if ups then
				for i = #ups, 1, -1 do
					if string.find(ups[i], "dodge", 1, true) then table.remove(ups, i) end
				end
			end
		end
	end)
end
