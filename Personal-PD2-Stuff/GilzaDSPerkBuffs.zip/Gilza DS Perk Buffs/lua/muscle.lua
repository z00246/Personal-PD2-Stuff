GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

-- difficulty scaling (shared with buffs.lua): t = 0 up to Overkill, 1/3 Mayhem, 2/3 Death Wish, 1 Death Sentence
if not B.diff_t then
	B.DIFF_T = { easy_wish = 1 / 3, overkill_290 = 2 / 3, sm_wish = 1 }
	function B.diff_t()
		local gs = Global and Global.game_settings
		return gs and B.DIFF_T[gs.difficulty] or 0
	end
	function B.sc(base, ds) return base + (ds - base) * B.diff_t() end
	function B.sci(base, ds) return math.floor(base + (ds - base) * B.diff_t() + 0.5) end
end

-- Muscle (7.00 rework, Geo 2026-10-24: Juggernaut + crowd control + crew tank + berserker).
--  card 1 Rage: health/armor lost -> stacks; each stack: more damage and speed. Kills keep it from fading.
--  card 3 Taunt (enemies prefer you) + Bodyguard (teammates within 10 m take less damage; you too at 5+ Rage)
--  card 5 Juggernaut: health regen per Rage stack; at 5+ Rage no flashbang blinding and kills heal
--  card 7 Fearsome: at 5+ Rage kills panic nearby non-special enemies; more damage per stack
--  card 9 Unstoppable at 8 Rage: half damage, no tase / Cloaker kick downs, teammates nearby protected too
-- *_ds values are the Death Sentence end of the difficulty scale (B.sc).
B.MUSCLE = {
	deck = 2,
	stack_per_health = 0.05,   -- 1 stack per 5% of max health lost
	stack_per_armor = 0.10,    -- 1 stack per 10% of max armor lost
	max_stacks = 10, max_stacks_ds = 12,
	damage_per_stack = { [1] = 0.03, [7] = 0.05 },
	speed_per_stack = 0.01,
	taunt = 1.5,               -- card 3: enemies 50% more likely to target you (the game's own is 15%)
	guard_range = 1000,        -- card 3 Bodyguard
	guard = 0.10, guard_ds = 0.15,
	resist_at = 5, resist = 0.15,
	regen = 0.002, regen_ds = 0.003,   -- card 5 Juggernaut: share of max health per second per stack
	kill_heal_at = 5, kill_heal = 0.03,
	flash_immune_at = 5,
	fear_at = 5, fear_range = 800, fear_range_ds = 1200,   -- card 7 Fearsome
	decay_after = 4,           -- seconds without losing health or killing
	decay_every = 2,
	unstoppable_at = 8,
	unstoppable_time = 5,
	unstoppable_resist = 0.5,
	unstoppable_cooldown = 25, unstoppable_cooldown_ds = 20,
	crew_resist = 0.25,        -- card 9: teammates within guard_range while Unstoppable lasts
	-- (7.24) Wolf's signature (card 9, only as Wolf): Snapped - dropping below 25% health sends you straight to full Rage
	-- and Unstoppable (even while it's cooling down); kills during it heal 5%; once every 45 s
	snap_health = 0.25, snap_every = 45, snap_heal = 0.05,
}
B.NET_ID = B.NET_ID or "GilzaDSBuffs"
B.rage = B.rage or 0
B.crew_unstop = B.crew_unstop or {}   -- peer id -> Application:time() when that Muscle's Unstoppable ends
local C = B.MUSCLE

-- a line in the BLT log the first times a feature does something (buffs.lua)
local function live(key, ...) if B.live then B.live("muscle " .. key, ...) end end

-- the lobby's peers; an empty list outside a real network session (menus)
local function session_peers()
	local session = managers.network and managers.network:session()
	local peers = type(session) == "table" and type(session.peers) == "function" and session:peers()
	return type(peers) == "table" and peers or {}
end

function B.muscle_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == C.deck) then
		return 0
	end
	return st:get_specialization_value(C.deck, "tiers", "current_tier") or 0
end

function B.muscle_max_stacks()
	return B.sci(C.max_stacks, C.max_stacks_ds)
end

local function per_stack(tier)
	return tier >= 7 and C.damage_per_stack[7] or C.damage_per_stack[1]
end

function B.muscle_unstoppable()
	return Application:time() < (B._unstoppable_until or 0)
end

function B.muscle_flash_immune()
	return B.muscle_tier() >= 5 and (B.rage or 0) >= C.flash_immune_at
end

-- a peer's perk deck and card, from its synced skills
local function peer_deck(peer)
	local skills = peer and peer.unpacked_skills and peer:unpacked_skills()
	local spec = skills and skills.specializations
	if not spec then return 0, 0 end
	return tonumber(spec[1]) or 0, tonumber(spec[2]) or 0
end
B.peer_deck = B.peer_deck or peer_deck

-- Bodyguard and crew Unstoppable cover for a unit standing at pos, from every Muscle in the lobby but that unit:
-- returns the damage reduction share (0..1) and whether a nearby Muscle's Unstoppable is running
function B.muscle_cover(pos, self_unit)
	if not pos then return 0, false end
	local guard, unstop = 0, false
	local range_sq = C.guard_range * C.guard_range
	local now = Application:time()
	local me = managers.player and managers.player:player_unit()
	if alive(me) and me ~= self_unit and B.muscle_tier() >= 3 and mvector3.distance_sq(me:position(), pos) <= range_sq then
		guard = B.sc(C.guard, C.guard_ds)
		if B.muscle_unstoppable() then unstop = true end
	end
	for _, peer in pairs(session_peers()) do
		local u = peer:unit()
		if alive(u) and u ~= self_unit then
			local deck, tier = peer_deck(peer)
			if deck == C.deck and tier >= 3 and mvector3.distance_sq(u:position(), pos) <= range_sq then
				guard = math.max(guard, B.sc(C.guard, C.guard_ds))
				if now < (B.crew_unstop[peer:id()] or 0) then unstop = true end
			end
		end
	end
	return guard, unstop
end

local function check_unstoppable(now)
	if B.rage >= C.unstoppable_at and B.muscle_tier() >= 9 and now >= (B._unstoppable_ready or 0) then
		B._unstoppable_until = now + C.unstoppable_time
		B._unstoppable_ready = now + B.sc(C.unstoppable_cooldown, C.unstoppable_cooldown_ds)
		live("unstoppable", "on at Rage %d for %ds, ready again in %ds", B.rage, C.unstoppable_time, B._unstoppable_ready - now)
		local unit = managers.player:player_unit()
		if alive(unit) and unit:sound() then unit:sound():play("perkdeck_activate", nil, false) end
		-- teammates with this mod (and the host, for the bots) protect themselves while it lasts
		local session = managers.network and managers.network:session()
		if session and LuaNetworking and LuaNetworking.SendToPeers then
			pcall(LuaNetworking.SendToPeers, LuaNetworking, B.NET_ID, "munstop:" .. C.unstoppable_time)
		end
	end
end

-- lost / max of health ("health") or armor ("armor") -> Rage stacks
function B.muscle_add_rage(lost, max, kind)
	if B.muscle_tier() < 1 or not max or max <= 0 or not lost or lost <= 0 then return end
	local per = kind == "armor" and C.stack_per_armor or C.stack_per_health
	local carry_key = kind == "armor" and "_rage_carry_armor" or "_rage_carry"
	B[carry_key] = (B[carry_key] or 0) + lost / max
	local gained = math.floor(B[carry_key] / per)
	if gained > 0 then
		B[carry_key] = B[carry_key] - gained * per
		B.rage = math.min(B.rage + gained, B.muscle_max_stacks())
		live("rage", "+%d from lost %s, now %d of %d", gained, kind, B.rage, B.muscle_max_stacks())
	end
	local now = Application:time()
	B._rage_hit_t = now
	B._rage_decay_t = now + C.decay_after
	check_unstoppable(now)
	if kind == "health" and B.muscle_snap then pcall(B.muscle_snap, now) end
end

-- (7.24) Wolf's Snapped
function B.muscle_snapped()
	return Application:time() < (B._snapped_until or 0)
end
function B.muscle_snap(now)
	now = now or Application:time()
	if now < (B._snapped_ready or 0) or not (B.sig_active and B.sig_active(C.deck)) then return end
	local unit = managers.player and managers.player:player_unit()
	local dmg = alive(unit) and unit:character_damage()
	if not dmg or dmg:dead() or dmg:need_revive() or dmg:health_ratio() >= C.snap_health then return end
	B._snapped_ready = now + C.snap_every
	B.rage = B.muscle_max_stacks()
	B._rage_decay_t = now + C.decay_after
	B._unstoppable_ready = 0
	check_unstoppable(now)
	B._snapped_until = B._unstoppable_until
	if B.sig_live then B.sig_live("snapped", "below 25%% health: Rage %d and Unstoppable", B.rage) end
end

-- card 7 Fearsome: kills panic the non-special enemies around you
function B.muscle_fearsome(killed_unit)
	local player = managers.player and managers.player:player_unit()
	if not alive(player) then return end
	local mask = managers.slot:get_mask("enemies")
	local n = 0
	for _, u in ipairs(World:find_units_quick("sphere", player:position(), B.sc(C.fear_range, C.fear_range_ds), mask) or {}) do
		local dmg = u ~= killed_unit and alive(u) and u:character_damage()
		local base = dmg and u:base()
		if dmg and dmg.build_suppression and not (dmg.dead and dmg:dead())
			and not (base and base.has_tag and (base:has_tag("special") or base:has_tag("tank"))) then
			pcall(dmg.build_suppression, dmg, 0, 1)
			n = n + 1
		end
	end
	if n > 0 then live("fearsome", "a kill at Rage %d made %d enemies roll for panic", B.rage or 0, n) end
end

if script == "lib/managers/playermanager" then
	-- card 5: flashbangs can't blind you at 5+ Rage (the blinding lives on the environment controller)
	local function wrap_flash()
		local ec = managers.environment_controller
		if not ec or ec._gdsb_flash == ec.set_flashbang or not ec.set_flashbang then return end
		local orig = ec.set_flashbang
		local wrapped = function(self, ...)
			local immune = false
			pcall(function() immune = B.muscle_flash_immune() end)
			if not immune then return orig(self, ...) end
			live("flashbang", "blinding blocked at Rage %d", B.rage or 0)
			local f, ff, c, ce = self._current_flashbang, self._current_flashbang_flash, self._current_concussion, self._concussion_effect
			local ok, err = pcall(orig, self, ...)
			self._current_flashbang, self._current_flashbang_flash, self._current_concussion = f, ff, c
			if self._concussion_effect ~= ce then
				local new = self._concussion_effect
				self._concussion_effect = ce
				if new then pcall(function() World:effect_manager():fade_kill(new) end) end
			end
			if not ok and not B._flash_err then B._flash_err = true; log("[Gilza DS Perk Buffs] flashbang: " .. tostring(err)) end
		end
		ec.set_flashbang = wrapped
		ec._gdsb_flash = wrapped
	end

	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_muscle_update", function(t, dt)
		local now = Application:time()
		local last = B._rage_last or now
		B._rage_last = now
		local step = math.min(math.max(now - last, 0), 0.5)
		pcall(wrap_flash)
		if (B.rage or 0) <= 0 then return end
		local unit = managers.player and managers.player:player_unit()
		local dmg = alive(unit) and unit:character_damage()
		if not dmg or dmg:dead() then
			B.rage, B._rage_carry, B._rage_carry_armor, B._jug_heal = 0, 0, 0, 0
			return
		end
		if now >= (B._rage_decay_t or 0) then
			B.rage = math.max(B.rage - 1, 0)
			B._rage_decay_t = now + C.decay_every
		end
		-- card 5 Juggernaut: health back every second for each Rage stack
		if B.muscle_tier() >= 5 and B.rage > 0 and not dmg:need_revive() then
			B._jug_heal = (B._jug_heal or 0) + step * B.rage * B.sc(C.regen, C.regen_ds)
			if B._jug_heal >= 0.005 then
				dmg:restore_health(B._jug_heal, false)
				live("juggernaut", "regenerating %.2f%% of max health a second at Rage %d", B.rage * B.sc(C.regen, C.regen_ds) * 100, B.rage)
				B._jug_heal = 0
			end
		end
	end)

	local orig_resist = PlayerManager.damage_reduction_skill_multiplier
	function PlayerManager:damage_reduction_skill_multiplier(...)
		local m = orig_resist(self, ...)
		if type(m) ~= "number" then return m end
		local ok, tier = pcall(B.muscle_tier)
		if ok and tier >= 1 then
			if tier >= 3 and B.rage >= C.resist_at then
				m = m * (1 - C.resist)
				live("resist", "damage taken x%.2f at Rage %d", 1 - C.resist, B.rage)
			end
			if B.muscle_unstoppable() then
				m = m * (1 - C.unstoppable_resist)
				live("unstoppable resist", "damage taken x%.2f while Unstoppable", 1 - C.unstoppable_resist)
			end
		end
		-- a teammate's Bodyguard / Unstoppable (only a real player unit: Player Stats Panel Enhancements asks with a
		-- stand-in in the menus)
		local ok2, guard, unstop = pcall(function()
			local me = self:player_unit()
			if not alive(me) or (type(me) == "table" and me.is_mock) then return 0, false end
			return B.muscle_cover(me:position(), me)
		end)
		if ok2 then
			if guard and guard > 0 then
				m = m * (1 - guard)
				live("bodyguard", "a Muscle teammate close by: damage taken x%.2f", 1 - guard)
			end
			if unstop then
				m = m * (1 - C.crew_resist)
				live("crew unstoppable", "a Muscle teammate's Unstoppable: damage taken x%.2f", 1 - C.crew_resist)
			end
		elseif not B._muscle_cover_err then
			B._muscle_cover_err = true
			log("[Gilza DS Perk Buffs] Muscle Bodyguard check error: " .. tostring(guard))
		end
		return m
	end

	-- card 1: each Rage stack makes you a bit faster
	local orig_speed = PlayerManager.movement_speed_multiplier
	function PlayerManager:movement_speed_multiplier(...)
		local m = orig_speed(self, ...)
		if type(m) == "number" and (B.rage or 0) > 0 then
			local ok, tier = pcall(B.muscle_tier)
			if ok and tier >= 1 then
				m = m * (1 + B.rage * C.speed_per_stack)
				live("speed", "moving x%.2f at Rage %d", 1 + B.rage * C.speed_per_stack, B.rage)
			end
		end
		return m
	end

	Hooks:PostHook(PlayerManager, "on_killshot", "GilzaDSBuffs_muscle_kill", function(self, killed_unit)
		pcall(function()
			local tier = B.muscle_tier()
			if tier < 1 then return end
			-- kills keep Rage from decaying
			if (B.rage or 0) > 0 then
				B._rage_decay_t = math.max(B._rage_decay_t or 0, Application:time() + C.decay_after)
			end
			if tier >= 5 and B.rage >= C.kill_heal_at then
				local unit = self:player_unit()
				local dmg = alive(unit) and unit:character_damage()
				if dmg and not dmg:dead() and not dmg:need_revive() then
					dmg:restore_health(C.kill_heal, false)
					live("kill heal", "+%d%% health on a kill at Rage %d", C.kill_heal * 100, B.rage)
				end
			end
			if tier >= 7 and B.rage >= C.fear_at then
				B.muscle_fearsome(killed_unit)
			end
			-- (7.24) Wolf's Snapped: kills heal 5% while it lasts
			if B.muscle_snapped() then
				local unit = self:player_unit()
				local dmg = alive(unit) and unit:character_damage()
				if dmg and not dmg:dead() and not dmg:need_revive() then
					dmg:restore_health(C.snap_heal, false)
					B.sig_live("snapped heal", "+%d%% health on a kill", C.snap_heal * 100)
				end
			end
		end)
	end)

	if LuaNetworking and LuaNetworking.AddReceiveHook then
		LuaNetworking:AddReceiveHook(B.NET_ID, "GilzaDSBuffs_muscle_net", function(data, sender) pcall(function()
			local dur = type(data) == "string" and tonumber(string.match(data, "^munstop:([%d%.]+)$") or "")
			if not dur then return end
			local session = managers.network and managers.network:session()
			local peer = session and session:peer(tonumber(sender))
			local deck, tier = peer_deck(peer)
			if deck ~= C.deck or tier < 9 then return end
			B.crew_unstop[peer:id()] = Application:time() + math.min(dur, C.unstoppable_time + 1)
			live("crew unstoppable heard", "player %d went Unstoppable", peer:id())
		end) end)
	end

	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_muscle_reset", function()
		local session = managers.network and managers.network:session()
		if B._muscle_session ~= session then
			B._muscle_session = session
			B.rage, B._rage_carry, B._rage_carry_armor, B._jug_heal = 0, 0, 0, 0
			B._unstoppable_until, B._unstoppable_ready, B.crew_unstop = nil, nil, {}
			B._snapped_until, B._snapped_ready = nil, nil
		end
	end)

elseif script == "lib/units/beings/player/playerdamage" then
	local orig_health = PlayerDamage._calc_health_damage
	function PlayerDamage:_calc_health_damage(attack_data, ...)
		local lost = orig_health(self, attack_data, ...)
		if type(lost) == "number" and lost > 0 then
			pcall(B.muscle_add_rage, lost, self:_max_health(), "health")
		end
		return lost
	end

	local orig_armor = PlayerDamage._calc_armor_damage
	function PlayerDamage:_calc_armor_damage(attack_data, ...)
		local lost = orig_armor(self, attack_data, ...)
		if type(lost) == "number" and lost > 0 then
			pcall(B.muscle_add_rage, lost, self:_max_armor(), "armor")
		end
		return lost
	end

	-- Unstoppable: tasers can't hold you (same as the game's own god mode check)
	local orig_tase = PlayerDamage.damage_tase
	function PlayerDamage:damage_tase(attack_data, ...)
		if B.muscle_unstoppable and B.muscle_unstoppable() then
			live("tase blocked", "a taser's hit did nothing (Unstoppable)")
			return
		end
		return orig_tase(self, attack_data, ...)
	end
	local orig_can_tase = PlayerDamage.can_be_tased
	if orig_can_tase then
		function PlayerDamage:can_be_tased(...)
			if B.muscle_unstoppable and B.muscle_unstoppable() then
				live("tase check", "can't be tased right now (Unstoppable)")
				return false
			end
			return orig_can_tase(self, ...)
		end
	end

elseif script == "lib/units/beings/player/playermovement" then
	-- Unstoppable: Cloaker kicks don't take you down, tasers don't try
	local orig_spooc = PlayerMovement.on_SPOOCed
	function PlayerMovement:on_SPOOCed(enemy_unit, ...)
		if B.muscle_unstoppable and B.muscle_unstoppable() then
			live("kick blocked", "a Cloaker kick did nothing (Unstoppable)")
			return
		end
		return orig_spooc(self, enemy_unit, ...)
	end
	local orig_spooc_ok = PlayerMovement.is_SPOOC_attack_allowed
	function PlayerMovement:is_SPOOC_attack_allowed(...)
		if B.muscle_unstoppable and B.muscle_unstoppable() then
			live("kick check", "Cloakers can't go for you right now (Unstoppable)")
			return false
		end
		return orig_spooc_ok(self, ...)
	end
	local orig_taser_ok = PlayerMovement.is_taser_attack_allowed
	function PlayerMovement:is_taser_attack_allowed(...)
		if B.muscle_unstoppable and B.muscle_unstoppable() then
			live("taser check", "Tasers can't go for you right now (Unstoppable)")
			return false
		end
		return orig_taser_ok(self, ...)
	end

elseif script == "lib/units/enemies/cop/copdamage" then
	local function rage_bonus(attack_data)
		if not attack_data or type(attack_data.damage) ~= "number" or (B.rage or 0) <= 0 then return end
		local player = managers.player and managers.player:player_unit()
		if not (alive(player) and attack_data.attacker_unit == player) then return end
		local tier = B.muscle_tier()
		if tier < 1 then return end
		attack_data.damage = attack_data.damage * (1 + B.rage * per_stack(tier))
		live("damage", "dealing x%.2f at Rage %d", 1 + B.rage * per_stack(tier), B.rage)
	end
	for _, fn in ipairs({ "damage_bullet", "damage_melee" }) do
		Hooks:PreHook(CopDamage, fn, "GilzaDSBuffs_muscle_" .. fn, function(self, attack_data)
			pcall(rage_bonus, attack_data)
		end)
	end

elseif script == "lib/units/player_team/teamaidamage" then
	-- bots live on the host: a Muscle's Bodyguard and Unstoppable cover them there
	if TeamAIDamage and TeamAIDamage._apply_damage then
		Hooks:PreHook(TeamAIDamage, "_apply_damage", "GilzaDSBuffs_muscle_bots", function(self, attack_data)
			pcall(function()
				if not (Network:is_server() and attack_data and type(attack_data.damage) == "number" and alive(self._unit)) then return end
				local guard, unstop = B.muscle_cover(self._unit:position(), self._unit)
				local m = (1 - (guard or 0)) * (unstop and (1 - C.crew_resist) or 1)
				if m < 1 then
					attack_data.damage = attack_data.damage * m
					live("bot cover", "a bot near a Muscle took x%.2f damage", m)
				end
			end)
		end)
	end

elseif script == "lib/tweak_data/skilltreetweakdata" then
	-- card 9: Juggernaut's regeneration replaces the old flat health regeneration
	Hooks:PostHook(SkillTreeTweakData, "init", "GilzaDSBuffs_muscle_cards", function(self)
		local deck = self.specializations and self.specializations[C.deck]
		local ups = deck and deck[9] and deck[9].upgrades
		if not ups then return end
		for i = #ups, 1, -1 do
			if ups[i] == "player_passive_health_regen" then table.remove(ups, i) end
		end
	end)
end
