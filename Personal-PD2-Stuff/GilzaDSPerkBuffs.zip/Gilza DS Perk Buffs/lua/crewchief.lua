GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

-- difficulty scaling (shared with buffs.lua): t = 0 up to Overkill, 1/3 Mayhem, 2/3 Death Wish, 1 Death Sentence
if not B.diff_t then
	B.DIFF_T = { easy_wish = 1 / 3, overkill_290 = 2 / 3, sm_wish = 1 }
	function B.diff_t()
		local gs = Global and Global.game_settings
		return gs and B.DIFF_T[gs.difficulty] or 0
	end
	function B.sc(base, ds) return base + (ds - base) * B.diff_t() end
	function B.sci(base, ds) return math.floor(base + (ds - base) * B.diff_t() + 0.5) end
end

-- a line in the BLT log the first times a feature does something (buffs.lua)
local function live(key, ...) if B.live then B.live("crew chief " .. key, ...) end end

-- Crew Chief (7.20 rework v1b, Geo 2026-10-25: "now what about crew chief, any ideas?" - picked "Rework standard",
-- "Bots and Jokers", "Orders" and "anything with squad cohesion would be good too"; the hostage damage reduction stacks
-- ("why not make the damage res stack too?", picked "First 8%, then +4% each"); "yea go ahead and build them").
-- The 6.x effects stay (Cohesion, Focus Fire, Rally) with Death Sentence ends; the game's own cards stay as they are.
--  card 1 Cohesion: teammates and AI teammates within 18 m (not downed) are your Squad, up to 3: 5% » 7% less damage
--   each.
--  card 3 Call the Shots: every 8 » 6 s you mark the nearest special enemy you can see within 30 m, with the game's own
--   mark (the same call as your shout, so everyone sees it and High Value Target applies); one already marked is
--   skipped. Focus Fire: marked enemies take 25% » 35% more damage from your crew (the host does it for everyone, a
--   client without a modded host for himself). The close-contact damage reduction (8% » 12%) is a "scaled" niche in
--   buffs.lua now.
--  card 5 Rally: reviving a teammate -> 40% » 50% less damage for 6 s. Confirmed: an enemy you marked (your shout or
--   Call the Shots) dying while still marked gives you 10% » 15% of your armor back, whoever killed it.
--  card 7 Testudo: Cohesion becomes 7% » 9% per Squad member, and each Squad member speeds up your armor recovery by
--   10%. Pinned Down: marked enemies deal 20% » 30% less damage to you.
--  card 9 Hostage Situation: the hostage damage reduction stacks: 8% » 12% for the first hostage and 4% » 6% for each
--   further one, up to 4 (the game: 8% flat, hostage_max_num.damage_dampener = 1). Chain of Command (host): AI
--   teammates and the enemies a Crew Chief converted take 30% » 40% less damage and deal 25% » 35% more while within
--   18 m of him; his converts also take a third less damage always (= 50% more health).
-- *_ds values are the Death Sentence end of the difficulty scale (B.sc).
B.CC = {
	deck = 1,
	range = 1800,                                   -- the Squad: within 18 m
	per_ally = 0.05, per_ally_ds = 0.07,            -- card 1 Cohesion, each Squad member
	per_ally7 = 0.07, per_ally7_ds = 0.09,          -- card 7: Cohesion raised
	max_allies = 3,
	ally_regen = 0.10,                              -- card 7: armor recovery per Squad member
	mark_damage = 0.25, mark_damage_ds = 0.35,      -- card 3 Focus Fire
	call_every = 8, call_every_ds = 6,              -- card 3 Call the Shots
	call_retry = 0.5, call_range = 3000, call_cone = 0.35, call_checks = 8,
	rally_resist = 0.40, rally_resist_ds = 0.50, rally_time = 6,   -- card 5 Rally
	confirmed = 0.10, confirmed_ds = 0.15, mark_memory = 15,       -- card 5 Confirmed
	pinned = 0.20, pinned_ds = 0.30,                -- card 7 Pinned Down
	hostage_first = 0.08, hostage_first_ds = 0.12,  -- card 9: the first hostage...
	hostage_extra = 0.04, hostage_extra_ds = 0.06,  -- ...each further one
	hostage_max = 4,
	chain_range = 1800,                             -- card 9 Chain of Command
	chain_resist = 0.30, chain_resist_ds = 0.40,
	chain_damage = 0.25, chain_damage_ds = 0.35,
	chain_health = 1.5                              -- converts: 50% more health (damage taken / 1.5)
}
local C = B.CC
B.NET_ID = B.NET_ID or "GilzaDSBuffs"
B.cc_marks = B.cc_marks or {}          -- enemies you marked: unit key -> { unit, t }
B.cc_converts = B.cc_converts or {}    -- (host) converted enemy key -> the player unit who converted it

local MARK_TYPES = { "mark_enemy", "mark_enemy_damage_bonus", "mark_enemy_damage_bonus_distance" }

function B.cc_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == C.deck) then
		return 0
	end
	return st:get_specialization_value(C.deck, "tiers", "current_tier") or 0
end

local function peer_cc_tier(peer)
	local skills = peer and peer.unpacked_skills and peer:unpacked_skills()
	local spec = skills and skills.specializations
	if spec and tonumber(spec[1]) == C.deck then
		return tonumber(spec[2]) or 0
	end
	return 0
end

-- every Crew Chief in the heist: you and teammates (their synced perk deck), { unit, tier }
function B.cc_list()
	local list = {}
	local me = managers.player and managers.player:player_unit()
	local my_tier = B.cc_tier()
	if alive(me) and my_tier > 0 then
		table.insert(list, { unit = me, tier = my_tier })
	end
	local session = managers.network and managers.network:session()
	for _, peer in pairs(session and session:peers() or {}) do
		local tier = peer_cc_tier(peer)
		if tier > 0 and alive(peer:unit()) then
			table.insert(list, { unit = peer:unit(), tier = tier })
		end
	end
	return list
end

function B.cc_best_tier()
	local best = 0
	for _, cc in ipairs(B.cc_list()) do
		if cc.tier > best then best = cc.tier end
	end
	return best
end

-- the Crew Chief tier of a player unit (you or a teammate), 0 for anyone else
local function unit_cc_tier(u)
	if not alive(u) then return 0 end
	if u == (managers.player and managers.player:player_unit()) then return B.cc_tier() end
	local session = managers.network and managers.network:session()
	for _, peer in pairs(session and session:peers() or {}) do
		if peer:unit() == u then return peer_cc_tier(peer) end
	end
	return 0
end

-- teammates and AI teammates within 18 m who aren't down, up to 3
local function allies_near(unit)
	local state = managers.groupai and managers.groupai:state()
	if not (alive(unit) and state) then return 0 end
	local pos, count = unit:position(), 0
	for _, c in pairs(state:all_char_criminals() or {}) do
		local u = c.unit
		if alive(u) and u ~= unit and not c.status and mvector3.distance(u:position(), pos) <= C.range then
			count = count + 1
		end
	end
	return math.min(count, C.max_allies)
end

-- your Squad right now (0 if you aren't a Crew Chief)
function B.cc_squad()
	if B.cc_tier() < 1 then return 0 end
	return allies_near(managers.player and managers.player:player_unit())
end

-- card 1 Cohesion / card 7 Testudo: your damage reduction from the Squad
function B.cc_cohesion()
	local tier = B.cc_tier()
	if tier < 1 then return 0 end
	local per = tier >= 7 and B.sc(C.per_ally7, C.per_ally7_ds) or B.sc(C.per_ally, C.per_ally_ds)
	return per * allies_near(managers.player and managers.player:player_unit())
end

local function is_marked(unit)
	local contour = alive(unit) and unit.contour and unit:contour()
	if not (contour and contour.has_id) then return false end
	for _, ty in ipairs(MARK_TYPES) do
		if contour:has_id(ty) then return true end
	end
	return false
end
B.cc_is_marked = is_marked

-- a Crew Chief with card 9 within 18 m of this position: Chain of Command (host side)
local function chain_near(pos, owner)
	if not pos then return false end
	local range_sq = C.chain_range * C.chain_range
	if owner then
		return unit_cc_tier(owner) >= 9 and mvector3.distance_sq(owner:position(), pos) <= range_sq
	end
	for _, cc in ipairs(B.cc_list()) do
		if cc.tier >= 9 and mvector3.distance_sq(cc.unit:position(), pos) <= range_sq then return true end
	end
	return false
end

-- (host) the player who converted this enemy, if a Crew Chief with card 9 did
local function convert_owner(u)
	local owner = alive(u) and B.cc_converts[u:key()]
	if alive(owner) and unit_cc_tier(owner) >= 9 then return owner end
	return nil
end

local function is_bot(u)
	local state = managers.groupai and managers.groupai:state()
	local bots = state and state.all_AI_criminals and state:all_AI_criminals()
	return alive(u) and bots and bots[u:key()] and true or false
end

if script == "lib/managers/playermanager" then
	------------------------------------------------------------------ card 1 Cohesion, card 5 Rally: your damage reduction
	local orig_resist = PlayerManager.damage_reduction_skill_multiplier
	function PlayerManager:damage_reduction_skill_multiplier(...)
		local m = orig_resist(self, ...)
		if type(m) ~= "number" then return m end
		local cohesion = B.cc_cohesion()
		if cohesion > 0 then
			m = m * (1 - cohesion)
			live("cohesion", "%.1f%% less damage from the Squad", cohesion * 100)
		end
		if Application:time() < (B.cc_rally_until or 0) then
			local rally = B.sc(C.rally_resist, C.rally_resist_ds)
			m = m * (1 - rally)
			live("rally", "%.1f%% less damage after a revive", rally * 100)
		end
		return m
	end

	------------------------------------------------------------------ card 7 Testudo: faster armor recovery per Squad member
	local orig_regen = PlayerManager.body_armor_regen_multiplier
	if orig_regen then
		function PlayerManager:body_armor_regen_multiplier(...)
			local m = orig_regen(self, ...)
			if type(m) ~= "number" then return m end
			local n = B.cc_tier() >= 7 and B.cc_squad() or 0
			if n > 0 then
				m = m * (1 - C.ally_regen * n)
				live("testudo", "armor recovery timer x%.2f with %d in the Squad", 1 - C.ally_regen * n, n)
			end
			return m
		end
	end

	------------------------------------------------------------------ card 9: the hostage damage reduction stacks
	-- (the game: 8% for one or more hostages, hostage_max_num.damage_dampener = 1; Gilza adds it to its damage
	-- reduction sum). Here: first + extra x (hostages - 1), hostages = the heist's + your converts, up to 4. A
	-- teammate's game does this only if he has this mod; Crew Chief's team upgrade is what tells it the card is on.
	local function hostage_dr(pm)
		local team = pm:team_upgrade_value("damage_dampener", "hostage_multiplier", 1)
		if type(team) ~= "number" or team >= 1 then return nil end
		local state = managers.groupai and managers.groupai:state()
		local minions = pm.num_local_minions and pm:num_local_minions() or 0
		local n = (state and state.hostage_count and state:hostage_count() or 0) + (type(minions) == "number" and minions or 0)
		n = math.min(n, C.hostage_max)
		if n < 1 then return 1 end
		local dr = B.sc(C.hostage_first, C.hostage_first_ds) + B.sc(C.hostage_extra, C.hostage_extra_ds) * (n - 1)
		if pm:has_category_upgrade("player", "close_to_hostage_boost") and pm._is_local_close_to_hostage then
			dr = dr * (tweak_data.upgrades.hostage_near_player_multiplier or 1)
		end
		live("hostages", "%.1f%% less damage with %d hostages", dr * 100, n)
		return 1 - dr
	end
	local orig_hostage = PlayerManager.get_hostage_bonus_multiplier
	if orig_hostage then
		function PlayerManager:get_hostage_bonus_multiplier(category, ...)
			local m = orig_hostage(self, category, ...)
			if category ~= "damage_dampener" or type(m) ~= "number" then return m end
			local v = hostage_dr(self)
			if type(v) == "number" then return v end
			return m
		end
	end

	------------------------------------------------------------------ card 3 Call the Shots
	local tmp = Vector3()
	local function is_special(u)
		local base = u:base()
		if base and base.has_tag and base:has_tag("special") then return true end
		local ct = base and tweak_data.character and tweak_data.character[base._tweak_table]
		return ct and ct.priority_shout ~= nil or false
	end

	local function usable(u)
		if not alive(u) then return false end
		local dmg = u:character_damage()
		if not dmg or dmg._dead or (dmg.dead and dmg:dead()) then return false end
		local brain = u.brain and u:brain()
		if brain and ((brain.is_hostage and brain:is_hostage()) or (brain.converted and brain:converted())) then return false end
		return true
	end

	-- the nearest special you can see within 30 m that isn't marked yet
	local function pick(player)
		local cam = player.camera and player:camera()
		local pmov = player:movement()
		local from = cam and cam:position() or (pmov and pmov:m_head_pos())
		if not from then return nil end
		local fwd = cam and cam:forward()
		local mask = managers.slot:get_mask("enemies")
		local list = {}
		for _, data in pairs(managers.enemy:all_enemies() or {}) do
			local u = data.unit
			if usable(u) and u:in_slot(mask) and is_special(u) and not is_marked(u) then
				local mov = u:movement()
				local head = mov and mov:m_head_pos() or u:position()
				local d = mvector3.distance(from, head)
				if d <= C.call_range then
					local ahead = true
					if fwd and d > 1 then
						mvector3.set(tmp, head)
						mvector3.subtract(tmp, from)
						mvector3.normalize(tmp)
						ahead = mvector3.dot(tmp, fwd) >= C.call_cone
					end
					if ahead then list[#list + 1] = { u = u, d = d } end
				end
			end
		end
		table.sort(list, function(a, b) return a.d < b.d end)
		local vis = managers.slot:get_mask("AI_visibility")
		for i = 1, math.min(#list, C.call_checks) do
			local u = list[i].u
			local mov = u:movement()
			local seen = mov and not World:raycast("ray", from, mov:m_head_pos(), "slot_mask", vis, "ray_type", "ai_vision", "report")
			if mov and not seen and mov.m_com then
				seen = not World:raycast("ray", from, mov:m_com(), "slot_mask", vis, "ray_type", "ai_vision", "report")
			end
			if seen then return u, list[i].d end
		end
		return nil
	end

	local function call_the_shots()
		local session = managers.network and managers.network:session()
		if B._cc_session ~= session then
			B._cc_session = session
			B.cc_marks, B.cc_converts = {}, {}
			B._cc_call_t, B.cc_rally_until = nil, nil
		end
		if B.cc_tier() < 3 then return end
		local now = Application:time()
		if now < (B._cc_call_t or 0) then return end
		local player = managers.player and managers.player:player_unit()
		local state = managers.groupai and managers.groupai:state()
		if not alive(player) or (state and state:whisper_mode()) or not managers.game_play_central
			or not (managers.slot and managers.enemy) then
			B._cc_call_t = now + C.call_retry
			return
		end
		local u, d = pick(player)
		if u and managers.game_play_central:auto_highlight_enemy(u, true) then
			B._cc_call_t = now + B.sc(C.call_every, C.call_every_ds)
			local base = u:base()
			live("call the shots", "marked a %s %.1f m away", tostring(base and base._tweak_table), (d or 0) / 100)
		else
			B._cc_call_t = now + C.call_retry
		end
	end

	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_cc_call", function()
		call_the_shots()
	end)

	------------------------------------------------------------------ is the host modded (Focus Fire on clients)
	if LuaNetworking and LuaNetworking.AddReceiveHook then
		LuaNetworking:AddReceiveHook(B.NET_ID, "GilzaDSBuffs_cc_net", function(data)
			if data == "host" then
				B.host_has_mod = managers.network and managers.network:session()
			end
		end)
	end

	local function greet(peer_id)
		if Network:is_server() and LuaNetworking and LuaNetworking.SendToPeer and peer_id then
			LuaNetworking:SendToPeer(peer_id, B.NET_ID, "host")
		end
	end
	Hooks:Add("NetworkManagerOnPeerAdded", "GilzaDSBuffs_host_greet", function(peer, peer_id)
		DelayedCalls:Add("GilzaDSBuffs_greet_" .. tostring(peer_id), 6, function() greet(peer_id) end)
	end)
	Hooks:Add("BaseNetworkSessionOnLoadComplete", "GilzaDSBuffs_host_greet_load", function()
		DelayedCalls:Add("GilzaDSBuffs_greet_all", 3, function()
			local session = managers.network and managers.network:session()
			for _, peer in pairs(session and session:peers() or {}) do greet(peer:id()) end
		end)
	end)

elseif script == "lib/managers/gameplaycentralmanager" then
	-- your own marks (your shout, Call the Shots): the game's mark with your upgrades; remembered for Confirmed
	local orig_highlight = GamePlayCentralManager.auto_highlight_enemy
	if orig_highlight then
		function GamePlayCentralManager:auto_highlight_enemy(unit, use_player_upgrades, ...)
			local r = orig_highlight(self, unit, use_player_upgrades, ...)
			if r and use_player_upgrades and alive(unit) and B.cc_tier() >= 1 then
				B.cc_marks[unit:key()] = { unit = unit, t = Application:time() }
			end
			return r
		end
	end

elseif script == "lib/units/enemies/cop/copdamage" then
	------------------------------------------------------------------ card 3 Focus Fire
	local function crew_attacker(unit)
		local state = managers.groupai and managers.groupai:state()
		return alive(unit) and state and state:all_criminals()[unit:key()] and true or false
	end

	local function applies(self, attacker)
		if not crew_attacker(attacker) or not is_marked(self._unit) then return false end
		local me = managers.player and managers.player:player_unit()
		if attacker == me then
			local host_boosts = not Network:is_server() and B.host_has_mod and managers.network and B.host_has_mod == managers.network:session()
			return not host_boosts and B.cc_best_tier() >= 3
		end
		return Network:is_server() and B.cc_best_tier() >= 3
	end

	local function focus_mul()
		return 1 + B.sc(C.mark_damage, C.mark_damage_ds)
	end

	------------------------------------------------------------------ card 9 Chain of Command (host): bots and converts
	local function chain_mul(self, attack_data)
		if not Network:is_server() then return 1 end
		local m = 1
		local attacker = attack_data.attacker_unit
		-- dealt: an AI teammate near a Crew Chief, or a convert near the Crew Chief who converted it
		if alive(attacker) then
			if is_bot(attacker) then
				if chain_near(attacker:position()) then
					m = m * (1 + B.sc(C.chain_damage, C.chain_damage_ds))
					live("chain bot damage", "a bot near a Crew Chief dealt x%.2f damage", m)
				end
			else
				local owner = convert_owner(attacker)
				if owner and chain_near(attacker:position(), owner) then
					m = m * (1 + B.sc(C.chain_damage, C.chain_damage_ds))
					live("chain convert damage", "a convert near its Crew Chief dealt x%.2f damage", m)
				end
			end
		end
		-- taken: a convert of a Crew Chief (50% more health, and less damage near him)
		local owner = convert_owner(self._unit)
		if owner then
			local t = 1 / C.chain_health
			if chain_near(self._unit:position(), owner) then t = t * (1 - B.sc(C.chain_resist, C.chain_resist_ds)) end
			m = m * t
			live("chain convert taken", "a Crew Chief's convert took x%.2f damage", t)
		end
		return m
	end

	local function cc_hit(self, attack_data, fn)
		if not (attack_data and type(attack_data.damage) == "number" and alive(self._unit)) then return end
		local m = 1
		if (fn == "damage_bullet" or fn == "damage_melee") and applies(self, attack_data.attacker_unit) then
			m = m * focus_mul()
			live("focus fire", "a marked enemy took x%.2f damage", m)
		end
		m = m * chain_mul(self, attack_data)
		if m ~= 1 then attack_data.damage = attack_data.damage * m end
	end
	for _, fn in ipairs({ "damage_bullet", "damage_melee", "damage_fire", "damage_explosion", "damage_dot" }) do
		if CopDamage[fn] then
			Hooks:PreHook(CopDamage, fn, "GilzaDSBuffs_cc_" .. fn, function(self, attack_data)
				cc_hit(self, attack_data, fn)
			end)
		end
	end

	-- a client's hits arrive on the host as a share of the enemy's health
	for _, fn in ipairs({ "sync_damage_bullet", "sync_damage_melee" }) do
		local orig = CopDamage[fn]
		if orig then
			CopDamage[fn] = function(self, attacker_unit, damage_percent, ...)
				if Network:is_server() and type(damage_percent) == "number" and applies(self, attacker_unit) then
					damage_percent = math.ceil(damage_percent * focus_mul())
				end
				return orig(self, attacker_unit, damage_percent, ...)
			end
		end
	end

	------------------------------------------------------------------ card 5 Confirmed: an enemy you marked dies marked
	Hooks:PreHook(CopDamage, "die", "GilzaDSBuffs_cc_confirmed", function(self)
		local u = self._unit
		local rec = alive(u) and B.cc_marks[u:key()]
		if not rec then return end
		B.cc_marks[u:key()] = nil
		local now = Application:time()
		if now - rec.t > C.mark_memory or not is_marked(u) or B.cc_tier() < 5 then return end
		local base = u:base()
		if base and CopDamage.is_civilian and CopDamage.is_civilian(base._tweak_table) then return end
		local player = managers.player and managers.player:player_unit()
		local dmg = alive(player) and player:character_damage()
		if not dmg or dmg._dead or (dmg.dead and dmg:dead()) then return end
		local share = B.sc(C.confirmed, C.confirmed_ds)
		dmg:restore_armor(dmg:_max_armor() * share)
		live("confirmed", "an enemy you marked died: %.1f%% armor back", share * 100)
	end)

elseif script == "lib/units/enemies/cop/copbrain" then
	-- (host) who converted this enemy: the teammate's unit, or you
	if CopBrain.convert_to_criminal then
		Hooks:PreHook(CopBrain, "convert_to_criminal", "GilzaDSBuffs_cc_convert", function(self, mastermind_criminal)
			local owner = alive(mastermind_criminal) and mastermind_criminal or (managers.player and managers.player:player_unit())
			if alive(self._unit) and alive(owner) then
				B.cc_converts[self._unit:key()] = owner
				if unit_cc_tier(owner) >= 9 then live("chain convert", "a Crew Chief converted an enemy") end
			end
		end)
	end

elseif script == "lib/units/beings/player/playerdamage" then
	-- card 7 Pinned Down: marked enemies hit you softer (melee goes through damage_bullet)
	for _, fn in ipairs({ "damage_bullet", "damage_explosion", "damage_fire" }) do
		if PlayerDamage[fn] then
			Hooks:PreHook(PlayerDamage, fn, "GilzaDSBuffs_cc_pinned_" .. fn, function(self, attack_data)
				if not (attack_data and type(attack_data.damage) == "number") then return end
				local u = attack_data.attacker_unit
				if not (alive(u) and B.cc_tier() >= 7 and is_marked(u)) then return end
				local less = B.sc(C.pinned, C.pinned_ds)
				attack_data.damage = attack_data.damage * (1 - less)
				live("pinned down", "%.1f%% less damage from a marked enemy (%s)", less * 100, fn)
			end)
		end
	end

elseif script == "lib/units/player_team/teamaidamage" then
	-- card 9 Chain of Command (host): bots near a Crew Chief take less damage
	if TeamAIDamage and TeamAIDamage._apply_damage then
		Hooks:PreHook(TeamAIDamage, "_apply_damage", "GilzaDSBuffs_cc_chain_bots", function(self, attack_data)
			if not (Network:is_server() and attack_data and type(attack_data.damage) == "number" and alive(self._unit)) then return end
			if not chain_near(self._unit:position()) then return end
			local less = B.sc(C.chain_resist, C.chain_resist_ds)
			attack_data.damage = attack_data.damage * (1 - less)
			live("chain bot taken", "a bot near a Crew Chief took %.1f%% less damage", less * 100)
		end)
	end

elseif script == "lib/units/interactions/interactionext" then
	-- card 5 Rally
	Hooks:PostHook(ReviveInteractionExt, "interact", "GilzaDSBuffs_cc_rally", function(self, reviving_unit)
		local player = managers.player and managers.player:player_unit()
		if not (alive(player) and reviving_unit == player and B.cc_tier() >= 5) then return end
		B.cc_rally_until = Application:time() + C.rally_time
	end)
end
