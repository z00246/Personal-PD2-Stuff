GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

-- difficulty scaling (shared with buffs.lua): t = 0 up to Overkill, 1/3 Mayhem, 2/3 Death Wish, 1 Death Sentence
if not B.diff_t then
	B.DIFF_T = { easy_wish = 1 / 3, overkill_290 = 2 / 3, sm_wish = 1 }
	function B.diff_t()
		local gs = Global and Global.game_settings
		return gs and B.DIFF_T[gs.difficulty] or 0
	end
	function B.sc(base, ds) return base + (ds - base) * B.diff_t() end
	function B.sci(base, ds) return math.floor(base + (ds - base) * B.diff_t() + 0.5) end
end

-- Infiltrator (7.00 rework, Geo 2026-10-24: close-quarters gunfighter, melee duelist toned down since Sociopath exists)
--  card 1 Point Blank: guns hit harder the closer the enemy (full within 4 m, nothing past 12 m)
--  card 3/5/7 Closing In: less damage the closer the nearest enemy; card 3 Quick Hands (shotgun/SMG reloads up close)
--  card 5 Opening: melee hits Expose the target and enemies around it; guns deal more damage to Exposed enemies
--  card 7 Melt Away: kills within 5 m (any weapon) -> speed and less damage for a moment
--  card 9 Bloodrush: kills within 8 m (any weapon) restore armor, melee kills more, once a second (7.16, Geo: "I still
--   feel like I can barely survive with infiltrator" - picked "close kills refill armor", counted as % of max armor);
--   Exposed kills restore health
-- *_ds values are the Death Sentence end of the difficulty scale (B.sc).
B.INFIL = {
	deck = 8,
	point_blank = 0.25, point_blank_ds = 0.30,
	pb_full = 400,             -- full Point Blank within 4 m
	pb_none = 1200,            -- none beyond 12 m
	close = { [3] = 0.12, [5] = 0.20, [7] = 0.28 },
	close_ds = { [3] = 0.15, [5] = 0.25, [7] = 0.35 },
	near = 500,
	far = 1800,
	far_ratio = 0.4,
	quick_range = 800,         -- card 3 Quick Hands
	quick = 1.15,
	expose_time = 7,           -- card 5 Opening
	expose_dmg = 0.3, expose_dmg_ds = 0.4,
	cleave_range = 300,
	melt_range = 500,          -- card 7 Melt Away
	melt_time = 3,
	melt_speed = 1.2,
	melt_dr = 0.25, melt_dr_ds = 0.35,
	blood_range = 800,         -- card 9 Bloodrush: kills this close refill armor (melee kills at any range)
	blood_gun = 0.10, blood_gun_ds = 0.15,       -- share of max armor, a gun (or any other) kill
	blood_melee = 0.15, blood_melee_ds = 0.20,   -- share of max armor, a melee kill
	blood_every = 1,           -- at most once a second
	exposed_heal = 0.05
}
B.NET_ID = B.NET_ID or "GilzaDSBuffs"
local C = B.INFIL

-- a line in the BLT log the first times a feature does something (buffs.lua)
local function live(key, ...) if B.live then B.live("infiltrator " .. key, ...) end end

function B.infil_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == C.deck) then
		return 0
	end
	return st:get_specialization_value(C.deck, "tiers", "current_tier") or 0
end

local function by_tier(tbl, tier)
	local best, v = 0, 0
	for card, val in pairs(tbl) do
		if tier >= card and card > best then best, v = card, val end
	end
	return v
end

-- the Closing In cap for this card and difficulty
function B.infil_close_max(tier)
	return B.sc(by_tier(C.close, tier), by_tier(C.close_ds, tier))
end

-- (the old card 7 "Infiltrate" made enemies lose track of you; that's Burglar's now)
function B.infil_hidden() return false end

function B.infil_close_dr()
	return B.infil_close or 0
end

function B.infil_melting()
	return Application:time() < (B.infil_melt_until or 0)
end

-- card 1 Point Blank bonus at this distance (cm)
function B.infil_point_blank(dis)
	if not dis or dis >= C.pb_none then return 0 end
	local full = B.sc(C.point_blank, C.point_blank_ds)
	if dis <= C.pb_full then return full end
	return full * (C.pb_none - dis) / (C.pb_none - C.pb_full)
end

if script == "lib/managers/playermanager" then
	local function nearest_enemy_dis(pos)
		local best
		local mask = managers.slot:get_mask("enemies")
		for _, u_data in pairs(managers.enemy:all_enemies() or {}) do
			local u = u_data.unit
			if alive(u) and u:in_slot(mask) then
				local dmg = u:character_damage()
				if not (dmg and dmg._dead) then
					local brain = u:brain()
					if not (brain and brain.is_hostage and brain:is_hostage()) then
						local d = mvector3.distance(pos, u:position())
						if not best or d < best then best = d end
					end
				end
			end
		end
		return best
	end

	local function update_close()
		local tier = B.infil_tier()
		local unit = managers.player:player_unit()
		if tier < 1 or not alive(unit) then
			B.infil_close, B.infil_near_dis = 0, nil
			return
		end
		local d = nearest_enemy_dis(unit:position())
		B.infil_near_dis = d
		if tier < 3 then
			B.infil_close = 0
			return
		end
		local max = B.infil_close_max(tier)
		if not d or d > C.far then
			B.infil_close = 0
		elseif d <= C.near then
			B.infil_close = max
		else
			local f = (d - C.near) / (C.far - C.near)
			B.infil_close = max * (1 - f * (1 - C.far_ratio))
		end
	end

	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_infil_update", function()
		local now = Application:time()
		if now < (B._infil_next or 0) then return end
		B._infil_next = now + 0.2
		local ok, err = pcall(update_close)
		if not ok and not B._infil_err then
			B._infil_err = true
			log("[Gilza DS Perk Buffs] Infiltrator update error: " .. tostring(err))
		end
	end)

	local orig_resist = PlayerManager.damage_reduction_skill_multiplier
	function PlayerManager:damage_reduction_skill_multiplier(...)
		local m = orig_resist(self, ...)
		if type(m) ~= "number" then return m end
		local close = B.infil_close or 0
		if close > 0 then
			m = m * (1 - close)
			live("closing in", "damage taken x%.2f, nearest enemy %.1f m", 1 - close, (B.infil_near_dis or 0) / 100)
		end
		if B.infil_melting() then
			m = m * (1 - B.sc(C.melt_dr, C.melt_dr_ds))
			live("melt away resist", "damage taken x%.2f during Melt Away", 1 - B.sc(C.melt_dr, C.melt_dr_ds))
		end
		return m
	end

	local orig_speed = PlayerManager.movement_speed_multiplier
	function PlayerManager:movement_speed_multiplier(...)
		local m = orig_speed(self, ...)
		if type(m) == "number" and B.infil_melting() then
			live("melt away speed", "moving x%.2f during Melt Away", C.melt_speed)
			return m * C.melt_speed
		end
		return m
	end

	Hooks:PostHook(PlayerManager, "on_killshot", "GilzaDSBuffs_infil_kill", function(self, killed_unit, variant)
		pcall(function()
			local tier = B.infil_tier()
			if tier < 7 then return end
			local unit = self:player_unit()
			if not (alive(unit) and alive(killed_unit)) then return end
			-- card 7 Melt Away: a kill within 5 m with any weapon
			local dis = mvector3.distance(unit:position(), killed_unit:position())
			if dis <= C.melt_range then
				B.infil_melt_until = Application:time() + C.melt_time
				live("melt away", "a %s kill at %.1f m started it", tostring(variant), dis / 100)
			end
			-- card 9 Bloodrush: kills within 8 m with any weapon restore armor, melee kills more, once a second
			local melee = variant == "melee"
			if tier >= 9 and (melee or dis <= C.blood_range) then
				local now = Application:time()
				local dmg = unit:character_damage()
				if now >= (B._infil_blood_next or 0) and dmg and not dmg:dead() and not dmg:need_revive() then
					local share = melee and B.sc(C.blood_melee, C.blood_melee_ds) or B.sc(C.blood_gun, C.blood_gun_ds)
					B._infil_blood_next = now + C.blood_every
					dmg:restore_armor(dmg:_max_armor() * share)
					live("bloodrush armor", "a %s kill at %.1f m gave back %.1f%% armor", tostring(variant), dis / 100, share * 100)
				end
			end
		end)
	end)

	function B.infil_on_exposed_kill()
		if B.infil_tier() < 9 then return end
		local unit = managers.player:player_unit()
		local dmg = alive(unit) and unit:character_damage()
		if dmg and not dmg:dead() and not dmg:need_revive() then
			dmg:restore_health(C.exposed_heal)
			live("bloodrush heal", "killing an Exposed enemy healed %d%%", C.exposed_heal * 100)
		end
	end

	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_infil_reset", function()
		local session = managers.network and managers.network:session()
		if B._infil_session ~= session then
			B._infil_session = session
			B.infil_exposed = {}
			B.infil_melt_until = nil
			B._infil_blood_next = nil
		end
	end)

elseif script == "lib/units/weapons/newraycastweaponbase" then
	-- card 3 Quick Hands: shotguns and SMGs reload faster with an enemy close by
	local orig_reload = NewRaycastWeaponBase.reload_speed_multiplier
	if orig_reload then
		function NewRaycastWeaponBase:reload_speed_multiplier(...)
			local m = orig_reload(self, ...)
			if self._current_reload_speed_multiplier or type(m) ~= "number" then return m end   -- cached: already counted
			local ok, quick = pcall(function()
				local user = self._setup and self._setup.user_unit
				if not (alive(user) and user == managers.player:player_unit()) then return false end
				if B.infil_tier() < 3 or not B.infil_near_dis or B.infil_near_dis > C.quick_range then return false end
				return self.is_category and self:is_category("shotgun", "smg") or false
			end)
			if ok and quick then
				m = m * C.quick
				live("quick hands", "reloading x%.2f with an enemy %.1f m away", C.quick, (B.infil_near_dis or 0) / 100)
			end
			return m
		end
	end

elseif script == "lib/units/enemies/cop/copdamage" then
	B.infil_exposed = B.infil_exposed or {}

	local function is_me(attack_data)
		local player = managers.player and managers.player:player_unit()
		return alive(player) and attack_data and attack_data.attacker_unit == player
	end

	local function exposed(self)
		local e = B.infil_exposed[self._unit:key()]
		return e and Application:time() < e
	end

	Hooks:PreHook(CopDamage, "damage_bullet", "GilzaDSBuffs_infil_bullet", function(self, attack_data)
		self._gdsb_infil_alive = not self._dead
		self._gdsb_infil_exposed = nil
		pcall(function()
			if not (is_me(attack_data) and type(attack_data.damage) == "number") then return end
			local tier = B.infil_tier()
			if tier < 1 then return end
			-- card 1 Point Blank: the closer, the harder
			local dis = mvector3.distance(attack_data.attacker_unit:position(), self._unit:position())
			local pb = B.infil_point_blank(dis)
			if pb > 0 then
				attack_data.damage = attack_data.damage * (1 + pb)
				live("point blank", "gun damage x%.2f at %.1f m", 1 + pb, dis / 100)
			end
			if tier < 5 or not exposed(self) then return end
			self._gdsb_infil_exposed = true
			attack_data.damage = attack_data.damage * (1 + B.sc(C.expose_dmg, C.expose_dmg_ds))
			live("exposed hit", "gun damage x%.2f on an Exposed enemy", 1 + B.sc(C.expose_dmg, C.expose_dmg_ds))
		end)
	end)
	Hooks:PostHook(CopDamage, "damage_bullet", "GilzaDSBuffs_infil_bullet_post", function(self, attack_data)
		local was_alive, was_exposed = self._gdsb_infil_alive, self._gdsb_infil_exposed
		self._gdsb_infil_alive, self._gdsb_infil_exposed = nil, nil
		if was_alive and was_exposed and self._dead and B.infil_on_exposed_kill then
			pcall(B.infil_on_exposed_kill)
		end
	end)

	Hooks:PreHook(CopDamage, "damage_melee", "GilzaDSBuffs_infil_melee", function(self, attack_data)
		self._gdsb_infil_melee_alive = not self._dead
		self._gdsb_infil_melee_exposed = exposed(self)
	end)
	Hooks:PostHook(CopDamage, "damage_melee", "GilzaDSBuffs_infil_melee_post", function(self, attack_data)
		local was_alive, was_exposed = self._gdsb_infil_melee_alive, self._gdsb_infil_melee_exposed
		self._gdsb_infil_melee_alive, self._gdsb_infil_melee_exposed = nil, nil
		if not (was_alive and is_me(attack_data)) then return end
		pcall(function()
			local tier = B.infil_tier()
			if tier < 5 then return end
			if self._dead then
				if was_exposed and B.infil_on_exposed_kill then B.infil_on_exposed_kill() end
				return
			end
			-- card 5 Opening: the target and everyone close to it are Exposed
			local until_t = Application:time() + C.expose_time
			B.infil_exposed[self._unit:key()] = until_t
			B.infil_last_exposed = self._unit
			local mask = managers.slot:get_mask("enemies")
			local n = 1
			for _, u in ipairs(World:find_units_quick("sphere", self._unit:position(), C.cleave_range, mask) or {}) do
				local d = u ~= self._unit and alive(u) and u:character_damage()
				if d and not d._dead then
					B.infil_exposed[u:key()] = until_t
					n = n + 1
				end
			end
			live("opening", "a melee hit Exposed %d enemies for %ds", n, C.expose_time)
		end)
	end)

elseif script == "lib/tweak_data/skilltreetweakdata" then
	-- Closing In and Bloodrush replace Gilza's close contact damage reduction and melee life leech
	local REMOVE = {
		[3] = { player_damage_dampener_close_contact_1 = true },
		[5] = { player_damage_dampener_close_contact_2 = true },
		[7] = { player_damage_dampener_close_contact_3 = true },
		[9] = { player_melee_life_leech = true }
	}
	Hooks:PostHook(SkillTreeTweakData, "init", "GilzaDSBuffs_infil_cards", function(self)
		local deck = self.specializations and self.specializations[C.deck]
		for card, names in pairs(REMOVE) do
			local ups = deck and deck[card] and deck[card].upgrades
			if ups then
				for i = #ups, 1, -1 do
					if names[ups[i]] then table.remove(ups, i) end
				end
			end
		end
	end)
end
