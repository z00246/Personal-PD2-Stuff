GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs

B.SOCIO = {
	deck = 9,
	passive = { [3] = 0.15, [5] = 0.25, [9] = 0.35 },
	hold_tier = 3,
	hold_gain = 0.1,
	hold_max = 0.3,
	hold_linger = 2,
	hold_decay = 0.15,
	panic_range = 2500
}
B.socio_hold = 0
B.socio_release_t = 0

function B.socio_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == B.SOCIO.deck) then
		return 0
	end
	return st:get_specialization_value(B.SOCIO.deck, "tiers", "current_tier") or 0
end

function B.socio_passive(tier)
	local best = 0
	for card, value in pairs(B.SOCIO.passive) do
		if tier >= card and value > best then best = value end
	end
	return best
end

local function holding_melee()
	local state = managers.player and managers.player:get_current_state()
	return state and state.in_melee and state:in_melee() or false
end

function B.socio_update(t, dt)
	if tweak_data and tweak_data.upgrades and tweak_data.upgrades.killshot_close_panic_range ~= B.SOCIO.panic_range then
		tweak_data.upgrades.killshot_close_panic_range = B.SOCIO.panic_range
	end
	if B.socio_tier() < B.SOCIO.hold_tier then
		B.socio_hold = 0
		return
	end
	local now = Application:time()
	if holding_melee() then
		B.socio_hold = math.min(B.socio_hold + B.SOCIO.hold_gain * dt, B.SOCIO.hold_max)
		B.socio_release_t = now
	elseif B.socio_hold > 0 and now - B.socio_release_t > B.SOCIO.hold_linger then
		B.socio_hold = math.max(B.socio_hold - B.SOCIO.hold_decay * dt, 0)
	end
end

Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_sociopath", function(t, dt)
	pcall(B.socio_update, t, dt or 0)
end)

local orig_resist = PlayerManager.damage_reduction_skill_multiplier
function PlayerManager:damage_reduction_skill_multiplier(...)
	local m = orig_resist(self, ...)
	if type(m) ~= "number" then return m end
	local ok, tier = pcall(B.socio_tier)
	if ok and tier > 0 then
		m = m * (1 - B.socio_passive(tier)) * (1 - (B.socio_hold or 0))
	end
	return m
end
