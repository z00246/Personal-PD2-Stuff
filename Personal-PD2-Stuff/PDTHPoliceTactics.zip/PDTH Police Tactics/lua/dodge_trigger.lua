if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics
local script = RequiredScript and RequiredScript:lower() or ""

T.DODGE_RANGE = 2500
T.DODGE_RECHECK = 0.4
T.DODGE_RANGE_DS = 3500
T.DODGE_RECHECK_DS = 0.25

local function attack_data_of(unit)
	local brain = alive(unit) and unit:brain()
	local data = brain and brain._logic_data
	if data and data.name == "attack" and data.internal_data and not data.is_converted and not unit:in_slot(16) then
		return data
	end
end

function T.try_dodge(data, reason)
	if not (data.char_tweak and data.char_tweak.dodge and data.char_tweak.dodge.occasions[reason]) then return end
	local fe = data.attention_obj
	if not (fe and fe.reaction and fe.reaction >= AIAttentionObject.REACT_COMBAT) then return end
	return CopLogicBase.chk_start_action_dodge(data, reason)
end

if script == "lib/units/enemies/cop/logics/coplogicattack" then
	-- is any heister (not just the one this cop is fighting) aiming at this cop?
	local function aimed_at_by_anyone(data, range)
		local fe = data.attention_obj
		if fe and fe.aimed_at and fe.verified and fe.is_person and fe.dis and fe.dis < range then return true end
		for _, att in pairs(data.detected_attention_objects or {}) do
			if att.aimed_at and att.verified and att.is_person and att.dis and att.dis < range then return true end
		end
		return false
	end

	local function after_aim(data, my_data)
		if my_data ~= data.internal_data then return end
		if data.is_converted or data.unit:in_slot(16) then return end
		local fe = data.attention_obj
		if not (fe and fe.is_person) then return end
		local range = T.is_ds() and T.DODGE_RANGE_DS or T.DODGE_RANGE
		if my_data.pdth_dodge_t and data.t < my_data.pdth_dodge_t then return end
		my_data.pdth_dodge_t = data.t + (T.is_ds() and T.DODGE_RECHECK_DS or T.DODGE_RECHECK)

		local last_sup = data.unit:character_damage():last_suppression_t()
		if data.is_suppressed and last_sup and data.t - last_sup < 0.7 and fe.verified and fe.dis and fe.dis < range then
			T.try_dodge(data, "scared")
		elseif aimed_at_by_anyone(data, range) then
			T.try_dodge(data, "preemptive")
		end
	end

	local orig = CopLogicAttack._upd_aim
	CopLogicAttack._upd_aim = function(data, my_data, ...)
		local r = orig(data, my_data, ...)
		if T.active() and my_data then
			pcall(after_aim, data, my_data)
		end
		return r
	end

elseif script == "lib/units/enemies/cop/copdamage" then
	Hooks:PostHook(CopDamage, "damage_bullet", "PDTHTactics_dodge_on_hit", function(self, attack_data)
		if not T.active() or self._dead then return end
		local attacker = attack_data and attack_data.attacker_unit
		local state = managers.groupai and managers.groupai:state()
		if not (alive(attacker) and state and state:all_criminals()[attacker:key()]) then return end
		local data = attack_data_of(self._unit)
		if data and not data.important then
			pcall(T.try_dodge, data, "hit")
		end
	end)
end
