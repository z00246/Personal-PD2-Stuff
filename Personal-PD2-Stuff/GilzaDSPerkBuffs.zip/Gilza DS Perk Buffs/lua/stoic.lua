GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

B.STOIC = {
	deck = 19,
	grit = 0.20,
	grit_ds = 0.30,
	grit_full = 0.5,
	composure = 0.40,
	composure_time = 2,
	upper_lip = 0.02
}
local C = B.STOIC

function B.stoic_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == C.deck) then
		return 0
	end
	return st:get_specialization_value(C.deck, "tiers", "current_tier") or 0
end

-- pending damage-over-time, tracked from delay_damage calls
B.stoic_chunks = B.stoic_chunks or {}
function B.stoic_pending()
	local now, total = Application:time(), 0
	for i = #B.stoic_chunks, 1, -1 do
		local c = B.stoic_chunks[i]
		local left = 1 - (now - c.t) / c.d
		if left <= 0 then
			table.remove(B.stoic_chunks, i)
		else
			total = total + c.amount * left
		end
	end
	return total
end

function B.stoic_grit()
	if B.stoic_tier() < 3 then return 0 end
	local unit = managers.player and managers.player:player_unit()
	local dmg = alive(unit) and unit:character_damage()
	if not dmg then return 0 end
	local full = dmg:_max_health() * C.grit_full
	if full <= 0 then return 0 end
	return math.clamp(B.stoic_pending() / full, 0, 1) * (B.on and C.grit_ds or C.grit)
end

function B.stoic_composure()
	return Application:time() < (B.stoic_composure_until or 0)
end

if script == "lib/units/beings/player/playerdamage" then
	local orig_delay = PlayerDamage.delay_damage
	if orig_delay then
		function PlayerDamage:delay_damage(damage, seconds, ...)
			if type(damage) == "number" and damage > 0 and type(seconds) == "number" and seconds > 0 then
				table.insert(B.stoic_chunks, { amount = damage, t = Application:time(), d = seconds })
			end
			return orig_delay(self, damage, seconds, ...)
		end
	end
	local orig_clear = PlayerDamage.clear_delayed_damage
	if orig_clear then
		function PlayerDamage:clear_delayed_damage(...)
			B.stoic_chunks = {}
			return orig_clear(self, ...)
		end
	end

elseif script == "lib/managers/playermanager" then
	-- Composure: damage reduction right after drinking the flask
	Hooks:PostHook(PlayerManager, "init", "GilzaDSBuffs_stoic_init", function(self)
		self:register_message("ability_activated", "GilzaDSBuffs_stoic_flask", function(ability)
			if ability == "damage_control" and B.stoic_tier() >= 5 then
				B.stoic_composure_until = Application:time() + C.composure_time
			end
		end)
	end)

	local orig_resist = PlayerManager.damage_reduction_skill_multiplier
	function PlayerManager:damage_reduction_skill_multiplier(...)
		local m = orig_resist(self, ...)
		if type(m) == "number" and B.stoic_composure() then
			m = m * (1 - C.composure)
		end
		return m
	end

	-- Stiff Upper Lip: kills while you have pending damage heal you
	Hooks:PostHook(PlayerManager, "on_killshot", "GilzaDSBuffs_stoic_lip", function(self)
		if B.stoic_tier() < 7 or B.stoic_pending() <= 0 then return end
		local unit = self:player_unit()
		local dmg = alive(unit) and unit:character_damage()
		if dmg and not dmg:dead() and not dmg:need_revive() then
			dmg:restore_health(C.upper_lip)
		end
	end)

elseif script == "lib/units/enemies/cop/copdamage" then
	-- Grit: the more damage you are holding back, the harder you hit
	local function grit(self, attack_data)
		if not attack_data or type(attack_data.damage) ~= "number" then return end
		local player = managers.player and managers.player:player_unit()
		if not (alive(player) and attack_data.attacker_unit == player) then return end
		local g = B.stoic_grit()
		if g > 0 then attack_data.damage = attack_data.damage * (1 + g) end
	end
	for _, fn in ipairs({ "damage_bullet", "damage_melee" }) do
		Hooks:PreHook(CopDamage, fn, "GilzaDSBuffs_stoic_" .. fn, function(self, attack_data)
			grit(self, attack_data)
		end)
	end
end
