GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs

B.DODGE_CAP = { normal = 0.7, ds = 0.8 }

local orig_dodge = PlayerManager.skill_dodge_chance
function PlayerManager:skill_dodge_chance(running, crouching, on_zipline, override_armor, ...)
	local chance = orig_dodge(self, running, crouching, on_zipline, override_armor, ...)
	if type(chance) ~= "number" then return chance end
	-- (7.25: checked instead of pcall) the armor's own dodge: an unknown armor id has no entry, nothing to cap then
	local dmg_t = tweak_data and tweak_data.player and tweak_data.player.damage
	local armors = tweak_data and tweak_data.blackmarket and tweak_data.blackmarket.armors
	if not (dmg_t and self.body_armor_value) or (override_armor and not (armors and armors[override_armor])) then return chance end
	local armor_dodge = self:body_armor_value("dodge", override_armor)
	if type(armor_dodge) ~= "number" then return chance end
	local base = (dmg_t.DODGE_INIT or 0) + armor_dodge
	local cap = B.on and B.DODGE_CAP.ds or B.DODGE_CAP.normal
	return math.min(chance, cap - base)
end
