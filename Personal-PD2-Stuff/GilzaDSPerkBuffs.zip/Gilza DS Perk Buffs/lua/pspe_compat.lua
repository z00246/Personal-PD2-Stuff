-- Gilza + Player Stats Panel Enhancements compat (was the separate "Gilza PSPE Compat" mod): only with PSPE installed
do
	local mods = BLT and BLT.Mods
	local pspe = mods and mods.GetModByName and mods:GetModByName("Player Stats Panel Enhancements")
	if not (pspe and (not pspe.IsEnabled or pspe:IsEnabled())) then return end
end

if not PlayerManager then
	return
end

local function has_real_player(pm)
	local ok, unit = pcall(PlayerManager.player_unit, pm)
	return ok and unit and alive(unit)
end

local mock_damage = {
	health_ratio = function() return 1 end,
	get_real_armor = function() return 1 end,
	get_real_health = function() return 1 end,
	_max_health = function() return 1 end
}
local mock_movement = { _current_state = nil, current_state = function() return nil end }
local mock_unit = {
	character_damage = function() return mock_damage end,
	movement = function() return mock_movement end,
	position = function() return Vector3() end,
	alive = function() return true end,
	is_mock = function() return true end
}
local mock_peer_unit = { movement = function() return { _current_state = { _moving = true } } end }
local mock_peer = { unit = function() return mock_peer_unit end }
local mock_session = { local_peer = function() return mock_peer end }

local function menu_safe(pm, damage_type)
	local net = managers.network
	local saved = {
		player_unit = rawget(pm, "player_unit"),
		get_current_state = rawget(pm, "get_current_state"),
		current_state = rawget(pm, "current_state"),
		Gilza_is_close_to_sentry_gun = rawget(pm, "Gilza_is_close_to_sentry_gun")
	}
	local saved_session = net and rawget(net, "session")

	pm.player_unit = function() return mock_unit end
	pm.get_current_state = function() return nil end
	pm.current_state = function() return "standard" end
	pm.Gilza_is_close_to_sentry_gun = function() return false end
	if net then
		net.session = function() return mock_session end
	end

	local ok, value = pcall(PlayerManager.damage_reduction_skill_multiplier, pm, damage_type)

	for _, v in ipairs({ "player_unit", "get_current_state", "current_state", "Gilza_is_close_to_sentry_gun" }) do
		rawset(pm, v, saved[v])
	end
	if net then
		rawset(net, "session", saved_session)
	end

	if ok and type(value) == "number" then
		return value
	end
	return 1
end

function PlayerManager:damage_reduction_skill_multiplier_hehe(damage_type)
	if has_real_player(self) then
		local ok, value = pcall(self.damage_reduction_skill_multiplier, self, damage_type)
		return ok and type(value) == "number" and value or 1
	end
	return menu_safe(self, damage_type)
end

if RequiredScript == "lib/managers/menu/playerinventorygui" and PlayerInventoryGui and not PlayerInventoryGui._pspe_label_fix then
	PlayerInventoryGui._pspe_label_fix = true

	local NAME_W = 185

	local function fit(text)
		if not alive(text) then
			return
		end
		text:set_text(utf8.to_upper(text:text()))
		local holder = text:parent()
		if alive(holder) and holder:w() < NAME_W then
			holder:set_w(NAME_W)
		end
		text:set_w(holder:w())
		local size = text:font_size()
		local _, _, w = text:text_rect()
		while w > holder:w() - 2 and size > 12 do
			size = size - 1
			text:set_font_size(size)
			_, _, w = text:text_rect()
		end
	end

	local function fit_rows(rows)
		for _, row in pairs(rows or {}) do
			pcall(fit, row.name)
		end
	end

	if PlayerInventoryGui.setup_add_player_stats then
		Hooks:PostHook(PlayerInventoryGui, "setup_add_player_stats", "GilzaPSPE_fit_dmg_labels", function(self)
			fit_rows(self._player_stats_texts_add)
		end)
	end
	if PlayerInventoryGui.player_health_regen_stats then
		Hooks:PostHook(PlayerInventoryGui, "player_health_regen_stats", "GilzaPSPE_fit_hp_labels", function(self)
			fit_rows(self._player_stats_texts_add_hp)
		end)
	end
end

-- Death Sentence column: Gilza and Gilza DS Perk Buffs change your stats on Death Sentence (perk deck
-- buffs, a higher damage resistance cap). The normal columns now always show the regular values and an
-- extra "DS" column shows the same stats as they'll be on Death Sentence.
if RequiredScript == "lib/managers/menu/playerinventorygui" and PlayerInventoryGui and not PlayerInventoryGui._gilza_ds_column then
	PlayerInventoryGui._gilza_ds_column = true

	local DS_COLOR = Color(1, 1, 0.35, 0.3)
	local DS_W = 60

	-- run fn with the game set to (or away from) Death Sentence, then put everything back
	local function with_difficulty(ds, fn)
		local gs = Global.game_settings
		local B = rawget(_G, "GilzaDSBuffs")
		local old_diff = gs and gs.difficulty
		local old_on = B and B.on
		if gs then gs.difficulty = ds and "sm_wish" or (old_diff ~= "sm_wish" and old_diff or "overkill_290") end
		if B and B.apply and (B.on or false) ~= ds then pcall(B.apply, ds) end
		local ok, a, b, c = pcall(fn)
		if gs then gs.difficulty = old_diff end
		if B and B.apply and (B.on or false) ~= (old_on or false) then pcall(B.apply, old_on or false) end
		if not ok then error(a, 0) end
		return a, b, c
	end

	local function add_column(rows, stats, title_parent, title_x)
		local texts = {}
		for _, stat in ipairs(stats or {}) do
			local row = rows[stat.name]
			local any = row and (row.total or row.reduction_highest or row.name)
			local holder = any and alive(any) and any:parent()
			local line = holder and alive(holder) and holder:parent()
			if alive(line) then
				local right = 0
				for _, child in ipairs(line:children()) do right = math.max(right, child:right()) end
				local w = math.min(DS_W, line:w() - right - 8)
				if w >= 30 then
					local p = line:panel({ layer = 0, x = right + 8, w = w, h = line:h() })
					texts[stat.name] = p:text({
						text = "", layer = 4, align = "right", color = DS_COLOR,
						font_size = tweak_data.menu.pd2_small_font_size, font = tweak_data.menu.pd2_medium_font
					})
				end
			end
		end
		return texts
	end

	local function title(panel, x)
		if not alive(panel) then return end
		local t = panel:text({
			x = x, layer = 2, text = "DS", color = DS_COLOR,
			font_size = tweak_data.menu.pd2_small_font_size, font = tweak_data.menu.pd2_medium_font
		})
		return t
	end

	Hooks:PostHook(PlayerInventoryGui, "setup_player_stats", "GilzaPSPE_ds_column", function(self)
		pcall(function()
			self._gilza_ds_texts = add_column(self._player_stats_texts, self._player_stats_shown)
			local any = next(self._gilza_ds_texts) and self._gilza_ds_texts[next(self._gilza_ds_texts)]
			if any then
				local sp = self._player_stats_titles and self._player_stats_titles.skill
				local parent = sp and alive(sp) and sp:parent()
				local holder = any:parent()
				local x = holder:world_x() - (parent and parent:world_x() or 0) + holder:w() - 22
				self._gilza_ds_title = title(parent, x)
			end
		end)
	end)


	local orig_update = PlayerInventoryGui._update_player_stats
	function PlayerInventoryGui:_update_player_stats(...)
		-- the normal columns: regular (non-DS) values
		local args = { ... }
		local res = { with_difficulty(false, function() return orig_update(self, unpack(args)) end) }
		pcall(function()
			with_difficulty(true, function()
				local texts = self._gilza_ds_texts or {}
				if next(texts) then
					local equipped = managers.blackmarket:equipped_item("armors")
					local temp = self._stats_shown
					self._stats_shown = self._player_stats_shown
					local base, mods, skill = self:_get_armor_stats(equipped)
					self._stats_shown = temp
					for _, stat in ipairs(self._player_stats_shown or {}) do
						local t = texts[stat.name]
						if t and alive(t) and base[stat.name] then
							local v = math.max(base[stat.name].value + mods[stat.name].value + skill[stat.name].value, 0)
							-- one decimal at most, like the other columns
							local s = string.format("%.1f", v)
							s = string.gsub(s, "%.0$", "")
							if stat.procent and (stat.name == "dodge" or stat.name == "crit") then s = s .. "%" end
							t:set_text(s)
						end
					end
				end
				-- damage reduction: the empty middle row becomes "DS REDUCTION", and the 225-damage example
				-- (a Death Sentence hit) is worked out with the Death Sentence values
				local rows = self._player_stats_texts_add or {}
				local pm = managers.player
				local dr = pm:damage_reduction_skill_multiplier_hehe()
				local cond = pm.cal_conditional_damage_reduction and pm:cal_conditional_damage_reduction() or 1
				local function pct(m) local v = math.abs(m * 100 - 100); return (string.gsub(string.format("%.1f", v), "%.0$", "")) .. "%" end
				local arrow = rows.arrow
				if arrow and alive(arrow.name) then
					arrow.name:set_text("DS REDUCTION")
					arrow.name:set_color(DS_COLOR)
					if alive(arrow.reduction_basic) then arrow.reduction_basic:set_text(pct(dr)) arrow.reduction_basic:set_color(DS_COLOR) end
					if alive(arrow.reduction_highest) then arrow.reduction_highest:set_text(pct(dr * cond)) arrow.reduction_highest:set_color(DS_COLOR) end
				end
				local ex = rows.dmg_red_ds_example
				if ex then
					local function num(v) return (string.gsub(string.format("%.1f", v), "%.0$", "")) end
					if alive(ex.reduction_basic) then ex.reduction_basic:set_text(num(225 * dr)) end
					if alive(ex.reduction_highest) then ex.reduction_highest:set_text(num(225 * dr * cond)) end
				end
			end)
		end)
		return unpack(res)
	end
end
