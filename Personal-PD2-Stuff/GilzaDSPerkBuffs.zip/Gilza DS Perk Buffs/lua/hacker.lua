GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

B.HACKER = {
	deck = 21,
	mark_every = 3,
	mark_type = "mark_enemy_damage_bonus",
	duration_ds = 12,
	drain_ds = 6,
	feedback_dr_ds = 0.15,    -- DS: less damage taken while your feedback runs
	overclock_dmg_ds = 0.15,  -- DS: crew deals extra damage to Overclock-marked enemies (on top of the mark bonus)
	-- (7.24) Joy's signature (card 9, only as Joy): Uplink - while your feedback is active you see specials within 20 m
	-- outlined through walls (on your screen), and each kill takes 1 extra second off the Pocket ECM cooldown
	uplink_range = 2000, uplink_cd = 1, uplink_scan = 0.25
}
B._overclocked = B._overclocked or {}

-- enemies currently marked by any Hacker's Overclock (by network id), shared over the mod network
function B.is_overclocked(unit)
	if not alive(unit) then return false end
	local t = B._overclocked[unit:id()]
	return t and Application:time() < t or false
end
local C = B.HACKER

function B.hacker_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == C.deck) then
		return 0
	end
	return st:get_specialization_value(C.deck, "tiers", "current_tier") or 0
end

local function unit_tier(unit)
	local me = managers.player and managers.player:player_unit()
	if unit == me then return B.hacker_tier() end
	local session = managers.network and managers.network:session()
	local peer = session and session:peer_by_unit(unit)
	local skills = peer and peer.unpacked_skills and peer:unpacked_skills()
	local spec = skills and skills.specializations
	if spec and tonumber(spec[1]) == C.deck then
		return tonumber(spec[2]) or 0
	end
	return 0
end

function B.hacker_feedback_active()
	local unit = managers.player and managers.player:player_unit()
	local inv = alive(unit) and unit.inventory and unit:inventory()
	local data = inv and inv._jammer_data
	return data and data.effect == "feedback" or false
end

if script == "lib/managers/playermanager" then
	-- Overclock: enemies inside your feedback get marked for the whole crew
	B._hacker_marked = B._hacker_marked or {}
	local function overclock()
		if B.hacker_tier() < 5 or not B.hacker_feedback_active() then return end
		if not (managers.enemy and managers.slot) then return end
		local unit = managers.player:player_unit()
		local inv = alive(unit) and unit.inventory and unit:inventory()
		if not (inv and inv.get_feedback_values) then return end
		local _, range = inv:get_feedback_values()
		if not range or range <= 0 then return end
		local pos = unit:position()
		local now = Application:time()
		local ids = {}
		for key, u_data in pairs(managers.enemy:all_enemies() or {}) do
			local enemy = u_data.unit
			if alive(enemy) and enemy:in_slot(managers.slot:get_mask("enemies")) and now >= (B._hacker_marked[key] or 0) then
				local dmg = enemy:character_damage()
				if dmg and not dmg._dead and mvector3.distance(enemy:position(), pos) <= range then
					local contour = enemy.contour and enemy:contour()
					if contour and contour.add then
						contour:add(C.mark_type, true, 1)
						B._hacker_marked[key] = now + C.mark_every
						if enemy:id() ~= -1 then
							B._overclocked[enemy:id()] = now + C.mark_every + 1
							table.insert(ids, tostring(enemy:id()))
						end
					end
				end
			end
		end
		if #ids > 0 and LuaNetworking and LuaNetworking.SendToPeers then
			LuaNetworking:SendToPeers(B.NET_ID or "GilzaDSBuffs", "overclock:" .. table.concat(ids, ","))
		end
	end

	-- DS uptime: loud feedback lasts longer and kills shave more off the cooldown
	local function jammer_base()
		local values = tweak_data and tweak_data.upgrades and tweak_data.upgrades.values
		local v = values and values.player and values.player.pocket_ecm_jammer_base
		return v and v[1]
	end

	local function apply_uptime()
		local base = jammer_base()
		if not base then return end
		if C.drain_orig == nil then C.drain_orig = base.cooldown_drain or 4 end
		base.cooldown_drain = B.on and C.drain_ds or C.drain_orig
	end

	local orig_resist = PlayerManager.damage_reduction_skill_multiplier
	function PlayerManager:damage_reduction_skill_multiplier(...)
		local m = orig_resist(self, ...)
		if type(m) == "number" and B.on and B.hacker_tier() >= 1 and B.hacker_feedback_active() then
			m = m * (1 - C.feedback_dr_ds)
		end
		return m
	end

	Hooks:PreHook(PlayerManager, "_attempt_pocket_ecm_jammer", "GilzaDSBuffs_hacker_uptime", function(self)
		apply_uptime()
		local base = jammer_base()
		local state = managers.groupai and managers.groupai:state()
		if B.on and base and state and not state:whisper_mode() then
			base.duration = C.duration_ds
		end
	end)

	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_hacker_update", function()
		local now = Application:time()
		if now < (B._hacker_next or 0) then return end
		B._hacker_next = now + 0.5
		apply_uptime()
		if managers.player then overclock() end
	end)

	-- (7.24) Joy's Uplink: specials within 20 m outlined while the feedback runs (checked 4 times a second)
	B.hacker_uplinked = B.hacker_uplinked or {}
	local function is_special(u)
		local base = u:base()
		local name = base and base._tweak_table
		local td = name and tweak_data.character and tweak_data.character[name]
		for _, tag in ipairs(td and td.tags or {}) do
			if tag == "special" then return true end
		end
		return false
	end
	local function uplink_clear()
		for key, u in pairs(B.hacker_uplinked) do
			if alive(u) and B.sig_outline then B.sig_outline(u, "gdsb_uplink", false) end
			B.hacker_uplinked[key] = nil
		end
	end
	local function uplink()
		if not (B.hacker_feedback_active() and B.sig_active and B.sig_active(C.deck)) then
			if next(B.hacker_uplinked) then uplink_clear() end
			return
		end
		local unit = managers.player and managers.player:player_unit()
		if not (alive(unit) and managers.slot and managers.enemy) then return end
		local pos = unit:position()
		local mask = managers.slot:get_mask("enemies")
		local seen = {}
		for _, u_data in pairs(managers.enemy:all_enemies() or {}) do
			local u = u_data.unit
			if alive(u) and u:in_slot(mask) then
				local dmg = u:character_damage()
				if dmg and not dmg._dead and mvector3.distance(u:position(), pos) <= C.uplink_range and is_special(u) then
					seen[u:key()] = u
				end
			end
		end
		for key, u in pairs(seen) do
			if not B.hacker_uplinked[key] then
				B.hacker_uplinked[key] = u
				if B.sig_outline then B.sig_outline(u, "gdsb_uplink", true) end
				B.sig_live("uplink mark", "a special within %d m is outlined (feedback)", C.uplink_range / 100)
			end
		end
		for key, u in pairs(B.hacker_uplinked) do
			if not seen[key] then
				if alive(u) and B.sig_outline then B.sig_outline(u, "gdsb_uplink", false) end
				B.hacker_uplinked[key] = nil
			end
		end
	end
	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_hacker_uplink", function()
		local now = Application:time()
		if now < (B._uplink_next or 0) then return end
		B._uplink_next = now + C.uplink_scan
		local session = managers.network and managers.network:session()
		if B._uplink_session ~= session then
			B._uplink_session = session
			B.hacker_uplinked = {}
		end
		uplink()
	end)

	-- (7.24) Joy's Uplink: kills while the feedback runs take an extra second off the Pocket ECM cooldown
	Hooks:PostHook(PlayerManager, "on_killshot", "GilzaDSBuffs_hacker_uplink_kill", function(self)
		if not (B.hacker_feedback_active() and B.sig_active and B.sig_active(C.deck)) then return end
		if not self.speed_up_grenade_cooldown then return end
		self:speed_up_grenade_cooldown(C.uplink_cd)
		B.sig_live("uplink kill", "a kill during feedback: %d s more off the Pocket ECM cooldown", C.uplink_cd)
	end)

elseif script == "lib/units/beings/player/playerinventory" then
	-- Firewall (host): while a Hacker with card 7 has feedback running, Tazers and Cloakers in range
	-- can't tase or charge/kick (an attempt in progress gets cancelled). They can still shoot.
	local function block(enemy, until_t)
		local brain = enemy.brain and enemy:brain()
		local data = brain and brain._logic_data
		if not data then return end
		local my_data = data.internal_data
		local base = enemy:base()
		local tweak = base and base._tweak_table or ""
		if string.find(tweak, "spooc", 1, true) then
			data.spooc_attack_timeout_t = math.max(data.spooc_attack_timeout_t or 0, until_t)
			if my_data and my_data.spooc_attack and SpoocLogicAttack and SpoocLogicAttack._cancel_spooc_attempt then
				SpoocLogicAttack._cancel_spooc_attempt(data, my_data)
			end
		elseif string.find(tweak, "taser", 1, true) then
			data.tase_delay_t = math.max(data.tase_delay_t or -1, until_t)
			if my_data and my_data.tasing and TaserLogicAttack and TaserLogicAttack._cancel_tase_attempt then
				TaserLogicAttack._cancel_tase_attempt(data, my_data)
			end
		end
	end

	local function is_special(enemy)
		local base = enemy:base()
		local tweak = base and base._tweak_table
		if type(tweak) ~= "string" then return false end
		return string.find(tweak, "taser", 1, true) or string.find(tweak, "spooc", 1, true)
	end

	-- Firewall also keeps Tazers out of the feedback stun: they keep shooting, they just can't tase.
	-- (A stunned Tazer couldn't tase anyway, so without this the card did nothing to them.)
	local function taser_tweaks()
		local list = {}
		for name, ct in pairs(tweak_data.character or {}) do
			if type(ct) == "table" and name ~= "presets" and type(ct.tags) == "table" then
				for _, tag in ipairs(ct.tags) do
					if tag == "taser" then table.insert(list, ct) break end
				end
			end
		end
		return list
	end

	local orig_feedback = PlayerInventory._do_feedback
	function PlayerInventory:_do_feedback(...)
		local shielded
		if Network:is_server() and alive(self._unit) and unit_tier(self._unit) >= 7 then
			shielded = {}
			for _, ct in ipairs(taser_tweaks()) do
				shielded[ct] = ct.ecm_vulnerability
				ct.ecm_vulnerability = 0
			end
		end
		local a, b = orig_feedback(self, ...)
		for ct, v in pairs(shielded or {}) do ct.ecm_vulnerability = v end
		return a, b
	end

	Hooks:PreHook(PlayerInventory, "_do_feedback", "GilzaDSBuffs_hacker_firewall", function(self)
		if not Network:is_server() or not alive(self._unit) then return end
		local data = self._jammer_data
		if not (data and data.range) then return end
		if unit_tier(self._unit) < 7 then return end
		if not (self._get_feedback_pos and managers.enemy and managers.slot) then return end
		local pos = self:_get_feedback_pos()
		if not pos then return end
		local until_t = TimerManager:game():time() + (data.interval or 1.5) + 1
		local mask = managers.slot:get_mask("enemies")
		for _, u_data in pairs(managers.enemy:all_enemies() or {}) do
			local enemy = u_data.unit
			local dmg = alive(enemy) and enemy:character_damage()
			local mov = dmg and enemy:movement()
			if mov and mov.m_head_pos and not dmg._dead and enemy:in_slot(mask) and is_special(enemy)
				and mvector3.distance(mov:m_head_pos(), pos) <= data.range then
				block(enemy, until_t)
			end
		end
	end)

elseif script == "lib/units/enemies/cop/copdamage" then
	-- DS: everyone with this mod hits Overclock-marked enemies harder
	local function bonus(self, attack_data)
		if not (B.on and attack_data and type(attack_data.damage) == "number") then return end
		local player = managers.player and managers.player:player_unit()
		if not (alive(player) and attack_data.attacker_unit == player) then return end
		if B.is_overclocked(self._unit) then
			attack_data.damage = attack_data.damage * (1 + C.overclock_dmg_ds)
		end
	end
	for _, fn in ipairs({ "damage_bullet", "damage_melee", "damage_explosion", "damage_fire" }) do
		if CopDamage[fn] then
			Hooks:PreHook(CopDamage, fn, "GilzaDSBuffs_overclock_" .. fn, function(self, attack_data)
				bonus(self, attack_data)
			end)
		end
	end

elseif script == "lib/tweak_data/skilltreetweakdata" then
	-- Overclock and Firewall replace the flat dodge on cards 5 and 7
	Hooks:PostHook(SkillTreeTweakData, "init", "GilzaDSBuffs_hacker_cards", function(self)
		local deck = self.specializations and self.specializations[C.deck]
		for _, card in ipairs({ 5, 7 }) do
			local ups = deck and deck[card] and deck[card].upgrades
			if ups then
				for i = #ups, 1, -1 do
					if string.find(ups[i], "dodge", 1, true) then table.remove(ups, i) end
				end
			end
		end
	end)
end

if LuaNetworking and LuaNetworking.AddReceiveHook and not B._overclock_net then
	B._overclock_net = true
	LuaNetworking:AddReceiveHook(B.NET_ID or "GilzaDSBuffs", "GilzaDSBuffs_overclock_net", function(data)
		local list = type(data) == "string" and string.match(data, "^overclock:([%d,%-]+)$")
		if not list then return end
		local until_t = Application:time() + C.mark_every + 1
		for id in string.gmatch(list, "[^,]+") do
			local n = tonumber(id)
			if n then B._overclocked[n] = until_t end
		end
	end)
end
