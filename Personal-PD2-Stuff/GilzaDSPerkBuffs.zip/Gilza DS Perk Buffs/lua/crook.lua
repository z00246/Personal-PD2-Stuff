GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

B.CROOK = {
	deck = 6,
	vests = { level_2 = true, level_3 = true, level_4 = true },
	deflect = { [1] = 0.1, [3] = 0.15, [5] = 0.2 },
	counter_damage = 0.25,
	counter_time = 3,
	slip_dodge = 0.3,
	slip_time = 5,
	slip_cooldown = 15
}

function B.crook_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == B.CROOK.deck) then
		return 0
	end
	return st:get_specialization_value(B.CROOK.deck, "tiers", "current_tier") or 0
end

local function by_tier(tbl, tier)
	local best, v = 0, nil
	for card, val in pairs(tbl) do
		if tier >= card and card > best then best, v = card, val end
	end
	return v
end

function B.crook_vest(override_armor)
	local armor = override_armor or (managers.blackmarket and managers.blackmarket:equipped_armor(true, true))
	return armor and B.CROOK.vests[armor] or false
end


-- Death Sentence: +5% vest dodge for each of cards 1, 3, 5 and 7.
-- The generic DS niche only bumps the upgrade tables once, so top up the difference here.
B.CROOK.ds_dodge_per_card = 0.05
B.CROOK.ds_dodge_cards = { 1, 3, 5, 7 }

local function ds_bonus_applied(pm, key)
	local rec = B.saved and B.saved["player." .. key]
	if not rec then return 0 end
	local level = pm:upgrade_level("player", key, 0) or 0
	if level <= 0 then return 0 end
	local o, b = rec.orig and rec.orig[level], rec.buffed and rec.buffed[level]
	if type(o) == "number" and type(b) == "number" then
		return b - o
	end
	return 0
end

function B.crook_ds_dodge_fix(pm, tier, override_armor)
	local armor = override_armor or (managers.blackmarket and managers.blackmarket:equipped_armor(true, true))
	if not (armor and B.CROOK.vests[armor]) then return 0 end
	local want = 0
	for _, card in ipairs(B.CROOK.ds_dodge_cards) do
		if tier >= card then want = want + B.CROOK.ds_dodge_per_card end
	end
	local have = ds_bonus_applied(pm, armor .. "_dodge_addend") + ds_bonus_applied(pm, "passive_dodge_chance")
	return math.max(want - have, 0)
end

if script == "lib/managers/playermanager" then
	local function on_dodge()
		local tier = B.crook_tier()
		if tier < 1 then return end
		local now = Application:time()
		if B.crook_vest() then
			local unit = managers.player:player_unit()
			local dmg = alive(unit) and unit:character_damage()
			if dmg and not dmg:dead() then
				dmg:restore_armor(dmg:_max_armor() * (by_tier(B.CROOK.deflect, tier) or 0))
			end
		end
		if tier >= 7 then
			B.crook_counter_until = now + B.CROOK.counter_time
		end
	end

	Hooks:PostHook(PlayerManager, "init", "GilzaDSBuffs_crook_dodge", function(self)
		self:register_message(Message.OnPlayerDodge, "GilzaDSBuffs_crook_dodge", function()
			pcall(on_dodge)
		end)
	end)

	local orig_dodge = PlayerManager.skill_dodge_chance
	function PlayerManager:skill_dodge_chance(running, crouching, on_zipline, override_armor, ...)
		local chance = orig_dodge(self, running, crouching, on_zipline, override_armor, ...)
		if type(chance) ~= "number" then return chance end
		local ok, tier = pcall(B.crook_tier)
		if ok and tier > 0 then
			if B.crook_vest(override_armor) then
				if Application:time() < (B.crook_slip_until or 0) then
					chance = chance + B.CROOK.slip_dodge
				end
				if B.on then
					local ok2, fix = pcall(B.crook_ds_dodge_fix, self, tier, override_armor)
					if ok2 and type(fix) == "number" then
						chance = chance + fix
					end
				end
			else
				chance = chance - self:upgrade_value("player", "passive_dodge_chance", 0)
			end
		end
		return chance
	end

elseif script == "lib/units/beings/player/playerdamage" then
	Hooks:PreHook(PlayerDamage, "_calc_armor_damage", "GilzaDSBuffs_crook_slip_pre", function(self)
		B._crook_pre_armor = self:get_real_armor()
	end)
	Hooks:PostHook(PlayerDamage, "_calc_armor_damage", "GilzaDSBuffs_crook_slip", function(self)
		if (B._crook_pre_armor or 0) <= 0 or self:get_real_armor() > 0 or B.crook_tier() < 9 or not B.crook_vest() then return end
		local now = Application:time()
		if now < (B.crook_slip_ready or 0) then return end
		B.crook_slip_until = now + B.CROOK.slip_time
		B.crook_slip_ready = now + B.CROOK.slip_cooldown
	end)

elseif script == "lib/units/enemies/cop/copdamage" then
	for _, fn in ipairs({ "damage_bullet", "damage_melee" }) do
		Hooks:PreHook(CopDamage, fn, "GilzaDSBuffs_crook_counter_" .. fn, function(self, attack_data)
			if not attack_data or type(attack_data.damage) ~= "number" then return end
			if Application:time() >= (B.crook_counter_until or 0) then return end
			local player = managers.player and managers.player:player_unit()
			if alive(player) and attack_data.attacker_unit == player then
				attack_data.damage = attack_data.damage * (1 + B.CROOK.counter_damage)
			end
		end)
	end

elseif script == "lib/tweak_data/skilltreetweakdata" then
	Hooks:PostHook(SkillTreeTweakData, "init", "GilzaDSBuffs_crook_cards", function(self)
		local card = self.specializations and self.specializations[B.CROOK.deck] and self.specializations[B.CROOK.deck][9]
		local ups = card and card.upgrades
		if ups then
			for i = #ups, 1, -1 do
				if ups[i] == "weapon_passive_armor_piercing_chance_maxed" or ups[i] == "weapon_passive_armor_piercing_chance" then
					table.remove(ups, i)
				end
			end
		end
	end)
end
