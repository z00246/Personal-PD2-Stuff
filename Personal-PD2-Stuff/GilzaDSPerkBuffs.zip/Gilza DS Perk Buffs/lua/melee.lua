-- Melee additions (7.03, 7.04): melee headshots, Bulldozer armour and shield bashes, Restoration's swing sets, sideways
-- charged swings that cleave, and the numbers for all of it in the inventory.
--
-- Swing sets and swing directions come from Restoration Mod (the payday-restoration team): their melee weapon groups
-- (lua/sc/tweak_data/blackmarkettweakdata.lua) and their swing direction data (anim_attack_var_dir). Every swing
-- direction below was measured on the first-person attack animations themselves. 7.04 adds three of Restoration's
-- animation files (assets/anims/fps/melee, add.xml): the bearded-axe set's right-hand swing (melee_beardy var4, put into
-- the animation set by supermod.xml / melee_anims.xml like Restoration does) and El Verdugo / Hackaton swings that hold
-- their last pose to 0.6 s.
GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript

local function live(key, ...)
	if B.live then B.live("melee " .. key, ...) end
end

if not B.MELEE then
	local M = {
		charged = 0.5,      -- a swing charged this far sweeps sideways, cleaves and bashes shields
		full = 0.99,        -- "full charge"
		full_speed = 1.2,   -- a full-charge swing comes out 20% faster
		hs_share = 0.5,     -- a melee headshot gets half of the enemy's headshot bonus (Brawler keeps all of it)
		armor_share = 0.6,  -- share of a hit's damage stat that wears down Bulldozer armour
		cleave_mul = 0.75,  -- damage to every extra enemy of a cleave
		arc_cos = 0.766,    -- cleave arc: 40 degrees either side of where you look...
		tilt = 0.707,       -- ...and no more than 45 degrees up or down
		reach_pad = 40,     -- cm past the weapon's range (the cast is to the enemy's middle, not his surface)
		plate = 15          -- Bulldozer faceplate ("damage" endurance in his sequence), for the menu
	}
	B.MELEE = M

	-- Restoration's swing sets (lua/sc/tweak_data/blackmarkettweakdata.lua), with the base game's animations only.
	-- vars = the quick (uncharged) swings. Sets with a speed play their attack animation that much faster and their
	-- timings are Restoration's divided by it (Restoration does the same with anim_speed_mult).
	M.SWAPS = {
		{ set = "melee_blunt", align = "a_weapon_right", vars = { "var1" },
			ids = { "baton", "oldbaton", "detector", "shovel", "shillelagh", "whiskey", "morning", "branding_iron", "slot_lever",
				"hammer", "tenderizer", "croupier_rake", "shock", "spatula", "swagger", "selfie", "chac", "iceaxe" } },
		{ set = "melee_beardy", align = "a_weapon_right", vars = { "var2", "var3" }, speed = 1.26,
			expire_t = 1.45, repeat_expire_t = 1.2, melee_damage_delay = 0.63,
			ids = { "hockey", "barbedwire", "baseballbat", "stick", "piggy_hammer", "dingdong", "alien_maul", "beardy", "fireaxe" } },
		{ set = "melee_great", align = "a_weapon_right", vars = { "var4" }, speed = 1.26,
			expire_t = 1.45, repeat_expire_t = 1.2, melee_damage_delay = 0.63,
			ids = { "spoon", "meter", "spoon_gold", "great" } },
		{ set = "melee_cleaver", align = "a_weapon_left", vars = { "var1", "var3" }, speed = 1.25,
			expire_t = 0.875, repeat_expire_t = 0.6, melee_damage_delay = 0.15,
			ids = { "cleaver", "meat_cleaver" } }
	}
	M.SWAP_OF = {}
	for _, g in ipairs(M.SWAPS) do
		for _, id in ipairs(g.ids) do M.SWAP_OF[id] = g end
	end

	-- The sideways swings of each animation set: L = the blade sweeps to the left, R = to the right. Measured on the
	-- first-person animations (the weapon tip's fastest 0.1 s across the view); where Restoration's direction data
	-- covers a base-game animation it agrees. melee_beardy var4 is Restoration's right-hand swing (melee_anims.xml).
	M.SWEEP = {
		melee_agave = { L = { "var3" }, R = { "var1" } },
		melee_great = { L = { "var1" }, R = { "var2" } },
		melee_sandsteel = { L = { "var2" }, R = { "var1" } },
		melee_cleaver = { L = { "var4" }, R = { "var2" } },
		melee_briefcase = { L = { "var1" }, R = { "var3" } },
		melee_beardy = { L = { "var1" }, R = { "var4" } },
		melee_fireaxe = { L = { "var1" } },
		melee_baseballbat = { L = { "var1" } },
		melee_baseballbat_miami = { L = { "var1" } },
		melee_blunt = { L = { "var2" } },
		melee_happy = { L = { "var2" } },
		melee_hockey = { L = { "var2" } },
		melee_machete = { L = { "var1" } },
		melee_cutters = { L = { "var2" } },
		melee_buck = { R = { "var2" } }
	}
	-- When the blade crosses the middle of the view in those swings (seconds, at normal animation speed): the hit of a
	-- sideways swing lands then.
	M.STRIKE = {
		melee_agave = { var1 = 0.11, var3 = 0.125 },
		melee_great = { var1 = 0.61, var2 = 0.6 },
		melee_sandsteel = { var1 = 0.225, var2 = 0.195 },
		melee_cleaver = { var2 = 0.13, var4 = 0.265 },
		melee_briefcase = { var1 = 0.155, var3 = 0.315 },
		melee_beardy = { var1 = 0.63, var4 = 0.6 },
		melee_fireaxe = { var1 = 0.63 },
		melee_baseballbat = { var1 = 0.245 },
		melee_baseballbat_miami = { var1 = 0.245 },
		melee_blunt = { var2 = 0.08 },
		melee_happy = { var2 = 0.125 },
		melee_hockey = { var2 = 0.1 },
		melee_machete = { var1 = 0.18 },
		melee_cutters = { var2 = 0.27 },
		melee_buck = { var2 = 0.48 }
	}
	-- (7.07) Heavier tiers charge faster (Geo: "make it faster depending on the tier ... I don't want the charge for every
	-- other melee to be instant"): Gilza's melee classes 2-6, which Gilza gives exactly these charge times. Tasers, poison
	-- weapons, chainsaws, the weapon butt, the Psycho Knife and anything else keep their charge. Multiplies with
	-- Sociopath's Combo and Gilza's Pumping Iron.
	M.TIER_CHARGE = { { t = 0.75, bonus = 0 }, { t = 1.4, bonus = 0.10 }, { t = 1.9, bonus = 0.20 }, { t = 2.5, bonus = 0.30 },
		{ t = 3.5, bonus = 0.40 } }
	function M.charge_bonus(w)
		if type(w) ~= "table" or w.instant or w.chainsaw then return 0 end
		local ct = w.stats and w.stats.charge_time
		if type(ct) ~= "number" then return 0 end
		for _, e in ipairs(M.TIER_CHARGE) do
			if math.abs(ct - e.t) < 1e-3 then return e.bonus end
		end
		return 0
	end
	-- the CHARGE TIME stat in the menus: the real time with the tier bonus and Pumping Iron (which Gilza shows as -0.5 s);
	-- base_stats / skill_stats are what BlackMarketGui / PlayerInventoryGui:_get_melee_weapon_stats return
	function M.charge_stat(name, base_stats, skill_stats)
		local bonus = M.charge_bonus(M.tweak(name))
		if bonus <= 0 then return end
		local b = type(base_stats) == "table" and base_stats.charge_time
		local s = type(skill_stats) == "table" and skill_stats.charge_time
		if not (type(b) == "table" and type(s) == "table" and type(b.value) == "number") then return end
		local pi = managers.player and managers.player:upgrade_value("player", "melee_faster_charge", 1) or 1
		if type(pi) ~= "number" or pi <= 0 then pi = 1 end
		local delta = b.value * pi / (1 + bonus) - b.value
		s.value, s.min_value, s.max_value, s.real_value = delta, delta, delta, delta
		s.skill_in_effect = true
		live("menu charge", "%s charge time %.2f s shown (tier bonus x%.2f)", tostring(name), b.value + delta, 1 + bonus)
	end
	M.NO_CLEAVE = { weapon = true, brick = true }
	M.CAP2 = { briefcase = true, buck = true }
	M.ARMOR_BODIES = { "body_helmet_plate", "body_helmet_glass", "body_armor_chest", "body_armor_stomache", "body_armor_back",
		"body_armor_throat", "body_armor_neck" }

	M.STRINGS = {
		bm_menu_gdsb_cleave = "Cleave",
		bm_menu_gdsb_sweep = "Sweep",
		bm_menu_gdsb_headshot = "Headshot",
		bm_menu_gdsb_plate = "Dozer plate",
		bm_menu_gdsb_shield = "Shield bash",
		bm_menu_gdsb_full = "Full swing",
		bm_menu_gdsb_both = "Both",
		bm_menu_gdsb_left = "Left",
		bm_menu_gdsb_right = "Right",
		bm_menu_gdsb_any = "Any"
	}

	function M.tweak(id)
		local bm = tweak_data and tweak_data.blackmarket
		return bm and bm.melee_weapons and id and bm.melee_weapons[id] or nil
	end

	-- put one weapon on its Restoration swing set (idempotent)
	function M.swap(id, w)
		local g = M.SWAP_OF[id]
		if not (g and type(w) == "table") then return false end
		if w._gdsb_set == g.set and w.anim_global_param == g.set then return false end
		w.anim_global_param = g.set
		w.align_objects = { g.align }
		w.anim_attack_vars = {}
		for i, v in ipairs(g.vars) do w.anim_attack_vars[i] = v end
		if g.speed then
			w.expire_t = g.expire_t / g.speed
			w.repeat_expire_t = g.repeat_expire_t / g.speed
			w.melee_damage_delay = g.melee_damage_delay / g.speed
		end
		w._gdsb_speed = g.speed
		w._gdsb_set = g.set
		return true
	end

	function M.apply_sets(bm)
		local list = bm and bm.melee_weapons
		if type(list) ~= "table" then return 0 end
		local n = 0
		for id, g in pairs(M.SWAP_OF) do
			if list[id] and M.swap(id, list[id]) then n = n + 1 end
		end
		return n
	end

	-- Sideways swings that need one of this mod's own animation files. add.xml (BeardLib) adds the file and
	-- melee_anims.xml (SuperBLT) puts it into the animation set. SuperBLT reads its tweaks only when the game starts,
	-- while BeardLib re-reads add.xml on every Lua reload, so a copy installed or updated while the game runs has the
	-- file but not the tweak until the next restart. Those swings are offered only when both are certain: the file is in
	-- the asset database and this file already ran in the game's first Lua state (M.BOOT, set below).
	M.NEEDS = { melee_beardy = { R = "anims/fps/melee/beardy/melee_attack_var4" } }
	M.HAVE = {}
	function M.have_anim(path)
		local g = rawget(_G, "Global")
		if not (g and g.gdsb_melee_boot and g.gdsb_melee_boot.anims) then return false end
		if M.HAVE[path] then return true end
		local ok, has = pcall(function() return DB:has(Idstring("animation"), Idstring(path)) end)
		if ok and has then M.HAVE[path] = true end
		return M.HAVE[path] or false
	end

	-- the sideways swings of a weapon (nil = it has none: knives, fists, stabs, chainsaws, hatchets, the flag...)
	function M.sweep_of(id, w)
		w = w or M.tweak(id)
		if type(w) ~= "table" or w.instant or w.chainsaw then return nil end
		if not (w.stats and (w.stats.charge_time or 0) > 0) then return nil end
		local set = w.anim_global_param
		local sweep, needs = M.SWEEP[set], M.NEEDS[set]
		if sweep and needs then
			local out
			for side, list in pairs(sweep) do
				if not needs[side] or M.have_anim(needs[side]) then
					out = out or {}
					out[side] = list
				else
					live("anims", "%s: the %s swing waits for a game restart (%s not loaded)", set, side, needs[side])
				end
			end
			return out
		end
		return sweep
	end

	function M.cleave_cap(id, w)
		if M.NO_CLEAVE[id] then return 1 end
		if M.CAP2[id] then return 2 end
		local s = type(w) == "table" and w.stats or {}
		if (s.max_damage or 0) >= 20 then return 3 end
		return 2
	end

	local function has(up)
		local pm = managers and managers.player
		return pm and pm:has_category_upgrade("player", up) or false
	end

	-- everything the menu shows, and what the swings use
	function M.info(id)
		local w = M.tweak(id)
		if not w then return nil end
		local sweep = M.sweep_of(id, w)
		local s = w.stats or {}
		local charges = not w.instant and not w.chainsaw and (s.charge_time or 0) > 0
		local lo = s.min_damage or 0
		local hi = s.max_damage or lo
		local brawler = has("melee_headshot_multiplier")
		local info = {
			sides = sweep and ((sweep.L and sweep.R) and "both" or sweep.L and "left" or "right") or nil,
			cleave = sweep and M.cleave_cap(id, w) or 1,
			hs = brawler and 2 or (1 + (2 - 1) * M.hs_share),
			brawler = brawler,
			plate_quick = lo > 0 and math.ceil(M.plate / (M.armor_share * lo) - 1e-6) or nil,
			plate_full = hi > 0 and math.ceil(M.plate / (M.armor_share * hi) - 1e-6) or nil,
			charges = charges,
			shield = has("shield_knock") and "any" or (charges and "half" or nil),
			full = charges and M.full_speed or nil
		}
		return info
	end

	M.errs = {}
	function M.err(what, e)
		if M.errs[what] then return end
		M.errs[what] = true
		log("[Gilza DS Perk Buffs] melee " .. tostring(what) .. " failed: " .. tostring(e))
	end
end
local M = B.MELEE

-- Did this version start with the game? Global survives Lua reloads; lib/setups/setup.lua requires the tweak data
-- (and so this file) before Setup:init_managers creates Global.game_settings, so only the game's first Lua state
-- sees neither. Set once per game process; a copy installed mid-game finds Global already filled -> false.
do
	local g = rawget(_G, "Global")
	if g and g.gdsb_melee_boot == nil then
		g.gdsb_melee_boot = { anims = g.game_settings == nil and g.initialized == nil }
	end
end

if script == "lib/tweak_data/blackmarkettweakdata" then
	-- After the whole black market init: Gilza and Better Melee Animation change animation sets in their
	-- _init_melee_weapons hooks, and BeardLib runs Better Melee Animation's after ours, so this has to come later still.
	Hooks:PostHook(BlackMarketTweakData, "init", "GilzaDSBuffs_melee_sets", function(self)
		local ok, n = pcall(M.apply_sets, self)
		if not ok then M.err("swing sets", n) end
		M.sets_applied = ok and n or 0
		if ok and not M.sets_logged then
			M.sets_logged = true
			log("[Gilza DS Perk Buffs] melee: " .. tostring(n) .. " weapons on Restoration's swing sets")
		end
	end)

elseif script == "lib/managers/localizationmanager" then
	Hooks:Add("LocalizationManagerPostInit", "GilzaDSBuffs_melee_loc", function(loc)
		pcall(function() loc:add_localized_strings(M.STRINGS) end)
	end)

elseif script == "lib/managers/playermanager" then
	-- a charged melee hit (50%+) bashes shields like Shock and Awe ace (the "player shield_knock" upgrade; the game's
	-- skill id for Shock and Awe is iron_man, the skill shown as Iron Man is juggernaut) through the game's own
	-- shield_knock path in PlayerStandard:_do_melee_damage; Captain Winters and his escort stay immune there, Marshal
	-- Shields too unless you have the real Shock and Awe ace (7.13, copdamage part below)
	local orig_has = PlayerManager.has_category_upgrade
	B.real_has_upgrade = orig_has   -- (7.13) the upgrade check without the charged hit's stand-in
	if orig_has then
		function PlayerManager:has_category_upgrade(category, upgrade, ...)
			if upgrade == "shield_knock" and category == "player" and B._melee_knock then
				return true
			end
			return orig_has(self, category, upgrade, ...)
		end
	end

elseif script == "lib/units/beings/player/states/playerstandard" then
	-- (7.07) the tier bonus: everything that reads the charge (the swing, the hit's damage, the wind-up pose, Gilza's charge
	-- bar and counter-strikes, Sociopath) goes through this function, so scaling its result speeds all of it up alike.
	-- Gilza replaces the function before this file loads; a PostHook's return value replaces the result in SuperBLT.
	Hooks:PostHook(PlayerStandard, "_get_melee_charge_lerp_value", "GilzaDSBuffs_melee_tier_charge", function(self, t, offset)
		local v = Hooks:GetReturn()
		if type(v) ~= "number" or v <= 0 or v >= 1 then return end
		local ok, bonus = pcall(function()
			local id = managers.blackmarket:equipped_melee_weapon()
			return M.charge_bonus(M.tweak(id)), id
		end)
		if not ok then M.err("tier charge", bonus) return end
		if bonus and bonus > 0 then
			if not M.tier_logged then
				M.tier_logged = true
				live("tier charge", "%s charges x%.2f faster (tier bonus)", tostring(managers.blackmarket:equipped_melee_weapon()), 1 + bonus)
			end
			return math.min(v * (1 + bonus), 1)
		end
	end)

	local SAVED
	local function restore_vars()
		if SAVED then
			SAVED.w.anim_attack_vars = SAVED.vars
			SAVED = nil
		end
	end

	local function pick_side(self, sweep)
		local want
		local sm = self._stick_move
		if sm then
			local x, y = sm.x or 0, sm.y or 0
			local len = math.sqrt(x * x + y * y)
			if len > 0.2 then
				local nx = x / len
				if nx <= -0.6 then want = "L" elseif nx >= 0.6 then want = "R" end
			end
		end
		if want and sweep[want] then return want end
		return sweep.L and "L" or "R"
	end

	-- the swing: a charged swing (50%+) sweeps sideways (strafe left/right picks the side where the weapon has both)
	local function swing_pre(self, t)
		restore_vars()
		self._gdsb_swing = nil
		if not (managers.player and self._unit == managers.player:player_unit()) then return end
		local id = managers.blackmarket:equipped_melee_weapon()
		local w = M.tweak(id)
		if not w then return end
		if w.instant or w.chainsaw then return end
		local charge = self:_get_melee_charge_lerp_value(t, 0) or 0
		local sw = { t = t, id = id, set = w.anim_global_param, charge = charge, speed = w._gdsb_speed or 1,
			full = charge >= M.full and (w.stats and (w.stats.charge_time or 0) > 0) }
		local sweep = charge >= M.charged and M.sweep_of(id, w)
		if sweep then
			local side = pick_side(self, sweep)
			local list = sweep[side]
			local var = list[math.random(#list)]
			sw.side, sw.var, sw.cleave = side, var, M.cleave_cap(id, w)
			local n = math.max(1, #(w.anim_attack_vars or {}))
			local forced = {}
			for i = 1, n do forced[i] = var end
			SAVED = { w = w, vars = w.anim_attack_vars }
			w.anim_attack_vars = forced
		end
		self._gdsb_swing = sw
	end

	local function swing_post(self, t)
		local sw = self._gdsb_swing
		local sd = self._state_data
		if not (sw and sw.t == t and sd) then return end
		local socio = 1
		pcall(function()
			local m = B.socio_combo_mul and B.socio_combo_mul()
			if type(m) == "number" and m > 1 then socio = m end
		end)
		local full = sw.full and M.full_speed or 1
		if full > 1 then
			for _, k in ipairs({ "melee_damage_delay_t", "melee_repeat_expire_t", "melee_expire_t" }) do
				local v = sd[k]
				if type(v) == "number" and v > t then sd[k] = t + (v - t) / full end
			end
		end
		local total = (sw.speed or 1) * full * socio
		-- a sideways swing lands its hit when the blade crosses the middle of the view
		local strike = sw.var and M.STRIKE[sw.set] and M.STRIKE[sw.set][sw.var]
		if strike and type(sd.melee_damage_delay_t) == "number" then
			local d = t + strike / total
			if type(sd.melee_repeat_expire_t) == "number" then d = math.min(d, sd.melee_repeat_expire_t) end
			sd.melee_damage_delay_t = d
		end
		if total ~= 1 then
			local asm = self._camera_unit and self._camera_unit:anim_state_machine()
			local state = asm and asm:segment_state(self:get_animation("base"))
			if state then asm:set_speed(state, total) end
		end
		if sw.var then
			live("swing", "%s charged %d%%: %s swing (%s), cleaves %d, speed x%.2f", tostring(sw.id), math.floor(sw.charge * 100 + 0.5),
				sw.side == "L" and "left" or "right", tostring(sw.var), sw.cleave or 1, total)
		end
		if sw.full then live("full", "%s: full charge, swing x%.2f", tostring(sw.id), total) end
		if (sw.speed or 1) ~= 1 then live("set speed", "%s on %s plays x%.2f", tostring(sw.id), tostring(sw.set), sw.speed) end
	end

	Hooks:PreHook(PlayerStandard, "_do_action_melee", "GilzaDSBuffs_melee_swing_pre", function(self, t)
		local ok, e = pcall(swing_pre, self, t)
		if not ok then restore_vars(); M.err("swing", e) end
	end)
	Hooks:PostHook(PlayerStandard, "_do_action_melee", "GilzaDSBuffs_melee_swing_post", function(self, t)
		restore_vars()
		local ok, e = pcall(swing_post, self, t)
		if not ok then M.err("swing timing", e) end
	end)
	-- (before the charge picks the animation set: put the weapon back on its swing set if anything undid it)
	Hooks:PreHook(PlayerStandard, "_start_action_melee", "GilzaDSBuffs_melee_start", function(self)
		restore_vars()
		B._melee_knock = nil
		pcall(function()
			local id = managers.blackmarket:equipped_melee_weapon()
			if M.SWAP_OF[id] then M.swap(id, M.tweak(id)) end
		end)
	end)

	-- the hit: who it lands on (cleave), charged shield bashes, Bulldozer armour
	local STACK = {}
	local function hit_pre(self, t, melee_entry)
		if #STACK > 3 then STACK = {} end
		local ctx = { t = t, depth = #STACK + 1, extra = B._melee_next_extra }
		STACK[#STACK + 1] = ctx
		B._melee_ctx = ctx
		B._melee_knock = nil
		if not (managers.player and self._unit == managers.player:player_unit()) then return end
		local id = melee_entry or managers.blackmarket:equipped_melee_weapon()
		local w = M.tweak(id)
		if not w then return end
		local sw = self._gdsb_swing
		if sw and sw.id == id and math.abs(t - sw.t) < 3 and (not sw.done or ctx.depth > 1) then
			ctx.swing = sw
			ctx.charge = sw.charge
			-- the game works the hit's charge out again from the time it lands, assuming the weapon's usual delay: with the
			-- swing sped up or landing at its own moment, move the charge start by the difference so the hit deals the
			-- charge it was released at
			local sd = self._state_data
			if ctx.depth == 1 and sd and type(sd.melee_start_t) == "number" then
				local shift = (t - sw.t) - (w.melee_damage_delay or 0)
				if math.abs(shift) > 1e-4 and math.abs(shift) < 1 then
					ctx.start_restore = sd.melee_start_t
					ctx.state_data = sd
					sd.melee_start_t = sd.melee_start_t + shift
				end
			end
		elseif not w.instant then
			ctx.charge = self:_get_melee_charge_lerp_value(t, w.melee_damage_delay or 0) or 0
		end
		ctx.id, ctx.w = id, w
		if (ctx.charge or 0) >= M.charged and not w.instant and not w.chainsaw then
			B._melee_knock = true
		end
	end

	local function enemy_char(unit)
		if not alive(unit) then return nil end
		if unit:in_slot(8) and alive(unit:parent()) then unit = unit:parent() end
		local cd = unit:character_damage()
		if not (cd and cd.damage_melee) then return nil end
		return unit
	end

	local function is_enemy(unit)
		return managers.enemy and managers.enemy.is_enemy and managers.enemy:is_enemy(unit) or false
	end

	local function standing(unit)
		local cd = unit:character_damage()
		if not cd or (cd.dead and cd:dead()) then return false end
		local ad = unit:anim_data()
		if ad and (ad.hands_tied or ad.surrender) then return false end
		local br = unit:brain()
		if br and type(br.is_hostage) == "function" and br:is_hostage() then return false end
		return true
	end

	-- the other enemies a charged sideways swing cuts through: in front (80 degree arc), within reach, nothing in between
	local function cleave_targets(self, w, primary, slots)
		local from = self._unit:movement():m_head_pos()
		local fwd = self._unit:movement():m_head_rot():y()
		local fx, fy = fwd.x, fwd.y
		local fl = math.sqrt(fx * fx + fy * fy)
		if fl < 0.01 then return {} end
		fx, fy = fx / fl, fy / fl
		local reach = ((w.stats and w.stats.range) or 175) + M.reach_pad
		local units = World:find_units_quick("sphere", from, reach + 60, managers.slot:get_mask("enemies"))
		local found = {}
		for _, u in ipairs(units or {}) do
			if alive(u) and u ~= primary and u:character_damage() and u:character_damage().damage_melee and standing(u) and is_enemy(u) then
				local mv = u:movement()
				local com = mv and (mv.m_com and mv:m_com() or mv:m_pos())
				if com then
					local dx, dy, dz = com.x - from.x, com.y - from.y, com.z - from.z
					local dist = math.sqrt(dx * dx + dy * dy + dz * dz)
					local hl = math.sqrt(dx * dx + dy * dy)
					if dist > 1 and dist <= reach and hl > 1 and math.abs(dz) / dist <= M.tilt then
						local c = (dx * fx + dy * fy) / hl
						if c >= M.arc_cos then
							local to = from + Vector3(dx, dy, dz) * ((dist + 50) / dist)
							local ray = self._unit:raycast("ray", from, to, "slot_mask", self._slotmask_bullet_impact_targets,
								"sphere_cast_radius", 10, "ray_type", "body melee")
							if ray and alive(ray.unit) and (ray.distance or 0) <= reach + 20 and enemy_char(ray.unit) == u then
								found[#found + 1] = { unit = u, ray = ray, c = c }
							end
						end
					end
				end
			end
		end
		table.sort(found, function(a, b) return a.c > b.c end)
		local out = {}
		for i = 1, math.min(slots, #found) do out[i] = found[i] end
		return out
	end

	local function do_cleave(self, t, bayonet_melee, melee_entry, ctx)
		local sw = ctx.swing
		local primary = enemy_char(ctx.hit_unit)
		-- (7.12) whether he was an enemy when the hit landed (melee_pre): a dead enemy is no longer on the game's list
		local primary_enemy = false
		if primary then
			if ctx.front_unit == primary and ctx.front_enemy ~= nil then
				primary_enemy = ctx.front_enemy
			else
				primary_enemy = is_enemy(primary)
			end
		end
		local slots = (sw.cleave or 1) - (primary_enemy and 1 or 0)
		if slots <= 0 then return end
		local targets = cleave_targets(self, ctx.w, primary, slots)
		if #targets == 0 then return end
		local cam = self._ext_camera
		local own_shaker = cam and rawget(cam, "play_shaker")
		if cam then cam.play_shaker = function() end end
		local hit = 0
		for i, tg in ipairs(targets) do
			B._melee_next_extra = primary_enemy or i > 1
			local ok, e = pcall(self._do_melee_damage, self, t, bayonet_melee, tg.ray, melee_entry)
			B._melee_next_extra = nil
			if ok then hit = hit + 1 else M.err("cleave hit", e) end
		end
		if cam then cam.play_shaker = own_shaker end
		live("cleave", "%s: the swing hit %d more enem%s (%s)", tostring(sw.id), hit, hit == 1 and "y" or "ies",
			primary_enemy and "after the one in front" or "none in front")
	end

	local function hit_post(self, t, bayonet_melee, melee_entry)
		local ctx = STACK[#STACK]
		if not ctx then return end
		if ctx.depth == 1 and ctx.hit_unit and B._melee_knock and alive(ctx.hit_unit) and ctx.hit_unit:in_slot(8) then
			live("shield", "%s: a %d%% charged hit on a shield bashes it", tostring(ctx.id), math.floor((ctx.charge or 0) * 100 + 0.5))
		end
		local sw = ctx.swing
		if ctx.depth == 1 and sw then sw.done = true end
		if ctx.depth == 1 and sw and (sw.cleave or 1) > 1 and not sw.cleaved and sw.var then
			sw.cleaved = true
			B._melee_knock = (ctx.charge or 0) >= M.charged or nil
			do_cleave(self, t, bayonet_melee, melee_entry, ctx)
		end
	end

	Hooks:PreHook(PlayerStandard, "_do_melee_damage", "GilzaDSBuffs_melee_hit_pre", function(self, t, bayonet_melee, melee_hit_ray, melee_entry)
		local ok, e = pcall(hit_pre, self, t, melee_entry)
		if not ok then M.err("hit", e) end
	end)
	Hooks:PostHook(PlayerStandard, "_do_melee_damage", "GilzaDSBuffs_melee_hit_post", function(self, t, bayonet_melee, melee_hit_ray, melee_entry)
		local ok, e = pcall(hit_post, self, t, bayonet_melee, melee_entry)
		if not ok then M.err("cleave", e) end
		local top = STACK[#STACK]
		if top and top.start_restore and top.state_data then
			top.state_data.melee_start_t = top.start_restore
		end
		STACK[#STACK] = nil
		B._melee_ctx = STACK[#STACK]
		B._melee_knock = nil
	end)

	-- Bulldozer armour: the hit wears the plate / visor / body armour it lands on the way bullets do (the game's "damage"
	-- endurance; melee only fed the "melee" endurance, which his armour doesn't use), synced like a bullet hit
	local ARMOR
	local function armor_body(body)
		if not ARMOR then
			ARMOR = {}
			for _, n in ipairs(M.ARMOR_BODIES) do ARMOR[#ARMOR + 1] = Idstring(n) end
		end
		local name = body:name()
		for _, ids in ipairs(ARMOR) do
			if name == ids then return true end
		end
		return false
	end

	local function wear_armor(self, hit_unit, col_ray)
		local ctx = B._melee_ctx
		if not ctx then return end
		if ctx.depth == 1 then ctx.hit_unit = hit_unit end
		if not (ctx.w and alive(hit_unit) and col_ray and col_ray.body) then return end
		local cd = hit_unit:character_damage()
		local ct = cd and cd._char_tweak
		if not (ct and (ct.access == "tank" or (type(ct.tags) == "table" and table.contains(ct.tags, "tank")))) then return end
		if not armor_body(col_ray.body) then return end
		local ext = col_ray.body:extension()
		local bd = ext and ext.damage
		if not bd then return end
		local dmg = managers.blackmarket:equipped_melee_weapon_damage_info(ctx.charge or 0)
		if type(dmg) ~= "number" or dmg <= 0 then return end
		local amount = dmg * M.armor_share * (ctx.extra and M.cleave_mul or 1)
		local net = math.min(16384, math.ceil(amount * 163.84))
		amount = net / 163.84
		local session = managers.network and managers.network:session()
		if session and hit_unit:id() ~= -1 and InstantBulletBase and InstantBulletBase._get_vector_sync_yaw_pitch then
			local nyaw, npitch = InstantBulletBase._get_vector_sync_yaw_pitch(col_ray.normal, 128, 64)
			local dyaw, dpitch = InstantBulletBase._get_vector_sync_yaw_pitch(col_ray.ray, 128, 64)
			session:send_to_peers_synched("sync_body_damage_bullet", col_ray.unit:id() ~= -1 and col_ray.body or nil,
				self._unit:id() ~= -1 and self._unit or nil, nyaw, npitch, col_ray.position, dyaw, dpitch, net)
		end
		bd:damage_bullet(self._unit, col_ray.normal, col_ray.position, col_ray.ray, 1)
		if hit_unit:alive() then
			bd:damage_damage(self._unit, col_ray.normal, col_ray.position, col_ray.ray, amount)
		end
		live("armour", "%s: %.1f into a Bulldozer's %s", tostring(ctx.id), amount, tostring(col_ray.body:name()))
	end

	Hooks:PostHook(PlayerStandard, "_perform_sync_melee_damage", "GilzaDSBuffs_melee_armour", function(self, hit_unit, col_ray)
		local ok, e = pcall(wear_armor, self, hit_unit, col_ray)
		if not ok then M.err("armour", e) end
	end)

elseif script == "lib/units/enemies/cop/copdamage" then
	-- melee headshots (half the enemy's headshot bonus, after Gilza turned the hit into a share of his health; Brawler
	-- already gets all of it from Gilza) and the cleave's 75% on every extra enemy
	local function mine(attack_data)
		local p = managers.player and managers.player:player_unit()
		return alive(p) and attack_data and attack_data.attacker_unit == p
	end
	local function melee_pre(self, attack_data)
		if not (attack_data and type(attack_data.damage) == "number" and mine(attack_data)) then return end
		if attack_data._gdsb_melee then return end
		attack_data._gdsb_melee = true
		local ctx = B._melee_ctx
		-- (7.12) is the one the swing lands on an enemy? Asked here, before the hit: killing him takes him off the game's
		-- enemy list at once, and the cleave only asks after the hit (it took one enemy too many, the first at full damage)
		if ctx and ctx.depth == 1 and ctx.front_unit == nil then
			local em = managers.enemy
			ctx.front_unit = self._unit
			ctx.front_enemy = em and em.is_enemy and em:is_enemy(self._unit) or false
		end
		if self._dead or self._invulnerable then return end
		if ctx and ctx.extra then
			attack_data.damage = attack_data.damage * M.cleave_mul
		end
		local ct = self._char_tweak
		local body = attack_data.col_ray and attack_data.col_ray.body
		local head = self._head_body_name and body and body:name() == self._ids_head_body_name
		if not head or not ct or ct.ignore_headshot or self._damage_reduction_multiplier then return end
		local mul = ct.headshot_dmg_mul
		if type(mul) ~= "number" or mul <= 1 then return end
		if managers.player:has_category_upgrade("player", "melee_headshot_multiplier") then return end
		attack_data.damage = attack_data.damage * (1 + (mul - 1) * M.hs_share)
		live("headshot", "melee headshot x%.2f on %s", 1 + (mul - 1) * M.hs_share, tostring(self._unit:base()._tweak_table))
	end
	Hooks:PreHook(CopDamage, "damage_melee", "GilzaDSBuffs_melee_head", function(self, attack_data)
		local ok, e = pcall(melee_pre, self, attack_data)
		if not ok then M.err("headshot", e) end
	end)

	-- (7.13, Geo: "with aced for marshal shield let me knockback him, not winters and his shields though") Shock and
	-- Awe aced knocks Marshal Shields back like any other shield: melee, and the ace's chance with guns. The game makes them
	-- immune (damage.immune_to_knockback, and damage.shield_knocked = false for melee hits). Only with the real ace
	-- (not the charged hit's stand-in) and only for your own hits; Captain Winters and his Phalanx shields stay immune.
	local KNOCKABLE = { marshal_shield = true }
	local function knockable(cd)
		local u = cd and cd._unit
		local base = alive(u) and u:base()
		return base and KNOCKABLE[base._tweak_table] or false
	end
	local function real_ace()
		local pm = managers.player
		if not pm then return false end
		local f = B.real_has_upgrade
		if f then return f(pm, "player", "shield_knock") and true or false end
		local g = pm._global and pm._global.upgrades and pm._global.upgrades.player
		return g and g.shield_knock and true or false
	end
	local function knock_ok(cd) return knockable(cd) and real_ace() end
	local orig_immune = CopDamage.is_immune_to_shield_knockback
	if orig_immune then
		function CopDamage:is_immune_to_shield_knockback(...)
			local immune = orig_immune(self, ...)
			if immune then
				local ok, yes = pcall(knock_ok, self)
				if ok and yes then return false end
				if not ok then M.err("marshal knock", yes) end
			end
			return immune
		end
	end
	-- the melee hit itself: the game only turns it into a knock when the enemy's damage.shield_knocked is set. That is
	-- shared tweak data, so it is set for this one hit and put back right after (and before any later hit, if
	-- something stopped this one half way)
	local KNOCK
	local function knock_undo()
		if KNOCK then
			KNOCK.dmg.shield_knocked = KNOCK.was
			KNOCK = nil
		end
	end
	local function knock_pre(self, attack_data)
		if not (attack_data and attack_data.shield_knock and mine(attack_data)) then return end
		local ct = self._char_tweak
		local dmg = type(ct) == "table" and ct.damage
		if type(dmg) ~= "table" or dmg.shield_knocked or not knockable(self) or not real_ace() then return end
		KNOCK = { dmg = dmg, was = dmg.shield_knocked }
		dmg.shield_knocked = true
		live("marshal", "Shock and Awe aced: a hit knocks a Marshal Shield back")
	end
	Hooks:PreHook(CopDamage, "damage_melee", "GilzaDSBuffs_marshal_knock", function(self, attack_data)
		knock_undo()
		local ok, e = pcall(knock_pre, self, attack_data)
		if not ok then knock_undo(); M.err("marshal knock", e) end
	end)
	Hooks:PostHook(CopDamage, "damage_melee", "GilzaDSBuffs_marshal_knock_post", function()
		knock_undo()
	end)

elseif script == "lib/managers/menu/blackmarketgui" then
	-- the new numbers under the melee weapon's stats (rows of the game's own melee stats panel, so the description and
	-- everything below moves down with them)
	local ROWS = { "cleave", "sweep", "headshot", "plate", "shield", "full" }

	local function label(key)
		local id = "bm_menu_gdsb_" .. key
		local s = managers.localization and managers.localization:text(id)
		if type(s) ~= "string" or s == "" or string.find(s, "ERROR", 1, true) then s = M.STRINGS[id] or key end
		return s
	end

	local function rows_of(self)
		local p = self._mweapon_stats_panel
		if not (p and alive(p) and self._mweapon_stats_texts) then return nil end
		if self._gdsb_rows_panel == p and self._gdsb_rows then return self._gdsb_rows end
		local font, font_size = tweak_data.menu.pd2_small_font, tweak_data.menu.pd2_small_font_size
		local y, n = 20, 0
		for _, c in ipairs(p:children()) do
			y = math.max(y, c:bottom())
			n = n + 1
		end
		local columns = {
			{ name = "name", size = 100 },
			{ name = "equip", size = 55, align = "right", alpha = 0.75, blend = "add" },
			{ name = "base", size = 60, align = "right", alpha = 0.75, blend = "add" },
			{ name = "skill", size = 65, align = "right", alpha = 0.75, blend = "add", color = tweak_data.screen_colors.resource },
			{ name = "total", size = 55, align = "right" }
		}
		local rows = {}
		for i, key in ipairs(ROWS) do
			local row = p:panel({ name = "gdsb_" .. key, h = 20, layer = 1, x = 0, y = y, w = p:w() })
			if (n + i) % 2 == 0 then
				row:rect({ name = tostring(n + i), color = Color.black:with_alpha(0.3) })
			end
			y = y + 20
			local texts = {}
			local x = 2
			for _, col in ipairs(columns) do
				local tp = row:panel({ layer = 0, x = x, w = col.size, h = row:h() })
				texts[col.name] = tp:text({ layer = 1, font_size = font_size, font = font, align = col.align, alpha = col.alpha,
					blend_mode = col.blend, color = col.color or tweak_data.screen_colors.text, text = "" })
				x = x + col.size
				if col.name == "total" then tp:set_x(190) end
			end
			rows[key] = texts
			self._mweapon_stats_texts["gdsb_" .. key] = texts
		end
		self._gdsb_rows_panel, self._gdsb_rows = p, rows
		live("menu", "%d melee stat rows added", #ROWS)
		return rows
	end

	-- { text, rank (higher = better, nil = no comparison) } per row
	local function values(id)
		local info = M.info(id)
		if not info then return nil end
		local up = function(key) return utf8.to_upper(label(key)) end
		local v = {}
		v.cleave = { tostring(info.cleave), info.cleave }
		v.sweep = { info.sides and up(info.sides) or "-", info.sides == "both" and 2 or info.sides and 1 or 0 }
		v.headshot = { string.format("\195\151%s", info.hs == math.floor(info.hs) and tostring(info.hs) or string.format("%.1f", info.hs)), nil }
		if info.plate_quick and info.plate_full and info.plate_quick ~= info.plate_full and info.charges then
			v.plate = { info.plate_quick .. " (" .. info.plate_full .. ")", -info.plate_full }
		elseif info.plate_full then
			v.plate = { tostring(info.plate_full), -info.plate_full }
		else
			v.plate = { "-", nil }
		end
		v.shield = { info.shield == "any" and up("any") or info.shield == "half" and "50%" or "-", info.shield == "any" and 2 or info.shield and 1 or 0 }
		v.full = { info.full and string.format("+%d%%", math.floor((info.full - 1) * 100 + 0.5)) or "-", info.full and 1 or 0 }
		return v
	end

	local function fill(self)
		local rows = rows_of(self)
		if not rows then return end
		local sd = self._slot_data
		local id = sd and sd.comparision_data and sd.category == "melee_weapons" and sd.name
		local w = id and M.tweak(id)
		local cur = w and values(id)
		if not cur then
			for _, texts in pairs(rows) do
				for _, t in pairs(texts) do t:set_text("") end
			end
			return
		end
		local equipped = managers.blackmarket:equipped_item(sd.category or "melee_weapons")
		local eq = equipped and equipped ~= id and values(equipped) or nil
		local col = tweak_data.screen_colors
		for _, key in ipairs(ROWS) do
			local texts = rows[key]
			texts.name:set_text(utf8.to_upper(label(key)))
			texts.base:set_text("")
			texts.skill:set_text("")
			local c = cur[key]
			if eq then
				local e = eq[key]
				texts.equip:set_alpha(0.75)
				texts.equip:set_text(e[1])
				texts.equip:set_color(col.text)
				texts.total:set_text(c[1])
				local colour = col.text
				if c[2] and e[2] then
					if c[2] > e[2] then colour = col.stats_positive elseif c[2] < e[2] then colour = col.stats_negative end
				end
				texts.total:set_color(colour)
			else
				texts.equip:set_alpha(1)
				texts.equip:set_text(c[1])
				texts.equip:set_color(col.text)
				texts.total:set_text("")
			end
		end
	end

	-- before the game lays the panel out, so the rows count when it moves the rest down
	Hooks:PreHook(BlackMarketGui, "show_stats", "GilzaDSBuffs_melee_rows", function(self)
		local ok, e = pcall(fill, self)
		if not ok then M.err("menu rows", e) end
	end)

	Hooks:PostHook(BlackMarketGui, "_get_melee_weapon_stats", "GilzaDSBuffs_melee_charge_stat", function(self, name)
		local base_stats, mods_stats, skill_stats = Hooks:GetReturn()
		local ok, e = pcall(M.charge_stat, name, base_stats, skill_stats)
		if not ok then M.err("menu charge time", e) end
	end)

elseif script == "lib/managers/menu/playerinventorygui" then
	-- (7.07) the same CHARGE TIME number in the inventory screen's melee box
	Hooks:PostHook(PlayerInventoryGui, "_get_melee_weapon_stats", "GilzaDSBuffs_melee_charge_stat_inv", function(self, name)
		local base_stats, mods_stats, skill_stats = Hooks:GetReturn()
		local ok, e = pcall(M.charge_stat, name, base_stats, skill_stats)
		if not ok then M.err("inventory charge time", e) end
	end)
end
