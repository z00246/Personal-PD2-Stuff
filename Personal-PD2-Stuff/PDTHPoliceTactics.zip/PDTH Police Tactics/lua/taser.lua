if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics
local orig = TaserLogicAttack._chk_reaction_to_attention_object

TaserLogicAttack._chk_reaction_to_attention_object = function(data, attention_data, stationary, ...)
	local my_data = data.internal_data
	local unit = attention_data and attention_data.unit
	if T.active() and T.vanilla_tase and my_data and my_data.tase_distance
		and alive(unit) and unit:base() and unit:base().is_husk_player and not T.unit_has_mod(unit) then
		local real = my_data.tase_distance
		my_data.tase_distance = math.min(real, T.vanilla_tase)
		local ok, r = pcall(orig, data, attention_data, stationary, ...)
		my_data.tase_distance = real
		if ok then return r end
	end
	return orig(data, attention_data, stationary, ...)
end
