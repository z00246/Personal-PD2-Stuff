GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

B.BURGLAR = {
	deck = 7,
	hidden_delay = 0.5,
	hidden_dodge = 0.15,
	hidden_dodge_ds = 0.20,
	crouch_detect = 0.8,
	ambush = 0.40,
	ambush_ds = 0.50,
	mark_mul = 1.5,
	silent_time = 4,
	silent_weight = 0.2,
	silent_cooldown = 6,
	ecm_mul = 1.25,
	vanish_time = 3,
	vanish_time_ds = 4,
	vanish_cooldown = 20,
	vanish_fallback_dodge = 0.3,
	patience_delay = 2,
	patience = 0.5,
	patience_ds = 0.75,
	pellet_window = 0.05,
	hidden_regen = 0.01,     -- card 9: share of max health healed every second while Hidden
	hidden_regen_ds = 0.015,
	-- rework (Oct 13): Shadow / Backstab / Disorient / Slip Away / Ghost
	sight_delay = 1.5,       -- card 1: out of every enemy's sight this long -> Hidden
	sight_range = 3000,      -- enemies further than this aren't checked for line of sight
	exposed_time = 1.0,      -- an unsilenced shot breaks Hidden for this long
	hidden_range = 800,      -- while Hidden, enemies further than this can't acquire you
	hidden_range_ds = 600,
	front_dot = 0.5,         -- inside it: an enemy's forward 120 degrees
	point_blank = 200,       -- enemies this close always see you
	busy_range = 300,        -- an enemy busy with a teammate only turns to you this close (and facing you)
	backstab_mul = 2.5,      -- card 3
	backstab_mul_ds = 3.0,
	execute_ratio = 0.6,     -- non-specials under this share of health die to a backstab
	backshot = 0.25,         -- card 3: silenced shots into the back while Hidden
	backshot_ds = 0.35,
	disorient_range = 400,   -- card 5
	quiet_kills = 3,         -- card 5: this many silenced kills -> next backstab's disorient radius doubled
	slip_time = 3,           -- card 7
	slip_cooldown = 15,
	ghost_speed = 1.2,       -- card 9: speed burst after a backstab kill
	ghost_speed_time = 2
}
B.NET_ID = B.NET_ID or "GilzaDSBuffs"
local C = B.BURGLAR

function B.burglar_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == C.deck) then
		return 0
	end
	return st:get_specialization_value(C.deck, "tiers", "current_tier") or 0
end

local function peer_tier(peer)
	if not peer then return 0 end
	local session = managers.network and managers.network:session()
	if session and peer == session:local_peer() then
		return B.burglar_tier()
	end
	local skills = peer.unpacked_skills and peer:unpacked_skills()
	local spec = skills and skills.specializations
	if spec and tonumber(spec[1]) == C.deck then
		return tonumber(spec[2]) or 0
	end
	return 0
end
B.burglar_peer_tier = peer_tier

-- is this player unit (local or husk) on the Burglar deck? (used by PD:TH Police Tactics' snipers too)
function B.is_burglar_unit(unit)
	if not alive(unit) or not unit:base() then return false end
	if unit:base().is_local_player then return B.burglar_tier() >= 1 end
	local session = managers.network and managers.network:session()
	local peer = session and session:peer_by_unit(unit)
	return peer and peer_tier(peer) >= 1 or false
end

local function peer_by_id(id)
	local session = managers.network and managers.network:session()
	return session and id and session:peer(id)
end

local function host_modded()
	if Network:is_server() then return true end
	return B.host_has_mod and managers.network and B.host_has_mod == managers.network:session() and true or false
end

local function weapons_hot()
	local state = managers.groupai and managers.groupai:state()
	return state and state:enemy_weapons_hot() and true or false
end

local function game_t()
	return TimerManager:game():time()
end

-- Vanish (host side): attention objects of these units report nothing to enemies
B.burg_vanish = B.burg_vanish or {}
-- Silent kills (host side): these units are a low priority target
B.burg_weight = B.burg_weight or {}

function B.burglar_start_vanish(unit, duration)
	if not (Network:is_server() and alive(unit) and weapons_hot()) then return end
	B.burg_vanish[unit:key()] = game_t() + duration
	local handler = unit:movement() and unit:movement().attention_handler and unit:movement():attention_handler()
	if handler and handler._call_listeners then
		pcall(handler._call_listeners, handler)
	end
end

function B.burglar_start_silent(unit, duration)
	if not (Network:is_server() and alive(unit)) then return end
	B.burg_weight[unit:key()] = { unit = unit, until_t = game_t() + duration }
end

-- Vanish is now applied per enemy in targeting.lua (enemies within 5m still see the Burglar),
-- so the attention object itself stays untouched
local function wrap_get_attention(orig)
	return orig
end

-- enemies this close always see and shoot a Burglar, whatever the deck's stealth effects
C.close_range = 500
function B.burglar_vanished(unit)
	local e = alive(unit) and B.burg_vanish[unit:key()]
	return e and game_t() < e or false
end

if script == "lib/managers/playermanager" then
	B.burg_hidden = false
	B.burg_charge = 0

	function B.burglar_hidden()
		local now = Application:time()
		if now < (B.burg_exposed_until or 0) then return false end
		return B.burg_hidden or now < (B.burg_forced_until or 0) or B.burg_unseen or B.burg_interacting or false
	end

	-- out of sight of every enemy (cheap: a few rays every 0.25s)
	local function seen_by_enemy(unit)
		local mask = managers.slot:get_mask("AI_visibility")
		local head = unit:movement():m_head_pos()
		for _, data in pairs(managers.enemy:all_enemies() or {}) do
			local e = data.unit
			if alive(e) and e:character_damage() and not e:character_damage():dead() then
				local eh = e:movement() and e:movement():m_head_pos()
				if eh and mvector3.distance_sq(eh, head) < C.sight_range * C.sight_range then
					if not World:raycast("ray", eh, head, "slot_mask", mask, "ray_type", "ai_vision", "report") then
						return true
					end
				end
			end
		end
		return false
	end

	function B.burglar_patience_ratio()
		do return 0 end   -- (old card 9 "patience shot", replaced by Ghost in the rework)
		if B.burglar_tier() < 9 or not B.burg_hidden_since then return 0 end
		local from = math.max(B.burg_hidden_since, B.burg_patience_used or 0)
		return math.clamp((Application:time() - from) / C.patience_delay, 0, 1)
	end

	local orig_dodge = PlayerManager.skill_dodge_chance
	function PlayerManager:skill_dodge_chance(running, crouching, on_zipline, override_armor, ...)
		local chance = orig_dodge(self, running, crouching, on_zipline, override_armor, ...)
		if type(chance) ~= "number" or override_armor then return chance end
		local ok, tier = pcall(B.burglar_tier)
		if ok and tier >= 1 then
			if B.burglar_hidden() then
				chance = chance + (B.on and C.hidden_dodge_ds or C.hidden_dodge)
			end
			if Application:time() < (B.burg_fallback_until or 0) then
				chance = chance + C.vanish_fallback_dodge
			end
		end
		return chance
	end

	local HIDE_STATES = { standard = true, carry = true, bipod = true }

	local function update_hidden(now, dt)
		local tier = B.burglar_tier()
		local unit = managers.player:player_unit()
		if tier < 1 or not alive(unit) then
			B.burg_hidden, B.burg_charge, B.burg_hidden_since = false, 0, nil
			return
		end
		local mov = unit:movement()
		local state = mov and mov:current_state()
		local ok_state = HIDE_STATES[mov:current_state_name() or ""]
		local ducking = mov:crouching()
		local moving = state and state._moving
		local still = ok_state and (ducking or not moving) and not mov:running() and not mov:in_air()
		-- card 1: out of sight long enough also hides you (checked 4x a second)
		if now >= (B._burg_sight_t or 0) then
			B._burg_sight_t = now + 0.25
			local ok, seen = pcall(seen_by_enemy, unit)
			if ok and not seen then
				B._burg_unseen_since = B._burg_unseen_since or now
			else
				B._burg_unseen_since = nil
			end
			B.burg_unseen = B._burg_unseen_since and now - B._burg_unseen_since >= C.sight_delay or false
		end
		-- card 7: drilling / bagging / hacking keeps you Hidden
		B.burg_interacting = tier >= 7 and state and state._interacting and state:_interacting() and true or false
		if now < (B.burg_exposed_until or 0) then still = false end
		if still then
			B.burg_charge = B.burg_charge + dt
			if B.burg_charge >= C.hidden_delay and not B.burg_hidden then
				B.burg_hidden = true
				B.burg_hidden_since = now
			end
		else
			B.burg_charge = 0
			B.burg_hidden = false
			if now >= (B.burg_forced_until or 0) then
				B.burg_hidden_since = nil
			end
		end
		if not B.burg_hidden and now < (B.burg_forced_until or 0) then
			B.burg_hidden_since = B.burg_hidden_since or now
		end
		-- tell the host when the Hidden state changes (enemy targeting runs there)
		local hid = B.burglar_hidden()
		if hid and not B._burg_prev_hid and tier >= 9 then B.burg_ghost_ready = true end   -- card 9: next melee is a backstab
		B._burg_prev_hid = hid
		if hid ~= B._burg_sent_hid or now >= (B._burg_sent_t or 0) then
			B._burg_sent_hid, B._burg_sent_t = hid, now + 2
			if Network:is_server() then
				B.burg_hidden_units = B.burg_hidden_units or {}
				B.burg_hidden_units[unit:key()] = hid or nil
			elseif B.burglar_send_host then
				B.burglar_send_host("bhide:" .. (hid and 1 or 0))
			end
		end
		-- card 9: heal while Hidden (Burglar has no armor to fall back on)
		if tier >= 9 and B.burglar_hidden() and now >= (B._burg_regen_t or 0) then
			B._burg_regen_t = now + 1
			local dmg = unit:character_damage()
			if dmg and not dmg:is_downed() and dmg.restore_health then
				dmg:restore_health(B.on and C.hidden_regen_ds or C.hidden_regen)
			end
		end
	end

	local function set_base_mul(unit, crouched)
		local base = unit:base()
		if not (base and base.set_suspicion_multiplier and base.set_detection_multiplier) then return end
		local want = crouched and C.crouch_detect or 1
		if base._gdsb_burg_mul == want then return end
		base._gdsb_burg_mul = want
		base:set_suspicion_multiplier("gdsb_burglar", want)
		base:set_detection_multiplier("gdsb_burglar", want)
	end

	local function apply_weight(unit, factor)
		local mov = unit:movement()
		local handler = mov and mov.attention_handler and mov:attention_handler()
		local data = handler and handler._attention_data
		if not data then return end
		for _, setting in pairs(data) do
			if type(setting) == "table" and setting._gdsb_f ~= factor then
				if setting._gdsb_base == nil then
					setting._gdsb_base = setting.weight_mul or false
				end
				local base = setting._gdsb_base or nil
				if factor == 1 then
					setting.weight_mul = base
					setting._gdsb_base = nil
					setting._gdsb_f = nil
				else
					setting.weight_mul = (base or 1) * factor
					setting._gdsb_f = factor
				end
			end
		end
	end

	local function update_host()
		if not Network:is_server() then return end
		local session = managers.network and managers.network:session()
		if not session then return end
		-- crouch detection for every Burglar in the lobby
		local me = managers.player:player_unit()
		if alive(me) then
			set_base_mul(me, B.burglar_tier() >= 1 and me:movement():crouching())
		end
		for _, peer in pairs(session:peers() or {}) do
			local u = peer:unit()
			if alive(u) then
				local mov = u:movement()
				local crouched = mov and (mov._pose_code == 2 or (u:anim_data() and u:anim_data().crouch)) or false
				set_base_mul(u, peer_tier(peer) >= 1 and crouched)
			end
		end
		-- silent kill target priority (read by targeting.lua)
		local now = game_t()
		for key, w in pairs(B.burg_weight) do
			if not alive(w.unit) or now >= w.until_t then
				B.burg_weight[key] = nil
			end
		end
		for key, e in pairs(B.burg_vanish) do
			if now >= e then B.burg_vanish[key] = nil end
		end
	end

	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_burglar_update", function(t, dt)
		local now = Application:time()
		local last = B._burg_last or now
		B._burg_last = now
		local step = math.min(math.max(now - last, 0), 0.5)
		pcall(update_hidden, now, step)
		if now >= (B._burg_host_next or 0) then
			B._burg_host_next = now + 0.2
			local ok, err = pcall(update_host)
			if not ok and not B._burg_err then
				B._burg_err = true
				log("[Gilza DS Perk Buffs] Burglar update error: " .. tostring(err))
			end
		end
	end)

	-- client -> host requests
	if LuaNetworking and LuaNetworking.AddReceiveHook then
		LuaNetworking:AddReceiveHook(B.NET_ID, "GilzaDSBuffs_burglar_net", function(data, sender) pcall(function()
			if not Network:is_server() or type(data) ~= "string" then return end
			local kind, value = string.match(data, "^(b%a+):([%d%.]+)$")
			if not kind then return end
			local peer = peer_by_id(tonumber(sender))
			local unit = peer and peer:unit()
			if not alive(unit) then return end
			local tier = peer_tier(peer)
			local dur = math.min(tonumber(value) or 0, 5)
			if kind == "bhide" and tier >= 1 then
				B.burg_hidden_units = B.burg_hidden_units or {}
				B.burg_hidden_units[unit:key()] = (tonumber(value) or 0) > 0 or nil
			elseif kind == "bvanish" and tier >= 7 then
				B.burglar_start_vanish(unit, dur)
			elseif kind == "bsilent" and tier >= 5 then
				B.burglar_start_silent(unit, dur)
			end
		end) end)
	end

	function B.burglar_send_host(msg)
		if LuaNetworking and not Network:is_server() then
			pcall(LuaNetworking.SendToPeer, LuaNetworking, 1, B.NET_ID, msg)
		end
	end

	function B.burglar_on_silent_kill()
		if B.burglar_tier() < 5 then return end
		B.burg_quiet = math.min((B.burg_quiet or 0) + 1, C.quiet_kills)
		local now = Application:time()
		if now < (B._burg_silent_cd or 0) then return end
		B._burg_silent_cd = now + C.silent_cooldown
		B.burg_forced_until = Application:time() + C.silent_time
		if not weapons_hot() then return end
		if Network:is_server() then
			B.burglar_start_silent(managers.player:player_unit(), C.silent_time)
			B.burg_silent_until = Application:time() + C.silent_time
		elseif host_modded() then
			B.burglar_send_host("bsilent:" .. C.silent_time)
			B.burg_silent_until = Application:time() + C.silent_time
		end
	end

	function B.burglar_on_armor_break()
		if B.burglar_tier() < 7 or not weapons_hot() then return end
		local now = Application:time()
		if now < (B.burg_vanish_ready or 0) then return end
		B.burg_vanish_ready = now + C.slip_cooldown
		local dur = B.on and C.vanish_time_ds or C.slip_time
		B.burg_vanish_until = now + dur
		B.burg_forced_until = math.max(B.burg_forced_until or 0, now + dur)   -- Slip Away: Hidden even while moving
		if Network:is_server() then
			B.burglar_start_vanish(managers.player:player_unit(), dur)
		elseif host_modded() then
			B.burglar_send_host("bvanish:" .. dur)
		else
			B.burg_fallback_until = now + dur
		end
		local unit = managers.player:player_unit()
		if alive(unit) and unit:sound() then
			unit:sound():play("perkdeck_activate", nil, false)
		end
	end

	-- an unsilenced shot gives you away for a moment
	function B.burglar_on_fire(silenced)
		if silenced or B.burglar_tier() < 1 then return end
		B.burg_exposed_until = Application:time() + C.exposed_time
		B.burg_charge, B.burg_hidden = 0, false
		B._burg_unseen_since, B.burg_unseen = nil, false
	end

	-- card 9: speed burst after a backstab kill
	local orig_speed = PlayerManager.movement_speed_multiplier
	function PlayerManager:movement_speed_multiplier(...)
		local m = orig_speed(self, ...)
		if type(m) == "number" and Application:time() < (B.burg_speed_until or 0) then m = m * C.ghost_speed end
		return m
	end

	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_burglar_reset", function()
		local session = managers.network and managers.network:session()
		if B._burg_session ~= session then
			B._burg_session = session
			B.burg_vanish, B.burg_weight, B.burg_hidden_units = {}, {}, {}
			B.burg_quiet, B.burg_exposed_until, B.burg_speed_until = 0, nil, nil
			B.burg_forced_until, B.burg_vanish_until, B.burg_vanish_ready, B.burg_fallback_until, B.burg_patience_used = nil, nil, nil, nil, nil
		end
	end)

elseif script == "lib/units/beings/player/playerdamage" then
	-- Burglar wears no armor at all: they live on dodge, stealth and Vanish
	local orig_max_armor = PlayerDamage._max_armor
	function PlayerDamage:_max_armor(...)
		-- the real deck only (Copycat's Mimicry copies cards 1 and 3 but keeps its armor)
		local st = managers.skilltree
		if st and st:get_specialization_value("current_specialization") == C.deck then return 0 end
		return orig_max_armor(self, ...)
	end

	-- with no armor to break, Vanish triggers when you lose health instead
	Hooks:PreHook(PlayerDamage, "_calc_health_damage", "GilzaDSBuffs_burglar_hp_pre", function(self)
		B._burg_pre_hp = self:get_real_health()
	end)
	Hooks:PostHook(PlayerDamage, "_calc_health_damage", "GilzaDSBuffs_burglar_hp_post", function(self)
		local before = B._burg_pre_hp
		B._burg_pre_hp = nil
		if before and self:get_real_health() < before and B.burglar_on_armor_break then
			pcall(B.burglar_on_armor_break)
		end
	end)

	Hooks:PreHook(PlayerDamage, "_calc_armor_damage", "GilzaDSBuffs_burglar_pre", function(self)
		B._burg_pre_armor = self:get_real_armor()
	end)
	Hooks:PostHook(PlayerDamage, "_calc_armor_damage", "GilzaDSBuffs_burglar_post", function(self)
		local before = B._burg_pre_armor
		B._burg_pre_armor = nil
		if before and before > 0 and self:get_real_armor() <= 0 and B.burglar_on_armor_break then
			pcall(B.burglar_on_armor_break)
		end
	end)

elseif script == "lib/units/enemies/cop/copdamage" then
	-- is the attacker outside this enemy's forward cone? dot of its facing with the direction to the attacker
	local function facing_dot(self, player)
		local mov = self._unit:movement()
		local rot = mov and mov.m_rot and mov:m_rot()
		if not rot then return 1 end
		local fwd = rot:y()
		local to = player:position() - self._unit:position()
		mvector3.set_z(to, 0); mvector3.normalize(to)
		local f = Vector3(fwd.x, fwd.y, 0); mvector3.normalize(f)
		return mvector3.dot(f, to)
	end
	local function targeting_me(self, player)
		local mov = self._unit:movement()
		local att = mov and mov.attention and mov:attention()
		return att and att.unit == player
	end
	local function is_heavy(self)
		local base = self._unit:base()
		if not base then return false end
		if base.has_tag and (base:has_tag("tank") or base:has_tag("captain")) then return true end
		local td = tweak_data.character[base._tweak_table]
		return td and td.immune_to_concussion or false
	end
	local function is_special(self)
		local base = self._unit:base()
		return base and base.has_tag and base:has_tag("special") or false
	end

	-- card 3 / 9: is this melee hit a backstab?
	local function backstab(self, player, tier)
		if tier >= 9 and B.burg_ghost_ready then return true, true end      -- first melee from Hidden: any angle
		local d = facing_dot(self, player)
		if d < 0 then return true end
		return d < C.front_dot and not targeting_me(self, player)
	end

	local function bonus(self, attack_data, ranged)
		if not attack_data or type(attack_data.damage) ~= "number" then return end
		local player = managers.player and managers.player:player_unit()
		if not (alive(player) and attack_data.attacker_unit == player) then return end
		local tier = B.burglar_tier()
		if tier < 3 then return end
		if ranged then
			-- silenced back-shots while Hidden
			local wpn = attack_data.weapon_unit
			local base = alive(wpn) and wpn:base()
			local silenced = base and base.got_silencer and base:got_silencer()
			if silenced and B.burglar_hidden and B.burglar_hidden() and facing_dot(self, player) < C.front_dot then
				attack_data.damage = attack_data.damage * (1 + (B.on and C.backshot_ds or C.backshot))
			end
			return
		end
		local bs, ghost = backstab(self, player, tier)
		if not bs then return end
		if ghost then B.burg_ghost_ready = false end
		self._gdsb_backstab = true
		attack_data.armor_piercing = true
		attack_data.damage = attack_data.damage * (B.on and C.backstab_mul_ds or C.backstab_mul)
		-- executes: regular enemies already worn down die outright
		local hp, init = self._health, self._HEALTH_INIT
		if hp and init and init > 0 and not is_special(self) and not is_heavy(self) and hp / init < C.execute_ratio then
			attack_data.damage = math.max(attack_data.damage, hp * 4)
		end
	end

	local function stun(enemy, player)
		local dmg = alive(enemy) and enemy:character_damage()
		if not (dmg and dmg.stun_hit and not dmg:dead()) then return end
		local base = enemy:base()
		local td = base and tweak_data.character[base._tweak_table]
		if td and td.immune_to_concussion then return end
		if base and base.has_tag and (base:has_tag("tank") or base:has_tag("captain")) then return end
		local pos = enemy:movement() and enemy:movement():m_head_pos() or enemy:position()
		local dir = pos - player:position(); mvector3.normalize(dir)
		pcall(dmg.stun_hit, dmg, { variant = "stun", attacker_unit = player, col_ray = { position = pos, ray = dir }, damage = 0 })
	end

	-- after a backstab: stagger the target (card 3), concuss everyone around it (card 5), refresh Hidden (card 9)
	local function after_backstab(self)
		local player = managers.player:player_unit()
		if not alive(player) then return end
		local tier = B.burglar_tier()
		if not self._dead then stun(self._unit, player) end
		if tier >= 5 then
			local r = C.disorient_range
			if (B.burg_quiet or 0) >= C.quiet_kills then r = r * 2; B.burg_quiet = 0 end
			local mask = managers.slot:get_mask("enemies")
			for _, u in ipairs(World:find_units_quick("sphere", self._unit:position(), r, mask) or {}) do
				if u ~= self._unit then stun(u, player) end
			end
		end
		if self._dead and tier >= 9 then
			local now = Application:time()
			B.burg_forced_until = math.max(B.burg_forced_until or 0, now + 1.5)
			B.burg_speed_until = now + C.ghost_speed_time
		end
	end

	Hooks:PreHook(CopDamage, "damage_bullet", "GilzaDSBuffs_burglar_bullet", function(self, attack_data)
		self._gdsb_burg_alive = not self._dead
		pcall(bonus, self, attack_data, true)
	end)
	Hooks:PreHook(CopDamage, "damage_melee", "GilzaDSBuffs_burglar_melee", function(self, attack_data)
		self._gdsb_backstab = nil
		pcall(bonus, self, attack_data, false)
	end)
	Hooks:PostHook(CopDamage, "damage_melee", "GilzaDSBuffs_burglar_melee_post", function(self)
		if not self._gdsb_backstab then return end
		self._gdsb_backstab = nil
		pcall(after_backstab, self)
	end)

	Hooks:PostHook(CopDamage, "damage_bullet", "GilzaDSBuffs_burglar_silent", function(self, attack_data)
		local was_alive = self._gdsb_burg_alive
		self._gdsb_burg_alive = nil
		if not (was_alive and self._dead and attack_data) then return end
		pcall(function()
			local player = managers.player:player_unit()
			if attack_data.attacker_unit ~= player then return end
			local wpn = attack_data.weapon_unit
			local base = alive(wpn) and wpn:base()
			if base and base.got_silencer and base:got_silencer() and B.burglar_on_silent_kill then
				B.burglar_on_silent_kill()
			end
		end)
	end)

elseif script == "lib/units/weapons/newraycastweaponbase" then
	-- an unsilenced shot breaks Hidden for a moment
	Hooks:PostHook(NewRaycastWeaponBase, "fire", "GilzaDSBuffs_burglar_fire", function(self)
		pcall(function()
			local user = self._setup and self._setup.user_unit
			if not (alive(user) and user == managers.player:player_unit() and B.burglar_on_fire) then return end
			B.burglar_on_fire(self.got_silencer and self:got_silencer() or false)
		end)
	end)

elseif script == "lib/units/contourext" then
	local orig_add = ContourExt.add
	function ContourExt:add(type_name, sync, multiplier, ...)
		if sync and type(type_name) == "string" and string.sub(type_name, 1, 5) == "mark_" then
			local ok, tier = pcall(B.burglar_tier)
			if ok and tier >= 3 then
				multiplier = (multiplier or 1) * C.mark_mul
			end
		end
		return orig_add(self, type_name, sync, multiplier, ...)
	end

elseif script == "lib/units/equipment/ecm_jammer/ecmjammerbase" then
	local function extend(self, peer_id)
		if self._gdsb_burg_ecm then return end
		if peer_tier(peer_by_id(peer_id)) < 5 then return end
		self._gdsb_burg_ecm = true
		self._max_battery_life = (self._max_battery_life or 0) * C.ecm_mul
		self._battery_life = self._max_battery_life
		self._duration_multiplier = (self._duration_multiplier or 1) * C.ecm_mul
	end
	Hooks:PostHook(ECMJammerBase, "setup", "GilzaDSBuffs_burglar_ecm", function(self)
		pcall(extend, self, self._owner_id)
	end)
	Hooks:PostHook(ECMJammerBase, "sync_setup", "GilzaDSBuffs_burglar_ecm_sync", function(self, upgrade_lvl, peer_id)
		pcall(extend, self, peer_id)
	end)

elseif script == "lib/units/props/aiattentionobject" then
	B._orig_get_attention = B._orig_get_attention or AIAttentionObject.get_attention
	AIAttentionObject.get_attention = wrap_get_attention(B._orig_get_attention)

elseif script == "lib/units/characters/characterattentionobject" then
	local own = rawget(CharacterAttentionObject, "get_attention")
	if own and own ~= AIAttentionObject.get_attention then
		CharacterAttentionObject.get_attention = wrap_get_attention(own)
	elseif not own and B._orig_get_attention then
		CharacterAttentionObject.get_attention = AIAttentionObject.get_attention
	end
end
