GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

B.BIKER = {
	deck = 16,
	road_rage = 0.04,
	road_rage_ds = 0.05,
	chopper = 0.03,
	colors_slots = 3,
	colors = 0.10,
	colors_ds = 0.15,
	burnout = 0.25,
	burnout_time = 3,
	burnout_cd = 10,
	-- (7.24) Rust's signature (card 9, only as Rust): Ride or Die - reaching max Momentum starts 8 s of Ride or Die:
	-- 20% faster, 25% more damage, kills restore 5 health and 5 armor; once every 20 s
	ride_time = 8, ride_every = 20, ride_speed = 1.2, ride_damage = 0.25, ride_health = 0.5, ride_armor = 0.5
}
local C = B.BIKER

-- (7.24) Rust's Ride or Die running?
function B.biker_ride()
	return Application:time() < (B.biker_ride_until or 0)
end

function B.biker_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == C.deck) then
		return 0
	end
	return st:get_specialization_value(C.deck, "tiers", "current_tier") or 0
end

function B.biker_max_slots()
	return tweak_data and tweak_data.upgrades and tweak_data.upgrades.wild_max_triggers_per_time or 4
end

-- Momentum: kills by you or your crew in the last 4 seconds, up to 4.
-- Tracked separately from the Regeneration slots, which only fill when a stack actually heals.
B.biker_kills = B.biker_kills or {}
function B.biker_slots()
	local now, n = Application:time(), 0
	for i = #B.biker_kills, 1, -1 do
		if B.biker_kills[i] <= now then
			table.remove(B.biker_kills, i)
		else
			n = n + 1
		end
	end
	return math.min(n, B.biker_max_slots())
end

local function add_kill()
	local window = tweak_data and tweak_data.upgrades and tweak_data.upgrades.wild_trigger_time or 4
	B.biker_slots()
	table.insert(B.biker_kills, Application:time() + window)
	while #B.biker_kills > B.biker_max_slots() do
		table.remove(B.biker_kills, 1)
	end
end

function B.biker_burnout()
	return Application:time() < (B.biker_burnout_until or 0)
end

if script == "lib/managers/playermanager" then
	-- every kill feeds Momentum; Burnout: reaching max Momentum gives a damage burst
	local orig_wild = PlayerManager.chk_wild_kill_counter
	function PlayerManager:chk_wild_kill_counter(...)
		local before = B.biker_slots()
		local r = orig_wild(self, ...)
		pcall(function()
			if B.biker_tier() < 1 then return end
			add_kill()
			if B.biker_tier() < 9 then return end
			local now = Application:time()
			local reached = before < B.biker_max_slots() and B.biker_slots() >= B.biker_max_slots()
			if reached and now >= (B.biker_burnout_ready or 0) then
				B.biker_burnout_until = now + C.burnout_time
				B.biker_burnout_ready = now + C.burnout_cd
			end
			-- (7.24) Rust's Ride or Die
			if reached and not B.biker_ride() and now >= (B.biker_ride_ready or 0) and B.sig_active and B.sig_active(C.deck) then
				B.biker_ride_until = now + C.ride_time
				B.biker_ride_ready = now + C.ride_every
				local unit = self:player_unit()
				if alive(unit) and unit:sound() then unit:sound():play("perkdeck_activate", nil, false) end
				B.sig_live("ride or die", "max Momentum: Ride or Die for %d seconds", C.ride_time)
			end
		end)
		return r
	end

	-- (7.24) Rust's Ride or Die: kills restore health and armor
	Hooks:PostHook(PlayerManager, "on_killshot", "GilzaDSBuffs_biker_ride", function(self)
		pcall(function()
			if not B.biker_ride() then return end
			local unit = self:player_unit()
			local dmg = alive(unit) and unit:character_damage()
			if not dmg or dmg:need_revive() or dmg:dead() then return end
			dmg:restore_health(C.ride_health, true)
			dmg:restore_armor(C.ride_armor)
			B.sig_live("ride or die kill", "a kill during Ride or Die: +%d health, +%d armor", C.ride_health * 10, C.ride_armor * 10)
		end)
	end)

	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_biker_reset", function()
		local session = managers.network and managers.network:session()
		if B._biker_session ~= session then
			B._biker_session = session
			B.biker_ride_until, B.biker_ride_ready = nil, nil
		end
	end)

	-- Colors: less damage at 3+ Momentum
	local orig_resist = PlayerManager.damage_reduction_skill_multiplier
	function PlayerManager:damage_reduction_skill_multiplier(...)
		local m = orig_resist(self, ...)
		if type(m) ~= "number" then return m end
		local ok, tier = pcall(B.biker_tier)
		if ok and tier >= 7 and B.biker_slots() >= C.colors_slots then
			m = m * (1 - (B.on and C.colors_ds or C.colors))
		end
		return m
	end

	-- Chopper: faster per Momentum
	local orig_speed = PlayerManager.movement_speed_multiplier
	function PlayerManager:movement_speed_multiplier(...)
		local m = orig_speed(self, ...)
		if type(m) == "number" then
			local ok, tier = pcall(B.biker_tier)
			if ok and tier >= 5 then
				m = m * (1 + C.chopper * B.biker_slots())
			end
			-- (7.24) Rust's Ride or Die
			if ok and tier >= 9 and B.biker_ride() then
				m = m * C.ride_speed
			end
		end
		return m
	end

elseif script == "lib/units/enemies/cop/copdamage" then
	-- Road Rage (+damage per Momentum) and Burnout
	local function bonus(self, attack_data)
		if not attack_data or type(attack_data.damage) ~= "number" then return end
		local player = managers.player and managers.player:player_unit()
		if not (alive(player) and attack_data.attacker_unit == player) then return end
		local tier = B.biker_tier()
		if tier < 3 then return end
		local mul = 1 + B.biker_slots() * (B.on and C.road_rage_ds or C.road_rage)
		if tier >= 9 and B.biker_burnout() then mul = mul + C.burnout end
		if tier >= 9 and B.biker_ride() then mul = mul + C.ride_damage end   -- (7.24) Rust's Ride or Die
		if mul ~= 1 then attack_data.damage = attack_data.damage * mul end
	end
	for _, fn in ipairs({ "damage_bullet", "damage_melee" }) do
		Hooks:PreHook(CopDamage, fn, "GilzaDSBuffs_biker_" .. fn, function(self, attack_data)
			pcall(bonus, self, attack_data)
		end)
	end
end
