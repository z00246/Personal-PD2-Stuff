GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

-- Muscle: Rage. 2026-10-24 rework (Geo: "a bit underwhelming"): Rage builds twice as fast and from armor damage too,
-- kills keep it from decaying, and Unstoppable (card 9) comes at 8 Rage, lasts longer and also stops tasers and Cloaker
-- kicks.
B.MUSCLE = {
	deck = 2,
	stack_per_health = 0.05,   -- 1 stack per 5% of max health lost (was 10%)
	stack_per_armor = 0.10,    -- 1 stack per 10% of max armor lost (new)
	max_stacks = 10,
	max_stacks_ds = 12,
	damage_per_stack = { [1] = 0.03, [7] = 0.05 },
	resist_at = 5,
	resist = 0.15,
	kill_heal_at = 5,
	kill_heal = 0.03,
	decay_after = 4,           -- seconds without losing health or killing
	decay_every = 2,
	unstoppable_at = 8,        -- was "max Rage"
	unstoppable_time = 5,      -- was 4
	unstoppable_resist = 0.5,
	unstoppable_cooldown = 25  -- was 20 (the card said 30)
}
B.rage = 0

function B.muscle_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == B.MUSCLE.deck) then
		return 0
	end
	return st:get_specialization_value(B.MUSCLE.deck, "tiers", "current_tier") or 0
end

local function max_stacks()
	return B.on and B.MUSCLE.max_stacks_ds or B.MUSCLE.max_stacks
end

local function per_stack(tier)
	return tier >= 7 and B.MUSCLE.damage_per_stack[7] or B.MUSCLE.damage_per_stack[1]
end

function B.muscle_unstoppable()
	return Application:time() < (B._unstoppable_until or 0)
end

local function check_unstoppable(now)
	if B.rage >= B.MUSCLE.unstoppable_at and B.muscle_tier() >= 9 and now >= (B._unstoppable_ready or 0) then
		B._unstoppable_until = now + B.MUSCLE.unstoppable_time
		B._unstoppable_ready = now + B.MUSCLE.unstoppable_cooldown
		local unit = managers.player:player_unit()
		if alive(unit) then unit:sound():play("perkdeck_activate", nil, false) end
	end
end

-- lost / max of health ("health") or armor ("armor") -> Rage stacks
function B.muscle_add_rage(lost, max, kind)
	if B.muscle_tier() < 1 or not max or max <= 0 or not lost or lost <= 0 then return end
	local per = kind == "armor" and B.MUSCLE.stack_per_armor or B.MUSCLE.stack_per_health
	local carry_key = kind == "armor" and "_rage_carry_armor" or "_rage_carry"
	B[carry_key] = (B[carry_key] or 0) + lost / max
	local gained = math.floor(B[carry_key] / per)
	if gained > 0 then
		B[carry_key] = B[carry_key] - gained * per
		B.rage = math.min(B.rage + gained, max_stacks())
	end
	local now = Application:time()
	B._rage_hit_t = now
	B._rage_decay_t = now + B.MUSCLE.decay_after
	check_unstoppable(now)
end

if script == "lib/managers/playermanager" then
	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_muscle_decay", function()
		if (B.rage or 0) <= 0 then return end
		local now = Application:time()
		local unit = managers.player and managers.player:player_unit()
		if not alive(unit) or unit:character_damage():dead() then
			B.rage, B._rage_carry, B._rage_carry_armor = 0, 0, 0
			return
		end
		if now >= (B._rage_decay_t or 0) then
			B.rage = math.max(B.rage - 1, 0)
			B._rage_decay_t = now + B.MUSCLE.decay_every
		end
	end)

	local orig_resist = PlayerManager.damage_reduction_skill_multiplier
	function PlayerManager:damage_reduction_skill_multiplier(...)
		local m = orig_resist(self, ...)
		if type(m) ~= "number" then return m end
		local ok, tier = pcall(B.muscle_tier)
		if not ok or tier < 1 then return m end
		if tier >= 3 and B.rage >= B.MUSCLE.resist_at then
			m = m * (1 - B.MUSCLE.resist)
		end
		if B.muscle_unstoppable() then
			m = m * (1 - B.MUSCLE.unstoppable_resist)
		end
		return m
	end

	Hooks:PostHook(PlayerManager, "on_killshot", "GilzaDSBuffs_muscle_kill", function(self)
		local tier = B.muscle_tier()
		if tier < 1 then return end
		-- kills keep Rage from decaying
		if (B.rage or 0) > 0 then
			B._rage_decay_t = math.max(B._rage_decay_t or 0, Application:time() + B.MUSCLE.decay_after)
		end
		if tier < 5 or B.rage < B.MUSCLE.kill_heal_at then return end
		local unit = self:player_unit()
		local dmg = alive(unit) and unit:character_damage()
		if dmg and not dmg:dead() and not dmg:need_revive() then
			dmg:restore_health(B.MUSCLE.kill_heal, false)
		end
	end)

elseif script == "lib/units/beings/player/playerdamage" then
	local orig_health = PlayerDamage._calc_health_damage
	function PlayerDamage:_calc_health_damage(attack_data, ...)
		local lost = orig_health(self, attack_data, ...)
		if type(lost) == "number" and lost > 0 then
			pcall(B.muscle_add_rage, lost, self:_max_health(), "health")
		end
		return lost
	end

	local orig_armor = PlayerDamage._calc_armor_damage
	function PlayerDamage:_calc_armor_damage(attack_data, ...)
		local lost = orig_armor(self, attack_data, ...)
		if type(lost) == "number" and lost > 0 then
			pcall(B.muscle_add_rage, lost, self:_max_armor(), "armor")
		end
		return lost
	end

	-- Unstoppable: tasers can't hold you (same as the game's own god mode check)
	local orig_tase = PlayerDamage.damage_tase
	function PlayerDamage:damage_tase(attack_data, ...)
		if B.muscle_unstoppable and B.muscle_unstoppable() then return end
		return orig_tase(self, attack_data, ...)
	end
	local orig_can_tase = PlayerDamage.can_be_tased
	if orig_can_tase then
		function PlayerDamage:can_be_tased(...)
			if B.muscle_unstoppable and B.muscle_unstoppable() then return false end
			return orig_can_tase(self, ...)
		end
	end

elseif script == "lib/units/beings/player/playermovement" then
	-- Unstoppable: Cloaker kicks don't take you down, tasers don't try
	local orig_spooc = PlayerMovement.on_SPOOCed
	function PlayerMovement:on_SPOOCed(enemy_unit, ...)
		if B.muscle_unstoppable and B.muscle_unstoppable() then return end
		return orig_spooc(self, enemy_unit, ...)
	end
	local orig_spooc_ok = PlayerMovement.is_SPOOC_attack_allowed
	function PlayerMovement:is_SPOOC_attack_allowed(...)
		if B.muscle_unstoppable and B.muscle_unstoppable() then return false end
		return orig_spooc_ok(self, ...)
	end
	local orig_taser_ok = PlayerMovement.is_taser_attack_allowed
	function PlayerMovement:is_taser_attack_allowed(...)
		if B.muscle_unstoppable and B.muscle_unstoppable() then return false end
		return orig_taser_ok(self, ...)
	end

elseif script == "lib/units/enemies/cop/copdamage" then
	local function rage_bonus(attack_data)
		if not attack_data or type(attack_data.damage) ~= "number" or (B.rage or 0) <= 0 then return end
		local player = managers.player and managers.player:player_unit()
		if not (alive(player) and attack_data.attacker_unit == player) then return end
		local tier = B.muscle_tier()
		if tier < 1 then return end
		attack_data.damage = attack_data.damage * (1 + B.rage * per_stack(tier))
	end
	for _, fn in ipairs({ "damage_bullet", "damage_melee" }) do
		Hooks:PreHook(CopDamage, fn, "GilzaDSBuffs_muscle_" .. fn, function(self, attack_data)
			pcall(rage_bonus, attack_data)
		end)
	end
end
