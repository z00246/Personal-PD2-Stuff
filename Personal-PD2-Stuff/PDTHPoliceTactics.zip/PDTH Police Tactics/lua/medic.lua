if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics
local orig = MedicDamage.is_available_for_healing

function MedicDamage:is_available_for_healing(requesting_unit, ...)
	local ok = orig(self, requesting_unit, ...)
	if not ok or not T.active() or T.has_tag(requesting_unit, "tank") then
		return ok
	end
	local res = true
	pcall(function()
		local my_pos = self._unit:movement():m_pos()
		local r_sq = self:get_healing_radius_sq()
		for _, u_data in pairs(managers.groupai:state()._police or {}) do
			local u = u_data.unit
			if u ~= requesting_unit and alive(u) and T.has_tag(u, "tank") and not u:character_damage():dead()
				and mvector3.distance_sq(my_pos, u:movement():m_pos()) <= r_sq then
				res = false
				return
			end
		end
	end)
	return res
end

-- Medics need line of sight to heal (Restoration): no more healing through walls and floors
local orig_verify = MedicDamage.verify_heal_requesting_unit
function MedicDamage:verify_heal_requesting_unit(requesting_unit, ...)
	if not orig_verify(self, requesting_unit, ...) then return false end
	if not T.active() then return true end
	local ok, blocked = pcall(function()
		local from = requesting_unit:movement():m_head_pos()
		local to = self._unit:movement():m_head_pos()
		return World:raycast("ray", from, to, "slot_mask", managers.slot:get_mask("AI_visibility"), "report") and true or false
	end)
	return not (ok and blocked)
end

-- A Medic that heals someone glows green for 2 seconds so you can find it
-- (synced, so everyone sees it, modded or not)
Hooks:PostHook(MedicDamage, "heal_unit", "PDTHTactics_medic_reveal", function(self)
	if not (T.active() and Network:is_server()) then return end
	pcall(function()
		if not self._dead and self._unit:contour() then
			self._unit:contour():add("medic_heal", true)
		end
	end)
end)
