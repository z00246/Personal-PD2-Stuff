if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics

local WALL_RANGE = 900
local SPACING = 115
local ANCHOR_LIFE = 4

T.wall_anchor = T.wall_anchor or {}

local function nearby_shields(data)
	local state = managers.groupai:state()
	local list = {}
	for u_key, u_data in pairs(state._police or {}) do
		local u = u_data.unit
		if alive(u) and T.has_tag(u, "shield") and not u:character_damage():dead()
			and mvector3.distance(u_data.m_pos, data.m_pos) < WALL_RANGE then
			table.insert(list, { key = tostring(u_key), unit = u, pos = u_data.m_pos })
		end
	end
	return list
end

local function form_wall(data, my_data)
	local focus = data.attention_obj
	if not (my_data.optimal_pos and focus and focus.m_pos) then return end
	local shields = nearby_shields(data)
	local my_key = tostring(data.key)
	if #shields < 2 then
		T.wall_anchor[my_key] = nil
		return
	end

	table.sort(shields, function(a, b) return a.key < b.key end)
	local leader = shields[1].key
	local t = data.t
	local anchor
	if leader == my_key then
		local dir = focus.m_pos - my_data.optimal_pos
		mvector3.set_z(dir, 0)
		mvector3.normalize(dir)
		anchor = { pos = mvector3.copy(my_data.optimal_pos), dir = dir, t = t }
		T.wall_anchor[my_key] = anchor
	else
		anchor = T.wall_anchor[leader]
		if not anchor or t - anchor.t > ANCHOR_LIFE then return end
	end

	local side = Vector3()
	mvector3.cross(side, anchor.dir, math.UP)
	table.sort(shields, function(a, b)
		return mvector3.dot(a.pos - anchor.pos, side) < mvector3.dot(b.pos - anchor.pos, side)
	end)
	local n, slot = #shields, 1
	for i, s in ipairs(shields) do
		if s.key == my_key then slot = i break end
	end

	local pos = mvector3.copy(side)
	mvector3.multiply(pos, (slot - (n + 1) / 2) * SPACING)
	mvector3.add(pos, anchor.pos)
	mvector3.set_z(pos, my_data.optimal_pos.z)
	my_data.optimal_pos = pos
	my_data.pdth_in_wall = true
end

Hooks:PostHook(ShieldLogicAttack, "_upd_enemy_detection", "PDTHTactics_shield_wall", function(data)
	local my_data = data.internal_data
	if not (my_data and T.active()) then return end
	my_data.pdth_in_wall = nil
	form_wall(data, my_data)
end)
