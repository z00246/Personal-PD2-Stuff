if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

PDTHTactics.set_client(HuskCopBrain, "_ENABLE_LASER_TIME", 0.3)
