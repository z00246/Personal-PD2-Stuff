if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics
local orig = MedicDamage.is_available_for_healing

function MedicDamage:is_available_for_healing(requesting_unit, ...)
	local ok = orig(self, requesting_unit, ...)
	if not ok or not T.active() or T.has_tag(requesting_unit, "tank") then
		return ok
	end
	local res = true
	pcall(function()
		local my_pos = self._unit:movement():m_pos()
		local r_sq = self:get_healing_radius_sq()
		for _, u_data in pairs(managers.groupai:state()._police or {}) do
			local u = u_data.unit
			if u ~= requesting_unit and alive(u) and T.has_tag(u, "tank") and not u:character_damage():dead()
				and mvector3.distance_sq(my_pos, u:movement():m_pos()) <= r_sq then
				res = false
				return
			end
		end
	end)
	return res
end
