if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics

-- Restoration-style Cloakers:
--  * they think every frame instead of every so often, so they react and charge right away
--  * other cops in the way no longer stop a charge
--  * a short wind-up before charging someone close (up to 1 second), so it's fair up close
--  * they stand up before charging
local MAX_DIS = 2000

local orig_upd = SpoocLogicAttack._upd_spooc_attack
SpoocLogicAttack._upd_spooc_attack = function(data, my_data, ...)
	if not T.active() then
		return orig_upd(data, my_data, ...)
	end
	if my_data.spooc_attack or data.t <= (data.spooc_attack_timeout_t or 0) or data.unit:movement():chk_action_forbidden("walk") then
		return
	end
	local fe = data.attention_obj
	if not (fe and fe.nav_tracker and fe.is_person and fe.criminal_record) then return end
	if fe.criminal_record.status and fe.criminal_record.status ~= "electrified" then return end
	local max_dis = MAX_DIS * (my_data.want_to_take_cover and 0.5 or 1)
	if (fe.reaction or 0) < AIAttentionObject.REACT_SHOOT or not fe.dis or fe.dis > max_dis then return end
	if SpoocLogicAttack._is_last_standing_criminal(fe) or not fe.unit:movement():is_SPOOC_attack_allowed() or fe.unit:movement():zipline_unit() then
		return
	end

	if not my_data.pdth_spooc_delay_t then
		my_data.pdth_spooc_delay_t = data.t + math.clamp(1 - fe.dis / 500, 0, 1)
		return
	elseif my_data.pdth_spooc_delay_t > data.t then
		return
	end

	local flying_strike
	if ActionSpooc.chk_can_start_flying_strike(data.unit, fe.unit) then
		flying_strike = true
	elseif not ActionSpooc.chk_can_start_spooc_sprint(data.unit, fe.unit) then
		return
	end

	if my_data.attention_unit ~= fe.u_key then
		CopLogicBase._set_attention(data, fe)
		my_data.attention_unit = fe.u_key
	end

	local action = SpoocLogicAttack._chk_request_action_spooc_attack(data, my_data, flying_strike)
	if action then
		my_data.pdth_spooc_delay_t = nil
		my_data.spooc_attack = { start_t = data.t, target_u_data = fe, action = action }
		return true
	end
end

Hooks:PreHook(SpoocLogicAttack, "_chk_request_action_spooc_attack", "PDTHTactics_spooc_stand", function(data)
	if T.active() and alive(data.unit) then
		data.unit:movement():action_request({ body_part = 4, type = "stand" })
	end
end)

-- check for a charge every frame (the normal attack logic still runs on its own schedule)
Hooks:PostHook(SpoocLogicAttack, "enter", "PDTHTactics_spooc_enter", function(data)
	if T.active() and data.internal_data and data.brain then
		data.brain:set_update_enabled_state(true)
	end
end)

SpoocLogicAttack.update = function(data)
	local my_data = data.internal_data
	if not (T.active() and my_data) or my_data.spooc_attack or my_data.has_old_action then return end
	local fe = data.attention_obj
	if not fe or (fe.reaction or 0) < AIAttentionObject.REACT_AIM then return end
	data.t = TimerManager:game():time()
	pcall(SpoocLogicAttack._upd_spooc_attack, data, my_data)
end
