GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

local orig_hud_absorb = HUDManager and HUDManager.set_absorb_active
if script == "lib/managers/hudmanagerpd2" and orig_hud_absorb then
	function HUDManager:set_absorb_active(panel_id, amount, ...)
		if panel_id == HUDManager.PLAYER_PANEL and (B.hitman_overflow or 0) > 0 then
			amount = (amount or 0) + B.hitman_overflow
		end
		return orig_hud_absorb(self, panel_id, amount, ...)
	end
end

if script == "lib/units/beings/player/playerdamage" then
Hooks:PreHook(PlayerDamage, "_calc_armor_damage", "GilzaDSBuffs_hitman_overflow_absorb", function(self, attack_data)
	if (B.hitman_overflow or 0) > 0 and attack_data and type(attack_data.damage) == "number" and attack_data.damage > 0 then
		local take = math.min(B.hitman_overflow, attack_data.damage)
		B.hitman_overflow = B.hitman_overflow - take
		attack_data.damage = attack_data.damage - take
		pcall(B.hitman_overflow_hud)
	end
end)
end
