if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics
local script = RequiredScript and RequiredScript:lower() or ""

local LOADOUT = {
	{ "beretta92",    2 },
	{ "raging_bull",  1 },
	{ "deagle",       1 },
	{ "mp5_tactical", 2 },
	{ "asval_smg",    1 },
	{ "s552",         1 },
	{ "r870",         1 },
	{ "sko12_conc",   1 }
}

local HRT_UNITS = {
	[Idstring("units/payday2/characters/ene_fbi_1/ene_fbi_1"):key()] = true,
	[Idstring("units/payday2/characters/ene_fbi_2/ene_fbi_2"):key()] = true,
	[Idstring("units/payday2/characters/ene_fbi_3/ene_fbi_3"):key()] = true
}

T.HRT_FACTORY_DAMAGE = T.HRT_FACTORY_DAMAGE or {}
local SUPPRESSOR = {}
for _, e in ipairs(LOADOUT) do
	if e[3] then
		T.HRT_FACTORY_DAMAGE[e[3]] = e[4]
		SUPPRESSOR[e[3]] = e[5]
		T.HRT_DROP = T.HRT_DROP or {}
		T.HRT_DROP[e[3]] = e[1]
	end
end

local function hrt_blueprint(factory_id)
	local blueprint = deep_clone(managers.weapon_factory:get_default_blueprint_by_factory_id(factory_id) or {})
	local part_id = SUPPRESSOR[factory_id]
	local parts = tweak_data.weapon.factory.parts
	local part = part_id and parts[part_id]
	if part then
		for i = #blueprint, 1, -1 do
			local p = parts[blueprint[i]]
			if p and p.type == part.type then table.remove(blueprint, i) end
		end
		table.insert(blueprint, part_id)
	end
	return blueprint
end

function T.all_modded()
	local session = managers.network and managers.network:session()
	for _, peer in pairs(session and session:peers() or {}) do
		if not T.modded_peers[peer:id()] then return false end
	end
	return true
end

local function npc_unit_name(id)
	for i, weap_id in ipairs(tweak_data.character.weap_ids) do
		if weap_id == id then return tweak_data.character.weap_unit_names[i] end
	end
end

local function usable(base, weapon_tweak)
	local weapons = base._char_tweak and base._char_tweak.weapon or {}
	return weapon_tweak and weapon_tweak.usage and weapons[weapon_tweak.usage] and true or false
end

local function roll(base)
	local pool, total = {}, 0
	local factory_ok = T.all_modded()
	for _, e in ipairs(LOADOUT) do
		local npc = tweak_data.weapon[e[1] .. "_npc"]
		if npc_unit_name(e[1]) and usable(base, npc) then
			local factory = factory_ok and e[3] and tweak_data.weapon.factory[e[3]] and e[3] or nil
			table.insert(pool, { npc = e[1], factory = factory, w = e[2] })
			total = total + e[2]
		end
	end
	local r = math.random() * total
	for _, p in ipairs(pool) do
		r = r - p.w
		if r <= 0 then return p end
	end
end

local function hrt_damage(weapon_base, factory_id)
	local equiv = T.HRT_FACTORY_DAMAGE[factory_id]
	local td = equiv and tweak_data.weapon[equiv .. "_npc"]
	if td and td.DAMAGE then weapon_base._damage = td.DAMAGE end
end

if script == "lib/units/enemies/cop/copbase" then
	local orig = CopBase.default_weapon_name
	function CopBase:default_weapon_name(selection_name, ...)
		if self._pdth_weapon then
			return self._pdth_weapon
		end
		if T.active() and alive(self._unit) and HRT_UNITS[self._unit:name():key()] then
			local ok, pick = pcall(roll, self)
			if ok and pick then
				self._pdth_weapon = npc_unit_name(pick.npc)
				self._pdth_factory = pick.factory
				return self._pdth_weapon
			end
		end
		return orig(self, selection_name, ...)
	end

elseif script == "lib/units/enemies/cop/copmovement" then
	local function give_factory_gun(unit, factory_id)
		local inv = unit:inventory()
		local fw = tweak_data.weapon.factory[factory_id]
		local ids = Idstring(fw.unit)
		managers.dyn_resource:load(Idstring("unit"), ids, managers.dyn_resource.DYN_RESOURCES_PACKAGE, nil)
		local gun = World:spawn_unit(ids, Vector3(), Rotation())
		local base = gun:base()
		base:set_factory_data(factory_id)
		base:set_cosmetics_data(nil)
		base:assemble_from_blueprint(factory_id, hrt_blueprint(factory_id))
		base:check_npc()
		if not usable(unit:base(), base:weapon_tweak_data()) then
			gun:set_slot(0)
			return false
		end
		base:setup({
			user_unit = unit,
			ignore_units = { unit, gun },
			expend_ammo = false,
			hit_slotmask = managers.slot:get_mask("bullet_impact_targets"),
			hit_player = true,
			user_sound_variant = tweak_data.character[unit:base()._tweak_table].weapon_voice,
			alert_AI = true,
			alert_filter = unit:brain():SO_access()
		})
		hrt_damage(base, factory_id)

		local sel = inv:equipped_selection()
		if sel then inv:remove_selection(sel, true) end
		inv:add_unit(gun, true)
		return true
	end

	Hooks:PostHook(CopMovement, "add_weapons", "PDTHTactics_hrt_factory_gun", function(self)
		local base = self._ext_base
		local factory_id = base and base._pdth_factory
		if not (factory_id and T.active() and alive(self._unit)) then return end
		local ok, done = pcall(give_factory_gun, self._unit, factory_id)
		if not (ok and done) then
			base._pdth_factory = nil
		end
	end)

elseif script == "lib/units/enemies/cop/copinventory" then
	Hooks:PreHook(CopInventory, "drop_weapon", "PDTHTactics_hrt_drop", function(self)
		local sel = self._available_selections and self._available_selections[self._equipped_selection]
		local gun = sel and sel.unit
		local base = alive(gun) and gun:base()
		local drop_id = base and base._factory_id and T.HRT_DROP and T.HRT_DROP[base._factory_id]
		if not drop_id then return end
		pcall(function()
			local name = npc_unit_name(drop_id)
			local pos, rot = gun:position(), gun:rotation()
			if base.set_visibility_state then base:set_visibility_state(false) end
			gun:set_visible(false)
			local dropped = name and World:spawn_unit(name, pos, rot)
			if dropped then
				if dropped:damage() then dropped:damage():run_sequence_simple("enable_body") end
				managers.game_play_central:weapon_dropped(dropped)
			end
		end)
	end)

elseif script == "lib/units/enemies/cop/huskcopinventory" then
	Hooks:PostHook(HuskCopInventory, "add_unit_by_factory_blueprint", "PDTHTactics_hrt_husk_gun", function(self, factory_name)
		if not (T.client_on() or T.active()) then return end
		local gun = self:equipped_unit()
		local base = gun and gun:base()
		if not base then return end
		base._hit_player = true
		base._bullet_slotmask = managers.slot:get_mask("bullet_impact_targets_no_AI")
		hrt_damage(base, factory_name)
	end)
end
