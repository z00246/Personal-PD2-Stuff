GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs

B.NET_ID = "GilzaDSBuffs"
B.GUARDIAN_TEAM_HEAL = 0.5
B.GUARDIAN_TEAM_RESIST = { normal = 0.85, ds = 0.8 }
B.guardian_protect_until = 0

local function flat(pos)
	return Vector3(pos.x, pos.y, 0)
end

-- teammates count as inside a bit further out than the area itself (Gilza's area is only 3-5m)
B.GUARDIAN_TEAM_RANGE_MUL = 2
B.GUARDIAN_TEAM_RANGE_MIN = 800

local function heal_bots(heal, center, radius, my_max)
	if not (managers.groupai and managers.groupai:state()) or my_max <= 0 then return end
	for _, data in pairs(managers.groupai:state():all_AI_criminals() or {}) do
		local unit = data.unit
		local dmg = alive(unit) and unit:character_damage()
		if dmg and dmg._health and dmg._HEALTH_INIT and not dmg._bleed_out and not dmg._fatal and not dmg._dead
			and mvector3.distance(flat(unit:position()), center) <= radius then
			dmg._health = math.min(dmg._health + heal / my_max * dmg._HEALTH_INIT, dmg._HEALTH_INIT)
			dmg._health_ratio = dmg._health / dmg._HEALTH_INIT
		end
	end
end

function B.guardian_team_tick()
	local pm = managers.player
	local area = pm and pm.Gilza_guardian_area
	local me = pm and pm:player_unit()
	if not (area and area.is_active and area.position and alive(me)) then return end

	local heal = pm:upgrade_value("player", "guardian_area_passive_health_regen", 0) * B.GUARDIAN_TEAM_HEAL
	if type(heal) ~= "number" or heal <= 0 then return end
	local center = flat(area.position)
	local radius = math.max((area.radius or 300) * B.GUARDIAN_TEAM_RANGE_MUL, B.GUARDIAN_TEAM_RANGE_MIN)
	local my_dmg = me:character_damage()
	local my_max = my_dmg and my_dmg:_max_health() or 0

	local session = managers.network and managers.network:session()
	local can_send = LuaNetworking and LuaNetworking.SendToPeer and true or false
	if session and can_send then
		for _, peer in pairs(session:peers() or {}) do
			local unit = peer:unit()
			if alive(unit) and mvector3.distance(flat(unit:position()), center) <= radius then
				LuaNetworking:SendToPeer(peer:id(), B.NET_ID, "guardian:" .. string.format("%.3f", heal))
			end
		end
	end

	if Network:is_server() then
		heal_bots(heal, center, radius, my_max)
	elseif B.host_has_mod and session and B.host_has_mod == session and can_send and my_max > 0 then
		-- bots live on the host: ask it to heal them (heal is sent as a ratio of our max health)
		LuaNetworking:SendToPeer(1, B.NET_ID,
			string.format("guardianbots:%.4f:%.0f:%.0f:%.0f", heal / my_max, center.x, center.y, radius))
	end
end

function B.guardian_team_loop()
	B.guardian_team_tick()
	DelayedCalls:Add("GilzaDSBuffs_guardian_team", 2, function()
		B.guardian_team_loop()
	end)
end

if PlayerManager.Gilza_start_guardian_tracking then
	local orig_start = PlayerManager.Gilza_start_guardian_tracking
	function PlayerManager:Gilza_start_guardian_tracking(...)
		local r = orig_start(self, ...)
		B.guardian_team_loop()
		return r
	end
end

function B.on_guardian_heal(amount)
	local unit = managers.player and managers.player:player_unit()
	local dmg = alive(unit) and unit:character_damage()
	if not dmg or dmg:need_revive() or dmg:dead() then return end
	dmg:restore_health(amount, true)
	B.guardian_protect_until = TimerManager:game():time() + 2.5
end

local orig_resist = PlayerManager.damage_reduction_skill_multiplier
function PlayerManager:damage_reduction_skill_multiplier(...)
	local m = orig_resist(self, ...)
	if type(m) == "number" and TimerManager:game():time() < (B.guardian_protect_until or 0) then
		m = m * (B.on and B.GUARDIAN_TEAM_RESIST.ds or B.GUARDIAN_TEAM_RESIST.normal)
	end
	return m
end

if LuaNetworking and LuaNetworking.AddReceiveHook then
	LuaNetworking:AddReceiveHook(B.NET_ID, "GilzaDSBuffs_net", function(data, sender)
		if type(data) ~= "string" then return end
		local amount = tonumber(string.match(data, "^guardian:([%d%.]+)$") or "")
		if amount and amount > 0 and amount <= 10 then
			B.on_guardian_heal(amount)
			return
		end
		local ratio, x, y, r = string.match(data, "^guardianbots:([%d%.]+):(%-?[%d%.]+):(%-?[%d%.]+):([%d%.]+)$")
		if ratio and Network:is_server() then
			ratio, r = tonumber(ratio), math.min(tonumber(r) or 0, 2000)
			x, y = tonumber(x), tonumber(y)
			if ratio and ratio > 0 and ratio <= 0.5 and x and y then
				-- convert the ratio back into health using a bot-sized reference: heal_bots scales by bot max health
				heal_bots(ratio, Vector3(x, y, 0), r, 1)
			end
		end
	end)
end

-- make sure the crew loop runs even if Gilza started its Guardian tracking before we could hook it
Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_guardian_team_start", function()
	local pm = managers.player
	if pm and pm.Gilza_guardian_area and not B._guardian_loop_started then
		B._guardian_loop_started = true
		B.guardian_team_loop()
	end
end)
