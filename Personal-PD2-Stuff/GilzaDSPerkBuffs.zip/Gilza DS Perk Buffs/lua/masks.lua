GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

-- (7.26) Sociopath's card 9 mask pick (Geo 2026-10-26, plan v7: "redo the sociopath card 9 stuff a bit", "give card 1,
-- 3, 5, 7 stuff depending on what you pick too for all mask", "Swap a card effect"): card 9 picks one of Jacket's
-- Hotline Miami masks like Copycat picks a deck. Each mask brings its own perk from the games and swaps ONE effect of
-- card 1, 3, 5 or 7 for its own (the catch is the effect it gives up). Richard: nothing. Playing as Jacket, his default
-- mask (Richard Returns) becomes the picked mask - a DLC mask you don't own stays Richard Returns, and so does what the
-- others see of you (your outfit still says "the character's mask"; they resolve it on their side).
-- The numbers: B.MASK. Everything is local to your game; the Kick mod's kicks (KickKeybind) count for Don Juan and Biker.
B.MASK = B.MASK or {
	deck = 9, card = 9,
	rasmus_dodge = 0.02, rasmus_dodge_max = 0.20,     -- Sees it coming: dodge per Combo
	foresight_at = 0.2, foresight_every = 10,         -- Foresight (replaces Thick Skin)
	tony_charge = 0.5,                                -- Tony: a half-charged punch kills a non-special
	fury_step = 0.10,                                 -- Fury (replaces Frenzy's damage resistance): per Frenzy stack
	aubrey_pickup = 1.5, shotgun_stance = 0.15,       -- Aubrey
	wall_mul = 1.5, wall_dis = 120, doorman = 0.20, tight_dis = 110,   -- Don Juan (cm)
	graham_speed = 0.10, graham_per_combo = 0.01, graham_combo_max = 10, hop_step = 0.03,   -- Graham (7.27: the per-Combo part stops at 10)
	knife_mul = 1.25,                                 -- Dennis
	brandon_speed = 0.25, brandon_at = 5, pounce_window = 1, pounce_mul = 1.5,   -- Brandon
	venom_share = 0.5, venom_length = 3, venom_tick = 0.5, venom_grace = 0.5, spread_dis = 300,   -- Jake
	scav_ammo = 0.10, scav_armor = 1, scav_at = 5,    -- Richter (armor in game units: 1 = 10 on the HUD)
	survivor_at = 0.25, survivor_dr = 0.4, survivor_time = 5, survivor_every = 30,
	revenge_special_hits = 2, guard_mul = 2,          -- Tony's Revenge
	roll_time = 0.5, roll_every = 3, roll_every_combo = 1.5, roll_at = 5, momentum_mul = 1.5, momentum_time = 2,   -- Corey
	ash_share = 0.5, chainsaw_step = 0.20, chainsaw_max = 0.60,   -- Alex & Ash
	biker_regen = 0.5, biker_at = 5, helmet_armor = 3  -- Biker (30 on the HUD)
}
local K = B.MASK

-- the choices in card 9's order (the texture cells are the atlas made by make_mask_atlas.py: 8 per row, 64 px)
-- swap: which card effect the mask replaces (frenzy = card 1's damage resistance, tension = cards 1 + 7's Tension,
-- hold = card 3's melee-hold resistance, guard = that resistance doubled instead, thick = card 3's Thick Skin,
-- clean = card 5's Clean Hit, hardened = card 7's Hardened)
B.MASKS = B.MASKS or {
	{ key = "richard", mask = "richard_returns", name = "Richard" },
	{ key = "rasmus", mask = "owl", name = "Rasmus", swap = "thick" },
	{ key = "tony", mask = "tiger", name = "Tony", swap = "frenzy" },
	{ key = "aubrey", mask = "pig", name = "Aubrey", swap = "hold" },
	{ key = "don_juan", mask = "horse", name = "Don Juan", swap = "hardened" },
	{ key = "graham", mask = "rabbit", name = "Graham", swap = "frenzy" },
	{ key = "dennis", mask = "white_wolf", name = "Dennis", swap = "hold" },
	{ key = "brandon", mask = "panther", name = "Brandon", swap = "hardened" },
	{ key = "jake", mask = "jake", name = "Jake", swap = "hardened" },
	{ key = "richter", mask = "richter", name = "Richter", swap = "tension" },
	{ key = "tonys_revenge", mask = "tonys_revenge", name = "Tony's Revenge", swap = "guard" },
	{ key = "corey", mask = "corey", name = "Corey", swap = "thick" },
	{ key = "alex", mask = "alex", name = "Alex & Ash", swap = "hardened" },
	{ key = "biker", mask = "biker", name = "Biker", swap = "clean" }
}
B.MASK_BY_KEY = B.MASK_BY_KEY or {}
for i, m in ipairs(B.MASKS) do
	m.index = i
	B.MASK_BY_KEY[m.key] = m
end

-- the mask text ids (names.lua / descriptions.lua style: B.name_text and B.full_text answer them; the localization
-- branch below also registers them so the game's own text lookups find them)
B.MASK_TEXT = B.MASK_TEXT or {
	menu_gdsb_mask_richard = "Richard",
	menu_gdsb_mask_richard_desc = "Jacket wears Richard Returns. No extra perk, no card swap.",
	menu_gdsb_mask_rasmus = "Rasmus",
	menu_gdsb_mask_rasmus_desc = "Sees it coming: the first shot from each enemy that starts shooting at you always misses, and each Combo gives you ##2%## dodge chance, up to ##20%##.\nForesight replaces Thick Skin: every ##10## seconds, the first hit worth more than ##20%## of your health misses.\nJacket wears the Rasmus mask.",
	menu_gdsb_mask_tony = "Tony",
	menu_gdsb_mask_tony_desc = "A punch charged halfway kills any enemy that isn't a special, and a punch on a stunned or knocked-down enemy kills (not Bulldozers or Captains) and adds ##1## Combo.\nFury replaces Frenzy's damage resistance: each Frenzy stack gives your punches ##10%## more damage and speed (##5## stacks, ##6## on Death Sentence).\nJacket wears the Tony mask.",
	menu_gdsb_mask_aubrey = "Aubrey",
	menu_gdsb_mask_aubrey_desc = "Shotguns don't end your Combo, firing or killing with them, and ammo pickups give ##50%## more.\nShotgun stance replaces the melee-hold resistance: ##15%## less damage taken while you hold a shotgun.\nJacket wears the Aubrey mask.",
	menu_gdsb_mask_don_juan = "Don Juan",
	menu_gdsb_mask_don_juan_desc = "Melee hits deal ##50%## more damage to an enemy with a wall right behind him, and killing him there counts ##2## Combo. With the Kick mod, a kick into a wall kills any enemy that isn't a special.\nDoorman replaces Hardened: ##20%## less damage taken in a doorway or a tight spot.\nJacket wears the Don Juan mask.",
	menu_gdsb_mask_graham = "Graham",
	menu_gdsb_mask_graham_desc = "You move ##10%## faster, plus ##1%## per Combo up to ##10##.\nHop replaces Frenzy's damage resistance: ##3%## movement speed per Frenzy stack (##15%##, ##18%## on Death Sentence).\nJacket wears the Graham mask.",
	menu_gdsb_mask_dennis = "Dennis",
	menu_gdsb_mask_dennis_desc = "Knives deal ##25%## more damage, and a knife kill that starts a Combo counts ##2##.\nBackstab replaces the melee-hold resistance: knife hits on enemies that aren't facing you are critical hits.\nJacket wears the Dennis mask.",
	menu_gdsb_mask_brandon = "Brandon",
	menu_gdsb_mask_brandon_desc = "At Combo ##5## or more you move ##25%## faster.\nPounce replaces Hardened: a melee hit within ##1## second of sprinting deals ##50%## more damage and staggers anyone but a Bulldozer.\nJacket wears the Brandon mask.",
	menu_gdsb_mask_jake = "Jake",
	menu_gdsb_mask_jake_desc = "Venom: your melee hits poison the enemy for half the hit's damage over ##3## seconds. Poison kills add Combo and keep it going.\nSpreading venom replaces Hardened: an enemy dying to the poison passes it to the nearest enemy within ##3m##.\nJacket wears the Jake mask.",
	menu_gdsb_mask_richter = "Richter",
	menu_gdsb_mask_richter_desc = "Scavenger: melee kills give ##10%## ammo to both guns and ##10## armor (##20%## and ##20## at Combo ##5##+).\nSurvivor replaces Tension: dropping under ##25%## health makes you take ##40%## less damage for ##5## seconds, once every ##30## seconds.\nJacket wears the Richter mask.",
	menu_gdsb_mask_tonys_revenge = "Tony's Revenge",
	menu_gdsb_mask_tonys_revenge_desc = "Every punch kills an enemy that isn't a special; specials take ##2## punches (##1## at Massacre), not Bulldozers or Captains. Fists only: your guns can't fire and your melee is locked to Fists.\nGuard: the melee-hold resistance is doubled, up to ##30%##.\nJacket wears the Tony's Revenge mask.",
	menu_gdsb_mask_corey = "Corey",
	menu_gdsb_mask_corey_desc = "A slide is a roll: bullets can't hit you for ##0.5## seconds, once every ##3## seconds (##1.5## at Combo ##5##+).\nMomentum replaces Thick Skin: ##50%## more melee damage for ##2## seconds after a roll.\nJacket wears the Corey mask.",
	menu_gdsb_mask_alex = "Alex & Ash",
	menu_gdsb_mask_alex_desc = "Ash shoots back: while you hold your melee weapon, whoever shoots you takes half of that damage back, and those kills count as melee kills.\nAlex's chainsaw replaces Hardened: each consecutive melee hit on the same enemy deals ##20%## more damage, up to ##60%##.\nJacket wears the Alex & Ash mask.",
	menu_gdsb_mask_biker = "Biker",
	menu_gdsb_mask_biker_desc = "Stomp: a kick on a knocked-down enemy kills (not Bulldozers or Captains; needs the Kick mod). At Combo ##5##+ your armor starts recovering ##50%## sooner.\nHelmet replaces Clean Hit: melee kills restore ##30## armor.\nJacket wears the Biker mask.",
	menu_gdsb_mask_fists_locked = "Tony's Revenge: fists only"   -- (7.30) the melee lock's line in the menus
}
B.name_text = B.name_text or {}
B.full_text = B.full_text or {}
for id, text in pairs(B.MASK_TEXT) do
	if id:sub(-5) == "_desc" then B.full_text[id] = text else B.name_text[id] = text end
end

-- (7.31) the heister you are: in a heist the one you spawned as, in a lobby the one the lobby gave you (signatures.lua's
-- B.sig_character), in the menus your preferred heister
function B.mask_character()
	local name = B.sig_character and B.sig_character()
	if name then return name end
	local bm = managers.blackmarket
	return bm and bm.get_preferred_character and bm:get_preferred_character() or nil
end

-- (7.31) card 9's choice list is on the card for Jacket only (the perk deck screens call this before they build it)
function B.mask_sync_choices()
	if not B._mask_choices then return end
	local sp = tweak_data and tweak_data.skilltree and tweak_data.skilltree.specializations
	local card = sp and sp[K.deck] and sp[K.deck][K.card]
	if not card then return end
	card.multi_choice = B.mask_character() == "jacket" and B._mask_choices or nil
end

-- which mask card 9 picked (checked at most twice a second): only as Jacket (7.31 - anyone else has the plain card 9,
-- no pick: Geo "if I was anyone other than jacket then they wouldnt get a card 9 selection and would just be
-- default"), with Sociopath as your current deck and its card 9
B._mask_cache = B._mask_cache or { t = -1 }
function B.mask_choice()
	local now = Application:time()
	local c = B._mask_cache
	if now >= c.t and now - c.t < 0.5 then return c.mask end
	c.t, c.mask = now, nil
	if B.mask_character() ~= "jacket" then return nil end
	local st = managers.skilltree
	if not st or st:get_specialization_value("current_specialization") ~= K.deck then return nil end
	if (st:get_specialization_value(K.deck, "tiers", "current_tier") or 0) < K.card then return nil end
	local data = st._global and st._global.specializations and st._global.specializations[K.deck]
	local raw = data and data.choices and data.choices[K.card]
	local idx = raw and st.digest_value and st:digest_value(raw, false)
	c.mask = idx and B.MASKS[idx] or B.MASKS[1]
	return c.mask
end

function B.mask_key()
	local m = B.mask_choice()
	return m and m.key or nil
end

function B.mask_on(key)
	local m = B.mask_choice()
	return m ~= nil and m.key == key
end

-- does the picked mask replace this card effect? ("frenzy", "tension", "hold", "thick", "clean", "hardened")
function B.mask_swap(what)
	local m = B.mask_choice()
	return m ~= nil and m.swap == what
end

-- the melee-hold resistance's multiplier: gone for Aubrey and Dennis, doubled for Tony's Revenge
function B.mask_hold_mul()
	local m = B.mask_choice()
	if not m then return 1 end
	if m.swap == "hold" then return 0 end
	if m.swap == "guard" then return K.guard_mul end
	return 1
end

-- (7.30) Tony's Revenge keeps the melee at Fists (Geo: "make sure it also locks tony to fist and dont let him change
-- it, similar to how it was before before we let people change their heister, it should block it out for tony, and
-- lock it in the briefing room too"): the pick puts Fists on, the inventory's melee box is greyed out and dead the way
-- the game greys the heister box in a lobby, the briefing room's melee slot gets the game's own padlock and doesn't
-- open, the melee list locks every other weapon, and equipping another one puts Fists straight back. Only while
-- Fists are yours to equip (they always are; never lock the melee to something you can't use).
B.FISTS = "fists"
function B.mask_fists_locked()
	if not B.mask_on("tonys_revenge") then return false end
	local bm = Global and Global.blackmarket_manager
	local f = bm and bm.melee_weapons and bm.melee_weapons[B.FISTS]
	return f ~= nil and f.unlocked == true
end

-- Fists on when something else is (the menus, the pick and the deck switch call this); true when it switched
function B.mask_force_fists()
	if not B.mask_fists_locked() then return false end
	local bm = managers.blackmarket
	if not (bm and bm.equipped_melee_weapon and bm.equip_melee_weapon) then return false end
	if bm:equipped_melee_weapon() == B.FISTS then return false end
	B._mask_forcing_fists = true
	bm:equip_melee_weapon(B.FISTS)
	B._mask_forcing_fists = nil
	if not B._mask_fists_logged then
		B._mask_fists_logged = true
		log("[Gilza DS Perk Buffs] Tony's Revenge: melee set to Fists")
	end
	return true
end

-- a line in the BLT log the first times a mask does something (buffs.lua)
function B.mask_live(key, ...)
	if B.live then B.live("mask " .. key, ...) end
end

-- the equipped melee weapon's type from the game's tweak data ("fists", "knife", "axe", "blunt", ...)
function B.mask_melee_type(id)
	id = id or (managers.blackmarket and managers.blackmarket:equipped_melee_weapon())
	local w = id and tweak_data and tweak_data.blackmarket and tweak_data.blackmarket.melee_weapons[id]
	return w and w.type or nil, id
end

function B.mask_is_punch(id) return B.mask_melee_type(id) == "fists" end
function B.mask_is_knife(id) return B.mask_melee_type(id) == "knife" end

-- a Combo for the mask perks (the Combo itself lives in sociopath.lua)
function B.mask_add_combo(n)
	local C = B.SOCIO
	if not C then return end
	local now = Application:time()
	if not (B.combo_last_t and now - B.combo_last_t <= C.combo_window) then B.combo = 0 end
	B.combo = math.min((B.combo or 0) + (n or 1), C.combo_max)
	B.combo_last_t = now
	B.combo_kills = (B.combo_kills or 0) + (n or 1)
end

-- the kick (Geo's Kick mod, KickKeybind): the hit it's dealing right now ("ground" / "jump") or nil
function B.mask_kick(attack_data)
	if attack_data and attack_data.kick then return attack_data.kick end
	local kick = rawget(_G, "KickKeybind")
	return type(kick) == "table" and kick._hitting or nil
end

-- is the picked mask's DLC yours (its mask in the black market tweak data has a dlc); unknown masks: no
function B.mask_owned(mask_id)
	local mt = tweak_data and tweak_data.blackmarket and tweak_data.blackmarket.masks and tweak_data.blackmarket.masks[mask_id]
	if not mt then return false end
	local dlc = mt.dlc
	if not dlc then return true end
	return managers.dlc and managers.dlc.is_dlc_unlocked and managers.dlc:is_dlc_unlocked(dlc) and true or false
end

-- the mask Jacket's default mask turns into (nil = Richard Returns as usual)
function B.mask_visual_id()
	local m = B.mask_choice()
	if not m or m.key == "richard" then return nil end
	if not B.mask_owned(m.mask) then return nil end
	return m.mask
end

-- the kinds of hurt that count as "knocked down / stunned" for Tony and Biker's Stomp
B.MASK_DOWN = B.MASK_DOWN or { expl_hurt = true, knock_down = true, stagger = true, taser_tased = true, counter_tased = true, stun = true, heavy_hurt = true }
function B.mask_is_down(unit)
	local mv = alive(unit) and unit:movement()
	local action = mv and mv._active_actions and mv._active_actions[1]
	if not action then return false end
	if type(action.type) ~= "function" or action:type() ~= "hurt" then return false end
	local ht = type(action.hurt_type) == "function" and action:hurt_type() or nil
	return ht ~= nil and B.MASK_DOWN[ht] == true
end

local function not_special(cd)
	local tags = cd and cd._char_tweak and cd._char_tweak.tags
	if type(tags) == "table" then
		for _, tag in ipairs(tags) do
			if tag == "special" or tag == "civilian" then return false end
		end
	end
	local base = cd and alive(cd._unit) and cd._unit:base()
	local name = base and base._tweak_table
	if type(name) ~= "string" then return false end
	for _, bit in ipairs({ "boss", "phalanx", "tank", "marshal", "captain", "spooc", "shield", "taser", "medic", "sniper" }) do
		if name:find(bit, 1, true) then return false end
	end
	return true
end
B.mask_not_special = not_special

-- Bulldozers, Captain Winters and his shields, Marshals, bosses: the ones no mask perk kills outright
local function untouchable(cd)
	local tweak = cd and cd._char_tweak
	local tags = tweak and tweak.tags
	if type(tags) == "table" then
		for _, tag in ipairs(tags) do
			if tag == "tank" then return true end
		end
	end
	if tweak and (tweak.access == "tank" or tweak.Gilza_boss_tag or tweak.Gilza_boss_tag_deep or tweak.Gilza_winters_tag) then return true end
	local base = cd and alive(cd._unit) and cd._unit:base()
	local name = base and base._tweak_table
	if type(name) ~= "string" then return true end
	for _, bit in ipairs({ "boss", "phalanx", "tank", "marshal", "captain", "winters" }) do
		if name:find(bit, 1, true) then return true end
	end
	return false
end
B.mask_untouchable = untouchable

-- the resistance the mask gives on its own (Shotgun stance, Doorman, Survivor): 0 = none
function B.mask_dr()
	local m = B.mask_choice()
	if not m then return 0 end
	local now = Application:time()
	local dr = 0
	if m.key == "aubrey" and B._mask_shotgun_out then dr = K.shotgun_stance end
	if m.key == "don_juan" and B._mask_tight then dr = math.max(dr, K.doorman) end
	if m.key == "richter" and B._mask_survivor_t and now < B._mask_survivor_t then dr = math.max(dr, K.survivor_dr) end
	return dr
end

-- Fury (Tony): the punches' extra speed per Frenzy stack (1 = none)
function B.mask_speed_mul()
	if B.mask_on("tony") and B.mask_is_punch() then
		return 1 + (B.frenzy or 0) * K.fury_step
	end
	return 1
end

-- Aubrey: a gun kill with a shotgun doesn't end the Combo; Dennis: a knife kill that starts a Combo counts 2
function B.mask_gun_kill_ok(weapon_id)
	if not B.mask_on("aubrey") then return false end
	local w = type(weapon_id) == "string" and tweak_data and tweak_data.weapon and tweak_data.weapon[weapon_id]
	local cats = type(w) == "table" and w.categories
	if type(cats) ~= "table" then return false end
	for _, c in ipairs(cats) do
		if c == "shotgun" then return true end
	end
	return false
end

function B.mask_combo_bonus(weapon_id, combo_before)
	local bonus = 0
	if B.mask_on("dennis") and B.mask_is_knife(weapon_id) and (combo_before or 0) == 0 then
		bonus = bonus + 1
		B.mask_live("dennis", "a knife kill started the Combo at 2")
	end
	if B._mask_extra_combo then
		bonus = bonus + B._mask_extra_combo
		B._mask_extra_combo = nil
	end
	return bonus
end

-- Richter's Scavenger, Jake's spreading venom: after a kill that counted for the Combo (sociopath.lua)
function B.mask_on_kill(killed_unit, variant, weapon_id, melee)
	local m = B.mask_choice()
	if not m then return end
	local now = Application:time()
	if m.key == "richter" and melee then
		local player = managers.player and managers.player:player_unit()
		local inv = alive(player) and player:inventory()
		local big = (B.combo or 0) >= K.scav_at
		local share = big and K.scav_ammo * 2 or K.scav_ammo
		if inv and inv.unit_by_selection then
			for i = 1, 2 do
				local wu = inv:unit_by_selection(i)
				local base = alive(wu) and wu:base()
				local ab = base and base.ammo_base and base:ammo_base() or base
				if ab and ab.get_ammo_total and ab.get_ammo_max and ab.set_ammo_total then
					local max = ab:get_ammo_max()
					if type(max) == "number" and max > 0 then
						ab:set_ammo_total(math.min(max, ab:get_ammo_total() + math.ceil(max * share)))
						if managers.hud and base.ammo_info then managers.hud:set_ammo_amount(i, base:ammo_info()) end
					end
				end
			end
		end
		local dmg = alive(player) and player:character_damage()
		if dmg and dmg.restore_armor then dmg:restore_armor(big and K.scav_armor * 2 or K.scav_armor) end
		B.mask_live("scavenger", "a melee kill gave %d%% ammo and %d armor", share * 100, (big and 2 or 1) * K.scav_armor * 10)
	end
	if m.key == "jake" and variant == "poison" and alive(killed_unit) and B.mask_spread then
		B.mask_spread(killed_unit)
	end
end

if script == "lib/tweak_data/skilltreetweakdata" then
	-- card 9 gets the choices (like Copycat's card 9): no upgrades of their own, our names, our icons
	Hooks:PostHook(SkillTreeTweakData, "init", "GilzaDSBuffs_mask_choices", function(self)
		local deck = self.specializations and self.specializations[K.deck]
		local card = deck and deck[K.card]
		if not card then return end
		local choices = {}
		for i, m in ipairs(B.MASKS) do
			choices[i] = {
				upgrades = {},
				name_id = "menu_gdsb_mask_" .. m.key,
				desc_id = "menu_gdsb_mask_" .. m.key .. "_desc",
				icon_atlas = "icons_atlas",
				texture_bundle_folder = "gdsb_masks",
				icon_xy = { (i - 1) % 8, math.floor((i - 1) / 8) },
				icon_texture_rect = { 64, 64, 64, 64 },
				-- the perk deck screen puts the choice's text BEFORE the card's own (skip_tier_name): card 9's text is long
				-- and a paragraph appended after it never showed (Geo: "the boost arent popping up on the text")
				skip_tier_name = true
			}
		end
		card.multi_choice = choices
		B._mask_choices = choices   -- (7.31) the perk deck screen shows them for Jacket only (the skilltreegui branch)
	end)

elseif script == "lib/managers/localizationmanager" then
	Hooks:Add("LocalizationManagerPostInit", "GilzaDSBuffs_mask_loc", function(loc)
		if loc and loc.add_localized_strings then loc:add_localized_strings(B.MASK_TEXT) end
	end)

elseif script == "lib/managers/blackmarketmanager" then
	-- Jacket's default mask ("character_locked" -> Richard Returns) becomes the picked mask on your own screen
	local orig_real = BlackMarketManager.get_real_mask_id
	if orig_real then
		function BlackMarketManager:get_real_mask_id(mask_id, peer_id, character, ...)
			local real = orig_real(self, mask_id, peer_id, character, ...)
			if mask_id ~= "character_locked" or real ~= "richard_returns" then return real end
			if peer_id then
				local session = managers.network and managers.network:session()
				local me = session and session.local_peer and session:local_peer()
				if me and me:id() ~= peer_id then return real end
			end
			local picked = B.mask_visual_id()
			if picked then
				if not B._mask_visual_logged then
					B._mask_visual_logged = true
					log("[Gilza DS Perk Buffs] Jacket's mask: " .. tostring(picked) .. " (card 9 pick)")
				end
				return picked
			end
			return real
		end
	end

	-- (7.30) Tony's Revenge: equipping another melee weapon puts Fists straight back (the menus are locked; this is
	-- for anything else that equips one)
	Hooks:PostHook(BlackMarketManager, "equip_melee_weapon", "GilzaDSBuffs_mask_fists_lock", function(self, melee_weapon_id)
		if B._mask_forcing_fists or melee_weapon_id == B.FISTS then return end
		B.mask_force_fists()
	end)

elseif script == "lib/managers/skilltreemanager" then
	-- picking another mask in the menu: the heister on screen puts it on right away
	Hooks:PostHook(SkillTreeManager, "set_specialization_choice", "GilzaDSBuffs_mask_pick", function(self, tree, tier)
		if tree ~= K.deck or tier ~= K.card then return end
		B._mask_cache = { t = -1 }
		B.mask_force_fists()                                      -- (7.30) Tony's Revenge: Fists on at the pick
		local bm, ms = managers.blackmarket, managers.menu_scene
		if not (bm and ms and ms.set_character_mask_by_id and bm.equipped_mask) then return end
		if bm.get_preferred_character and bm:get_preferred_character() ~= "jacket" then return end
		local data = bm:equipped_mask()
		local mask_id = type(data) == "table" and data.mask_id or data
		local blueprint = type(data) == "table" and data.blueprint or nil
		if mask_id ~= "character_locked" then return end
		ms:set_character_mask_by_id(mask_id, blueprint)
	end)
	-- (7.30) switching to Sociopath, or reaching card 9, with Tony's Revenge picked: Fists on
	for _, fn in ipairs({ "set_current_specialization", "_increase_specialization_tier" }) do
		if SkillTreeManager[fn] then
			Hooks:PostHook(SkillTreeManager, fn, "GilzaDSBuffs_mask_fists_" .. fn, function(self)
				B._mask_cache = { t = -1 }
				B.mask_force_fists()
			end)
		end
	end

elseif script == "lib/managers/playermanager" then
	-- the timed bits: shotgun out, tight spots, Survivor, the slide roll, sprint time
	local function tight_spot(unit)
		if not (World and managers.slot) then return false end
		local mv = unit:movement()
		local pos = mv and mv:m_pos()
		local rot = mv and mv.m_rot and mv:m_rot()
		if not (pos and rot) then return false end
		local right = rot:x()
		local from = pos + Vector3(0, 0, 90)
		local mask = managers.slot:get_mask("world_geometry")
		local a = World:raycast("ray", from, from + right * K.tight_dis, "slot_mask", mask)
		if not a then return false end
		local b = World:raycast("ray", from, from - right * K.tight_dis, "slot_mask", mask)
		return b ~= nil
	end

	function B.mask_update(t, dt)
		local m = B.mask_choice()
		if not m then
			B._mask_shotgun_out, B._mask_tight, B._mask_survivor_t = nil, nil, nil
			return
		end
		local now = Application:time()
		local unit = managers.player and managers.player:player_unit()
		local dmg = alive(unit) and unit:character_damage()
		if not dmg or dmg:dead() then return end
		if m.key == "aubrey" then
			local inv = unit:inventory()
			local eq = inv and inv.equipped_unit and inv:equipped_unit()
			local base = alive(eq) and eq:base()
			B._mask_shotgun_out = base and base.is_category and base:is_category("shotgun") or false
		elseif m.key == "don_juan" then
			if now >= (B._mask_tight_t or 0) then
				B._mask_tight_t = now + 0.25
				local was = B._mask_tight
				B._mask_tight = tight_spot(unit)
				if B._mask_tight and not was then B.mask_live("doorman", "a tight spot: damage taken -%d%%", K.doorman * 100) end
			end
		elseif m.key == "richter" then
			local ratio = dmg.health_ratio and dmg:health_ratio()
			if type(ratio) == "number" and ratio < K.survivor_at and now >= (B._mask_survivor_next or 0) and not dmg:need_revive() then
				B._mask_survivor_t = now + K.survivor_time
				B._mask_survivor_next = now + K.survivor_every
				B.mask_live("survivor", "under %d%% health: damage taken -%d%% for %d s", K.survivor_at * 100, K.survivor_dr * 100, K.survivor_time)
			end
		elseif m.key == "corey" then
			local state = managers.player:get_current_state()
			local sliding = state and state._is_sliding and true or false
			if sliding and not B._mask_was_sliding then
				local every = (B.combo or 0) >= K.roll_at and K.roll_every_combo or K.roll_every
				if now >= (B._mask_roll_next or 0) then
					B._mask_roll_t = now + K.roll_time
					B._mask_roll_next = now + every
					B._mask_momentum_t = now + K.momentum_time
					B.mask_live("roll", "a slide rolled: bullets can't hit for %.1f s (next in %.1f s)", K.roll_time, every)
				end
			end
			B._mask_was_sliding = sliding
		elseif m.key == "brandon" then
			local mv = unit:movement()
			if mv and mv.running and mv:running() then B._mask_sprint_t = now end
		end
	end

	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_mask_update", function(t, dt)
		B.mask_update(t, dt or 0)
	end)

	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_mask_reset", function()
		local session = managers.network and managers.network:session()
		if B._mask_session ~= session then
			B._mask_session = session
			B._mask_seen, B._mask_revenge_hits, B._mask_venom = {}, {}, {}
			B._mask_survivor_t, B._mask_survivor_next, B._mask_roll_t, B._mask_roll_next = nil, nil, nil, nil
			B._mask_momentum_t, B._mask_sprint_t, B._mask_tight, B._mask_shotgun_out = nil, nil, nil, nil
			B._mask_foresight_next, B._mask_chain_unit, B._mask_chain_n, B._mask_extra_combo, B._mask_chain_t = nil, nil, nil, nil, nil
			B._mask_cache = { t = -1 }
		end
	end)

	-- Rasmus: dodge per Combo (inside dodgecap.lua's cap: that wrapper sits on top of this one)
	local orig_dodge = PlayerManager.skill_dodge_chance
	function PlayerManager:skill_dodge_chance(...)
		local chance = orig_dodge(self, ...)
		if type(chance) ~= "number" or not B.mask_on("rasmus") then return chance end
		return chance + math.min((B.combo or 0) * K.rasmus_dodge, K.rasmus_dodge_max)
	end

	-- Graham (+ Hop), Brandon
	local orig_speed = PlayerManager.movement_speed_multiplier
	function PlayerManager:movement_speed_multiplier(...)
		local mul = orig_speed(self, ...)
		if type(mul) ~= "number" then return mul end
		local m = B.mask_choice()
		if not m then return mul end
		if m.key == "graham" then
			mul = mul * (1 + K.graham_speed + math.min(B.combo or 0, K.graham_combo_max) * K.graham_per_combo) * (1 + (B.frenzy or 0) * K.hop_step)
		elseif m.key == "brandon" and (B.combo or 0) >= K.brandon_at then
			mul = mul * (1 + K.brandon_speed)
		end
		return mul
	end

	-- Dennis' Backstab: the hit's crit roll can't miss (the flag is set around the hit in the copdamage branch)
	local orig_crit_chance = PlayerManager.critical_hit_chance
	function PlayerManager:critical_hit_chance(...)
		local chance = orig_crit_chance(self, ...)
		if B._mask_crit and type(chance) == "number" then return chance + 100 end
		return chance
	end

elseif script == "lib/units/beings/player/playerdamage" then
	-- a clean miss: the game's own "revive miss" path (the bullet whizzes by, nothing else happens), used for one hit
	local function force_miss(self)
		B._mask_miss_was, B._mask_miss_set = self._revive_miss, true
		self._revive_miss = 1
	end
	local function miss_undo(self)
		if B._mask_miss_set then
			self._revive_miss = B._mask_miss_was
			B._mask_miss_was, B._mask_miss_set = nil, nil
		end
	end

	Hooks:PreHook(PlayerDamage, "damage_bullet", "GilzaDSBuffs_mask_bullet_pre", function(self, attack_data)
		miss_undo(self)
		B._mask_ash = nil
		local m = B.mask_choice()
		if not m or not attack_data or type(attack_data.damage) ~= "number" then return end
		if self._god_mode or self._invulnerable or (self.incapacitated and self:incapacitated()) then return end
		local now = Application:time()
		local attacker = attack_data.attacker_unit
		local melee_hit = attack_data.variant == "melee"
		if m.key == "rasmus" then
			-- Sees it coming: each enemy's first shot at you misses
			if not melee_hit and alive(attacker) and attacker.key then
				B._mask_seen = B._mask_seen or {}
				local key = attacker:key()
				if not B._mask_seen[key] then
					B._mask_seen[key] = true
					force_miss(self)
					B.mask_live("rasmus", "an enemy's first shot at you missed")
					return
				end
			end
			-- Foresight (instead of Thick Skin): the first big hit every 10 s misses
			local max = self:_max_health()
			local dr = managers.player:damage_reduction_skill_multiplier(melee_hit and "melee" or "bullet")
			if type(dr) ~= "number" then dr = 1 end
			if type(max) == "number" and max > 0 and attack_data.damage * dr > max * K.foresight_at and now >= (B._mask_foresight_next or 0) then
				B._mask_foresight_next = now + K.foresight_every
				force_miss(self)
				B.mask_live("foresight", "a hit worth more than %d%% of your health missed", K.foresight_at * 100)
				return
			end
		elseif m.key == "corey" then
			if not melee_hit and B._mask_roll_t and now < B._mask_roll_t then
				force_miss(self)
				B.mask_live("roll miss", "a bullet missed during the roll")
				return
			end
		elseif m.key == "alex" then
			-- Ash shoots back: remember the raw hit, answer it after the game has dealt with it
			if not melee_hit and alive(attacker) then
				local state = managers.player:get_current_state()
				if state and state.in_melee and state:in_melee() then
					B._mask_ash = { attacker = attacker, damage = attack_data.damage, armor = self:get_real_armor(), health = self:get_real_health() }
				end
			end
		end
	end)

	Hooks:PostHook(PlayerDamage, "damage_bullet", "GilzaDSBuffs_mask_bullet_post", function(self, attack_data)
		miss_undo(self)
		local ash = B._mask_ash
		B._mask_ash = nil
		if not ash or not B.mask_on("alex") then return end
		-- only a shot that landed (armor or health gone)
		if self:get_real_armor() + self:get_real_health() >= ash.armor + ash.health then return end
		local attacker = ash.attacker
		local cd = alive(attacker) and attacker:character_damage()
		if not (cd and cd.damage_simple and not cd._dead) then return end
		local player = managers.player:player_unit()
		if not alive(player) then return end
		local back = ash.damage * K.ash_share
		if back <= 0 then return end
		local mv = attacker:movement()
		local pos = mv and mv.m_head_pos and mv:m_head_pos() or attacker:position()
		local dir = pos - player:position()
		mvector3.normalize(dir)
		local result = cd:damage_simple({ variant = "bullet", damage = back, attacker_unit = player, pos = pos, attack_dir = dir })
		B.mask_live("ash", "Ash shot back for %.1f", back)
		if type(result) == "table" and result.type == "death" and B.socio_on_kill then
			B.socio_on_kill(attacker, "melee", false, nil)
		end
	end)

	-- Biker: at Combo 5+ the armor recovery wait is halved
	Hooks:PostHook(PlayerDamage, "set_regenerate_timer_to_max", "GilzaDSBuffs_mask_regen", function(self)
		if type(self._regenerate_timer) == "number" and B.mask_on("biker") and (B.combo or 0) >= K.biker_at then
			self._regenerate_timer = self._regenerate_timer * K.biker_regen
		end
	end)

elseif script == "lib/units/enemies/cop/copdamage" then
	local function mine(attack_data)
		local player = managers.player and managers.player:player_unit()
		return alive(player) and attack_data and attack_data.attacker_unit == player
	end

	-- a wall right behind him, along the hit
	local function wall_behind(self, attack_data)
		if not (World and managers.slot) then return false end
		local ray = attack_data.col_ray and attack_data.col_ray.ray
		local mv = self._unit:movement()
		local pos = mv and mv:m_pos()
		if not (ray and pos) then return false end
		local dir = Vector3(ray.x, ray.y, 0)
		if mvector3.normalize(dir) < 0.01 then return false end
		local from = pos + Vector3(0, 0, 100)
		return World:raycast("ray", from, from + dir * K.wall_dis, "slot_mask", managers.slot:get_mask("world_geometry")) ~= nil
	end

	local function facing_me(self, player)
		local mv = self._unit:movement()
		local rot = mv and mv.m_rot and mv:m_rot()
		local fwd = rot and rot:y()
		if not fwd then return true end
		local to = player:position() - self._unit:position()
		mvector3.set_z(to, 0)
		if mvector3.normalize(to) < 0.01 then return true end
		return mvector3.dot(fwd, to) > 0
	end

	local function lethal(self, attack_data)
		attack_data.damage = (self._HEALTH_INIT or self._health or attack_data.damage) * 10
	end

	-- the melee hit (after Gilza turned it into a share of his health, before the game applies it)
	Hooks:PreHook(CopDamage, "damage_melee", "GilzaDSBuffs_mask_melee_pre", function(self, attack_data)
		B._mask_crit = nil
		if self._dead or self._invulnerable or not (mine(attack_data) and type(attack_data.damage) == "number") then return end
		local m = B.mask_choice()
		if not m then return end
		if self.is_friendly_fire and self:is_friendly_fire(attack_data.attacker_unit) then return end
		local now = Application:time()
		local kick = B.mask_kick(attack_data)
		local melee_id = not kick and attack_data.name_id or nil
		local charge = attack_data.charge_lerp_value or (B._melee_ctx and B._melee_ctx.charge) or 0
		if type(charge) ~= "number" then charge = 0 end
		local base = self._unit:base()
		local who = tostring(base and base._tweak_table)
		if m.key == "tony" and not kick and B.mask_is_punch(melee_id) then
			attack_data.damage = attack_data.damage * (1 + (B.frenzy or 0) * K.fury_step)
			if not untouchable(self) and B.mask_is_down(self._unit) then
				lethal(self, attack_data)
				B._mask_extra_combo = 1
				B.mask_live("tony down", "a punch on a knocked-down %s killed (+1 Combo)", who)
			elseif charge >= K.tony_charge and not_special(self) and attack_data.damage < (self._health or 0) then
				lethal(self, attack_data)
				B.mask_live("tony", "a half-charged punch killed a %s", who)
			end
		elseif m.key == "tonys_revenge" and not kick and B.mask_is_punch(melee_id) then
			if not_special(self) then
				lethal(self, attack_data)
				B.mask_live("revenge", "a punch killed a %s", who)
			elseif not untouchable(self) then
				B._mask_revenge_hits = B._mask_revenge_hits or {}
				local key = self._unit:key()
				local hits = (B._mask_revenge_hits[key] or 0) + 1
				B._mask_revenge_hits[key] = hits
				local needed = (B.socio_massacre and B.socio_massacre()) and 1 or K.revenge_special_hits
				if hits >= needed then
					lethal(self, attack_data)
					B._mask_revenge_hits[key] = nil
					B.mask_live("revenge special", "punch %d killed a %s", hits, who)
				end
			end
		elseif m.key == "don_juan" then
			if wall_behind(self, attack_data) then
				attack_data._gdsb_wall = true
				attack_data.damage = attack_data.damage * K.wall_mul
				if kick and not_special(self) then
					lethal(self, attack_data)
					B.mask_live("wall kick", "a kick into the wall killed a %s", who)
				else
					B.mask_live("wall", "x%.1f melee damage with a wall behind a %s", K.wall_mul, who)
				end
			end
		elseif m.key == "dennis" and not kick and B.mask_is_knife(melee_id) then
			attack_data.damage = attack_data.damage * K.knife_mul
			local player = managers.player:player_unit()
			if alive(player) and not facing_me(self, player) then
				B._mask_crit = true
				B.mask_live("backstab", "a knife hit from behind a %s: critical", who)
			end
		elseif m.key == "brandon" and not kick then
			if B._mask_sprint_t and now - B._mask_sprint_t <= K.pounce_window then
				attack_data.damage = attack_data.damage * K.pounce_mul
				if not untouchable(self) and type(self._HEALTH_INIT) == "number" then
					attack_data.damage_effect = self._HEALTH_INIT
				end
				B.mask_live("pounce", "a melee hit out of a sprint: x%.1f and a stagger on a %s", K.pounce_mul, who)
			end
		elseif m.key == "corey" and not kick then
			if B._mask_momentum_t and now < B._mask_momentum_t then
				attack_data.damage = attack_data.damage * K.momentum_mul
				B.mask_live("momentum", "x%.1f melee damage after a roll", K.momentum_mul)
			end
		elseif m.key == "alex" and not kick then
			local key = self._unit:key()
			if B._mask_chain_unit == key then
				B._mask_chain_n = (B._mask_chain_n or 1) + 1
			else
				B._mask_chain_unit, B._mask_chain_n = key, 1
			end
			B._mask_chain_t = now          -- (7.27) for the HUD: the chain shows for the Combo window after the last hit
			local bonus = math.min((B._mask_chain_n - 1) * K.chainsaw_step, K.chainsaw_max)
			if bonus > 0 then
				attack_data.damage = attack_data.damage * (1 + bonus)
				B.mask_live("chainsaw", "hit %d on the same %s: +%d%%", B._mask_chain_n, who, bonus * 100)
			end
		elseif m.key == "biker" and kick then
			if not untouchable(self) and B.mask_is_down(self._unit) then
				lethal(self, attack_data)
				B.mask_live("stomp", "a kick on a knocked-down %s killed", who)
			end
		end
	end)

	-- Jake's Venom: the poison for half the hit (the hit's damage after Gilza and our multipliers), and Don Juan's
	-- second Combo for a kill against the wall
	function B.mask_venom(unit, per_tick, weapon_id)
		if not (managers.dot and managers.dot.add_doted_enemy and tweak_data.dot and tweak_data.dot.get_dot_data) then return false end
		local base = tweak_data.dot:get_dot_data("melee_fear")
		if not base then return false end
		local player = managers.player:player_unit()
		if not alive(player) then return false end
		local data = {}
		for k, v in pairs(base) do data[k] = v end
		data.dot_damage = per_tick
		data.dot_length = K.venom_length
		data.dot_tick_period = K.venom_tick
		data.dot_grace_period = K.venom_grace
		managers.dot:add_doted_enemy({ unit = unit, attacker_unit = player, weapon_id = weapon_id, hurt_animation = false, dot_data = data })
		B._mask_venom = B._mask_venom or {}
		B._mask_venom[unit:key()] = { per_tick = per_tick, weapon_id = weapon_id, t = Application:time(), unit = unit }
		return true
	end

	-- Spreading venom: the dead one's poison moves to the nearest enemy within 3 m
	function B.mask_spread(dead_unit)
		if not B.mask_swap("hardened") then return end
		local rec = B._mask_venom and B._mask_venom[dead_unit:key()]
		if not rec then return end
		B._mask_venom[dead_unit:key()] = nil
		if not (managers.enemy and managers.slot) then return end
		local pos = dead_unit:position()
		local mask = managers.slot:get_mask("enemies")
		local best, best_d
		for _, u_data in pairs(managers.enemy:all_enemies() or {}) do
			local u = u_data.unit
			if alive(u) and u ~= dead_unit and u:in_slot(mask) then
				local cd = u:character_damage()
				if cd and not cd._dead then
					local d = mvector3.distance(pos, u:position())
					if d <= K.spread_dis and (not best or d < best_d) then best, best_d = u, d end
				end
			end
		end
		if best and B.mask_venom(best, rec.per_tick, rec.weapon_id) then
			B.mask_live("spread", "the venom passed to a %s %.1f m away", tostring(best:base()._tweak_table), best_d / 100)
		end
	end

	Hooks:PostHook(CopDamage, "damage_melee", "GilzaDSBuffs_mask_melee_post", function(self, attack_data)
		B._mask_crit = nil
		if not (mine(attack_data) and type(attack_data.damage) == "number") then return end
		local m = B.mask_choice()
		if not m then return end
		if m.key == "don_juan" and attack_data._gdsb_wall and self._dead then
			B.mask_add_combo(1)
			B.mask_live("wall kill", "a kill against the wall counted 2 Combo (now %d)", B.combo or 0)
		elseif m.key == "jake" and not self._dead and not B.mask_kick(attack_data) and not (self.is_friendly_fire and self:is_friendly_fire(attack_data.attacker_unit)) then
			local ticks = math.max(1, math.floor(K.venom_length / K.venom_tick))
			local per_tick = attack_data.damage * K.venom_share / ticks
			if per_tick > 0 and B.mask_venom(self._unit, per_tick, attack_data.name_id) then
				B.mask_live("venom", "a %s is poisoned for %.1f over %d s", tostring(self._unit:base()._tweak_table), per_tick * ticks, K.venom_length)
			end
		end
	end)

elseif script == "lib/units/beings/player/states/playerstandard" then
	-- Tony's Revenge: fists only, the guns can't fire (the hint says "Guns are for pussies", Geo's words, 7.29). (7.28) A PreHook that clears the fire input, not a wrap of the
	-- function: Gilza's weaponlib fix (a persist script, WEAPONLIB_fixes_and_overrides.lua) replaces
	-- _check_action_primary_attack with Hooks:OverrideFunction on the first update of every heist, which threw the 7.26
	-- wrap away (Geo: "tony is still able to use his guns"); SuperBLT keeps pre-hooks across an override.
	Hooks:PreHook(PlayerStandard, "_check_action_primary_attack", "GilzaDSBuffs_mask_revenge_fists", function(self, t, input)
		if not (input and (input.btn_primary_attack_press or input.btn_primary_attack_state or input.btn_primary_attack_release)) then return end
		if not B.mask_on("tonys_revenge") then return end
		local eq = self._equipped_unit
		local base = alive(eq) and eq:base()
		if not (base and base.fire) then return end
		local pressed = input.btn_primary_attack_press
		input.btn_primary_attack_press, input.btn_primary_attack_state, input.btn_primary_attack_release = false, false, false
		if pressed and (not B._mask_revenge_hint_t or type(t) ~= "number" or t - B._mask_revenge_hint_t > 5) then
			B._mask_revenge_hint_t = type(t) == "number" and t or 0
			if managers.hud and managers.hud.show_hint then managers.hud:show_hint({ text = "Guns are for pussies", time = 2 }) end
		end
	end)

elseif script == "lib/managers/menu/playerinventorygui" then
	-- (7.30) the inventory with Tony's Revenge picked: Fists on before the boxes are built, then the melee box is greyed
	-- out and dead the way the game greys the heister / Infamy boxes in a lobby (alpha 0.2, no left / up / down, so no
	-- click, no cycling, no legends), and its info text carries the red line the heister box carried.
	-- (Player Stats Panel Enhancements replaces init; it loads first, these hooks wrap its copy.)
	Hooks:PreHook(PlayerInventoryGui, "init", "GilzaDSBuffs_mask_fists_box_pre", function(self)
		B.mask_force_fists()
	end)
	Hooks:PostHook(PlayerInventoryGui, "init", "GilzaDSBuffs_mask_fists_box", function(self)
		if not B.mask_fists_locked() then return end
		local box = self._boxes_by_name and self._boxes_by_name.melee
		if not box then return end
		box.clbks = { right = false }
		if box.params then box.params.alpha = 0.2 end
		if box.panel and alive(box.panel) then box.panel:set_alpha(0.2) end
		if self._update_selected_box then self:_update_selected_box(true) end
	end)
	Hooks:PostHook(PlayerInventoryGui, "_update_info_melee", "GilzaDSBuffs_mask_fists_info", function(self, name)
		if not B.mask_fists_locked() or not self.set_info_text then return end
		local bm = managers.blackmarket
		local pld = bm and bm.player_loadout_data and bm:player_loadout_data()
		local text = string.format("%s", pld and pld.melee_weapon and pld.melee_weapon.info_text or "") .. "\n"
		local range = { start = utf8.len(text), color = tweak_data.screen_colors.important_1 }
		text = text .. managers.localization:to_upper_text("menu_gdsb_mask_fists_locked") .. "\n"
		range.stop = utf8.len(text)
		self:set_info_text(text, { range })
	end)

elseif script == "lib/managers/menu/missionbriefinggui" then
	-- (7.30) the briefing room's loadout with Tony's Revenge picked: Fists on before the slots are built; the melee
	-- slot (the 3rd) is dimmed, gets the game's own padlock (what it shows when a job forces the loadout), says why
	-- under its name, and doesn't open (an instance method shadows open_node for that tab alone; the class's stays)
	if NewLoadoutTab then
		Hooks:PreHook(NewLoadoutTab, "init", "GilzaDSBuffs_mask_fists_briefing_pre", function(self)
			B.mask_force_fists()
		end)
		Hooks:PostHook(NewLoadoutTab, "init", "GilzaDSBuffs_mask_fists_briefing", function(self)
			if not B.mask_fists_locked() then return end
			local item = self._items and self._items[3]
			if not (item and item._panel and alive(item._panel) and item._item_panel and alive(item._item_panel)) then return end
			item._item_panel:set_alpha(0.35)
			local lock = item._panel:bitmap({ texture = "guis/textures/pd2/skilltree/padlock", name = "gdsb_fists_lock", w = 32, h = 32, layer = 2, color = tweak_data.screen_colors.text })
			lock:set_center(item._item_panel:center_x(), item._item_panel:center_y())
			if item.set_info_text and item._params and item._params.info_text then
				item:set_info_text(tostring(item._params.info_text) .. " - " .. managers.localization:to_upper_text("menu_gdsb_mask_fists_locked"), tweak_data.screen_colors.important_1)
			end
			self.open_node = function(tab, node, ...)
				if node == 3 and B.mask_fists_locked() then
					if managers.menu_component and managers.menu_component.post_event then managers.menu_component:post_event("menu_error") end
					return
				end
				return NewLoadoutTab.open_node(tab, node, ...)
			end
		end)
	end

elseif script == "lib/managers/menu/blackmarketgui" then
	-- (7.30) the melee list itself (should it open some other way) with Tony's Revenge picked: every weapon but Fists
	-- locked with the game's padlock and a line saying why, no Equip button
	local function lock_list(self, data)
		if not B.mask_fists_locked() then return end
		for _, item in ipairs(data) do
			if type(item) == "table" and item.category == "melee_weapons" and item.name ~= B.FISTS and item.name ~= "empty" then
				item.unlocked = false
				item.lock_texture = "guis/textures/pd2/skilltree/padlock"
				item.install_lock = "menu_gdsb_mask_fists_locked"
				for i = #item, 1, -1 do
					if item[i] == "lo_mw_equip" then table.remove(item, i) end
				end
			end
		end
	end
	for _, fn in ipairs({ "populate_melee_weapons", "populate_melee_weapons_new" }) do
		if BlackMarketGui[fn] then Hooks:PostHook(BlackMarketGui, fn, "GilzaDSBuffs_mask_fists_" .. fn, lock_list) end
	end

elseif script == "lib/managers/menu/specializationguinew" or script == "lib/managers/menu/skilltreegui" then
	-- (7.31) the perk deck screens: card 9's mask choices are there for Jacket only; anyone else sees the plain card
	-- (no pick, no "x/14", the card's own text). The card's choice list is put on / taken off right before a screen
	-- builds the card: the game's current screen (SpecializationGuiNew) makes one SpecializationListItem per deck
	-- whose "has choices" lookup and x/14 come from the card at init, and its detail panel and pick read the card
	-- live, so as someone else a click does nothing and the saved pick waits for Jacket; the old SkillTreeGui's
	-- SpecializationTierItem is covered the same way.
	if SpecializationGuiNew then
		Hooks:PreHook(SpecializationGuiNew, "init", "GilzaDSBuffs_mask_choices_jacket_gui", function() B.mask_sync_choices() end)
	end
	if SpecializationListItem then
		Hooks:PreHook(SpecializationListItem, "init", "GilzaDSBuffs_mask_choices_jacket_item", function() B.mask_sync_choices() end)
	end
	if SpecializationTierItem then
		Hooks:PreHook(SpecializationTierItem, "init", "GilzaDSBuffs_mask_choices_jacket", function() B.mask_sync_choices() end)
	end
end
