if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics
local orig = MedicDamage.is_available_for_healing

function MedicDamage:is_available_for_healing(requesting_unit, ...)
	local ok = orig(self, requesting_unit, ...)
	if not ok or not T.active() or T.has_tag(requesting_unit, "tank") then
		return ok
	end
	-- (1.91: no pcall) a Medic doesn't heal anyone while a Dozer is in his healing range
	local my_mov = alive(self._unit) and self._unit:movement()
	local gs = managers.groupai and managers.groupai:state()
	if not (my_mov and gs and self.get_healing_radius_sq) then return true end
	local my_pos = my_mov:m_pos()
	local r_sq = self:get_healing_radius_sq()
	for _, u_data in pairs(gs._police or {}) do
		local u = u_data.unit
		if u ~= requesting_unit and alive(u) and T.has_tag(u, "tank") then
			local cd, mov = u:character_damage(), u:movement()
			if cd and not cd:dead() and mov and mvector3.distance_sq(my_pos, mov:m_pos()) <= r_sq then
				return false
			end
		end
	end
	return true
end

-- Medics need line of sight to heal (Restoration): no more healing through walls and floors
local orig_verify = MedicDamage.verify_heal_requesting_unit
function MedicDamage:verify_heal_requesting_unit(requesting_unit, ...)
	if not orig_verify(self, requesting_unit, ...) then return false end
	if not T.active() then return true end
	local from_mov = alive(requesting_unit) and requesting_unit:movement()
	local to_mov = alive(self._unit) and self._unit:movement()
	if not (from_mov and to_mov) then return true end
	local blocked = World:raycast("ray", from_mov:m_head_pos(), to_mov:m_head_pos(), "slot_mask", managers.slot:get_mask("AI_visibility"), "report")
	return not blocked
end

-- A Medic that heals someone glows green for 2 seconds so you can find it
-- (synced, so everyone sees it, modded or not)
Hooks:PostHook(MedicDamage, "heal_unit", "PDTHTactics_medic_reveal", function(self)
	if not (T.active() and Network:is_server()) then return end
	local contour = not self._dead and alive(self._unit) and self._unit:contour()
	if contour then
		contour:add("medic_heal", true)
	end
end)
