if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics
local orig = CopLogicIdle._get_priority_attention

CopLogicIdle._get_priority_attention = function(data, attention_objects, reaction_func, ...)
	local best, slot, reaction = orig(data, attention_objects, reaction_func, ...)
	if not T.active() or (best and best.criminal_record and best.criminal_record.status == "electrified") then
		return best, slot, reaction
	end
	if data.unit and T.has_tag(data.unit, "taser") then
		return best, slot, reaction
	end
	for _, att in pairs(attention_objects or {}) do
		local rec = att.criminal_record
		if rec and rec.status == "electrified" and att.identified and att.verified
			and att.reaction and att.reaction >= AIAttentionObject.REACT_COMBAT then
			return att, 1, AIAttentionObject.REACT_SHOOT
		end
	end
	return best, slot, reaction
end
