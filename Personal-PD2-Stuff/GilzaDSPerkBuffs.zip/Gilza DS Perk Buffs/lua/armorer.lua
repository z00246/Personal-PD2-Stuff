GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

-- difficulty scaling (shared with buffs.lua): t = 0 up to Overkill, 1/3 Mayhem, 2/3 Death Wish, 1 Death Sentence
if not B.diff_t then
	B.DIFF_T = { easy_wish = 1 / 3, overkill_290 = 2 / 3, sm_wish = 1 }
	function B.diff_t()
		local gs = Global and Global.game_settings
		return gs and B.DIFF_T[gs.difficulty] or 0
	end
	function B.sc(base, ds) return base + (ds - base) * B.diff_t() end
	function B.sci(base, ds) return math.floor(base + (ds - base) * B.diff_t() + 0.5) end
end

-- a line in the BLT log the first times a feature does something (buffs.lua)
local function live(key, ...) if B.live then B.live("armorer " .. key, ...) end end

-- Armorer (7.20 rework v1b, Geo 2026-10-25: "what about armorer, I think he just needs the basic rework", then picked
-- Load Bearing and Reactive Plates; "yea go ahead and build them"). The 6.x plates stay, named, with Death Sentence
-- ends:
--  card 1 Plate Carrier: 2 plates, a hit breaks at most one, armor recovers a plate at a time. Reactive Plates: a plate
--   breaking gives 20% » 30% more damage for 5 s (refreshes).
--  card 3 Shatter: a plate breaking suppresses enemies within 6 m, 60% » 75% chance to panic. Load Bearing: your
--   armor's movement speed penalty is halved (on top of Gilza's card 2 for every deck).
--  card 5 Trauma Plates: 3 plates, a hit takes at most 75% of a plate.
--  card 7 Field Repair: armor recovery 20% faster; every 5 » 4 s the damaged plate is restored while the armor isn't
--   broken. Hold Fast: the game's armor-break immunity, 2 » 3 s (the buffs.lua niche makes it 3 s on Death Sentence;
--   below it, the scaled part is added here for Armorer only - Copycat's and Anarchist's levels stay as they are).
--  card 9 Liquid Armor: 4 plates, a hit takes at most 50% of a plate; the crew's 10% faster armor recovery.
-- *_ds values are the Death Sentence end of the difficulty scale (B.sc).
B.ARMORER = {
	deck = 3,
	plates = { [1] = 2, [5] = 3, [9] = 4 },
	hit_cap = { [1] = 1, [5] = 0.75, [9] = 0.5 },
	plate_regen_tier = 7,
	plate_regen_every = 5, plate_regen_every_ds = 4,   -- card 7 Field Repair
	shatter_tier = 3,
	shatter_range = 600,
	shatter_panic = 0.6, shatter_panic_ds = 0.75,      -- card 3 Shatter
	regen_mul = 0.8,
	plate_step = 0.75,
	reactive = 0.20, reactive_ds = 0.30, reactive_time = 5,   -- card 1 Reactive Plates
	load_bearing = 0.5,                                -- card 3: the armor's speed penalty x0.5
	hold_fast_ds = 1.5,                                -- card 7: the immunity x1.5 at the Death Sentence end
	-- (7.24) Chains's signature (card 9, only as Chains): Unchained - when your last plate breaks, 6 s of 20% more
	-- damage and 10% more speed, and your first kill puts a plate back; once every 60 s
	unchained_time = 6, unchained_every = 60, unchained_damage = 0.2, unchained_speed = 1.1
}
local C = B.ARMORER

-- (7.24) Chains's Unchained
function B.armorer_unchained()
	return Application:time() < (B.armorer_unchained_until or 0)
end
function B.armorer_unchain(unit)
	local now = Application:time()
	if now < (B._unchained_ready or 0) or not (B.sig_active and B.sig_active(C.deck)) then return end
	B.armorer_unchained_until = now + C.unchained_time
	B._unchained_ready = now + C.unchained_every
	B._unchained_plate = true
	if alive(unit) and unit:sound() then unit:sound():play("perkdeck_activate", nil, false) end
	B.sig_live("unchained", "the last plate broke: %d seconds Unchained", C.unchained_time)
end

function B.armorer_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == C.deck) then
		return 0
	end
	return st:get_specialization_value(C.deck, "tiers", "current_tier") or 0
end

function B.armorer_pre_apply()
	local values = tweak_data and tweak_data.upgrades and tweak_data.upgrades.values
	if not values or B._armorer_done_for == values then return end
	B._armorer_done_for = values
	values.player.armor_regen_timer_multiplier_passive = { C.regen_mul }
end

local function by_tier(tbl, tier)
	local best, v = 0, nil
	for card, val in pairs(tbl) do
		if tier >= card and card > best then best, v = card, val end
	end
	return v
end

local function plate_count(tier)
	local best, n = 0, 0
	for card, v in pairs(C.plates) do
		if tier >= card and card > best then best, n = card, v end
	end
	return n
end

local function shatter(player_unit)
	if not (alive(player_unit) and managers.slot) then return end
	local pos = player_unit:position()
	local panic = B.sc(C.shatter_panic, C.shatter_panic_ds)
	local enemies = World:find_units_quick("sphere", pos, C.shatter_range, managers.slot:get_mask("enemies"))
	for _, unit in ipairs(enemies or {}) do
		local dmg = alive(unit) and unit:character_damage()
		if dmg and dmg.build_suppression then
			dmg:build_suppression("max", panic)
		end
	end
	live("shatter", "a plate broke: enemies within 6 m suppressed, %.0f%% panic", panic * 100)
end

-- card 1 Reactive Plates
function B.armorer_reactive()
	return B.armorer_tier() >= 1 and Application:time() < (B.armorer_reactive_until or 0)
end

if script == "lib/units/beings/player/playerdamage" then
	-- recover armor one plate at a time instead of all at once
	local orig_regen = PlayerDamage._regenerate_armor
	function PlayerDamage:_regenerate_armor(...)
		local tier = B.armorer_tier()
		local plates = tier >= 1 and plate_count(tier) or 0
		if plates >= 2 and not self._dead and not self._bleed_out then
			local armor, max = self:get_real_armor(), self:_max_armor()
			if max > 0 and armor < max - 0.0001 then
				local plate = max / plates
				local top = math.min((math.floor(armor / plate + 0.0001) + 1) * plate, max)
				if top < max - 0.0001 then
					self:set_armor(top)
					self:_send_set_armor()
					if self._unit:sound() then
						self._unit:sound():play("shield_full_indicator")
					end
					self._regenerate_timer = C.plate_step
					self._current_state = self._update_regenerate_timer
					return
				end
			end
		end
		return orig_regen(self, ...)
	end

	Hooks:PreHook(PlayerDamage, "_calc_armor_damage", "GilzaDSBuffs_armorer_plates", function(self, attack_data)
		if not attack_data or attack_data.armor_piercing or type(attack_data.damage) ~= "number" then return end
		local tier = B.armorer_tier()
		if tier < 1 then return end
		local armor = self:get_real_armor()
		if armor <= 0 then return end
		local plates = plate_count(tier)
		if plates < 2 then return end
		local plate = self:_max_armor() / plates
		local in_plate = armor - plate * (math.ceil(armor / plate - 0.0001) - 1)
		local cap = math.min(in_plate, plate * (by_tier(C.hit_cap, tier) or 1))
		if attack_data.damage >= cap then
			attack_data.damage = cap
			if cap >= in_plate - 0.0001 then
				-- a plate breaks
				B.armorer_reactive_until = Application:time() + C.reactive_time
				live("reactive plates", "a plate broke: more damage for %d seconds", C.reactive_time)
				if tier >= C.shatter_tier then
					shatter(self._unit)
				end
				-- (7.24) Chains's Unchained: the last one
				if tier >= 9 and math.ceil(armor / plate - 0.0001) <= 1 then
					B.armorer_unchain(self._unit)
				end
			end
		end
	end)
end

if script == "lib/managers/playermanager" then
	-- card 7 Field Repair
	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_armorer_plate_regen", function()
		local tier = B.armorer_tier()
		if tier < C.plate_regen_tier then return end
		local now = Application:time()
		if now < (B._plate_regen_t or 0) then return end
		B._plate_regen_t = now + B.sc(C.plate_regen_every, C.plate_regen_every_ds)
		local unit = managers.player and managers.player:player_unit()
		local dmg = alive(unit) and unit:character_damage()
		if not dmg or dmg:dead() or dmg:need_revive() then return end
		local armor, max = dmg:get_real_armor(), dmg:_max_armor()
		if armor <= 0 or armor >= max then return end
		local plate = max / plate_count(tier)
		local top = math.min(math.ceil(armor / plate - 0.0001) * plate, max)
		if top > armor then
			dmg:restore_armor(top - armor)
			live("field repair", "the damaged plate restored")
		end
	end)

	-- (7.24) Chains's Unchained: faster, and the first kill puts a plate back
	local orig_speed = PlayerManager.movement_speed_multiplier
	function PlayerManager:movement_speed_multiplier(...)
		local m = orig_speed(self, ...)
		if type(m) == "number" and B.armorer_unchained() then return m * C.unchained_speed end
		return m
	end

	Hooks:PostHook(PlayerManager, "on_killshot", "GilzaDSBuffs_armorer_unchained", function(self)
		if not (B._unchained_plate and B.armorer_unchained()) then return end
		local unit = self:player_unit()
		local dmg = alive(unit) and unit:character_damage()
		if not dmg or dmg:dead() or dmg:need_revive() then return end
		B._unchained_plate = nil
		local plates = math.max(plate_count(B.armorer_tier()), 1)
		dmg:restore_armor(dmg:_max_armor() / plates)
		B.sig_live("unchained plate", "a kill put a plate back")
	end)

	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_armorer_sig_reset", function()
		local session = managers.network and managers.network:session()
		if B._armorer_sig_session ~= session then
			B._armorer_sig_session = session
			B.armorer_unchained_until, B._unchained_ready, B._unchained_plate = nil, nil, nil
		end
	end)

	-- card 3 Load Bearing: the armor's movement speed penalty halved (the inventory's armor stats read this too)
	local orig_penalty = PlayerManager.mod_movement_penalty
	if orig_penalty then
		function PlayerManager:mod_movement_penalty(movement_penalty, ...)
			local r = orig_penalty(self, movement_penalty, ...)
			if type(r) ~= "number" or r >= 1 then return r end
			if B.armorer_tier() >= 3 then
				r = 1 - (1 - r) * C.load_bearing
				live("load bearing", "armor speed x%.3f", r)
			end
			return r
		end
	end

	-- card 7 Hold Fast: the game's armor-break immunity, 2 s growing to 3 s (on Death Sentence the niche has it at 3 s)
	local orig_temp_value = PlayerManager.temporary_upgrade_value
	function PlayerManager:temporary_upgrade_value(category, upgrade, default, ...)
		local v = orig_temp_value(self, category, upgrade, default, ...)
		if upgrade ~= "armor_break_invulnerable" or type(v) ~= "number" or v <= 0 then return v end
		local t = 0
		if (B.t or 0) < 1 and B.armorer_tier() >= 7 then
			t = math.min(B.t or B.diff_t(), 1)
		end
		if t > 0 then
			v = v * (1 + (C.hold_fast_ds - 1) * t)
		end
		return v
	end

	local function hold_fast(pm)
		if B.armorer_tier() < 7 then return end
		local dur = pm:temporary_upgrade_value("temporary", "armor_break_invulnerable", 0)
		if type(dur) == "number" and dur > 0 then
			B.armorer_holdfast_until = Application:time() + dur
			live("hold fast", "immune to health damage for %.2f seconds", dur)
		end
	end
	local orig_activate = PlayerManager.activate_temporary_upgrade
	function PlayerManager:activate_temporary_upgrade(category, upgrade, ...)
		local r = orig_activate(self, category, upgrade, ...)
		if upgrade == "armor_break_invulnerable" then
			hold_fast(self)
		end
		return r
	end

elseif script == "lib/units/enemies/cop/copdamage" then
	-- card 1 Reactive Plates: your damage while it lasts
	for _, fn in ipairs({ "damage_bullet", "damage_melee", "damage_fire", "damage_explosion", "damage_dot" }) do
		if CopDamage[fn] then
			Hooks:PreHook(CopDamage, fn, "GilzaDSBuffs_armorer_reactive_" .. fn, function(self, attack_data)
				if not (attack_data and type(attack_data.damage) == "number") then return end
				local player = managers.player and managers.player:player_unit()
				if not (alive(player) and attack_data.attacker_unit == player) then return end
				-- (7.24) Chains's Unchained
				if B.armorer_unchained() then
					attack_data.damage = attack_data.damage * (1 + C.unchained_damage)
					B.sig_live("unchained damage", "+%d%% damage (%s)", C.unchained_damage * 100, fn)
				end
				if not B.armorer_reactive() then return end
				local more = B.sc(C.reactive, C.reactive_ds)
				attack_data.damage = attack_data.damage * (1 + more)
				live("reactive damage", "+%.1f%% damage after a plate broke (%s)", more * 100, fn)
			end)
		end
	end
end
