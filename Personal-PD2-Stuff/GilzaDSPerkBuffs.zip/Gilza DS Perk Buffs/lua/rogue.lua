GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

B.ROGUE = {
	deck = 4,
	targeted = 0.6,
	stack_dodge = 0.05,
	stack_dodge_ds = 0.075,
	stack_max = 4,
	stack_time = 6,
	ghost_dodges = 3,
	ghost_window = 3,
	ghost_time = 1.5,
	ghost_cooldown = 15,
	flank = { [1] = 0.25, [5] = 0.35 },
	flank_dot = 0.3,
	rush_speed = 1.3,
	rush_time = 4,
	riposte_time = 2
}

function B.rogue_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == B.ROGUE.deck) then
		return 0
	end
	return st:get_specialization_value(B.ROGUE.deck, "tiers", "current_tier") or 0
end

local function by_tier(tbl, tier)
	local best
	for card, v in pairs(tbl) do
		if tier >= card and (not best or card > best) then best = card end
	end
	return best and tbl[best] or 0
end

function B.rogue_pre_apply()
	local values = tweak_data and tweak_data.upgrades and tweak_data.upgrades.values
	if not values or B._rogue_done_for == values then return end
	B._rogue_done_for = values
	values.player.camouflage_multiplier = { B.ROGUE.targeted }
end

function B.rogue_rush()
	return Application:time() < (B.rogue_rush_until or 0)
end

if script == "lib/managers/playermanager" then
	local orig_dodge = PlayerManager.skill_dodge_chance
	function PlayerManager:skill_dodge_chance(...)
		local chance = orig_dodge(self, ...)
		local ok, tier = pcall(B.rogue_tier)
		if ok and tier >= 3 and type(chance) == "number" and Application:time() < (B.rogue_stack_until or 0) then
			chance = chance + (B.rogue_stacks or 0) * (B.on and B.ROGUE.stack_dodge_ds or B.ROGUE.stack_dodge)
		end
		return chance
	end

	local orig_crit = PlayerManager.critical_hit_chance
	function PlayerManager:critical_hit_chance(...)
		local chance = orig_crit(self, ...)
		if type(chance) == "number" and Application:time() < (B.rogue_riposte_until or 0) then
			return chance + 1
		end
		return chance
	end

	local function on_dodge()
		local tier = B.rogue_tier()
		local now = Application:time()
		if tier >= 3 then
			B.rogue_rush_until = now + B.ROGUE.rush_time
			if now >= (B.rogue_stack_until or 0) then
				B.rogue_stacks = 0
			end
			B.rogue_stacks = math.min((B.rogue_stacks or 0) + 1, B.ROGUE.stack_max)
			B.rogue_stack_until = now + B.ROGUE.stack_time
		end
		if tier >= 9 and now >= (B.rogue_ghost_ready or 0) then
			B.rogue_dodges = B.rogue_dodges or {}
			table.insert(B.rogue_dodges, now)
			while B.rogue_dodges[1] and now - B.rogue_dodges[1] > B.ROGUE.ghost_window do
				table.remove(B.rogue_dodges, 1)
			end
			if #B.rogue_dodges >= B.ROGUE.ghost_dodges then
				local unit = managers.player:player_unit()
				local dmg = alive(unit) and unit:character_damage()
				if dmg and dmg.Gilza_add_damage_invuln_timer then
					dmg:Gilza_add_damage_invuln_timer(B.ROGUE.ghost_time)
					unit:sound():play("perkdeck_activate", nil, false)
				end
				B.rogue_dodges = {}
				B.rogue_ghost_ready = now + B.ROGUE.ghost_cooldown
			end
		end
		if tier >= 7 then
			B.rogue_riposte_until = now + B.ROGUE.riposte_time
		end
	end

	Hooks:PostHook(PlayerManager, "init", "GilzaDSBuffs_rogue_dodge", function(self)
		self:register_message(Message.OnPlayerDodge, "GilzaDSBuffs_rogue_dodge", function()
			pcall(on_dodge)
		end)
	end)

elseif script == "lib/units/enemies/cop/copdamage" then
	local function flank_bonus(self, attack_data)
		if not attack_data or type(attack_data.damage) ~= "number" then return end
		local player = managers.player and managers.player:player_unit()
		if not (alive(player) and attack_data.attacker_unit == player) then return end
		local tier = B.rogue_tier()
		if tier < 1 then return end
		local mov = self._unit:movement()
		if not (mov and mov.m_rot and mov.m_pos) then return end
		local fwd = mov:m_rot():y()
		local to_player = player:position() - mov:m_pos()
		mvector3.set_z(to_player, 0)
		mvector3.normalize(to_player)
		if mvector3.dot(fwd, to_player) < B.ROGUE.flank_dot then
			attack_data.damage = attack_data.damage * (1 + by_tier(B.ROGUE.flank, tier))
		end
	end
	for _, fn in ipairs({ "damage_bullet", "damage_melee" }) do
		Hooks:PreHook(CopDamage, fn, "GilzaDSBuffs_rogue_flank_" .. fn, function(self, attack_data)
			pcall(flank_bonus, self, attack_data)
		end)
	end

elseif script == "lib/units/weapons/newraycastweaponbase" then
	local orig_reload = NewRaycastWeaponBase.reload_speed_multiplier
	function NewRaycastWeaponBase:reload_speed_multiplier(...)
		local m = orig_reload(self, ...)
		if type(m) == "number" and B.rogue_rush() then
			return m * B.ROGUE.rush_speed
		end
		return m
	end

elseif script == "lib/units/beings/player/states/playerstandard" then
	local orig_swap = PlayerStandard._get_swap_speed_multiplier
	function PlayerStandard:_get_swap_speed_multiplier(...)
		local m = orig_swap(self, ...)
		if type(m) == "number" and B.rogue_rush() then
			return m * B.ROGUE.rush_speed
		end
		return m
	end
elseif script == "lib/tweak_data/skilltreetweakdata" then
	local REMOVE = {
		[9] = { weapon_passive_armor_piercing_chance = true, player_crouch_dodge_chance_1 = true }
	}
	Hooks:PostHook(SkillTreeTweakData, "init", "GilzaDSBuffs_rogue_cards", function(self)
		local deck = self.specializations and self.specializations[B.ROGUE.deck]
		for card, names in pairs(REMOVE) do
			local ups = deck and deck[card] and deck[card].upgrades
			if ups then
				for i = #ups, 1, -1 do
					if names[ups[i]] then table.remove(ups, i) end
				end
			end
		end
	end)
end
