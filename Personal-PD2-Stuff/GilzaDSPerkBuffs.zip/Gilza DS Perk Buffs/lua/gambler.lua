GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs

-- Gambler (7.21 rework standard; Geo: "u can apply the gambler rework"). Gilza's dice roll (Gilza's lua/ammoclip.lua)
-- stays as it is: every ammo box you pick up rolls, at most once every 4 s (the temporary loose_ammo_restore_health
-- upgrade): 70% win, 15% loss (2x the roll, never below 1 health), 15% nothing; 1 win in 10 and 1 loss in 20 are
-- jackpots (x3); the first roll of a heist is a winning jackpot. What was Death Sentence only now grows with the
-- difficulty (B.diff_t: 0 up to Overkill, 1/3 Mayhem, 2/3 Death Wish, 1 Death Sentence):
--   heals and losses (card 1 and card 7) and card 9's dodge swings: buffs.lua niches, whole health points / percents
--   card 9's dodge cap (35% » 60%) and the crit gamble (a win / loss 2-6% » 3-9%, a jackpot 20% » 30%, kept between
--   -30% » -45% and 30% » 45%; while negative, that share of your bullet and melee hits heals the enemy: crit.lua): here
-- PocoHud shows the time until your next roll (B.gambler_next_roll); live lines in the BLT log.
B.GAMBLER = {
	dodge_cap = { 0.35, 0.6 },
	crit_min = { 0.02, 0.03 },
	crit_max = { 0.06, 0.09 },
	crit_jackpot = { 0.2, 0.3 },
	crit_cap = { 0.3, 0.45 },
	roll_cd = 4,
}

-- { up to Overkill, Death Sentence } -> the value for this difficulty, to a whole percent
local function pct(v)
	local t = B.diff_t and B.diff_t() or 0
	return math.floor((v[1] + (v[2] - v[1]) * t) * 100 + 0.5) / 100
end

function B.gambler_dodge_cap()
	return pct(B.GAMBLER.dodge_cap)
end

function B.crit_values()
	local G = B.GAMBLER
	return { min = pct(G.crit_min), max = pct(G.crit_max), jackpot = pct(G.crit_jackpot), cap = pct(G.crit_cap) }
end

B.gambler_crit = 0

-- a win raises the crit chance, a loss lowers it, a jackpot by the jackpot amount; returns the change
function B.gamble_crit(effect, jackpot)
	local c = B.crit_values()
	local amount
	if jackpot then
		amount = c.jackpot
	else
		amount = math.random(math.floor(c.min * 100 + 0.5), math.floor(c.max * 100 + 0.5)) / 100
	end
	if effect == "remove" then
		amount = -amount
	elseif effect ~= "add" then
		return 0
	end
	local v = math.max(-c.cap, math.min((B.gambler_crit or 0) + amount, c.cap))
	B.gambler_crit = math.floor(v * 100 + 0.5) / 100   -- (whole percents: no drift after many rolls)
	return amount
end

local function pc(v) return math.floor(v * 100 + 0.5) end   -- (a whole percent, either sign: -30% stays -30)

-- every roll (Gilza calls this right after it starts the 4 s cooldown, before it heals or hurts you)
local function on_roll(pm, g)
	if type(g) ~= "table" then return end
	local before = B.gambler_crit or 0
	B.gamble_crit(g.effect, g.jackpot)
	local now = Application:time()
	local exp = pm.get_activate_temporary_expire_time and pm:get_activate_temporary_expire_time("temporary", "loose_ammo_restore_health")
	if type(exp) ~= "number" or exp <= now or exp > now + 30 then exp = now + B.GAMBLER.roll_cd end
	B.gambler_next_roll = exp
	if not B.live then return end
	local what = g.effect == "add" and "win" or g.effect == "remove" and "loss" or "nothing"
	if g.jackpot and g.effect ~= "nothing" then what = what .. " jackpot" end
	local range = ""
	local v = pm:temporary_upgrade_value("temporary", "loose_ammo_restore_health", 0)
	if g.effect ~= "nothing" and type(v) == "table" and type(v[1]) == "number" and type(v[2]) == "number" then
		local k = (g.jackpot and 3 or 1) * (g.effect == "remove" and 2 or 1)
		range = string.format(", %s %d-%d health", g.effect == "remove" and "loses" or "heals", v[1] * k, v[2] * k)
	end
	local team = ""
	if pm:has_category_upgrade("temporary", "loose_ammo_give_team") then team = team .. ", team ammo" end
	if pm:has_category_upgrade("player", "loose_ammo_restore_health_give_team") then team = team .. ", team heal" end
	B.live("gambler roll", "%s%s, crit %+d%% -> %+d%% (cap %d%%), next roll in %.1f s%s", what, range, pc(before),
		pc(B.gambler_crit or 0), pc(B.crit_values().cap), exp - now, team)
end

if PlayerManager.Gilza_new_gambler_triggered then
	local orig_triggered = PlayerManager.Gilza_new_gambler_triggered
	function PlayerManager:Gilza_new_gambler_triggered(heal_gamble, ...)
		pcall(on_roll, self, heal_gamble)
		return orig_triggered(self, heal_gamble, ...)
	end
end

-- card 9: Gilza keeps the dodge gamble between 0 and 35%; the cap grows to 60% on Death Sentence
if PlayerManager.Gilza_add_gambler_new_dodge then
	local orig_dodge = PlayerManager.Gilza_add_gambler_new_dodge
	function PlayerManager:Gilza_add_gambler_new_dodge(amount, ...)
		local ok, cap = pcall(B.gambler_dodge_cap)
		if not ok or type(cap) ~= "number" or type(amount) ~= "number" then
			return orig_dodge(self, amount, ...)
		end
		local before = self._gilza_gambler_new_dodge or 0
		local v = math.max(0, math.min(before + amount, cap))
		self._gilza_gambler_new_dodge = math.floor(v * 100 + 0.5) / 100
		if B.live then
			B.live("gambler dodge", "%+d%%: %d%% -> %d%% (cap %d%%)", pc(amount), pc(before), pc(self._gilza_gambler_new_dodge), pc(cap))
		end
	end
end

local orig_crit = PlayerManager.critical_hit_chance
function PlayerManager:critical_hit_chance(...)
	local chance = orig_crit(self, ...)
	if (B.gambler_crit or 0) > 0 and type(chance) == "number" then
		return chance + B.gambler_crit
	end
	return chance
end

Hooks:PostHook(PlayerManager, "_setup", "GilzaDSBuffs_reset_crit", function()
	B.gambler_crit = 0
end)

Hooks:PreHook(PlayerManager, "on_enter_custody", "GilzaDSBuffs_custody_crit", function()
	B.gambler_crit = 0
end)
