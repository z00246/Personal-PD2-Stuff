if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics
local script = RequiredScript and RequiredScript:lower() or ""

T.DODGE_RANGE = 2500
T.DODGE_RECHECK = 0.4
T.DODGE_RANGE_DS = 3500
T.DODGE_RECHECK_DS = 0.25

local function attack_data_of(unit)
	local brain = alive(unit) and unit:brain()
	local data = brain and brain._logic_data
	if data and data.name == "attack" and data.internal_data and not data.is_converted and not unit:in_slot(16) then
		return data
	end
end

function T.try_dodge(data, reason)
	if not (data.char_tweak and data.char_tweak.dodge and data.char_tweak.dodge.occasions[reason]) then return end
	local fe = data.attention_obj
	if not (fe and fe.reaction and fe.reaction >= AIAttentionObject.REACT_COMBAT) then return end
	return CopLogicBase.chk_start_action_dodge(data, reason)
end

if script == "lib/units/enemies/cop/logics/coplogicattack" then
	local function after_aim(data, my_data)
		if data.important or my_data ~= data.internal_data then return end
		if data.is_converted or data.unit:in_slot(16) then return end
		local fe = data.attention_obj
		if not (fe and fe.verified and fe.is_person and fe.dis and fe.dis < (T.is_ds() and T.DODGE_RANGE_DS or T.DODGE_RANGE)) then return end
		if my_data.pdth_dodge_t and data.t < my_data.pdth_dodge_t then return end
		my_data.pdth_dodge_t = data.t + (T.is_ds() and T.DODGE_RECHECK_DS or T.DODGE_RECHECK)

		local last_sup = data.unit:character_damage():last_suppression_t()
		if data.is_suppressed and last_sup and data.t - last_sup < 0.7 then
			T.try_dodge(data, "scared")
		elseif fe.aimed_at then
			T.try_dodge(data, "preemptive")
		end
	end

	local orig = CopLogicAttack._upd_aim
	CopLogicAttack._upd_aim = function(data, my_data, ...)
		local r = orig(data, my_data, ...)
		if T.active() and my_data then
			pcall(after_aim, data, my_data)
		end
		return r
	end

elseif script == "lib/units/enemies/cop/copdamage" then
	Hooks:PostHook(CopDamage, "damage_bullet", "PDTHTactics_dodge_on_hit", function(self, attack_data)
		if not T.active() or self._dead then return end
		local attacker = attack_data and attack_data.attacker_unit
		local state = managers.groupai and managers.groupai:state()
		if not (alive(attacker) and state and state:all_criminals()[attacker:key()]) then return end
		local data = attack_data_of(self._unit)
		if data and not data.important then
			pcall(T.try_dodge, data, "hit")
		end
	end)
end
