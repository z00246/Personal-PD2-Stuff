GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

B.GRINDER = {
	deck = 11,
	cooldown = 0.75,
	max_stacks = 5,
	max_stacks_ds = 6,
	bloodlust = 0.03,
	share_cap = 0.15,
	share_cap_ds = 0.2,
	share_window = 5,
	share_range = 1500,
	frenzy_stacks = 3,
	gorge_health = 0.35,
	gorge_mul = 2,
	fire_cooldown = 2 -- fire damage (flamethrowers, Dragon's Breath, molotovs, burning) grants a stack at most this often
}
local C = B.GRINDER

function B.grinder_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == C.deck) then
		return 0
	end
	return st:get_specialization_value(C.deck, "tiers", "current_tier") or 0
end

function B.grinder_stacks()
	local unit = managers.player and managers.player:player_unit()
	local dmg = alive(unit) and unit:character_damage()
	local stack = dmg and dmg._damage_to_hot_stack
	return stack and #stack or 0
end

function B.grinder_cap()
	return B.on and C.max_stacks_ds or C.max_stacks
end

if script == "lib/managers/playermanager" then
	-- faster stacking with a stack cap (only affects whoever owns the damage_to_hot upgrade)
	local function apply_tweak()
		local data = tweak_data and tweak_data.upgrades and tweak_data.upgrades.damage_to_hot_data
		if not data then return end
		if data.stacking_cooldown ~= C.cooldown then data.stacking_cooldown = C.cooldown end
		local cap = B.grinder_cap()
		if data.max_stacks ~= cap then data.max_stacks = cap end
	end
	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_grinder_tweak", function() pcall(apply_tweak) end)
	Hooks:Add("MenuUpdate", "GilzaDSBuffs_grinder_tweak_menu", function() pcall(apply_tweak) end)

	-- Flamethrowers hit constantly and set whole crowds burning, which kept every stack up forever:
	-- fire damage can only grant a stack every 2 seconds (other damage keeps the normal 0.75s)
	local orig_doh = PlayerManager._check_damage_to_hot
	function PlayerManager:_check_damage_to_hot(t, unit, damage_info, ...)
		if damage_info and damage_info.variant == "fire" then
			if t < (B._grinder_fire_next or 0) then return end
			local before = self._next_allowed_doh_t
			local r = orig_doh(self, t, unit, damage_info, ...)
			if self._next_allowed_doh_t ~= before then
				B._grinder_fire_next = t + C.fire_cooldown
			end
			return r
		end
		return orig_doh(self, t, unit, damage_info, ...)
	end

	-- Gorge: stacks heal twice as much per tick while at low health
	local orig_uv = PlayerManager.upgrade_value
	function PlayerManager:upgrade_value(category, upgrade, default, ...)
		local v = orig_uv(self, category, upgrade, default, ...)
		if upgrade == "damage_to_hot" and category == "player" and type(v) == "number" and v > 0 then
			local ok, tier = pcall(B.grinder_tier)
			if ok and tier >= 9 then
				local unit = self:player_unit()
				local dmg = alive(unit) and unit:character_damage()
				if dmg and dmg:health_ratio() < C.gorge_health then
					return v * C.gorge_mul
				end
			end
		end
		return v
	end

	-- Frenzy: kills with 3+ stacks refresh every stack
	Hooks:PostHook(PlayerManager, "on_killshot", "GilzaDSBuffs_grinder_frenzy", function(self, killed_unit, variant)
		if variant == "fire" then return end -- burning kills don't refresh stacks
		pcall(function()
			if B.grinder_tier() < 7 then return end
			local unit = self:player_unit()
			local dmg = alive(unit) and unit:character_damage()
			local stack = dmg and dmg._damage_to_hot_stack
			if not stack or #stack < C.frenzy_stacks then return end
			local data = dmg._doh_data or {}
			local full = (data.total_ticks or 1) + self:upgrade_value("player", "damage_to_hot_extra_ticks", 0)
			for _, s in ipairs(stack) do
				s.ticks_left = full
			end
			B.grinder_frenzy_t = Application:time()
		end)
	end)

elseif script == "lib/units/beings/player/playerdamage" then
	-- Overgrowth: healing wasted at full health goes to your nearest teammate
	local orig_restore = PlayerDamage.restore_health
	function PlayerDamage:restore_health(health_restored, is_static, ...)
		local tier = B.grinder_tier()
		if tier < 5 or type(health_restored) ~= "number" or health_restored <= 0 then
			return orig_restore(self, health_restored, is_static, ...)
		end
		local before = self:get_real_health()
		local result = orig_restore(self, health_restored, is_static, ...)
		pcall(function()
			local gained = self:get_real_health() - before
			local intended = health_restored * (self._healing_reduction or 1)
			if not is_static then
				intended = intended * self:_max_health()
			end
			local over = intended - gained
			if over <= 0.0001 or self:get_real_health() < self:_max_health() - 0.0001 then return end
			local now = Application:time()
			if now - (B.grinder_share_t0 or -100) > C.share_window then
				B.grinder_share_t0, B.grinder_share_sum = now, 0
			end
			local cap = self:_max_health() * (B.on and C.share_cap_ds or C.share_cap)
			local amount = math.min(over, cap - (B.grinder_share_sum or 0))
			if amount <= 0 or not B.team_heal then return end
			if B.team_heal(amount, C.share_range, true) then
				B.grinder_share_sum = (B.grinder_share_sum or 0) + amount
			end
		end)
		return result
	end

elseif script == "lib/units/enemies/cop/copdamage" then
	-- Bloodlust: +3% damage per active stack
	local function bloodlust(self, attack_data)
		if not attack_data or type(attack_data.damage) ~= "number" then return end
		local player = managers.player and managers.player:player_unit()
		if not (alive(player) and attack_data.attacker_unit == player) then return end
		if B.grinder_tier() < 3 then return end
		local n = math.min(B.grinder_stacks(), B.grinder_cap())
		if n > 0 then
			attack_data.damage = attack_data.damage * (1 + C.bloodlust * n)
		end
	end
	for _, fn in ipairs({ "damage_bullet", "damage_melee" }) do
		Hooks:PreHook(CopDamage, fn, "GilzaDSBuffs_grinder_" .. fn, function(self, attack_data)
			pcall(bloodlust, self, attack_data)
		end)
	end
end
