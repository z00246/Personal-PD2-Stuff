if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics
local script = RequiredScript and RequiredScript:lower() or ""

local HRT_UNITS = {
	Idstring("units/payday2/characters/ene_fbi_1/ene_fbi_1"),
	Idstring("units/payday2/characters/ene_fbi_2/ene_fbi_2"),
	Idstring("units/payday2/characters/ene_fbi_3/ene_fbi_3")
}
local HRT_TACTICS = { "flank", "smoke_grenade", "pdth_hrt" }

local SQUAD = { [2] = {2,3}, [3] = {3,3}, [4] = {3,4}, [5] = {3,4}, [6] = {4,4}, [7] = {4,5}, [8] = {5,5} }
local function squad_size() return SQUAD[math.clamp(T.diff_index(), 2, 8)] end
local function max_hrt_alive() return squad_size()[2] + 1 end

if script == "lib/tweak_data/groupaitweakdata" then
	Hooks:PostHook(GroupAITweakData, "init", "PDTHTactics_hrt_groups", function(self)
		local ref = self.unit_categories.FBI_suit_C45_M4 or self.unit_categories.FBI_suit_M4_MP5
		if not ref then return end
		local types = {}
		for faction, list in pairs(ref.unit_types or {}) do
			types[faction] = (faction == "america" or faction == "murkywater" or faction == "federales") and HRT_UNITS or list
		end
		T.set(self.unit_categories, "pdth_hrt", { access = ref.access, unit_types = types })
		local size = squad_size()
		T.set(self.enemy_spawn_groups, "pdth_hrt", {
			amount = { size[1], size[2] },
			spawn = {
				{ unit = "pdth_hrt", freq = 1, amount_min = size[1], amount_max = size[2], rank = 1, tactics = HRT_TACTICS }
			}
		})

		local besiege = self.besiege
		local recon = besiege and besiege.recon and besiege.recon.groups
		if recon then
			for name, w in pairs(recon) do
				if type(w) == "table" and string.sub(name, 1, 4) == "tac_" then
					T.set(recon, name, { 0, 0, 0 })
				end
			end
			T.set(recon, "pdth_hrt", { 1, 1, 1 })
		end
		local assault = besiege and besiege.assault and besiege.assault.groups
		if assault then
			T.set(assault, "pdth_hrt", { 0, 0, 0 })
		end
	end)

elseif script == "lib/tweak_data/charactertweakdata" then
	Hooks:PostHook(CharacterTweakData, "init", "PDTHTactics_hrt_rescue", function(self)
		for name, data in pairs(self) do
			if type(data) == "table" and data.rescue_hostages and name ~= "fbi" and name ~= "presets" then
				T.set(data, "rescue_hostages", false)
			end
		end
		if self.fbi then
			T.set(self.fbi, "rescue_hostages", true)
		end
	end)

elseif script == "lib/managers/group_ai_states/groupaistatebesiege" then
	local function hrt_weight(groups)
		local sum, n = 0, 0
		for name, w in pairs(groups) do
			if name ~= "pdth_hrt" and type(w) == "table" and type(w[2]) == "number" and w[2] > 0 then
				sum, n = sum + w[2], n + 1
			end
		end
		return n > 0 and sum / n * 0.6 or 0.1
	end

	local WAVE_MIN_HOSTAGES = 2
	local HRT_FORCE = 0.5
	local HRT_MAX_TIME = 70
	local HRT_COOLDOWN = 2
	local function wave_chance(hostages)
		return math.min(0.25 + (hostages - WAVE_MIN_HOSTAGES) * 0.1, 0.6)
	end

	local function tell_peers(msg)
		if not LuaNetworking then return end
		for peer_id in pairs(T.modded_peers or {}) do
			pcall(LuaNetworking.SendToPeer, LuaNetworking, peer_id, T.NET_ID, msg)
		end
	end

	local function start_wave(groups)
		T._wave_saved = {}
		for name, w in pairs(groups) do
			if name ~= "pdth_hrt" and type(w) == "table" then
				T._wave_saved[name] = { w[1], w[2], w[3] }
				w[1], w[2], w[3] = 0, 0, 0
			end
		end
		groups.pdth_hrt[1], groups.pdth_hrt[2], groups.pdth_hrt[3] = 1, 1, 1
		T.hrt_wave = true
		T.hrt_push_t = nil
		T.set_hrt_banner(true)
		tell_peers("hrt")
	end

	local function end_wave(groups)
		for name, saved in pairs(T._wave_saved or {}) do
			local w = groups[name]
			if w then w[1], w[2], w[3] = saved[1], saved[2], saved[3] end
		end
		T._wave_saved = nil
		T.hrt_wave = nil
		T.hrt_push_t = nil
	end

	local function force_fade(self, task)
		if task.phase == "build" or task.phase == "sustain" then
			task.phase = "fade"
			task.phase_end_t = self._t + (self._tweak_data.assault.fade_duration or 15)
		end
	end

	Hooks:PostHook(GroupAIStateBesiege, "init", "PDTHTactics_hrt_reset", function()
		local groups = tweak_data.group_ai.besiege and tweak_data.group_ai.besiege.assault and tweak_data.group_ai.besiege.assault.groups
		if T._wave_saved and groups then
			end_wave(groups)
		end
		T.hrt_wave, T._wave_saved, T._hrt_next, T.hrt_cooldown = nil, nil, nil, 0
		T.hrt_banner = nil
	end)

	Hooks:PostHook(GroupAIStateBesiege, "_begin_assault_task", "PDTHTactics_hrt_wave", function(self)
		if not T.active() then return end
		local groups = self._tweak_data and self._tweak_data.assault and self._tweak_data.assault.groups
		if not (groups and groups.pdth_hrt) or T.hrt_wave then return end
		if (T.hrt_cooldown or 0) > 0 then
			T.hrt_cooldown = T.hrt_cooldown - 1
			return
		end
		local hostages = self._hostage_headcount or 0
		if hostages >= WAVE_MIN_HOSTAGES and math.random() < wave_chance(hostages) then
			start_wave(groups)
			local task = self._task_data and self._task_data.assault
			if task and task.force then
				task.force = math.max(3, math.ceil(task.force * HRT_FORCE))
			end
		end
	end)

	Hooks:PostHook(GroupAIStateBesiege, "_upd_police_activity", "PDTHTactics_hrt_assault", function(self)
		if not T.active() then return end
		local groups = self._tweak_data and self._tweak_data.assault and self._tweak_data.assault.groups
		if not (groups and groups.pdth_hrt) then return end
		local task = self._task_data and self._task_data.assault
		local t = self._t
		local hostages = self._hostage_headcount or 0

		if T.hrt_wave then
			if not (task and task.active) or task.phase == "fade" then
				end_wave(groups)
			elseif hostages == 0 then
				end_wave(groups)
				force_fade(self, task)
				T.set_hrt_banner(false)
				tell_peers("hrt_off")
			else
				if task.phase == "build" or task.phase == "sustain" then
					T.hrt_push_t = T.hrt_push_t or t
					if t - T.hrt_push_t > HRT_MAX_TIME then
						end_wave(groups)
						force_fade(self, task)
						T.hrt_cooldown = HRT_COOLDOWN
					end
				end
				return
			end
		end

		if T._hrt_next and t < T._hrt_next then return end
		T._hrt_next = t + 2

		local alive_hrt = 0
		for _, u_data in pairs(self._police or {}) do
			if u_data.tactics_map and u_data.tactics_map.pdth_hrt then
				alive_hrt = alive_hrt + 1
			end
		end
		local want = hostages > 0 and alive_hrt < max_hrt_alive()
		local w = want and hrt_weight(groups) or 0
		groups.pdth_hrt[1], groups.pdth_hrt[2], groups.pdth_hrt[3] = w, w, w
	end)

elseif script == "lib/managers/mission/elementspawnenemygroup" then
	Hooks:PostHook(ElementSpawnEnemyGroup, "_finalize_values", "PDTHTactics_hrt_spawnpoints", function(self)
		local list = self._values and self._values.preferred_spawn_groups
		if not (list and T.active() and tweak_data.group_ai.enemy_spawn_groups.pdth_hrt) then return end
		local standard = false
		for _, name in ipairs(list) do
			if name == "tac_swat_rifle_flank" or name == "tac_swat_rifle" or name == "FBI_spoocs" then
				standard = true
			elseif name == "pdth_hrt" then
				return
			end
		end
		if standard then
			table.insert(list, "pdth_hrt")
		end
	end)
end
