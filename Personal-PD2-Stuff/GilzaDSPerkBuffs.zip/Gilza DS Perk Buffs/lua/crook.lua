GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

-- difficulty scaling (shared with buffs.lua): t = 0 up to Overkill, 1/3 Mayhem, 2/3 Death Wish, 1 Death Sentence
if not B.diff_t then
	B.DIFF_T = { easy_wish = 1 / 3, overkill_290 = 2 / 3, sm_wish = 1 }
	function B.diff_t()
		local gs = Global and Global.game_settings
		return gs and B.DIFF_T[gs.difficulty] or 0
	end
	function B.sc(base, ds) return base + (ds - base) * B.diff_t() end
	function B.sci(base, ds) return math.floor(base + (ds - base) * B.diff_t() + 0.5) end
end

-- a line in the BLT log the first times a feature does something (buffs.lua)
local function live(key, ...) if B.live then B.live("crook " .. key, ...) end end

-- Crook (7.17 rework standard, Geo 2026-10-25: "so what can we do about crook now with this major rework", picked
-- "Rework standard"): ballistic vests only (LBV, BV, HBV). Cards named like the other reworked decks:
--  card 1 Sidestep: vest dodge; Deflect: a dodge restores armor
--  card 3 Padding: vest armor; card 5 Deflect: more armor per dodge
--  card 7 Counter: a dodge gives more damage for a moment
--  card 9 Slip: a broken vest gives a burst of dodge
-- The +5% vest dodge per card 1/3/5/7 that used to be Death Sentence only now grows with the difficulty (+1/3 of it
-- on Mayhem, 2/3 on Death Wish, all of it on Death Sentence), and so does Deflect (*_ds = the Death Sentence end).
B.CROOK = {
	deck = 6,
	vests = { level_2 = true, level_3 = true, level_4 = true },
	deflect = { [1] = 0.1, [3] = 0.15, [5] = 0.2 },
	deflect_ds = { [1] = 0.15, [3] = 0.2, [5] = 0.25 },
	counter_damage = 0.25,
	counter_time = 3,
	slip_dodge = 0.3,
	slip_time = 5,
	slip_cooldown = 15,
	-- (7.24) Hoxton's signature (card 9, only as Hoxton): Revenge - the enemy who downs you stays outlined for you;
	-- killing him while you're down gets you back up (the way Messiah does), killing him after you're up restores all
	-- your armor
	revenge_memory = 3          -- the last enemy who hurt you within this many seconds is the one who downed you
}

-- (7.24) Hoxton's Revenge: the marked enemy (or nil)
function B.crook_revenge_target()
	local u = B.hox_target
	if alive(u) and not (u:character_damage() and u:character_damage()._dead) then return u end
	return nil
end
function B.crook_revenge_clear()
	local u = B.hox_target
	B.hox_target = nil
	if alive(u) and B.sig_outline then B.sig_outline(u, "gdsb_revenge", false) end
end

function B.crook_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == B.CROOK.deck) then
		return 0
	end
	return st:get_specialization_value(B.CROOK.deck, "tiers", "current_tier") or 0
end

local function by_tier(tbl, tier)
	local best, v = 0, nil
	for card, val in pairs(tbl) do
		if tier >= card and card > best then best, v = card, val end
	end
	return v
end

function B.crook_vest(override_armor)
	local armor = override_armor or (managers.blackmarket and managers.blackmarket:equipped_armor(true, true))
	return armor and B.CROOK.vests[armor] or false
end


-- +5% vest dodge for each of cards 1, 3, 5 and 7 at the Death Sentence end, scaled by the difficulty (7.17; it was
-- Death Sentence only). On Death Sentence the generic niches (buffs.lua) already bump the upgrade tables once (card 1's
-- passive dodge and the vest's current addend level), so only the difference is added here; below Death Sentence those
-- niches aren't applied (B.saved holds none of them), so the whole scaled amount is added here.
B.CROOK.ds_dodge_per_card = 0.05
B.CROOK.ds_dodge_cards = { 1, 3, 5, 7 }

-- Deflect's share of max armor for this card and difficulty
function B.crook_deflect(tier)
	local base = by_tier(B.CROOK.deflect, tier)
	if not base then return 0 end
	return B.sc(base, by_tier(B.CROOK.deflect_ds, tier) or base)
end

local function ds_bonus_applied(pm, key)
	local rec = B.saved and B.saved["player." .. key]
	if not rec then return 0 end
	local level = pm:upgrade_level("player", key, 0) or 0
	if level <= 0 then return 0 end
	local o = type(rec.orig) == "table" and rec.orig[level]
	local b = type(rec.buffed) == "table" and rec.buffed[level]
	if type(o) == "number" and type(b) == "number" then
		return b - o
	end
	return 0
end

-- t: the difficulty scale the upgrade tables are set for (B.t, from B.apply); defaults to the current difficulty
function B.crook_ds_dodge_fix(pm, tier, override_armor, t)
	local armor = override_armor or (managers.blackmarket and managers.blackmarket:equipped_armor(true, true))
	if not (armor and B.CROOK.vests[armor]) then return 0 end
	t = t or B.t or B.diff_t()
	if not t or t <= 0 then return 0 end
	local want = 0
	for _, card in ipairs(B.CROOK.ds_dodge_cards) do
		if tier >= card then want = want + B.CROOK.ds_dodge_per_card end
	end
	want = want * math.min(t, 1)
	local have = ds_bonus_applied(pm, armor .. "_dodge_addend") + ds_bonus_applied(pm, "passive_dodge_chance")
	return math.max(want - have, 0)
end

if script == "lib/managers/playermanager" then
	local function on_dodge()
		local tier = B.crook_tier()
		if tier < 1 then return end
		local now = Application:time()
		if B.crook_vest() and managers.player then
			local unit = managers.player:player_unit()
			local dmg = alive(unit) and unit:character_damage()
			if dmg and not dmg:dead() then
				local share = B.crook_deflect(tier)
				dmg:restore_armor(dmg:_max_armor() * share)
				live("deflect", "a dodge restored %.1f%% armor", share * 100)
			end
		end
		if tier >= 7 then
			B.crook_counter_until = now + B.CROOK.counter_time
			live("counter", "a dodge gave +%d%% damage for %d seconds", B.CROOK.counter_damage * 100, B.CROOK.counter_time)
		end
	end

	Hooks:PostHook(PlayerManager, "init", "GilzaDSBuffs_crook_dodge", function(self)
		self:register_message(Message.OnPlayerDodge, "GilzaDSBuffs_crook_dodge", function()
			on_dodge()
		end)
	end)

	-- (7.24) Hoxton's Revenge: killing the enemy who downed you
	Hooks:PostHook(PlayerManager, "on_killshot", "GilzaDSBuffs_crook_revenge", function(self, killed_unit)
		if not (alive(killed_unit) and killed_unit == B.hox_target) then return end
		local unit = self:player_unit()
		local dmg = alive(unit) and unit:character_damage()
		B.crook_revenge_clear()
		if not dmg or dmg:dead() then return end
		if dmg:need_revive() or dmg._bleed_out then
			-- the way Messiah gets you up: the game's own revive message to your PlayerDamage
			self:send_message(Message.RevivePlayer, nil, nil)
			B.sig_live("revenge up", "you killed the enemy who downed you: back up")
		else
			dmg:restore_armor(dmg:_max_armor())
			B.sig_live("revenge armor", "you killed the enemy who downed you: all your armor back")
		end
		if unit:sound() then unit:sound():play("perkdeck_activate", nil, false) end
	end)

	Hooks:PreHook(PlayerManager, "on_enter_custody", "GilzaDSBuffs_crook_revenge_custody", function()
		B.crook_revenge_clear()
	end)

	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_crook_revenge_update", function()
		local session = managers.network and managers.network:session()
		if B._crook_session ~= session then
			B._crook_session = session
			B.hox_target, B._hox_last, B._hox_last_t, B._hox_spooc, B._hox_spooc_t = nil, nil, nil, nil, nil
		end
		-- someone else killed him: the outline goes
		if B.hox_target and not B.crook_revenge_target() then B.crook_revenge_clear() end
	end)

	local orig_dodge = PlayerManager.skill_dodge_chance
	function PlayerManager:skill_dodge_chance(running, crouching, on_zipline, override_armor, ...)
		local chance = orig_dodge(self, running, crouching, on_zipline, override_armor, ...)
		if type(chance) ~= "number" then return chance end
		local tier = B.crook_tier()
		if tier > 0 then
			if B.crook_vest(override_armor) then
				if Application:time() < (B.crook_slip_until or 0) then
					chance = chance + B.CROOK.slip_dodge
				end
				-- (7.17) the difficulty ramp: B.t is the scale the upgrade tables are set for (0 up to Overkill)
				local t = B.t or 0
				if t > 0 then
					local fix = B.crook_ds_dodge_fix(self, tier, override_armor, t)
					if type(fix) == "number" then
						chance = chance + fix
						if fix > 0 then live("dodge ramp", "+%.1f%% vest dodge (difficulty scale %.2f)", fix * 100, t) end
					end
				end
			else
				chance = chance - self:upgrade_value("player", "passive_dodge_chance", 0)
			end
		end
		return chance
	end

elseif script == "lib/units/beings/player/playerdamage" then
	Hooks:PreHook(PlayerDamage, "_calc_armor_damage", "GilzaDSBuffs_crook_slip_pre", function(self)
		B._crook_pre_armor = self:get_real_armor()
	end)
	Hooks:PostHook(PlayerDamage, "_calc_armor_damage", "GilzaDSBuffs_crook_slip", function(self)
		if (B._crook_pre_armor or 0) <= 0 or self:get_real_armor() > 0 or B.crook_tier() < 9 or not B.crook_vest() then return end
		local now = Application:time()
		if now < (B.crook_slip_ready or 0) then return end
		B.crook_slip_until = now + B.CROOK.slip_time
		B.crook_slip_ready = now + B.CROOK.slip_cooldown
		live("slip", "the vest broke: +%d%% dodge for %d seconds", B.CROOK.slip_dodge * 100, B.CROOK.slip_time)
	end)

	-- (7.24) Hoxton's Revenge: remember who last hurt you; when you go down, he is the one
	for _, fn in ipairs({ "damage_bullet", "damage_melee", "damage_explosion", "damage_fire" }) do
		if PlayerDamage[fn] then
			Hooks:PreHook(PlayerDamage, fn, "GilzaDSBuffs_crook_revenge_" .. fn, function(self, attack_data)
				local u = attack_data and attack_data.attacker_unit
				if alive(u) and u ~= self._unit and u:character_damage() and u:base() and not (u:base().is_husk_player) then
					B._hox_last, B._hox_last_t = u, Application:time()
				end
			end)
		end
	end
	-- on_downed: going down from health (bleed-out) and a Cloaker's kick (on_incapacitated) both come through here
	Hooks:PostHook(PlayerDamage, "on_downed", "GilzaDSBuffs_crook_revenge_downed", function(self)
		if not (B.sig_active and B.sig_active(B.CROOK.deck)) then return end
		local now = Application:time()
		local u = B._hox_last
		-- a Cloaker who kicked you a moment ago is the one, whoever shot you before
		if alive(B._hox_spooc) and now - (B._hox_spooc_t or -100) <= 1 then u = B._hox_spooc end
		local t = u == B._hox_spooc and B._hox_spooc_t or B._hox_last_t
		if not (alive(u) and now - (t or -100) <= B.CROOK.revenge_memory) then return end
		local cd = u:character_damage()
		if not cd or cd._dead then return end
		B.crook_revenge_clear()
		B.hox_target = u
		if B.sig_outline then B.sig_outline(u, "gdsb_revenge", true) end
		local base = u:base()
		B.sig_live("revenge", "a %s downed you: he's marked", tostring(base and base._tweak_table))
	end)

elseif script == "lib/units/beings/player/playermovement" then
	-- (7.24) Hoxton's Revenge: a Cloaker's kick never goes through PlayerDamage's damage functions
	Hooks:PreHook(PlayerMovement, "on_SPOOCed", "GilzaDSBuffs_crook_revenge_spooc", function(self, enemy_unit)
		if alive(enemy_unit) then
			B._hox_spooc, B._hox_spooc_t = enemy_unit, Application:time()
		end
	end)

elseif script == "lib/units/enemies/cop/copdamage" then
	for _, fn in ipairs({ "damage_bullet", "damage_melee" }) do
		Hooks:PreHook(CopDamage, fn, "GilzaDSBuffs_crook_counter_" .. fn, function(self, attack_data)
			if not attack_data or type(attack_data.damage) ~= "number" then return end
			if Application:time() >= (B.crook_counter_until or 0) then return end
			local player = managers.player and managers.player:player_unit()
			if alive(player) and attack_data.attacker_unit == player then
				attack_data.damage = attack_data.damage * (1 + B.CROOK.counter_damage)
			end
		end)
	end

elseif script == "lib/tweak_data/skilltreetweakdata" then
	Hooks:PostHook(SkillTreeTweakData, "init", "GilzaDSBuffs_crook_cards", function(self)
		local card = self.specializations and self.specializations[B.CROOK.deck] and self.specializations[B.CROOK.deck][9]
		local ups = card and card.upgrades
		if ups then
			for i = #ups, 1, -1 do
				if ups[i] == "weapon_passive_armor_piercing_chance_maxed" or ups[i] == "weapon_passive_armor_piercing_chance" then
					table.remove(ups, i)
				end
			end
		end
	end)
end
