-- Burglar visuals (7.00): the screen edges go hazy and cool while Slip Away, Fade Out or a Wraith dodge hides you.
-- (The 6.x cloak ring and the shimmer on other Burglars went with the cloak.)
GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
if B._burg_fx then return end
B._burg_fx = true

local EDGE = "guis/textures/gilza_plates/cloak_edge"
local COOL = Color(0.75, 0.88, 1)

local hud = {}
local function build()
	local ws = managers.hud and managers.hud._fullscreen_workspace
	local root = ws and ws:panel()
	if not (root and alive(root)) then return end
	if hud.panel and alive(hud.panel) then return hud.panel end
	local p = root:panel({ name = "gdsb_vanish", layer = 1 })
	hud.panel = p
	hud.edge = p:bitmap({ texture = EDGE, w = p:w(), h = p:h(), color = COOL, alpha = 0, layer = 0 })
	return p
end

local function approach(v, target, rate, dt)
	if v < target then return math.min(target, v + rate * dt) end
	return math.max(target, v - rate * dt)
end

local cur = 0
local function update_self(dt)
	local tier = B.burglar_tier and B.burglar_tier() or 0
	if tier < 1 then
		if hud.panel and alive(hud.panel) then hud.panel:set_visible(false) end
		cur = 0
		return
	end
	local p = build()
	if not p then return end
	p:set_visible(true)
	hud.edge:set_size(p:w(), p:h()); hud.edge:set_position(0, 0)
	local on = B.burglar_vanished and B.burglar_vanished() or false
	cur = approach(cur, on and 1 or 0, on and 2.5 or 5, dt)
	hud.edge:set_alpha(0.55 * cur)
end

Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_burglar_fx", function(t, dt)
	update_self(dt or 0)
end)
