if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics
local script = RequiredScript and RequiredScript:lower() or ""

-- Restoration Mod factions (NYPD, LAPD, Reapers, Sharks, Bravo), shipped in the separate "PDTH Factions" mod.
-- A faction is only used when the host and every player in the lobby have that pack loaded;
-- otherwise everyone gets the normal enemies. Appearance (heads/gear variations) is rolled locally.

if not T.FD then
	-- the data file stores itself in PDTHTactics.FD (the game's dofile doesn't hand back return values)
	local ok, data = pcall(dofile, ModPath .. "lua/faction_data.lua")
	if ok and type(data) == "table" then T.FD = data end
	if not ok then log(T.name .. " faction data failed: " .. tostring(data)) end
	if not T.FD then log(T.name .. " faction data missing") end
end
local D = T.FD
if not D then return end

-- no dual-pistol "veteran" cops (Restoration's akimbo Chimano enemy): their slot falls back
-- to the next lower difficulty's list for that faction
if not D._no_veterans then
	D._no_veterans = true
	local function strip(list)
		for i = #list, 1, -1 do
			if type(list[i]) == "string" and string.find(list[i], "veteran", 1, true) then table.remove(list, i) end
		end
	end
	for _, diffs in pairs(D.faction or {}) do
		for _, roles in pairs(diffs) do
			for _, list in pairs(roles) do strip(list) end
		end
	end
	for _, list in pairs(D.units or {}) do strip(list) end
end

local UNIT = Idstring("unit")
T.fac_peers = T.fac_peers or {}

-- key lookups (built once per Lua state)
if not T._fac_keys then
	T._fac_keys = { role = {}, faction_units = {}, enemy_seq = {}, head_seq = {} }
	local K = T._fac_keys
	for path, role in pairs(D.role) do K.role[Idstring(path):key()] = role end
	for _, list in pairs(D.units) do
		for _, path in ipairs(list) do
			K.faction_units[Idstring(path):key()] = true
			K.faction_units[Idstring(path .. "_husk"):key()] = true
		end
	end
	for path, seq in pairs(D.enemy_seq) do
		K.enemy_seq[Idstring(path):key()] = seq
		K.enemy_seq[Idstring(path .. "_husk"):key()] = seq
	end
	K.unit_weapon, K.weapons = {}, {}
	for path, w in pairs(D.unit_weapon or {}) do
		K.unit_weapon[Idstring(path):key()] = w
		K.unit_weapon[Idstring(path .. "_husk"):key()] = w
	end
	for _, w in ipairs(D.weapons or {}) do K.weapons[Idstring(w.unit):key()] = w end
	for path, seq in pairs(D.head_seq) do
		K.head_seq[Idstring(path):key()] = seq
		K.head_seq[Idstring(path .. "_husk"):key()] = seq
	end
end
local K = T._fac_keys


-- Restoration's faction guns. Stats, ids and network sync stay vanilla: the host and every client
-- (all have this mod whenever a faction is active) just show the faction's gun model instead.
local function vanilla_weapon_name(base_id)
	local c = tweak_data.character
	local i = c and c.weap_ids and table.index_of(c.weap_ids, base_id)
	return i and i > 0 and c.weap_unit_names[i] or nil
end

function T.faction_weapon_for(char_unit, wanted_name)
	if not (alive(char_unit) and wanted_name) then return end
	local custom = K.unit_weapon[char_unit:name():key()]
	if not custom then return end
	local w = K.weapons[Idstring(custom):key()]
	local van = w and vanilla_weapon_name(w.base)
	if van and van:key() == wanted_name:key() and DB:has(UNIT, Idstring(custom)) then
		-- the gun's stats must be usable by this enemy type, or the game crashes on equip
		local wt = tweak_data.weapon[w.name_id]
		local ct = char_unit:base() and char_unit:base():char_tweak()
		if not (wt and wt.usage and ct and ct.weapon and ct.weapon[wt.usage]) then return end
		local dyn = managers.dyn_resource
		if dyn and dyn.has_resource and not dyn:has_resource(UNIT, Idstring(custom), dyn.DYN_RESOURCES_PACKAGE) then return end
		return Idstring(custom)
	end
end

-- a faction enemy's own (vanilla) gun must also be usable by its enemy type; if not, pick one that is
local SAFE_GUNS = { "m4", "c45", "mp5", "r870", "benelli", "m249", "saiga", "ump", "m14_sniper_npc", "raging_bull" }
function T.faction_safe_weapon(base, name)
	local c = tweak_data.character
	local ct = base.char_tweak and base:char_tweak()
	if not (c and c.weap_ids and ct and ct.weapon and name) then return name end
	local function usage_of(unit_name)
		for i, n in ipairs(c.weap_unit_names) do
			if n:key() == unit_name:key() then
				local id = c.weap_ids[i]
				local wt = tweak_data.weapon[id .. "_npc"] or tweak_data.weapon[id]
				return wt and wt.usage
			end
		end
	end
	local u = usage_of(name)
	if u == nil or ct.weapon[u] then return name end
	for _, id in ipairs(SAFE_GUNS) do
		local i = table.index_of(c.weap_ids, id)
		local wt = tweak_data.weapon[id .. "_npc"] or tweak_data.weapon[id]
		if i and i > 0 and wt and wt.usage and ct.weapon[wt.usage] then
			return c.weap_unit_names[i]
		end
	end
	return name
end

T.SKIP_FACTIONS = T.SKIP_FACTIONS or {}

function T.level_faction()
	local level = Global.level_data and Global.level_data.level_id or Global.game_settings and Global.game_settings.level_id
	local f = level and D.levels[level]
	local t = tweak_data and tweak_data.levels and tweak_data.levels.get_ai_group_type and tweak_data.levels:get_ai_group_type()
	if not f and (t == "russia" or t == "murkywater" or t == "federales") then f = t end
	-- Reapers/Sharks use the Russian voice soundbank: only on heists that are Russian/Murkywater
	-- in the base game (Restoration moves extra heists to them, which would need that bank)
	if (f == "russia" or f == "murkywater") and t ~= f then f = nil end
	if f and T.SKIP_FACTIONS[f] then f = nil end
	return f
end

local function db_has(ids)
	local fm = BeardLib and BeardLib.Managers and BeardLib.Managers.File
	if fm and fm.Has then
		local ok, r = pcall(fm.Has, fm, UNIT, ids)
		if ok and r then return true end
	end
	return DB:has(UNIT, ids)
end

local function is_loaded(ids)
	local dyn = managers.dyn_resource
	-- the same check BeardLib uses before it force-loads a unit (PackageManager:has can say yes too early)
	if dyn and dyn.has_resource then return dyn:has_resource(UNIT, ids, dyn.DYN_RESOURCES_PACKAGE) and true or false end
	return PackageManager:has(UNIT, ids)
end

-- never hand the game a unit that isn't already in memory: loading one mid-fight can crash the game
function T.unit_ready(ids)
	if not ids then return false end
	if not T._fac_husk then
		T._fac_husk = {}
		for _, list in pairs(D.units) do
			for _, path in ipairs(list) do T._fac_husk[Idstring(path):key()] = Idstring(path .. "_husk") end
		end
		local z = "units/pd2_dlc_gitgud/characters/ene_zeal_medic/ene_zeal_medic"
		T._fac_husk[Idstring(z):key()] = Idstring(z .. "_husk")
	end
	local ok, r = pcall(function()
		local husk = T._fac_husk[ids:key()]
		return is_loaded(ids) and (not husk or is_loaded(husk))
	end)
	return ok and r or false
end

local function ready_or_nil(new)
	if new and T.unit_ready(new) then return new end
	if new and not T._fac_notready_logged then
		T._fac_notready_logged = true
		log(T.name .. " skipped a faction unit that wasn't loaded: " .. tostring(new))
	end
	return nil
end
T.faction_ready_or_nil = ready_or_nil

local function pack_present(f)
	local list = D.units[f]
	return list and list[1] and db_has(Idstring(list[1])) or false
end

T.fac_status = T.fac_status or {}

-- Restoration's approach: hand the units to BeardLib while the heist is loading
-- (GameSetup:load_packages). BeardLib loads them when the resource manager starts,
-- on the main thread before the world exists. Nothing is ever loaded mid-game.
T._fac_pending = T._fac_pending or {}
T._fac_queue = T._fac_queue or {}
local function queue_asset(ids, name)
	table.insert(T._fac_queue, { ids = ids, name = name or tostring(ids) })
end
T.faction_queue_asset = queue_asset

local function load_faction(f, keep)
	T._fac_loaded = T._fac_loaded or {}
	if T._fac_loaded[f] ~= nil then return T._fac_loaded[f] end
	T._fac_loaded[f] = false
	if not BeardLib then T.fac_status[f] = "BeardLib is not installed" return false end
	if not pack_present(f) then T.fac_status[f] = "the PD:TH Factions mod was not found" return false end
	local list = {}
	for _, path in ipairs(D.units[f]) do
		for _, name in ipairs((not keep or keep(path)) and { path, path .. "_husk" } or {}) do
			local ids = Idstring(name)
			table.insert(list, { ids = ids, name = name })
			local ok, err = pcall(queue_asset, ids, name)
			if not ok then log(T.name .. " faction " .. f .. " queue error " .. name .. ": " .. tostring(err)) end
		end
	end
	-- helmets, heads, debris and guns these units spawn later
	if not keep then
		for _, path in ipairs(D.extra and D.extra[f] or {}) do
			pcall(queue_asset, Idstring(path), path)
		end
	end
	log(T.name .. " faction " .. f .. ": queued " .. #list .. " units")
	T.fac_status[f] = "loading"
	T._fac_pending[f] = { list = list }
	return false
end

-- returns true when the faction finished (ready or failed)
local function poll_faction(f)
	local p = T._fac_pending[f]
	if not p then return true end
	p.start = p.start or Application:time()
	local missing = {}
	for _, e in ipairs(p.list) do
		if not is_loaded(e.ids) then table.insert(missing, e.name) end
	end
	if #missing == 0 then
		T._fac_pending[f] = nil
		T._fac_loaded[f] = true
		T.fac_status[f] = "ready"
		log(T.name .. " faction " .. f .. ": ready (" .. string.format("%.1f", Application:time() - p.start) .. "s)")
		return true
	end
	if Application:time() - p.start > 15 then
		T._fac_pending[f] = nil
		T.fac_status[f] = #missing .. " units failed to load (see BLT log)"
		for _, n in ipairs(missing) do log(T.name .. " faction " .. f .. " could not load " .. n) end
		return true
	end
	return false
end

local function everyone_has(f)
	local have = T.fac_peers[f] or {}
	local lobby = Global.pdth_fac_users or {}
	local mine = T.factions_pack_version and T.factions_pack_version()
	local session = managers.network and managers.network:session()
	for _, peer in pairs(session and session:peers() or {}) do
		-- confirmed in-game, or confirmed in the lobby with the same PD:TH Factions version as ours
		local uid = peer.user_id and peer:user_id()
		if not (have[peer:id()] or (mine and uid and lobby[uid] == mine)) then return false end
	end
	return true
end

local NAMES = { federales = "Federales", zealsniper = "ZEAL Sniper", dozers = "Bulldozer", tasers = "Tazer", nypd = "NYPD", lapd = "LAPD", russia = "Reapers", murkywater = "Sharks", bravo = "Bravo" }

local function say(text)
	if managers.chat then
		managers.chat:_receive_message(1, T.name, text, T.color or Color.white)
	end
end

local function missing_peers(f)
	local have = T.fac_peers[f] or {}
	local names = {}
	local session = managers.network and managers.network:session()
	for _, peer in pairs(session and session:peers() or {}) do
		if not have[peer:id()] then table.insert(names, peer:name()) end
	end
	return names
end

function T.faction_notice(f)
	local name = NAMES[f] or f
	if not (T._fac_loaded and T._fac_loaded[f]) then
		say(name .. " enemies are off: " .. tostring(T.fac_status[f] or "not loaded") .. ".")
		return
	end
	local miss = missing_peers(f)
	if #miss > 0 then
		say(name .. " enemies are off until everyone has PD:TH Factions (missing: " .. table.concat(miss, ", ") .. ").")
	else
		say(name .. " enemies are on.")
	end
end

function T.faction_usable(f)
	return f and T._fac_loaded and T._fac_loaded[f] and everyone_has(f) or false
end

-- the faction swapping right now (host), or nil
function T.faction_now()
	if not T.active() then return nil end
	local f = T.level_faction()
	return T.faction_usable(f) and f or nil
end

local BRAVO = {
	swat_1 = "rifle", swat_2 = "shotgun", heavy_1 = "lmg", heavy_2 = "shotgun",
	fsb_swat_1 = "rifle", fsb_swat_2 = "shotgun", fsb_heavy = "lmg"
}
local BRAVO_SUFFIX = { america = "", nypd = "", lapd = "", fbi = "", russia = "_ru", murkywater = "_murky", federales = "_mex" }
local DIFF_ORDER = { "sm_wish", "overkill_290", "easy_wish", "overkill_145", "overkill", "hard", "normal", "easy" }
T.BRAVO_CHANCE = 0.25
T.BRAVO_FROM_ASSAULT = 3

local function pick_bravo(role)
	local kind = BRAVO[role]
	if not kind or math.random() > T.BRAVO_CHANCE then return end
	if not (T.is_ds() and T.faction_usable("bravo")) then return end
	local state = managers.groupai and managers.groupai:state()
	local n = state and state._assault_number or 0
	if n < T.BRAVO_FROM_ASSAULT then return end
	local group = T.level_faction() or (tweak_data.levels:get_ai_group_type())
	local suffix = BRAVO_SUFFIX[group]
	if not suffix then return end
	local path = "units/pd2_mod_bravo/characters/ene_bravo_" .. kind .. suffix .. "/ene_bravo_" .. kind .. suffix
	return Idstring(path)
end

-- how many separate-head faction cops can be alive at once (each one is two animated units)
T.HEAD_UNIT_CAP = T.HEAD_UNIT_CAP or math.huge
function T.head_units_alive()
	local n = 0
	for _, u_data in pairs(managers.enemy and managers.enemy:all_enemies() or {}) do
		local u = u_data.unit
		if alive(u) and K.head_seq[u:name():key()] then n = n + 1 end
	end
	return n
end

function T.faction_pick(name, group_spawn)
	if not name then return end
	local role = K.role[name:key()]
	if not role then return end
	if group_spawn then
		local b = pick_bravo(role)
		if b then return b end
	end
	local f = T.faction_now()
	if not f then return T.taser_pick(name, role) end
	-- use this difficulty's list; if the faction has nothing of its own there (e.g. Restoration puts
	-- ZEAL on Death Sentence everywhere), fall back to the closest lower difficulty that does
	local diff = Global.game_settings and Global.game_settings.difficulty or "overkill"
	local start = false
	for _, d in ipairs(DIFF_ORDER) do
		if d == diff then start = true end
		if start then
			local list = D.faction[f][d] and D.faction[f][d][role]
			if list and #list > 0 then
				local pick = Idstring(list[math.random(#list)])
				-- NYPD/LAPD/Federales cops each spawn a second, linked head unit; past the cap the
				-- rest of the wave uses the regular enemies so big fights don't tank FPS
				if K.head_seq[pick:key()] and T.head_units_alive() >= T.HEAD_UNIT_CAP then
					return T.taser_pick(name, role)
				end
				return pick
			end
		end
	end
	return T.taser_pick(name, role)
end

-- everywhere else: Tazers use Restoration's model, which has a battery box you can shoot
local ZEAL_TAZER = Idstring("units/pd2_dlc_gitgud/characters/ene_zeal_tazer/ene_zeal_tazer"):key()
local TASER_GROUPS = { america = true, fbi = true, nypd = true, lapd = true }
local ZEAL_SNIPER = Idstring("units/pd2_dlc_gitgud/characters/ene_zeal_sniper/ene_zeal_sniper")
local ZEAL_SNIPER_FROM = {
	[Idstring("units/payday2/characters/ene_sniper_1/ene_sniper_1"):key()] = true,
	[Idstring("units/payday2/characters/ene_sniper_2/ene_sniper_2"):key()] = true
}
local DOZERS = {}
for v, r in pairs({
	["units/payday2/characters/ene_bulldozer_1/ene_bulldozer_1"] = "units/payday2/characters/ene_bulldozer_1_sc/ene_bulldozer_1_sc",
	["units/payday2/characters/ene_bulldozer_2/ene_bulldozer_2"] = "units/payday2/characters/ene_bulldozer_2_sc/ene_bulldozer_2_sc",
	["units/payday2/characters/ene_bulldozer_3/ene_bulldozer_3"] = "units/payday2/characters/ene_bulldozer_3_sc/ene_bulldozer_3_sc",
	["units/pd2_dlc_gitgud/characters/ene_zeal_bulldozer/ene_zeal_bulldozer"] = "units/pd2_dlc_gitgud/characters/ene_zeal_bulldozer_sc/ene_zeal_bulldozer_sc",
	["units/pd2_dlc_gitgud/characters/ene_zeal_bulldozer_2/ene_zeal_bulldozer_2"] = "units/pd2_dlc_gitgud/characters/ene_zeal_bulldozer_2_sc/ene_zeal_bulldozer_2_sc",
	["units/pd2_dlc_gitgud/characters/ene_zeal_bulldozer_3/ene_zeal_bulldozer_3"] = "units/pd2_dlc_gitgud/characters/ene_zeal_bulldozer_3_sc/ene_zeal_bulldozer_3_sc"
}) do DOZERS[Idstring(v):key()] = Idstring(r) end

function T.taser_pick(name, role)
	-- Restoration's Bulldozers in place of the matching vanilla ones (same weapon, same type)
	local dozer = DOZERS[name:key()]
	if dozer then
		if T.active() and T.faction_usable("dozers") then
			local group = tweak_data.levels.get_ai_group_type and tweak_data.levels:get_ai_group_type() or "america"
			if TASER_GROUPS[group] then return dozer end
		end
		return
	end
	-- Death Sentence: snipers on normal heists become Restoration's ZEAL Sniper
	if ZEAL_SNIPER_FROM[name:key()] then
		if T.active() and T.is_ds() and T.faction_usable("zealsniper") then
			local group = tweak_data.levels.get_ai_group_type and tweak_data.levels:get_ai_group_type() or "america"
			if TASER_GROUPS[group] then return ZEAL_SNIPER end
		end
		return
	end
	if role ~= "taser" and role ~= "ttaser" then return end
	if not (T.active() and T.faction_usable("tasers")) then return end
	local group = tweak_data.levels.get_ai_group_type and tweak_data.levels:get_ai_group_type() or "america"
	if not TASER_GROUPS[group] then return end
	if name:key() == ZEAL_TAZER then
		return Idstring("units/pd2_dlc_gitgud/characters/ene_zeal_tazer_sc/ene_zeal_tazer_sc")
	end
	return Idstring("units/payday2/characters/ene_tazer_1_sc/ene_tazer_1_sc")
end

function T.is_faction_unit(unit)
	return alive(unit) and K.faction_units[unit:name():key()] or false
end

-- heads, gear and body variations (Restoration's CopBase:_run_unit_sequences, local only)
local short_body_objects = { Idstring("g_body_short"), Idstring("g_body_b_short"), Idstring("g_body_short_fbi"), Idstring("g_body_b_short_fbi") }
local function run_sequences(base)
	local unit = base._unit
	if not alive(unit) then return end
	local key = unit:name():key()
	if not K.faction_units[key] then return end
	local dmg = unit:damage()
	local seq = K.enemy_seq[key]
	if seq and dmg and dmg:has_sequence(seq) then dmg:run_sequence_simple(seq) end

	local short_body = false
	for _, obj_name in ipairs(short_body_objects) do
		local obj = unit:get_object(obj_name)
		if obj and obj:visibility() then short_body = true break end
	end

	local spawn = unit:spawn_manager()
	local head = unit:character_damage() and unit:character_damage()._head
	if spawn and head then
		managers.dyn_resource:load(UNIT, Idstring(head), managers.dyn_resource.DYN_RESOURCES_PACKAGE, nil)
		spawn:spawn_and_link_unit("_char_joint_names", "cop_head", head)
		base._head_unit = spawn:get_unit("cop_head")
	end
	local head_unit = base._head_unit
	if alive(head_unit) then
		head_unit:set_enabled(unit:enabled())
		-- heads are not outlined (outlining body + head doubled the cost of every mark)
		local hd = head_unit:damage()
		if hd then
			local arms = short_body and "arms_short_on" or "arms_short_off"
			if hd:has_sequence(arms) then hd:run_sequence_simple(arms) end
			local hs = K.head_seq[key]
			if hs and hd:has_sequence(hs) then hd:run_sequence_simple(hs) end
		end
	end
end

-- picks and loads what this heist needs (host and clients alike)
function T.faction_preload()
	if T._fac_done then return end
	T._fac_done = true
	local wanted = {}
	local f = T.level_faction()
	local level = Global.level_data and Global.level_data.level_id or Global.game_settings and Global.game_settings.level_id
	log(T.name .. " factions: level=" .. tostring(level) .. " faction=" .. tostring(f) .. " ds=" .. tostring(T.is_ds())
		.. " host=" .. tostring(Network and Network:is_server()) .. " beardlib=" .. tostring(BeardLib ~= nil))
	if f then table.insert(wanted, f) end
	if T.is_ds() then table.insert(wanted, "bravo") end
	local vgroup = tweak_data.levels.get_ai_group_type and tweak_data.levels:get_ai_group_type() or "america"
	if vgroup == "america" or vgroup == "fbi" then
		table.insert(wanted, "tasers")
		table.insert(wanted, "dozers")
		if T.is_ds() then table.insert(wanted, "zealsniper") end
	end
	T._fac_wanted = wanted
	-- Bravo: only the variant that fits this heist (the Russian/Murkywater ones pull in
	-- the Russian voice soundbank, which a normal heist doesn't have loaded)
	local group = f or (tweak_data.levels.get_ai_group_type and tweak_data.levels:get_ai_group_type()) or "america"
	local sfx = ({ russia = "_ru", murkywater = "_murky", federales = "_mex" })[group] or ""
	local function bravo_keep(path)
		local name = string.match(path, "([^/]+)$") or ""
		if string.find(name, "bulldozer", 1, true) then return false end
		local has_sfx = string.match(name, "_ru$") or string.match(name, "_murky$") or string.match(name, "_mex$")
		if sfx == "" then return not has_sfx end
		return string.sub(name, -#sfx) == sfx
	end
	for _, w in ipairs(wanted) do
		local ok, err = pcall(load_faction, w, w == "bravo" and bravo_keep or nil)
		if not ok then
			T._fac_loaded[w] = false
			T.fac_status[w] = "load error (see BLT log)"
			log(T.name .. " faction " .. w .. " load error: " .. tostring(err))
		end
	end
	T._fac_heist_faction = f
	if T.zeal_preload then T.zeal_preload() end
end

-- load the queued units right after BeardLib's own loads (resource manager just started,
-- main thread, before the world exists). Each unit is logged first, so a hang names its unit.
function T.faction_load_queue()
	local dyn = managers.dyn_resource
	if not (dyn and T._fac_queue and #T._fac_queue > 0) then return end
	log(T.name .. " factions: loading " .. #T._fac_queue .. " units")
	for _, e in ipairs(T._fac_queue) do
		if not dyn:has_resource(UNIT, e.ids, dyn.DYN_RESOURCES_PACKAGE) then
			log(T.name .. " load " .. e.name)
			local ok, err = pcall(dyn.load, dyn, UNIT, e.ids, dyn.DYN_RESOURCES_PACKAGE, nil)
			if not ok then log(T.name .. " load failed " .. e.name .. ": " .. tostring(err)) end
		end
	end
	T._fac_queue = {}
	log(T.name .. " factions: all units loaded")
end

-- Like Restoration's enemy presets: make sure every enemy type has stats for every gun type,
-- so faction enemies can carry any gun. Missing entries are copied from the closest existing one.
local USAGE_FALLBACK = {
	is_smg = { "is_rifle" }, is_lmg = { "is_rifle" }, is_sniper = { "is_rifle" },
	is_bullpup = { "is_rifle" }, is_dmr = { "is_sniper", "is_rifle" },
	is_shotgun_pump = { "is_shotgun_mag", "is_rifle" }, is_shotgun_mag = { "is_shotgun_pump", "is_rifle" },
	mossberg = { "is_shotgun_pump", "is_shotgun_mag", "is_rifle" },
	is_pistol = { "is_revolver", "is_smg", "is_rifle" }, is_revolver = { "is_pistol", "is_rifle" },
	akimbo_pistol = { "is_pistol", "is_revolver", "is_rifle" },
	mini = { "is_lmg", "is_rifle" }, is_flamethrower = { "is_shotgun_mag", "is_rifle" }
}
function T.fill_weapon_usages(chars)
	local done = {}
	for name, char in pairs(chars) do
		local weapons = type(char) == "table" and name ~= "presets" and char.weapon
		if type(weapons) == "table" and not done[weapons] and next(weapons) then
			done[weapons] = true
			for usage, sources in pairs(USAGE_FALLBACK) do
				if weapons[usage] == nil then
					for _, src in ipairs(sources) do
						if type(weapons[src]) == "table" then
							weapons[usage] = deep_clone(weapons[src])
							break
						end
					end
				end
			end
		end
	end
end

if script == "lib/tweak_data/charactertweakdata" then
	local function fill(self) pcall(T.fill_weapon_usages, self) end
	Hooks:PostHook(CharacterTweakData, "init", "PDTHTactics_fill_usages", fill)
	for _, d in ipairs({ "_set_easy", "_set_normal", "_set_hard", "_set_overkill", "_set_overkill_145", "_set_easy_wish", "_set_overkill_290", "_set_sm_wish" }) do
		if CharacterTweakData[d] then
			Hooks:PostHook(CharacterTweakData, d, "PDTHTactics_fill_usages" .. d, fill)
		end
	end

elseif script == "lib/managers/musicmanager" then
	Hooks:PreHook(MusicManager, "init", "PDTHTactics_faction_load_queue", function()
		local ok, err = pcall(T.faction_load_queue)
		if not ok then log(T.name .. " faction load error: " .. tostring(err)) end
	end)

elseif script == "lib/setups/gamesetup" then
	Hooks:PostHook(GameSetup, "load_packages", "PDTHTactics_faction_preload", function()
		local ok, err = pcall(T.faction_preload)
		if not ok then log(T.name .. " faction preload error: " .. tostring(err)) end
	end)
	Hooks:PreHook(GameSetup, "init_managers", "PDTHTactics_faction_mark1", function()
		if T._fac_done then log(T.name .. " factions: starting managers (BeardLib loads the queued units now)") end
	end)
	Hooks:PostHook(GameSetup, "init_managers", "PDTHTactics_faction_mark2", function()
		if T._fac_done then log(T.name .. " factions: managers ready") end
	end)

elseif script == "lib/units/contourext" then
	-- (head outlines removed for performance)

elseif script == "lib/units/beings/player/playerinventory" then
	-- host: report a faction gun to clients as its vanilla counterpart
	local orig_idx = PlayerInventory._get_weapon_sync_index
	function PlayerInventory._get_weapon_sync_index(wanted_weap_name, ...)
		if type(wanted_weap_name) ~= "string" and wanted_weap_name and wanted_weap_name.key then
			local w = K.weapons[wanted_weap_name:key()]
			local van = w and vanilla_weapon_name(w.base)
			if van then wanted_weap_name = van end
		end
		return orig_idx(wanted_weap_name, ...)
	end

elseif script == "lib/units/enemies/cop/copinventory" then
	local orig_add = CopInventory.add_unit_by_name
	function CopInventory:add_unit_by_name(new_unit_name, ...)
		local ok, custom = pcall(T.faction_weapon_for, self._unit, new_unit_name)
		return orig_add(self, ok and custom or new_unit_name, ...)
	end

elseif script == "lib/units/enemies/cop/huskcopinventory" then
	local orig_add = HuskCopInventory.add_unit_by_name
	function HuskCopInventory:add_unit_by_name(new_unit_name, ...)
		local ok, custom = pcall(T.faction_weapon_for, self._unit, new_unit_name)
		return orig_add(self, ok and custom or new_unit_name, ...)
	end

elseif script == "lib/tweak_data/weapontweakdata" then
	-- the guns keep vanilla stats: their tweak entries are copies of the matching vanilla enemy gun
	Hooks:PostHook(WeaponTweakData, "init", "PDTHTactics_faction_weapon_stats", function(self)
		for _, w in ipairs(D.weapons or {}) do
			if not self[w.name_id] then
				local src = self[w.base .. "_npc"] or self[w.base] or self.m4_npc
				if src then self[w.name_id] = deep_clone(src) end
			end
		end
	end)

elseif script == "lib/units/enemies/cop/copbase" then
	local orig_dwn = CopBase.default_weapon_name
	function CopBase:default_weapon_name(...)
		local name = orig_dwn(self, ...)
		if alive(self._unit) and K.faction_units[self._unit:name():key()] then
			local ok, safe = pcall(T.faction_safe_weapon, self, name)
			if ok and safe then return safe end
		end
		return name
	end

	-- outlines for the faction units and their separate heads
	if CopBase._material_translation_map then
		for _, path in ipairs(D.contour) do
			local n, c = Idstring(path), Idstring(path .. "_contour")
			CopBase._material_translation_map[tostring(n:key())] = c
			CopBase._material_translation_map[tostring(c:key())] = n
		end
	end

	-- class used by the separate head units
	if not ContourSwapBase then
		ContourSwapBase = class()
		ContourSwapBase._material_translation_map = CopBase._material_translation_map
		ContourSwapBase.swap_material_config = CopBase.swap_material_config
		ContourSwapBase.on_material_applied = CopBase.on_material_applied
		ContourSwapBase.is_in_original_material = CopBase.is_in_original_material
		ContourSwapBase.set_material_state = CopBase.set_material_state
		function ContourSwapBase:init(unit)
			UnitBase.init(self, unit, false)
			self._unit = unit
			self._is_in_original_material = true
		end
	end

	Hooks:PostHook(CopBase, "post_init", "PDTHTactics_faction_looks", function(self)
		local ok, err = pcall(run_sequences, self)
		if not ok and not T._fac_seq_err then
			T._fac_seq_err = true
			log(T.name .. " faction looks error: " .. tostring(err))
		end
	end)

elseif script == "lib/units/enemies/cop/huskcopbase" then
	Hooks:PreHook(HuskCopBase, "post_init", "PDTHTactics_faction_looks_husk", function(self)
		local ok, err = pcall(run_sequences, self)
		if not ok and not T._fac_seq_err then
			T._fac_seq_err = true
			log(T.name .. " faction looks error: " .. tostring(err))
		end
	end)

elseif script == "lib/managers/mission/elementspawnenemydummy" then
	-- load on the first in-game frame (main thread, after the level's own loading is done;
	-- loading during the loading screen crashed the sound engine)
	Hooks:Add("GameSetupUpdate", "PDTHTactics_faction_load", function()
		-- the loading-time hook didn't run: never load mid-game, just stay vanilla this heist
		if not T._fac_done then
			T._fac_done = true
			T._fac_wanted = {}
			log(T.name .. " factions were not preloaded this heist; using vanilla enemies")
		end
	end)

	-- background loading: check every half second until everything is ready, then post the host notice
	Hooks:Add("GameSetupUpdate", "PDTHTactics_faction_poll", function()
		if not T._fac_done or T._fac_poll_done then return end
		local t = Application:time()
		if t < (T._fac_poll_t or 0) then return end
		T._fac_poll_t = t + 0.5
		local all = true
		for _, w in ipairs(T._fac_wanted or {}) do
			local ok, fin = pcall(poll_faction, w)
			if ok and not fin then all = false end
		end
		if not all then return end
		T._fac_poll_done = true
		for _, w in ipairs(T._fac_wanted or {}) do
			if T.fac_status[w] ~= "ready" then log(T.name .. " faction " .. w .. ": " .. tostring(T.fac_status[w])) end
		end
		local f = T._fac_heist_faction
		if f and Network and Network:is_server() then
			DelayedCalls:Add("PDTHTactics_faction_notice", 4, function()
				pcall(T.faction_notice, f)
			end)
		end
	end)

	-- host diagnostics: every 20s log how many enemies are alive vs what the assault asked for
	Hooks:Add("GameSetupUpdate", "PDTHTactics_faction_census", function()
		if not (Network and Network:is_server() and managers.enemy and managers.groupai) then return end
		local t = Application:time()
		if t < (T._census_t or 0) then return end
		T._census_t = t + 20
		pcall(function()
			local total, fac, groups, heads = 0, 0, 0, 0
			for _, u_data in pairs(managers.enemy:all_enemies() or {}) do
				total = total + 1
				if T.is_faction_unit(u_data.unit) then fac = fac + 1 end
				if alive(u_data.unit) and K.head_seq[u_data.unit:name():key()] then heads = heads + 1 end
			end
			local state = managers.groupai:state()
			for _ in pairs(state._groups or {}) do groups = groups + 1 end
			local task = state._task_data and state._task_data.assault
			log(string.format("%s census: enemies=%d faction=%d heads=%d groups=%d police_registered=%d assault phase=%s force=%s spawned=%s",
				T.name, total, fac, heads, groups, table.size(state._police or {}), tostring(task and task.phase),
				tostring(task and task.force), tostring(task and task.force_spawned)))
		end)
	end)

	-- clients: keep telling the host which packs are ready until it has heard (cheap, every few seconds)
	Hooks:Add("GameSetupUpdate", "PDTHTactics_faction_announce", function()
		if Network and Network:is_server() then return end
		if not (T._fac_done and T.client_on() and LuaNetworking) then return end
		local t = Application:time()
		if t < (T._fac_announce_t or 0) then return end
		T._fac_announce_t = t + 5
		for _, w in ipairs(T._fac_wanted or {}) do
			if T._fac_loaded and T._fac_loaded[w] then
				pcall(LuaNetworking.SendToPeer, LuaNetworking, 1, T.NET_ID, "fac:" .. w)
			end
		end
	end)

	if LuaNetworking and LuaNetworking.AddReceiveHook then
		LuaNetworking:AddReceiveHook(T.NET_ID, "PDTHTactics_faction_net", function(data, sender)
			local f = type(data) == "string" and string.match(data, "^fac:(%w+)$")
			if f and sender and Network and Network:is_server() then
				T.fac_peers[f] = T.fac_peers[f] or {}
				T.fac_peers[f][sender] = true
			end
		end)
	end

	Hooks:Add("BaseNetworkSessionOnPeerRemoved", "PDTHTactics_faction_peer_removed", function(peer, peer_id)
		for _, list in pairs(T.fac_peers) do list[peer_id] = nil end
	end)

	-- someone joins: their game has to confirm it has PD:TH Factions before new spawns use it again.
	-- Faction enemies already on the map are kept (deleting them broke mission cops/guards); a player
	-- without PD:TH Factions joining mid-heist would crash, so keep lobbies to people with the mods.
	Hooks:Add("NetworkManagerOnPeerAdded", "PDTHTactics_faction_joiner", function(peer, peer_id)
		for _, list in pairs(T.fac_peers) do list[peer_id] = nil end
	end)

	local orig_produce = ElementSpawnEnemyDummy.produce
	function ElementSpawnEnemyDummy:produce(params, ...)
		if T.active() then
			if params and params.name then
				local ok, new = pcall(T.faction_pick, params.name, true)
				if ok then new = ready_or_nil(new) end
				if ok and new then
					if not T._fac_first_swap then
						T._fac_first_swap = true
						log(T.name .. " first faction swap: " .. tostring(new))
					end
					params.name = new
				elseif not ok and not T._fac_pick_err then
					T._fac_pick_err = true
					log(T.name .. " faction pick error: " .. tostring(new))
				end
			elseif self._enemy_name then
				local ok, new = pcall(T.faction_pick, self._enemy_name, false)
				if ok then new = ready_or_nil(new) end
				if ok and new then
					local old = self._enemy_name
					self._enemy_name = new
					local res = { pcall(orig_produce, self, params, ...) }
					self._enemy_name = old
					if not res[1] then error(res[2], 0) end
					return unpack(res, 2)
				end
			end
		end
		return orig_produce(self, params, ...)
	end
end
