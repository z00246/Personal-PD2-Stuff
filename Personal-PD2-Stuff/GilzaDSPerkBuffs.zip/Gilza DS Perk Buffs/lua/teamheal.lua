GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
B.NET_ID = B.NET_ID or "GilzaDSBuffs"

-- Shared crew healing (Grinder Overgrowth, Ex-President Second Term).
-- Teammates need the mod to receive it; bots are healed directly when you are the host.
-- amount is in the game's internal health units (same scale as restore_health(x, true)).
local function bot_ok(dmg)
	return dmg and dmg._health and dmg._HEALTH_INIT and not dmg._bleed_out and not dmg._fatal and not dmg._dead
end

function B.team_heal(amount, radius, nearest_only)
	if type(amount) ~= "number" or amount <= 0 then return false end
	local me = managers.player and managers.player:player_unit()
	if not alive(me) then return false end
	local my_pos = me:position()
	local targets = {}

	local session = managers.network and managers.network:session()
	for _, peer in pairs(session and session:peers() or {}) do
		local unit = peer:unit()
		if alive(unit) then
			local d = mvector3.distance(unit:position(), my_pos)
			if d <= radius then
				table.insert(targets, { d = d, peer = peer })
			end
		end
	end
	if Network:is_server() and managers.groupai and managers.groupai:state() then
		for _, data in pairs(managers.groupai:state():all_AI_criminals() or {}) do
			local unit = data.unit
			local dmg = alive(unit) and unit:character_damage()
			if bot_ok(dmg) and dmg._health < dmg._HEALTH_INIT then
				local d = mvector3.distance(unit:position(), my_pos)
				if d <= radius then
					table.insert(targets, { d = d, bot = dmg })
				end
			end
		end
	end
	if #targets == 0 then return false end
	if nearest_only then
		table.sort(targets, function(a, b) return a.d < b.d end)
		targets = { targets[1] }
	end

	local my_max = me:character_damage():_max_health()
	for _, t in ipairs(targets) do
		if t.peer and LuaNetworking then
			pcall(LuaNetworking.SendToPeer, LuaNetworking, t.peer:id(), B.NET_ID, "teamheal:" .. string.format("%.3f", amount))
		elseif t.bot and my_max > 0 then
			local dmg = t.bot
			dmg._health = math.min(dmg._health + amount / my_max * dmg._HEALTH_INIT, dmg._HEALTH_INIT)
			dmg._health_ratio = dmg._health / dmg._HEALTH_INIT
		end
	end
	return true
end

if LuaNetworking and LuaNetworking.AddReceiveHook then
	LuaNetworking:AddReceiveHook(B.NET_ID, "GilzaDSBuffs_teamheal_net", function(data)
		local amount = tonumber(string.match(data or "", "^teamheal:([%d%.]+)$") or "")
		if not amount or amount <= 0 or amount > 10 then return end
		pcall(function()
			local unit = managers.player and managers.player:player_unit()
			local dmg = alive(unit) and unit:character_damage()
			if dmg and not dmg:need_revive() and not dmg:dead() then
				dmg:restore_health(amount, true)
			end
		end)
	end)
end
