-- Burglar Cloak visuals
--  * you: a thin ring under the crosshair fills while the cloak charges, and the screen edges go hazy
--    and cool while you're cloaked
--  * other Burglars (with this mod): their body, mask and guns fade out and a heat-haze shimmer marks
--    where they are; their name tag stays
GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
if B._burg_fx then return end
B._burg_fx = true

local RING = "guis/textures/gilza_plates/cloak_ring"
local EDGE = "guis/textures/gilza_plates/cloak_edge"
local FX = Idstring("effects/gilza/burglar_cloak")
local IDS_EFFECT = Idstring("effect")
local COOL = Color(0.75, 0.88, 1)

---------------------------------------------------------------- your own screen
local hud = {}
local function build()
	local ws = managers.hud and managers.hud._fullscreen_workspace
	local root = ws and ws:panel()
	if not (root and alive(root)) then return end
	if hud.panel and alive(hud.panel) then return hud.panel end
	local p = root:panel({ name = "gdsb_cloak", layer = 1 })
	hud.panel = p
	hud.edge = p:bitmap({ texture = EDGE, w = p:w(), h = p:h(), color = COOL, alpha = 0, layer = 0 })
	local R = 30
	hud.bg = p:bitmap({ texture = RING, w = R, h = R, alpha = 0, color = Color.white, layer = 2 })
	hud.fill = p:bitmap({ texture = RING, w = R, h = R, alpha = 0, render_template = "VertexColorTexturedRadial",
		color = Color(0, 1, 1), layer = 3 })
	hud.text = p:text({ text = "CLOAKED", font = tweak_data.menu.pd2_small_font, font_size = 12, color = COOL,
		align = "center", w = 120, h = 16, alpha = 0, layer = 3 })
	return p
end

local function layout(p)
	local cx, cy = p:w() / 2, p:h() / 2 + 70
	hud.bg:set_center(cx, cy); hud.fill:set_center(cx, cy)
	hud.text:set_center_x(cx); hud.text:set_top(cy + 18)
	hud.edge:set_size(p:w(), p:h()); hud.edge:set_position(0, 0)
end

local function approach(v, target, rate, dt)
	if v < target then return math.min(target, v + rate * dt) end
	return math.max(target, v - rate * dt)
end

local cur = { ring = 0, cloak = 0 }
local function update_self(dt)
	local tier = B.burglar_tier and B.burglar_tier() or 0
	if tier < 1 then
		if hud.panel and alive(hud.panel) then hud.panel:set_visible(false) end
		return
	end
	local p = build()
	if not p then return end
	p:set_visible(true)
	layout(p)
	local cloaked = B.burglar_hidden and B.burglar_hidden() or false
	local need = B.burglar_cloak_need and B.burglar_cloak_need() or 1.5
	local charge = math.clamp((B.burg_charge or 0) / need, 0, 1)
	cur.ring = approach(cur.ring, (cloaked or charge > 0) and 1 or 0, 6, dt)
	cur.cloak = approach(cur.cloak, cloaked and 1 or 0, cloaked and 2.5 or 5, dt)
	-- Geo HUD shows the cloak in its ability slot next to the bars: keep only the screen haze then
	if rawget(_G, "GeoHUD") then cur.ring = 0 end
	hud.bg:set_alpha(0.22 * cur.ring * (1 - cur.cloak))
	hud.fill:set_color(Color(cloaked and 1 or charge, 1, 1))
	hud.fill:set_alpha(0.9 * cur.ring)
	hud.text:set_alpha(rawget(_G, "GeoHUD") and 0 or cur.cloak)
	hud.edge:set_alpha(0.55 * cur.cloak)
end

---------------------------------------------------------------- other Burglars
local shown = {}   -- key -> { unit, hidden = {units}, fx = {ids} }
local fx_state   -- nil = unknown, true = loaded, false = failed

local function fx_ready()
	if fx_state ~= nil then return fx_state end
	local ok, has = pcall(PackageManager.has, PackageManager, IDS_EFFECT, FX)
	if ok and has then fx_state = true return true end
	if managers.dyn_resource and not B._burg_fx_loading then
		B._burg_fx_loading = true
		pcall(function()
			managers.dyn_resource:load(IDS_EFFECT, FX, managers.dyn_resource.DYN_RESOURCES_PACKAGE, function()
				fx_state = true
			end)
		end)
	end
	if B._burg_fx_loading and not fx_state then
		B._burg_fx_wait = (B._burg_fx_wait or 0) + 1
		if B._burg_fx_wait > 600 then fx_state = false end   -- give up after ~10s; cloak still works without it
	end
	return fx_state or false
end

local HEIGHTS = { 45, 105, 155 }

local function hide_parts(unit)
	local list = {}
	local function hide(u)
		if not alive(u) then return end
		local ok, vis = pcall(u.visible, u)
		if ok and vis == false then return end
		if pcall(u.set_visible, u, false) then list[#list + 1] = u end
	end
	hide(unit)
	local inv = unit:inventory()
	if inv then
		pcall(function() hide(inv:equipped_unit()) end)
		pcall(function() hide(inv._mask_unit) end)
	end
	pcall(function()
		for _, c in ipairs(unit:children() or {}) do hide(c) end
	end)
	return list
end

local function cloak_on(key, unit)
	local e = { unit = unit, hidden = hide_parts(unit), fx = {} }
	if fx_ready() then
		local pos = unit:position()
		local em = World:effect_manager()
		for i, h in ipairs(HEIGHTS) do
			local ok, id = pcall(em.spawn, em, { effect = FX, position = pos + Vector3(0, 0, h), normal = math.UP })
			if ok and id then e.fx[i] = id end
		end
	end
	shown[key] = e
end

local function cloak_off(key)
	local e = shown[key]
	shown[key] = nil
	if not e then return end
	for _, u in ipairs(e.hidden) do
		if alive(u) then u:set_visible(true) end
	end
	local em = World:effect_manager()
	for _, id in pairs(e.fx) do pcall(em.fade_kill, em, id) end
end
B.burglar_cloak_off_all = function() for k in pairs(shown) do cloak_off(k) end end

local function update_others()
	local want = B.burg_cloak_units or {}
	for key, e in pairs(shown) do
		local u = want[key]
		if not (u and alive(u) and alive(e.unit)) then cloak_off(key) end
	end
	for key, u in pairs(want) do
		if alive(u) and not shown[key] then
			local dmg = u:character_damage()
			if not (dmg and dmg.dead and dmg:dead()) then cloak_on(key, u) end
		end
	end
	local em = World:effect_manager()
	for _, e in pairs(shown) do
		if alive(e.unit) then
			local pos = e.unit:position()
			for i, id in pairs(e.fx) do pcall(em.move, em, id, pos + Vector3(0, 0, HEIGHTS[i])) end
			-- a teammate could re-show a hidden part (weapon swap): keep the new weapon hidden too
			local inv = e.unit:inventory()
			local w = inv and inv:equipped_unit()
			if alive(w) and w ~= e.weapon then
				e.weapon = w
				if pcall(w.set_visible, w, false) then e.hidden[#e.hidden + 1] = w end
			end
		end
	end
end

Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_burglar_fx", function(t, dt)
	local ok, err = pcall(update_self, dt or 0)
	if not ok and not B._burg_fx_err then B._burg_fx_err = true; log("[Gilza DS Perk Buffs] cloak hud: " .. tostring(err)) end
	ok, err = pcall(update_others)
	if not ok and not B._burg_fx_err2 then B._burg_fx_err2 = true; log("[Gilza DS Perk Buffs] cloak fx: " .. tostring(err)) end
end)
