GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

B.CC = {
	deck = 1,
	range = 1800,
	per_ally = { [1] = 0.05, [7] = 0.07 },
	max_allies = 3,
	mark_damage = 1.25,
	rally_resist = 0.4,
	rally_time = 6
}
B.NET_ID = B.NET_ID or "GilzaDSBuffs"

function B.cc_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == B.CC.deck) then
		return 0
	end
	return st:get_specialization_value(B.CC.deck, "tiers", "current_tier") or 0
end

local function peer_cc_tier(peer)
	local skills = peer and peer.unpacked_skills and peer:unpacked_skills()
	local spec = skills and skills.specializations
	if spec and tonumber(spec[1]) == B.CC.deck then
		return tonumber(spec[2]) or 0
	end
	return 0
end

function B.cc_list()
	local list = {}
	local me = managers.player and managers.player:player_unit()
	local my_tier = B.cc_tier()
	if alive(me) and my_tier > 0 then
		table.insert(list, { unit = me, tier = my_tier })
	end
	local session = managers.network and managers.network:session()
	for _, peer in pairs(session and session:peers() or {}) do
		local tier = peer_cc_tier(peer)
		if tier > 0 and alive(peer:unit()) then
			table.insert(list, { unit = peer:unit(), tier = tier })
		end
	end
	return list
end

function B.cc_best_tier()
	local best = 0
	for _, cc in ipairs(B.cc_list()) do
		if cc.tier > best then best = cc.tier end
	end
	return best
end

local function allies_near(unit)
	local state = managers.groupai and managers.groupai:state()
	if not (alive(unit) and state) then return 0 end
	local pos, count = unit:position(), 0
	for _, c in pairs(state:all_char_criminals() or {}) do
		local u = c.unit
		if alive(u) and u ~= unit and not c.status and mvector3.distance(u:position(), pos) <= B.CC.range then
			count = count + 1
		end
	end
	return math.min(count, B.CC.max_allies)
end

function B.cc_cohesion()
	local tier = B.cc_tier()
	if tier < 1 then return 0 end
	local me = managers.player and managers.player:player_unit()
	local per = tier >= 7 and B.CC.per_ally[7] or B.CC.per_ally[1]
	return per * allies_near(me)
end

if script == "lib/managers/playermanager" then
	local orig_resist = PlayerManager.damage_reduction_skill_multiplier
	function PlayerManager:damage_reduction_skill_multiplier(...)
		local m = orig_resist(self, ...)
		if type(m) ~= "number" then return m end
		local ok, cohesion = pcall(B.cc_cohesion)
		if ok and cohesion > 0 then
			m = m * (1 - cohesion)
		end
		if Application:time() < (B.cc_rally_until or 0) then
			m = m * (1 - B.CC.rally_resist)
		end
		return m
	end

	if LuaNetworking and LuaNetworking.AddReceiveHook then
		LuaNetworking:AddReceiveHook(B.NET_ID, "GilzaDSBuffs_cc_net", function(data)
			if data == "host" then
				B.host_has_mod = managers.network and managers.network:session()
			end
		end)
	end

	local function greet(peer_id)
		if Network:is_server() and LuaNetworking then
			pcall(LuaNetworking.SendToPeer, LuaNetworking, peer_id, B.NET_ID, "host")
		end
	end
	Hooks:Add("NetworkManagerOnPeerAdded", "GilzaDSBuffs_host_greet", function(peer, peer_id)
		DelayedCalls:Add("GilzaDSBuffs_greet_" .. tostring(peer_id), 6, function() greet(peer_id) end)
	end)
	Hooks:Add("BaseNetworkSessionOnLoadComplete", "GilzaDSBuffs_host_greet_load", function()
		DelayedCalls:Add("GilzaDSBuffs_greet_all", 3, function()
			local session = managers.network and managers.network:session()
			for _, peer in pairs(session and session:peers() or {}) do greet(peer:id()) end
		end)
	end)

elseif script == "lib/units/enemies/cop/copdamage" then
	local function is_marked(unit)
		local contour = unit:contour()
		return contour and contour.has_id and (contour:has_id("mark_enemy") or contour:has_id("mark_enemy_damage_bonus") or contour:has_id("mark_enemy_damage_bonus_distance"))
	end

	local function crew_attacker(unit)
		local state = managers.groupai and managers.groupai:state()
		return alive(unit) and state and state:all_criminals()[unit:key()] and true or false
	end

	local function applies(self, attacker)
		if not crew_attacker(attacker) or not is_marked(self._unit) then return false end
		local me = managers.player and managers.player:player_unit()
		if attacker == me then
			local host_boosts = not Network:is_server() and B.host_has_mod and managers.network and B.host_has_mod == managers.network:session()
			return not host_boosts and B.cc_best_tier() >= 3
		end
		return Network:is_server() and B.cc_best_tier() >= 3
	end

	for _, fn in ipairs({ "damage_bullet", "damage_melee" }) do
		Hooks:PreHook(CopDamage, fn, "GilzaDSBuffs_cc_mark_" .. fn, function(self, attack_data)
			pcall(function()
				if attack_data and type(attack_data.damage) == "number" and applies(self, attack_data.attacker_unit) then
					attack_data.damage = attack_data.damage * B.CC.mark_damage
				end
			end)
		end)
	end

	for _, fn in ipairs({ "sync_damage_bullet", "sync_damage_melee" }) do
		local orig = CopDamage[fn]
		if orig then
			CopDamage[fn] = function(self, attacker_unit, damage_percent, ...)
				local ok, yes = pcall(function()
					return Network:is_server() and type(damage_percent) == "number" and applies(self, attacker_unit)
				end)
				if ok and yes then
					damage_percent = math.ceil(damage_percent * B.CC.mark_damage)
				end
				return orig(self, attacker_unit, damage_percent, ...)
			end
		end
	end

elseif script == "lib/units/interactions/interactionext" then
	Hooks:PostHook(ReviveInteractionExt, "interact", "GilzaDSBuffs_cc_rally", function(self, reviving_unit)
		local player = managers.player and managers.player:player_unit()
		if not (alive(player) and reviving_unit == player and B.cc_tier() >= 5) then return end
		B.cc_rally_until = Application:time() + B.CC.rally_time
	end)
end
