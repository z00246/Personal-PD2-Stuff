GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

B.KINGPIN = {
	deck = 17,
	surge = 0.20,
	overdose = 2,
	overdose_ds = 3,
	withdrawal = 0.25,
	withdrawal_time = 3
}
local C = B.KINGPIN

function B.kp_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == C.deck) then
		return 0
	end
	return st:get_specialization_value(C.deck, "tiers", "current_tier") or 0
end

local function injector_data()
	local pm = managers.player
	local t = pm and pm._temporary_upgrades and pm._temporary_upgrades.temporary
	return t and t.chico_injector
end

function B.kp_active()
	local d = injector_data()
	return d and d.expire_time and Application:time() < d.expire_time or false
end

function B.kp_injector_until()
	local d = injector_data()
	return d and d.expire_time or nil
end

function B.kp_withdrawal()
	return Application:time() < (B.kp_withdrawal_until or 0)
end

if script == "lib/managers/playermanager" then
	-- Overdose: kills during the injector take extra time off its cooldown
	Hooks:PostHook(PlayerManager, "on_killshot", "GilzaDSBuffs_kp_overdose", function(self)
		pcall(function()
			if B.kp_tier() < 7 or not B.kp_active() then return end
			self:speed_up_grenade_cooldown(B.on and C.overdose_ds or C.overdose)
		end)
	end)

	-- Withdrawal: damage reduction right after the injector ends
	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_kp_update", function()
		pcall(function()
			local active = B.kp_active()
			if B._kp_was_active and not active and B.kp_tier() >= 9 then
				B.kp_withdrawal_until = Application:time() + C.withdrawal_time
			end
			B._kp_was_active = active
		end)
	end)

	local orig_resist = PlayerManager.damage_reduction_skill_multiplier
	function PlayerManager:damage_reduction_skill_multiplier(...)
		local m = orig_resist(self, ...)
		if type(m) == "number" and B.kp_withdrawal() then
			m = m * (1 - C.withdrawal)
		end
		return m
	end

elseif script == "lib/units/enemies/cop/copdamage" then
	-- Adrenal Surge: more damage during the injector
	local function surge(self, attack_data)
		if not attack_data or type(attack_data.damage) ~= "number" then return end
		local player = managers.player and managers.player:player_unit()
		if not (alive(player) and attack_data.attacker_unit == player) then return end
		if B.kp_tier() >= 3 and B.kp_active() then
			attack_data.damage = attack_data.damage * (1 + C.surge)
		end
	end
	for _, fn in ipairs({ "damage_bullet", "damage_melee" }) do
		Hooks:PreHook(CopDamage, fn, "GilzaDSBuffs_kp_" .. fn, function(self, attack_data)
			pcall(surge, self, attack_data)
		end)
	end
end
