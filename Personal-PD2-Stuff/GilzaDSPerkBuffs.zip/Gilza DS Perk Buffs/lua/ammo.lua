GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs

B.AMMO_PICKUP_MUL = 1.6

local orig_add_ammo = RaycastWeaponBase.add_ammo
function RaycastWeaponBase:add_ammo(ratio, add_amount_override, ...)
	if add_amount_override then
		return orig_add_ammo(self, ratio, add_amount_override, ...)
	end
	return orig_add_ammo(self, (ratio or 1) * B.AMMO_PICKUP_MUL, add_amount_override, ...)
end
