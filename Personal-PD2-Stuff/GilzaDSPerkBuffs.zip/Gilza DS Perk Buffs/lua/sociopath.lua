GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

-- difficulty scaling (shared with buffs.lua): t = 0 up to Overkill, 1/3 Mayhem, 2/3 Death Wish, 1 Death Sentence
if not B.diff_t then
	B.DIFF_T = { easy_wish = 1 / 3, overkill_290 = 2 / 3, sm_wish = 1 }
	function B.diff_t()
		local gs = Global and Global.game_settings
		return gs and B.DIFF_T[gs.difficulty] or 0
	end
	function B.sc(base, ds) return base + (ds - base) * B.diff_t() end
	function B.sci(base, ds) return math.floor(base + (ds - base) * B.diff_t() + 0.5) end
end

-- Sociopath (7.00 rework, Geo 2026-10-24: kill chain + unbreakable + terror + melee master)
--  card 1 Frenzy (chained melee kills -> damage reduction stacks) + Tension (melee kills restore armor)
--  card 3 damage reduction, melee-hold resistance, Thick Skin (big hits hurt less)
--  card 5 Clean Hit (melee kills heal, extra Frenzy) + Combo (chained melee kills: faster melee, less damage taken)
--  card 7 Tension up close + Hardened (less damage the longer you fight)
--  card 9 Panic + Dread (more damage to panicking enemies) + Massacre (melee crits at high Combo)
-- 7.08 (Geo: "nullify the reliance on armor ... more damage res the higher your combo is", "do not add anything regarding
-- gun kills"): Tension is a flat amount on melee kills only, same on every armor, and Tension / Clean Hit work at most once
-- a second; holding melee gives up to 15%; Combo takes 2% off damage per Combo; the deck's damage reduction tops at 30%.
-- 7.09: Frenzy from melee kills only. 7.10 (Geo: "gun kills should make it where u lose the streaks and everything
-- though"): a gun kill ends Frenzy and Combo (B.socio_on_gun_kill). 7.11: every melee kill adds a Combo, a chain's
-- first one too (so every enemy a cleave kills shows).
-- 7.26: card 9 picks one of Jacket's masks (masks.lua); a mask can replace one card effect here (B.mask_swap), add
-- its own resistance (B.mask_dr), speed up the punches (Fury), let shotguns keep the Combo (Aubrey), count a poison
-- kill (Jake) or a knife opener (Dennis) for the Combo and act on a kill (B.mask_on_kill).
-- *_ds values are the Death Sentence end of the difficulty scale (B.sc).
B.SOCIO = {
	deck = 9,
	passive = { [3] = 0.15, [5] = 0.25, [9] = 0.30 },
	hold_tier = 3,
	hold_gain = 0.1,
	hold_max = 0.15,
	hold_linger = 2,
	hold_decay = 0.15,
	panic_range = 2500,
	frenzy_window = 3,          -- card 1 Frenzy
	frenzy_max = 5, frenzy_max_ds = 6,
	frenzy_dr = 0.03,
	frenzy_decay_after = 3,
	frenzy_decay_every = 1,
	tension = 2,                -- card 1 Tension: armor a melee kill restores (game units: 2 = 20 on the HUD), any armor
	tension_every = 1,          -- Tension and Clean Hit work at most once a second (the base game's Sociopath limit)
	thick_at = 0.2,             -- card 3 Thick Skin: hits over 20% of your health
	thick = 0.4, thick_ds = 0.5,
	clean_heal = 0.10, clean_heal_ds = 0.15,   -- card 5 Clean Hit
	combo_window = 5,           -- card 5 Combo
	combo_max = 10,
	combo_charge = 0.10,
	combo_charge_max = 0.5,
	combo_dr = 0.02,            -- less damage taken per Combo
	combo_dr_max = 0.20,
	close_range = 1800,         -- card 7
	tension_close = 3,          -- Tension on melee kills within 18 m (30 on the HUD)
	hard_every = 10,            -- card 7 Hardened
	hard_step = 0.05,
	hard_levels = 3,
	hard_reset = 10,
	dread = 0.25, dread_ds = 0.35,             -- card 9 Dread
	massacre_at = 8, massacre_at_ds = 6,       -- card 9 Massacre
	panic_time = 4.25,          -- how long an enemy counts as panicking after the panic animation starts
	-- (7.24) Jacket's signature (card 9, only as Jacket): Hotline - a fully charged melee hit kills any non-special in
	-- one hit, once every 4 s; firing a gun no longer ends Combo (a gun kill still does)
	hotline_charge = 0.99, hotline_every = 4
}
local C = B.SOCIO
B.socio_hold = B.socio_hold or 0
B.socio_release_t = B.socio_release_t or 0
B.frenzy = B.frenzy or 0
B.combo = B.combo or 0
B.hard_level = B.hard_level or 0
B.socio_panic = B.socio_panic or {}

function B.socio_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == C.deck) then
		return 0
	end
	return st:get_specialization_value(C.deck, "tiers", "current_tier") or 0
end

function B.socio_passive(tier)
	local best = 0
	for card, value in pairs(C.passive) do
		if tier >= card and value > best then best = value end
	end
	return best
end

function B.socio_frenzy_max()
	return B.sci(C.frenzy_max, C.frenzy_max_ds)
end

function B.socio_massacre_at()
	return B.sci(C.massacre_at, C.massacre_at_ds)
end

function B.socio_massacre()
	return B.socio_tier() >= 9 and (B.combo or 0) >= B.socio_massacre_at()
end

-- card 5 Combo: how much faster your melee weapon charges and swings (1 = normal)
function B.socio_combo_mul()
	if B.socio_tier() < 5 then return 1 end
	local mul = 1 + math.min((B.combo or 0) * C.combo_charge, C.combo_charge_max)
	if B.mask_speed_mul then mul = mul * B.mask_speed_mul() end   -- (7.26) Tony's Fury
	return mul
end

-- card 5 Combo (7.08): how much less damage you take (0 = none)
function B.socio_combo_dr()
	if B.socio_tier() < 5 then return 0 end
	return math.min((B.combo or 0) * C.combo_dr, C.combo_dr_max)
end

-- a line in the BLT log the first times a feature does something (buffs.lua)
local function live(key, ...) if B.live then B.live("sociopath " .. key, ...) end end

-- a few lines in the BLT log the first times Massacre / Combo do something, to check them in game
B._socio_diag = B._socio_diag or {}
function B.socio_diag(key, msg)
	local n = B._socio_diag[key] or 0
	if n >= 3 then return end
	B._socio_diag[key] = n + 1
	log("[Gilza DS Perk Buffs] Sociopath " .. key .. ": " .. tostring(msg))
end

function B.socio_panicking(unit)
	local e = alive(unit) and B.socio_panic[unit:key()]
	return e and Application:time() < e or false
end

-- gun fire ends the Combo (7.24: not with Jacket's Hotline - only a gun kill does then)
function B.socio_on_fire(weapon)
	if B.sig_active and B.sig_active(C.deck) then return end
	-- (7.26) Aubrey: shotguns don't end the Combo
	if B.mask_on and B.mask_on("aubrey") and weapon and weapon.is_category and weapon:is_category("shotgun") then return end
	if (B.combo or 0) > 0 or B.combo_last_t then
		B.combo, B.combo_last_t = 0, nil
	end
end

-- 7.10: is the kill's weapon one of your guns? The game names the weapon that got the kill: your primary or secondary
-- (bows, launchers, the saw and their fire / poison / explosive rounds too) has a weapon tweak entry; thrown weapons
-- (grenades, knives, javelins: their projectile name), trip mines ("trip_mine") and melee weapons don't. Sentry gun
-- kills never come here (the game only reports kills made by you).
function B.socio_is_gun(weapon_id)
	local w = type(weapon_id) == "string" and tweak_data and tweak_data.weapon and tweak_data.weapon[weapon_id]
	return type(w) == "table"
end

-- 7.10: a gun kill ends the streaks: Frenzy and its chain, the Combo (and with it Combo's faster melee, its damage
-- resistance and Massacre). Hardened and the melee-hold resistance aren't kill streaks and stay.
function B.socio_on_gun_kill()
	if (B.frenzy or 0) > 0 or (B.combo or 0) > 0 then
		live("gun kill", "a gun kill ended Frenzy %d and Combo %d", B.frenzy or 0, B.combo or 0)
	end
	B.frenzy, B._socio_last_kill = 0, nil
	B.combo, B.combo_last_t = 0, nil
end

local function holding_melee()
	local state = managers.player and managers.player:get_current_state()
	return state and state.in_melee and state:in_melee() or false
end

if script == "lib/managers/playermanager" then
	local function nearest_enemy_dis(pos)
		if not (managers.slot and managers.enemy) then return nil end
		local best
		local mask = managers.slot:get_mask("enemies")
		for _, u_data in pairs(managers.enemy:all_enemies() or {}) do
			local u = u_data.unit
			if alive(u) and u:in_slot(mask) then
				local dmg = u:character_damage()
				if not (dmg and dmg._dead) then
					local brain = u.brain and u:brain()
					if not (brain and brain.is_hostage and brain:is_hostage()) then
						local d = mvector3.distance(pos, u:position())
						if not best or d < best then best = d end
					end
				end
			end
		end
		return best
	end

	function B.socio_update(t, dt)
		if tweak_data and tweak_data.upgrades and tweak_data.upgrades.killshot_close_panic_range ~= C.panic_range then
			tweak_data.upgrades.killshot_close_panic_range = C.panic_range
		end
		local tier = B.socio_tier()
		local now = Application:time()
		local unit = managers.player and managers.player:player_unit()
		local dmg = alive(unit) and unit:character_damage()
		if tier < 1 or not dmg or dmg:dead() then
			B.socio_hold, B.frenzy, B.combo, B.combo_last_t = 0, 0, 0, nil
			B.hard_level, B._hard_fight, B._hard_quiet = 0, 0, 0
			return
		end
		-- card 1 Frenzy fades a stack a second once you stop killing
		if B.frenzy > 0 and now >= (B._frenzy_decay_t or 0) then
			B.frenzy = B.frenzy - 1
			B._frenzy_decay_t = now + C.frenzy_decay_every
		end
		-- card 5 Combo ends after 5 s without a melee kill
		if B.combo_last_t and now - B.combo_last_t > C.combo_window then
			B.combo, B.combo_last_t = 0, nil
		end
		-- (once: which functions are really in place when Massacre first turns on, for the log)
		if not B._socio_src_logged and B.socio_massacre() then
			B._socio_src_logged = true
			local function src(f)
				local info = type(f) == "function" and debug and debug.getinfo and debug.getinfo(f, "S")
				return info and (tostring(info.short_src) .. ":" .. tostring(info.linedefined)) or "?"
			end
			local CD, PS = rawget(_G, "CopDamage"), rawget(_G, "PlayerStandard")
			B.socio_diag("hooks", "roll_critical_hit=" .. src(CD and CD.roll_critical_hit)
				.. " critical_hit_chance=" .. src(PlayerManager.critical_hit_chance)
				.. " _do_melee_damage=" .. src(PS and PS._do_melee_damage))
		end
		-- card 5 Combo: the melee weapon charges faster. The charge is (now - melee_start_t) / charge time wherever
		-- the game reads it (damage, the wind-up pose, Gilza's charge bar), so moving the start back speeds all of it up.
		if tier >= 5 and ((B.combo or 0) > 0 or (B.frenzy or 0) > 0) and dt > 0 then
			local mul = B.socio_combo_mul()
			local state = managers.player:get_current_state()
			local sd = state and state._state_data
			if mul > 1 and sd and sd.meleeing and sd.melee_start_t then
				sd.melee_start_t = sd.melee_start_t - dt * (mul - 1)
				if not B._socio_charge_logged then
					B._socio_charge_logged = true
					B.socio_diag("charge", string.format("Combo %d: charging x%.2f", B.combo, mul))
				end
			end
		end
		-- card 3 melee hold
		if tier >= C.hold_tier then
			if holding_melee() then
				B.socio_hold = math.min(B.socio_hold + C.hold_gain * dt, C.hold_max)
				B.socio_release_t = now
				if B.socio_hold >= C.hold_max then live("melee hold", "holding melee: damage taken -%d%%", C.hold_max * 100) end
			elseif B.socio_hold > 0 and now - B.socio_release_t > C.hold_linger then
				B.socio_hold = math.max(B.socio_hold - C.hold_decay * dt, 0)
			end
		else
			B.socio_hold = 0
		end
		-- card 7 Hardened: time spent fighting with an enemy within 18 m
		if tier >= 7 then
			if now >= (B._hard_next or 0) then
				local step = now - (B._hard_last or now)
				B._hard_last, B._hard_next = now, now + 0.25
				local state = managers.groupai and managers.groupai:state()
				local d = state and state:enemy_weapons_hot() and nearest_enemy_dis(unit:position()) or nil
				if d and d <= C.close_range then
					B._hard_fight, B._hard_quiet = (B._hard_fight or 0) + step, 0
					B.hard_level = math.min(math.floor(B._hard_fight / C.hard_every), C.hard_levels)
					if B.hard_level > 0 then live("hardened", "level %d: damage taken -%d%%", B.hard_level, B.hard_level * C.hard_step * 100) end
				else
					B._hard_quiet = (B._hard_quiet or 0) + step
					if B._hard_quiet >= C.hard_reset then
						B.hard_level, B._hard_fight = 0, 0
					end
				end
			end
		else
			B.hard_level, B._hard_fight, B._hard_quiet = 0, 0, 0
		end
	end

	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_sociopath", function(t, dt)
		B.socio_update(t, dt or 0)
	end)

	local orig_resist = PlayerManager.damage_reduction_skill_multiplier
	function PlayerManager:damage_reduction_skill_multiplier(...)
		local m = orig_resist(self, ...)
		if type(m) ~= "number" then return m end
		local tier = B.socio_tier()
		if tier > 0 then
			-- (7.26) the mask can drop the hold resistance (Aubrey, Dennis) or double it (Tony's Revenge's Guard), swap out
			-- Frenzy's resistance (Tony, Graham) or Hardened (Don Juan, Brandon, Jake, Alex & Ash) and add its own
			local hold = (B.socio_hold or 0) * (B.mask_hold_mul and B.mask_hold_mul() or 1)
			m = m * (1 - B.socio_passive(tier)) * (1 - hold)
			if not (B.mask_swap and B.mask_swap("frenzy")) then m = m * (1 - (B.frenzy or 0) * C.frenzy_dr) end
			if tier >= 7 and not (B.mask_swap and B.mask_swap("hardened")) then m = m * (1 - (B.hard_level or 0) * C.hard_step) end
			m = m * (1 - B.socio_combo_dr())
			if B.mask_dr then m = m * (1 - B.mask_dr()) end
		end
		return m
	end

	-- card 9 Massacre: while one of your melee hits lands at high Combo (flag set around PlayerStandard._do_melee_damage
	-- below), the crit roll can't miss. Copdamage.roll_critical_hit forces it too; either one is enough.
	local orig_crit_chance = PlayerManager.critical_hit_chance
	function PlayerManager:critical_hit_chance(...)
		local chance = orig_crit_chance(self, ...)
		if B._socio_swing_crit and type(chance) == "number" then
			return chance + 100
		end
		return chance
	end

	-- kills: Frenzy, Tension, Clean Hit, Combo, Dread
	function B.socio_on_kill(killed_unit, variant, headshot, weapon_id)
		local tier = B.socio_tier()
		if tier < 1 then return end
		local unit = managers.player and managers.player:player_unit()
		local dmg = alive(unit) and unit:character_damage()
		if not dmg or dmg:dead() then return end
		local now = Application:time()
		local melee = variant == "melee"
		-- (7.26) Jake's Venom: a kill by the poison counts for the Combo
		local venom = variant == "poison" and B.mask_on and B.mask_on("jake") or false
		-- 7.10: a gun kill ends Frenzy and Combo (also while downed). Other kills that aren't melee (grenades, thrown
		-- weapons, trip mines) leave them alone. (7.26) Aubrey's shotgun kills neither end nor add anything.
		if not melee and B.socio_is_gun(weapon_id) then
			if not (B.mask_gun_kill_ok and B.mask_gun_kill_ok(weapon_id)) then
				B.socio_on_gun_kill()
			end
			return
		end
		-- Frenzy (7.09: melee kills only - Geo "only make frenzy work with melee"): melee kills within 3 s of the last
		-- melee kill stack; card 5 adds one more per melee kill, card 9 one more for a panicking enemy.
		if melee then
			local chain = B._socio_last_kill and now - B._socio_last_kill <= C.frenzy_window
			local gain = (chain and 1 or 0) + (tier >= 5 and 1 or 0) + ((tier >= 9 and B.socio_panicking(killed_unit)) and 1 or 0)
			B._socio_last_kill = now
			if gain > 0 then
				B.frenzy = math.min((B.frenzy or 0) + gain, B.socio_frenzy_max())
				live("frenzy", "+%d, now %d of %d", gain, B.frenzy, B.socio_frenzy_max())
				if tier >= 9 and B.socio_panicking(killed_unit) then live("panic kill", "killing a panicking enemy gave an extra Frenzy") end
			end
			B._frenzy_decay_t = now + C.frenzy_decay_after
		end
		if dmg:need_revive() then return end
		-- Tension: melee kills only, the same amount of armor whatever you wear, at most once a second ((7.26) not with
		-- Richter: Survivor replaces it)
		if melee and not (B.mask_swap and B.mask_swap("tension")) and now - (B._tension_t or -1e9) >= C.tension_every then
			B._tension_t = now
			local close = tier >= 7 and alive(killed_unit) and mvector3.distance(unit:position(), killed_unit:position()) <= C.close_range
			local amount = close and C.tension_close or C.tension
			dmg:restore_armor(amount)
			live(close and "tension close" or "tension", "a melee kill gave back %d armor", amount * 10)
		end
		if melee and tier >= 5 then
			-- Clean Hit (at most once a second; (7.26) Biker's Helmet gives armor instead)
			if now - (B._clean_t or -1e9) >= C.tension_every then
				B._clean_t = now
				if B.mask_swap and B.mask_swap("clean") then
					dmg:restore_armor(B.MASK.helmet_armor)
					live("helmet", "a melee kill gave back %d armor", B.MASK.helmet_armor * 10)
				else
					dmg:restore_health(B.sc(C.clean_heal, C.clean_heal_ds), false)
					live("clean hit", "a melee kill healed %d%%", B.sc(C.clean_heal, C.clean_heal_ds) * 100)
				end
			end
		end
		if (melee or venom) and tier >= 5 then
			-- Combo (7.11: every melee kill adds one, the first of a chain too - Geo: cleave kills "all still counts as
			-- one"; every kill of a cleave did count, but a chain's first kill didn't, so a cleave that killed two from
			-- nothing showed Combo 1). It ends 5 s after the last melee kill (B.socio_update), on gun fire or a gun kill.
			-- (7.26) a mask can make a kill count more (Dennis' knife opener, Tony's punch on a knocked-down enemy).
			local before = (B.combo_last_t and now - B.combo_last_t <= C.combo_window) and (B.combo or 0) or 0
			if before == 0 then B.combo = 0 end
			local gain = 1 + (B.mask_combo_bonus and B.mask_combo_bonus(weapon_id, before) or 0)
			B.combo = math.min((B.combo or 0) + gain, C.combo_max)
			B.combo_last_t = now
			B.combo_kills = (B.combo_kills or 0) + gain   -- (7.25) every melee kill of a Combo, for the HLM2 counter (hlm2.lua)
			live("combo", "Combo %d: melee charges and swings x%.2f, damage taken -%d%%", B.combo, B.socio_combo_mul(),
				math.floor(B.socio_combo_dr() * 100 + 0.5))
		end
		-- (7.26) the mask's own kill effects (Richter's Scavenger, Jake's spreading venom)
		if B.mask_on_kill then B.mask_on_kill(killed_unit, variant, weapon_id, melee) end
	end

	Hooks:PostHook(PlayerManager, "on_killshot", "GilzaDSBuffs_socio_kill", function(self, killed_unit, variant, headshot, weapon_id)
		B.socio_on_kill(killed_unit, variant, headshot, weapon_id)
	end)

	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_socio_reset", function()
		local session = managers.network and managers.network:session()
		if B._socio_session ~= session then
			B._socio_session = session
			B.frenzy, B.combo, B.combo_last_t, B._socio_last_kill = 0, 0, nil, nil
			B._tension_t, B._clean_t = nil, nil
			B.hard_level, B._hard_fight, B._hard_quiet = 0, 0, 0
			B.socio_panic = {}
			B._socio_diag, B._socio_src_logged, B._socio_charge_logged = {}, nil, nil
		end
	end)

elseif script == "lib/units/beings/player/playerdamage" then
	-- card 3 Thick Skin: a single hit worth more than 20% of your health hurts less ((7.26) not with Rasmus' Foresight
	-- or Corey's Momentum in its place)
	local function thick_skin(self, attack_data, kind)
		if not (attack_data and type(attack_data.damage) == "number" and attack_data.damage > 0) then return end
		if B.socio_tier() < 3 then return end
		if B.mask_swap and B.mask_swap("thick") then return end
		local max = self:_max_health()
		if not max or max <= 0 or not managers.player then return end
		local dr = managers.player:damage_reduction_skill_multiplier(kind)
		if type(dr) ~= "number" then dr = 1 end
		if attack_data.damage * dr > max * C.thick_at then
			attack_data.damage = attack_data.damage * (1 - B.sc(C.thick, C.thick_ds))
			live("thick skin", "a big %s hit was cut by %d%%", kind, B.sc(C.thick, C.thick_ds) * 100)
		end
	end
	for fn, kind in pairs({ damage_bullet = "bullet", damage_melee = "melee", damage_explosion = "explosion" }) do
		if PlayerDamage[fn] then
			Hooks:PreHook(PlayerDamage, fn, "GilzaDSBuffs_socio_thick_" .. fn, function(self, attack_data)
				thick_skin(self, attack_data, kind)
			end)
		end
	end

elseif script == "lib/units/enemies/cop/copdamage" then
	local function mine(attack_data)
		local player = managers.player and managers.player:player_unit()
		return alive(player) and attack_data and attack_data.attacker_unit == player
	end
	-- card 9 Dread: more damage to panicking enemies
	local function dread(self, attack_data)
		if not (mine(attack_data) and type(attack_data.damage) == "number") then return end
		if B.socio_tier() < 9 or not B.socio_panicking(self._unit) then return end
		attack_data.damage = attack_data.damage * (1 + B.sc(C.dread, C.dread_ds))
		live("dread", "x%.2f damage to a panicking enemy", 1 + B.sc(C.dread, C.dread_ds))
	end
	for _, fn in ipairs({ "damage_bullet", "damage_melee" }) do
		Hooks:PreHook(CopDamage, fn, "GilzaDSBuffs_socio_dread_" .. fn, function(self, attack_data)
			dread(self, attack_data)
		end)
	end

	-- (7.24) Jacket's Hotline: a fully charged melee hit kills any non-special, once every 4 s (only used when the hit
	-- wouldn't have killed anyway)
	local function not_special(self)
		local tags = self._char_tweak and self._char_tweak.tags
		if type(tags) == "table" then
			for _, tag in ipairs(tags) do
				if tag == "special" or tag == "civilian" then return false end
			end
		end
		local base = alive(self._unit) and self._unit:base()
		local name = base and base._tweak_table
		if type(name) ~= "string" then return false end
		for _, bit in ipairs({ "boss", "phalanx", "tank", "marshal", "captain", "spooc", "shield", "taser", "medic", "sniper" }) do
			if name:find(bit, 1, true) then return false end
		end
		return true
	end
	Hooks:PreHook(CopDamage, "damage_melee", "GilzaDSBuffs_socio_hotline", function(self, attack_data)
		if self._dead or self._invulnerable or not (mine(attack_data) and type(attack_data.damage) == "number") then return end
		if not (B.sig_active and B.sig_active(C.deck)) then return end
		local charge = attack_data.charge_lerp_value or (B._melee_ctx and B._melee_ctx.charge) or 0
		if type(charge) ~= "number" or charge < C.hotline_charge then return end
		local now = Application:time()
		if now < (B.socio_hotline_ready or 0) then return end
		if self.is_friendly_fire and self:is_friendly_fire(attack_data.attacker_unit) then return end
		if not not_special(self) then return end
		if attack_data.damage >= (self._health or 0) then return end
		-- the game clamps a hit to the enemy's full health
		attack_data.damage = (self._HEALTH_INIT or self._health or attack_data.damage) * 10
		B.socio_hotline_ready = now + C.hotline_every
		local base = self._unit:base()
		B.sig_live("hotline", "a fully charged hit killed a %s in one", tostring(base and base._tweak_table))
	end)
	-- card 9 Massacre: at high Combo every melee hit is a critical hit (Gilza: crits deal 2.25x). The crit chance is
	-- already pushed past 100% for the hit (playermanager branch); this catches anything that still rolls a miss.
	local orig_crit = CopDamage.roll_critical_hit
	if orig_crit then
		function CopDamage:roll_critical_hit(attack_data, damage, ...)
			local crit, dmg = orig_crit(self, attack_data, damage, ...)
			local massacre = attack_data and attack_data.variant == "melee" and mine(attack_data) and B.socio_massacre() or false
			if massacre then
				B.socio_diag("massacre", "melee hit at Combo " .. tostring(B.combo) .. ": rolled " .. tostring(crit))
			end
			if crit or not massacre then return crit, dmg end
			if self.can_be_critical and not self:can_be_critical(attack_data) then return crit, dmg end
			local base = damage or (attack_data and attack_data.damage)
			if type(base) == "number" then
				return true, base * 2.25
			end
			return crit, dmg
		end
	end

elseif script == "lib/units/enemies/cop/copmovement" then
	-- remember who's panicking (the panic animation), for Dread
	Hooks:PostHook(CopMovement, "action_request", "GilzaDSBuffs_socio_panic", function(self, action_desc)
		if action_desc and action_desc.variant == "suppressed_fumble_still" and alive(self._unit) then
			B.socio_panic[self._unit:key()] = Application:time() + C.panic_time
			live("panic seen", "an enemy started the panic animation")
		end
	end)

elseif script == "lib/units/beings/player/states/playerstandard" then
	-- (card 5 Combo's faster charging lives in the playermanager branch: it moves the charge start back every frame)

	-- card 9 Massacre: flag the melee hit while it's dealt, so the crit roll inside it can't miss
	Hooks:PreHook(PlayerStandard, "_do_melee_damage", "GilzaDSBuffs_socio_massacre_pre", function(self)
		B._socio_swing_crit = B.socio_massacre() or nil
	end)
	Hooks:PostHook(PlayerStandard, "_do_melee_damage", "GilzaDSBuffs_socio_massacre_post", function(self)
		B._socio_swing_crit = nil
	end)

	-- card 5 Combo: the swing itself is faster too. Everything the swing waits on is a time stamp set when it starts
	-- (when the hit lands, when you can swing again, when the weapon comes back), plus the arm animation's speed.
	local function speed_up(self, t, keys)
		local mul = B.socio_combo_mul()
		if not (mul and mul > 1 and t) then return end
		local sd = self._state_data
		if not sd then return end
		for _, key in ipairs(keys) do
			local v = sd[key]
			if type(v) == "number" and v > t then sd[key] = t + (v - t) / mul end
		end
		local asm = alive(self._camera_unit) and self._camera_unit:anim_state_machine()
		local anim = asm and self.get_animation and self:get_animation("base")
		local state = anim and asm:segment_state(anim)
		if state then asm:set_speed(state, mul) end
		return mul
	end
	Hooks:PostHook(PlayerStandard, "_do_action_melee", "GilzaDSBuffs_socio_swing", function(self, t)
		local mul = speed_up(self, t, { "melee_damage_delay_t", "melee_repeat_expire_t", "melee_expire_t" })
		if mul then B.socio_diag("swing", string.format("Combo %d: swing x%.2f", B.combo or 0, mul)) end
	end)
	Hooks:PostHook(PlayerStandard, "_start_action_melee", "GilzaDSBuffs_socio_swing_start", function(self, t)
		speed_up(self, t, { "melee_attack_allowed_t" })
	end)

elseif script == "lib/units/weapons/newraycastweaponbase" then
	-- firing a gun ends the Combo
	Hooks:PostHook(NewRaycastWeaponBase, "fire", "GilzaDSBuffs_socio_fire", function(self)
		local user = self._setup and self._setup.user_unit
		if alive(user) and managers.player and user == managers.player:player_unit() and B.socio_tier() >= 5 then
			B.socio_on_fire(self)
		end
	end)

elseif script == "lib/tweak_data/skilltreetweakdata" then
	-- the rework replaces Gilza's shared first card (surrounded resistance + melee stacking), the game's Tension /
	-- Clean Hit / close contact upgrades: Frenzy, Tension, Clean Hit and Hardened do that job now
	local REMOVE = {
		[1] = { player_damage_dampener_outnumbered_strong = true, melee_stacking_hit_damage_multiplier_1 = true, melee_stacking_hit_expire_t = true },
		[3] = { player_killshot_regen_armor_bonus = true },
		[5] = { player_melee_kill_life_leech = true, player_damage_dampener_close_contact_1 = true },
		[7] = { player_killshot_close_regen_armor_bonus = true }
	}
	Hooks:PostHook(SkillTreeTweakData, "init", "GilzaDSBuffs_socio_cards", function(self)
		local deck = self.specializations and self.specializations[C.deck]
		if not deck then return end
		for card, names in pairs(REMOVE) do
			local ups = deck[card] and deck[card].upgrades
			if ups then
				for i = #ups, 1, -1 do
					if names[ups[i]] then table.remove(ups, i) end
				end
			end
		end
		-- card 1 had Infiltrator's description: give it its own
		if deck[1] then
			deck[1].desc_id = "menu_deck9_1_desc"
			deck[1].short_id = "menu_deck9_1_short"
		end
	end)
end
