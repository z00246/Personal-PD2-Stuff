if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics

-- Restoration-style sniper focus:
--  * losing line of sight drops the laser almost right away and the focus starts over
--  * focus time gets a small random spread
--  * a suppressed sniper aims 50% slower
--  * moving far from where the sniper is aiming throws its aim off (loses half its progress)
local BREAK_TIME = 0.4
local HUSK_MIN_FOCUS = 3.3
local SUPPRESSED_MUL = 1.5
local MOVE_DIS = 400

local function focus_time()
	return math.lerp(3.0, 2.0, T.diff_k()) * (1 + math.random() * 0.3)
end

local function target_pos(fe)
	return fe.m_pos or (alive(fe.unit) and fe.unit:position())
end

local function set_laser(data, my_data, on)
	if not my_data.pdth_laser_ok or (my_data.weapon_laser_on and true or false) == on then return end
	local weapon = data.unit:inventory():equipped_unit()
	if weapon and weapon:base().set_laser_enabled then
		weapon:base():set_laser_enabled(on)
	end
	my_data.weapon_laser_on = on or nil
	data.unit:base():prevent_main_bones_disabling(on)
	managers.network:session():send_to_peers_synched("sync_unit_event_id_16", data.unit, "brain",
		on and HuskCopBrain._NET_EVENTS.weapon_laser_on or HuskCopBrain._NET_EVENTS.weapon_laser_off)
end

T.focused = T.focused or {}

local function notify(unit, focus, duration)
	if not alive(unit) or not unit:base() then return end
	if unit:base().is_local_player then
		if focus then T.sniper_focus(duration) else T.sniper_unfocus() end
	elseif unit:base().is_husk_player and T.unit_has_mod(unit) and LuaNetworking then
		local ok, id = pcall(function() return unit:network():peer():id() end)
		if ok and id then
			LuaNetworking:SendToPeer(id, T.NET_ID, focus and string.format("focus:%.1f", duration) or "unfocus")
		end
	end
end

local function start_focus(data, my_data, fe)
	local dur = focus_time()
	if fe.unit:base().is_husk_player and not T.unit_has_mod(fe.unit) then
		dur = math.max(dur, HUSK_MIN_FOCUS)
	end
	my_data.pdth_focus = { key = fe.u_key, unit = fe.unit, start = data.t, seen = data.t, last_t = data.t, dur = dur, progress = 0, anchor = mvector3.copy(target_pos(fe)) }
	set_laser(data, my_data, true)
	local set = T.focused[fe.u_key] or {}
	T.focused[fe.u_key] = set
	if not next(set) then notify(fe.unit, true, dur) end
	set[data.key] = true
end

local function stop_focus(data, my_data)
	local f = my_data.pdth_focus
	my_data.pdth_focus = nil
	set_laser(data, my_data, false)
	if not f then return end
	local set = T.focused[f.key]
	if set then
		set[data.key] = nil
		if not next(set) then
			T.focused[f.key] = nil
			notify(f.unit, false)
		end
	end
end

local function tick(data, my_data)
	local fe = data.attention_obj
	local valid = fe and fe.criminal_record and fe.is_person and fe.reaction
		and fe.reaction >= AIAttentionObject.REACT_SHOOT and alive(fe.unit) and fe.unit:base()
	local f = my_data.pdth_focus

	if f and (not valid or f.key ~= fe.u_key) then
		stop_focus(data, my_data)
		f = nil
	end
	if valid and fe.verified then
		if not f then
			start_focus(data, my_data, fe)
			f = my_data.pdth_focus
		else
			local dt = math.max(data.t - (f.last_t or data.t), 0)
			local rate = data.is_suppressed and (1 / SUPPRESSED_MUL) or 1
			f.progress = (f.progress or 0) + dt * rate
			f.seen = data.t
			local pos = target_pos(fe)
			if pos and f.anchor and mvector3.distance(pos, f.anchor) > MOVE_DIS then
				f.progress = f.progress * 0.5
				f.anchor = mvector3.copy(pos)
			end
		end
		f.last_t = data.t
	elseif f and data.t - f.seen > BREAK_TIME then
		stop_focus(data, my_data)
		f = nil
	elseif f then
		f.last_t = data.t
	end
	return f and (f.progress or 0) >= f.dur or false
end

Hooks:PostHook(CopLogicSniper, "enter", "PDTHTactics_sniper_enter", function(data)
	local my_data = data.internal_data
	if not (T.active() and my_data) then return end
	my_data.pdth_laser_ok = my_data.weapon_laser_on and true or false
	set_laser(data, my_data, false)
end)

Hooks:PreHook(CopLogicSniper, "exit", "PDTHTactics_sniper_exit", function(data)
	local my_data = data.internal_data
	if my_data and my_data.pdth_laser_ok ~= nil then
		pcall(stop_focus, data, my_data)
		my_data.weapon_laser_on = nil
	end
end)

local WOBBLE_START = 150
local function steady_aim(data, my_data)
	local f = my_data.pdth_focus
	local fe = data.attention_obj
	if not (f and fe and fe.verified and alive(fe.unit)) then return end
	local p = math.clamp((f.progress or 0) / f.dur, 0, 1)
	local r = WOBBLE_START * (1 - p) ^ 1.5
	local aim = mvector3.copy(fe.m_head_pos or fe.m_pos)
	mvector3.set_static(aim, aim.x + math.rand(-r, r), aim.y + math.rand(-r, r), aim.z - 25 + math.rand(-r, r) * 0.6)
	CopLogicBase._set_attention_on_pos(data, aim)
	my_data.attention_unit = fe.unit:key()
	my_data.pdth_wobbling = true
end

local orig_aim = CopLogicSniper._upd_aim
CopLogicSniper._upd_aim = function(data, my_data, ...)
	if not (my_data and my_data.pdth_laser_ok ~= nil and T.active()) then
		return orig_aim(data, my_data, ...)
	end
	local ok, ready = pcall(tick, data, my_data)
	if not ok or ready then
		if my_data.pdth_wobbling then
			my_data.pdth_wobbling = nil
			my_data.attention_unit = nil
		end
		return orig_aim(data, my_data, ...)
	end
	local real = CopLogicAttack.aim_allow_fire
	CopLogicAttack.aim_allow_fire = function(shoot, aim, ...)
		return real(false, aim or shoot, ...)
	end
	local ok2, err = pcall(orig_aim, data, my_data, ...)
	CopLogicAttack.aim_allow_fire = real
	if not ok2 then error(err) end
	pcall(steady_aim, data, my_data)
end
