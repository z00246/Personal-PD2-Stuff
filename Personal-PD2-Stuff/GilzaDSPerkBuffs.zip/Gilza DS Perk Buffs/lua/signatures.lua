GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs

-- (7.24) Character signature perks (Geo 2026-10-25/26: "wouldnt it be a good idea if we gave every perk deck a unique
-- perk associated to their character?" + "and its only locked to their character"; unlocks with card 9; the base decks
-- paired with Crew Chief - Dallas, Muscle - Wolf, Armorer - Chains, Rogue - Houston, Hitman - John Wick, Crook - Hoxton,
-- Gambler - Bonnie; "this is fine" to the v4 sheet). Each deck's signature lives in that deck's own file; this file only
-- answers "is it on?": your current perk deck is that deck, you have its card 9, and the heister you are playing is its
-- heister (your own character, on your own game - nothing is sent anywhere). Copycat copying a card 9 doesn't count.
-- Copycat, Leech and Gilza's Brawler / Speed Junkie / Guardian have none (every heister already has a deck).
-- (7.31) Sociopath has none either: Jacket's card 9 is the mask pick (masks.lua), Jacket only - the 7.24 Hotline is gone
-- (Geo: "instead of giving jacket this buff, i think its fine the way we have it where u can switch through masks and
-- its locked to jacket only").
B.SIG_CHARS = {
	[1] = { russian = true },        -- Crew Chief: Dallas
	[2] = { german = true },         -- Muscle: Wolf
	[3] = { spanish = true },        -- Armorer: Chains
	[4] = { american = true },       -- Rogue: Houston
	[5] = { jowi = true },           -- Hitman: John Wick
	[6] = { old_hoxton = true },     -- Crook: Hoxton
	[7] = { female_1 = true },       -- Burglar: Clover
	[8] = { dragan = true },         -- Infiltrator: Dragan
	[10] = { bonnie = true },        -- Gambler: Bonnie
	[11] = { sokol = true },         -- Grinder: Sokol
	[12] = { dragon = true },        -- Yakuza: Jiro
	[13] = { bodhi = true },         -- Ex-President: Bodhi
	[14] = { jimmy = true },         -- Maniac: Jimmy
	[15] = { sydney = true },        -- Anarchist: Sydney
	[16] = { wild = true },          -- Biker: Rust
	[17] = { chico = true },         -- Kingpin: Scarface
	[18] = { max = true },           -- Sicario: Sangres
	[19] = { myh = true },           -- Stoic: Duke
	[20] = { ecp_male = true, ecp_female = true },   -- Tag Team: Ethan and Hila
	[21] = { joy = true },           -- Hacker: Joy
}

-- the heister you are playing (the game's character name, e.g. "dragon" for Jiro)
function B.sig_character()
	local cm = managers.criminals
	local name = cm and cm.local_character_name and cm:local_character_name()
	if not name then
		local session = managers.network and managers.network:session()
		local peer = session and session.local_peer and session:local_peer()
		name = peer and peer.character and peer:character()
	end
	return name
end

-- is this deck's signature on right now (checked at most twice a second per deck)
B._sig_cache = B._sig_cache or {}
function B.sig_active(deck)
	local now = Application:time()
	local c = B._sig_cache[deck]
	if c and now >= c.t and now - c.t < 0.5 then return c.on end
	local on = false
	local st = managers.skilltree
	if st and st:get_specialization_value("current_specialization") == deck
		and (st:get_specialization_value(deck, "tiers", "current_tier") or 0) >= 9 then
		local chars = B.SIG_CHARS[deck]
		local name = chars and B.sig_character()
		on = name and chars[name] and true or false
	end
	B._sig_cache[deck] = { t = now, on = on }
	return on
end

-- a line in the BLT log the first times a signature does something (buffs.lua)
function B.sig_live(key, ...)
	if B.live then B.live("sig " .. key, ...) end
end

-- local outlines (only on your screen, never synced): one contour type per colour, added the first time it's needed;
-- priority 2 like the Contract: over the game's marks, under a Medic's heal flash
B.SIG_OUTLINES = {
	gdsb_revenge = { 1, 0.1, 0.75 },   -- Hoxton's Revenge: magenta
	gdsb_smoke = { 0.85, 0.05, 0.25 }, -- Sangres: crimson
	gdsb_uplink = { 1, 0.95, 0.3 },    -- Joy's Uplink: yellow
}
function B.sig_outline(unit, ty, on)
	if not alive(unit) then return false end
	local ce = unit.contour and unit:contour()
	local types = ContourExt and ContourExt._types
	if not (ce and types) then return false end
	if not types[ty] then
		local c = B.SIG_OUTLINES[ty] or { 1, 1, 1 }
		types[ty] = { priority = 2, material_swap_required = true, unique = true, color = Vector3(c[1], c[2], c[3]) }
	end
	if on then
		ce:add(ty, false)
		return true
	end
	ce:remove(ty, false)
	return true
end
