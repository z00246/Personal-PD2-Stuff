if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics

-- Restoration Mod's dodge (ported from its CopLogicBase.chk_start_action_dodge):
--  * checks how much room there is on both sides and dodges toward the more open one
--    (needs 0.9m, prefers 1.3m) instead of a random side, so cops stop dodging into walls
--  * up close (inside ~5m) there's a chance to dodge backwards, and they back off when the sides are blocked
--  * a steady 0.5s between dodge checks; getting hit ignores that wait
--  * only elite enemies shoot while side-stepping: HRT, ZEAL units and specials (see T.dodge_shooter)

local mvec3_add = mvector3.add
local mvec3_dot = mvector3.dot
local mvec3_mul = mvector3.multiply
local mvec3_neg = mvector3.negate
local mvec3_set = mvector3.set
local mvec3_set_z = mvector3.set_z
local mvec3_sub = mvector3.subtract
local tmp_vec1 = Vector3()
local tmp_vec2 = Vector3()
local tmp_vec3 = Vector3()

-- chance to keep shooting / accuracy while doing it, per dodge reason (Restoration's values)
local SHOOT = { hit = { 0.8, 0.5 }, preemptive = { 1, 0.7 }, scared = { 0.5, 0.4 } }

local ZEAL_UNITS = {
	"units/pd2_dlc_bex/characters/ene_zeal_city_1/ene_zeal_city_1",
	"units/pd2_dlc_bex/characters/ene_zeal_city_2/ene_zeal_city_2",
	"units/pd2_dlc_bex/characters/ene_zeal_city_3/ene_zeal_city_3",
	"units/pd2_dlc_bex/characters/ene_zeal_sniper/ene_zeal_sniper",
	"units/pd2_dlc_bex/characters/ene_zeal_swat_heavy_r870/ene_zeal_swat_heavy_r870",
	"units/pd2_dlc_bex/characters/ene_zeal_swat_heavy_sc/ene_zeal_swat_heavy_sc",
	"units/pd2_dlc_bex/characters/ene_zeal_swat_shield/ene_zeal_swat_shield",
	"units/pd2_dlc_drm/characters/ene_zeal_swat_heavy_sniper/ene_zeal_swat_heavy_sniper",
	"units/pd2_dlc_gitgud/characters/ene_zeal_bulldozer/ene_zeal_bulldozer",
	"units/pd2_dlc_gitgud/characters/ene_zeal_bulldozer_2/ene_zeal_bulldozer_2",
	"units/pd2_dlc_gitgud/characters/ene_zeal_bulldozer_2_sc/ene_zeal_bulldozer_2_sc",
	"units/pd2_dlc_gitgud/characters/ene_zeal_bulldozer_3/ene_zeal_bulldozer_3",
	"units/pd2_dlc_gitgud/characters/ene_zeal_bulldozer_3_sc/ene_zeal_bulldozer_3_sc",
	"units/pd2_dlc_gitgud/characters/ene_zeal_bulldozer_sc/ene_zeal_bulldozer_sc",
	"units/pd2_dlc_gitgud/characters/ene_zeal_city_1/ene_zeal_city_1",
	"units/pd2_dlc_gitgud/characters/ene_zeal_cloaker/ene_zeal_cloaker",
	"units/pd2_dlc_gitgud/characters/ene_zeal_sniper/ene_zeal_sniper",
	"units/pd2_dlc_gitgud/characters/ene_zeal_swat/ene_zeal_swat",
	"units/pd2_dlc_gitgud/characters/ene_zeal_swat_heavy/ene_zeal_swat_heavy",
	"units/pd2_dlc_gitgud/characters/ene_zeal_swat_shield/ene_zeal_swat_shield",
	"units/pd2_dlc_gitgud/characters/ene_zeal_tazer/ene_zeal_tazer",
	"units/pd2_dlc_gitgud/characters/ene_zeal_tazer_sc/ene_zeal_tazer_sc",
	"units/pd2_dlc_help/characters/ene_zeal_bulldozer_halloween/ene_zeal_bulldozer_halloween",
	"units/pd2_mod_reapers/characters/ene_zeal_city_1/ene_zeal_city_1",
	"units/pd2_mod_reapers/characters/ene_zeal_city_2/ene_zeal_city_2",
	"units/pd2_mod_reapers/characters/ene_zeal_city_3/ene_zeal_city_3",
	"units/pd2_mod_reapers/characters/ene_zeal_sniper/ene_zeal_sniper",
	"units/pd2_mod_reapers/characters/ene_zeal_swat_heavy/ene_zeal_swat_heavy",
	"units/pd2_mod_reapers/characters/ene_zeal_swat_heavy_r870/ene_zeal_swat_heavy_r870",
	"units/pd2_mod_reapers/characters/ene_zeal_swat_shield/ene_zeal_swat_shield",
	"units/pd2_mod_sharks/characters/ene_zeal_city_1/ene_zeal_city_1",
	"units/pd2_mod_sharks/characters/ene_zeal_city_2/ene_zeal_city_2",
	"units/pd2_mod_sharks/characters/ene_zeal_city_3/ene_zeal_city_3",
	"units/pd2_mod_sharks/characters/ene_zeal_swat_heavy/ene_zeal_swat_heavy",
	"units/pd2_mod_sharks/characters/ene_zeal_swat_heavy_r870/ene_zeal_swat_heavy_r870",
	"units/pd2_mod_sharks/characters/ene_zeal_swat_shield/ene_zeal_swat_shield",
}

function T.dodge_shooter(data)
	local unit = data.unit
	local base = alive(unit) and unit:base()
	if not base then return false end
	local tweak = base._tweak_table
	if tweak == "fbi" then return true end -- Hostage Rescue Team
	local ct = data.char_tweak
	if ct and T.has(ct.tags, "special") then return true end
	if not T._zeal_keys then
		T._zeal_keys = {}
		for _, path in ipairs(ZEAL_UNITS) do
			T._zeal_keys[Idstring(path):key()] = true
			T._zeal_keys[Idstring(path .. "_husk"):key()] = true
		end
	end
	return T._zeal_keys[unit:name():key()] or false
end

local function smart_dodge(data, reason)
	local dodge = data.char_tweak and data.char_tweak.dodge
	if not (dodge and dodge.occasions and dodge.occasions[reason]) then
		return
	end

	if data.dodge_timeout_t and data.t < data.dodge_timeout_t or data.unit:movement():chk_action_forbidden("walk") then
		return
	end

	if data.dodge_chk_timeout_t and data.t < data.dodge_chk_timeout_t and reason ~= "hit" then
		return
	end

	-- Consistent dodge check cooldown
	data.dodge_chk_timeout_t = TimerManager:game():time() + 0.5

	local dodge_tweak = data.char_tweak.dodge.occasions[reason]
	if dodge_tweak.chance == 0 or dodge_tweak.chance < math.random() then
		return
	end

	local enemy_dir = tmp_vec3
	if data.attention_obj and (data.attention_obj.reaction or 0) >= AIAttentionObject.REACT_COMBAT and data.attention_obj.m_pos then
		mvec3_set(enemy_dir, data.attention_obj.m_pos)
		mvec3_sub(enemy_dir, data.m_pos)
		mvec3_set_z(enemy_dir, 0)
		mvector3.normalize(enemy_dir)
	else
		mvector3.set(enemy_dir, math.UP)
		mvector3.random_orthogonal(enemy_dir)
	end

	local dodge_dir = mvector3.copy(enemy_dir)
	mvector3.cross(dodge_dir, enemy_dir, math.UP)
	if math.random() < 0.5 then
		mvec3_neg(dodge_dir)
	end

	local test_space, available_space, min_space, prefered_space = 0, 0, 90, 130
	local ray_params = {
		trace = true,
		tracker_from = data.unit:movement():nav_tracker(),
		pos_to = tmp_vec1
	}

	mvec3_set(ray_params.pos_to, dodge_dir)
	mvec3_mul(ray_params.pos_to, prefered_space)
	mvec3_add(ray_params.pos_to, data.m_pos)
	local ray_hit1 = managers.navigation:raycast(ray_params)
	if ray_hit1 then
		mvec3_set(tmp_vec2, ray_params.trace[1])
		mvec3_sub(tmp_vec2, data.m_pos)
		mvec3_set_z(tmp_vec2, 0)
		test_space = mvector3.length(tmp_vec2)
	else
		test_space = prefered_space
	end

	if test_space >= min_space then
		available_space = test_space
	end

	mvec3_set(ray_params.pos_to, dodge_dir)
	mvec3_mul(ray_params.pos_to, -prefered_space)
	mvec3_add(ray_params.pos_to, data.m_pos)
	local ray_hit2 = managers.navigation:raycast(ray_params)
	if ray_hit2 then
		mvec3_set(tmp_vec2, ray_params.trace[1])
		mvec3_sub(tmp_vec2, data.m_pos)
		mvec3_set_z(tmp_vec2, 0)
		test_space = mvector3.length(tmp_vec2)
	elseif available_space < prefered_space then
		test_space = prefered_space
	end

	if test_space >= min_space and test_space > available_space then
		available_space = test_space
		mvec3_neg(dodge_dir)
	end

	-- Give enemies a chance to dodge backwards if dodging to the side is not possible or if dodging backwards has more space
	if available_space < min_space or data.attention_obj and math.random() < math.max(0, 1 - (data.attention_obj.dis or 1000) / 500) then
		mvec3_set(ray_params.pos_to, enemy_dir)
		mvec3_mul(ray_params.pos_to, -prefered_space)
		mvec3_add(ray_params.pos_to, data.m_pos)
		local ray_hit3 = managers.navigation:raycast(ray_params)
		if ray_hit3 then
			mvec3_set(tmp_vec2, ray_params.trace[1])
			mvec3_sub(tmp_vec2, data.m_pos)
			mvec3_set_z(tmp_vec2, 0)
			test_space = mvector3.length(tmp_vec2)
		else
			test_space = prefered_space
		end

		if test_space >= min_space and test_space >= available_space then
			available_space = test_space
			mvec3_set(dodge_dir, enemy_dir)
			mvec3_neg(dodge_dir)
		end
	end

	if available_space < min_space then
		return
	end

	mrotation.x(data.unit:movement():m_rot(), tmp_vec1)
	local right_dot = mvec3_dot(dodge_dir, tmp_vec1)
	local fwd_dot = mvec3_dot(dodge_dir, data.unit:movement():m_fwd())
	local dodge_side =  math.abs(fwd_dot) > 0.6 and (fwd_dot > 0 and "fwd" or "bwd") or right_dot > 0 and "r" or "l"

	local rand_nr = math.random()
	local total_chance = 0
	local variation, variation_data
	for test_variation, test_variation_data in pairs(dodge_tweak.variations or {}) do
		local chance = test_variation_data.chance or 0
		total_chance = total_chance + chance

		if chance > 0 and rand_nr <= total_chance then
			variation = test_variation
			variation_data = test_variation_data
			break
		end
	end
	-- (a preset whose variations add up to less than the roll: no dodge this time)
	if not variation_data then
		return
	end

	local body_part = 1
	-- shooting while dodging: only HRT, ZEAL units and specials, and only on side-steps
	local shoot_chance, shoot_accuracy
	if variation == "side_step" and T.dodge_shooter(data) then
		local v = SHOOT[reason] or SHOOT.hit
		shoot_chance, shoot_accuracy = v[1], v[2]
	end
	if shoot_chance and shoot_chance > 0 and math.random() < shoot_chance then
		body_part = 2
	end

	local action_data = {
		type = "dodge",
		body_part = body_part,
		variation = variation,
		side = dodge_side,
		direction = dodge_dir,
		timeout = variation_data.timeout,
		speed = data.char_tweak.dodge.speed,
		shoot_accuracy = shoot_accuracy,
		blocks = {
			act = -1,
			tase = -1,
			dodge = -1,
			walk = -1,
			action = body_part == 1 and -1 or nil,
			aim = body_part == 1 and -1 or nil
		}
	}

	if variation ~= "side_step" then
		action_data.blocks.hurt = -1
		action_data.blocks.heavy_hurt = -1
	end

	local action = data.unit:movement():action_request(action_data)
	if action then
		local my_data = data.internal_data

		CopLogicAttack._cancel_cover_pathing(data, my_data)
		CopLogicAttack._cancel_charge(data, my_data)
		CopLogicAttack._cancel_expected_pos_path(data, my_data)
		CopLogicAttack._cancel_walking_to_cover(data, my_data, true)
	end

	return action
end

-- (1.91, Geo: no engine calls wrapped in pcalls) Restoration's dodge runs directly; the preset, the attention
-- object and the dodge variation are checked above instead
local orig_dodge = CopLogicBase.chk_start_action_dodge
function CopLogicBase.chk_start_action_dodge(data, reason, ...)
	if not T.active() then return orig_dodge(data, reason, ...) end
	return smart_dodge(data, reason)
end
