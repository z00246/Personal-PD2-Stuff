GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

B.TAGTEAM = {
	deck = 20,
	bond = 0.10,
	crossfire = 0.25,
	crossfire_ds = 0.35,
	crossfire_window = 3,
	lifeline_dr = 0.30,
	lifeline_speed = 1.2,
	lifeline_time = 3,
	shared_pain = 0.15,
	shared_pain_ds = 0.20,
	tag_out = 0.15
}
local C = B.TAGTEAM
B.NET_ID = B.NET_ID or "GilzaDSBuffs"

function B.tt_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == C.deck) then
		return 0
	end
	return st:get_specialization_value(C.deck, "tiers", "current_tier") or 0
end

function B.tt_linked()
	local pm = managers.player
	local mgr = pm and pm._coroutine_mgr
	return mgr and mgr.is_running and mgr:is_running("tag_team") and alive(B.tt_partner) or false
end

function B.tt_lifeline()
	return Application:time() < (B.tt_lifeline_until or 0)
end

local function partner_downed(unit)
	if not alive(unit) then return false end
	local mov, dmg = unit:movement(), unit:character_damage()
	if mov and mov.downed and mov:downed() then return true end
	if dmg and dmg.need_revive and dmg:need_revive() then return true end
	return false
end

local function heal_partner(unit, amount)
	if not alive(unit) or amount <= 0 then return end
	local session = managers.network and managers.network:session()
	local peer = session and session:peer_by_unit(unit)
	if peer and LuaNetworking and LuaNetworking.SendToPeer then
		LuaNetworking:SendToPeer(peer:id(), B.NET_ID, "teamheal:" .. string.format("%.3f", amount))
	elseif Network:is_server() then
		local dmg = unit:character_damage()
		if dmg and dmg._health and dmg._HEALTH_INIT and not dmg._dead then
			local me = managers.player and managers.player:player_unit()
			local my_dmg = alive(me) and me:character_damage()
			local my_max = my_dmg and my_dmg:_max_health() or 0
			if my_max > 0 then
				dmg._health = math.min(dmg._health + amount / my_max * dmg._HEALTH_INIT, dmg._HEALTH_INIT)
				dmg._health_ratio = dmg._health / dmg._HEALTH_INIT
			end
		end
	end
end

if script == "lib/managers/playermanager" then
	-- remember who we tagged
	local orig_add = PlayerManager.add_coroutine
	function PlayerManager:add_coroutine(name, func, ...)
		if name == "tag_team" then
			local tagged = select(1, ...)
			if alive(tagged) then B.tt_partner = tagged end
		end
		return orig_add(self, name, func, ...)
	end

	-- allow tagging your converted cops too (Gilza's tag check only looks at players and bots)
	local function find_convert(pm)
		local player = pm:player_unit()
		local state = managers.groupai and managers.groupai:state()
		local converts = state and state._converted_police
		if not (alive(player) and converts and next(converts)) then return nil end
		local cam = player.camera and player:camera()
		if not cam then return nil end
		local base = pm:upgrade_value("player", "tag_team_base")
		local max_dis = (type(base) == "table" and base.distance or 18) * 100
		local eye = cam:position()
		local fwd = cam:rotation():y()
		local best, best_angle
		for _, unit in pairs(converts) do
			local mov = alive(unit) and unit:movement()
			if mov and mov.m_com and not (unit:character_damage() and unit:character_damage()._dead) then
				local pos = mov:m_com()
				local vec = pos - eye
				local dis = mvector3.normalize(vec)
				if dis * 1 < max_dis then
					local max_angle = math.max(8, math.lerp(10, 30, dis / 1200))
					local angle = vec:angle(fwd)
					if angle < max_angle + 10 and (not best_angle or angle < best_angle) then
						best, best_angle = unit, angle
					end
				end
			end
		end
		return best
	end
	local orig_attempt = PlayerManager._attempt_tag_team
	if orig_attempt then
		function PlayerManager:_attempt_tag_team(...)
			local success = orig_attempt(self, ...)
			if success or (self._coroutine_mgr and self._coroutine_mgr:is_running("tag_team")) then
				return success
			end
			local tagged = find_convert(self)
			if alive(tagged) and PlayerAction and PlayerAction.TagTeam then
				self:add_coroutine("tag_team", PlayerAction.TagTeam, tagged, self:player_unit())
				return true
			end
			return success
		end
	end

	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_tt_update", function()
		local tier = B.tt_tier()
		local linked = B.tt_linked()
		-- Lifeline: partner goes down while linked
		if linked and tier >= 5 then
			local down = partner_downed(B.tt_partner)
			if down and not B._tt_partner_down then
				B.tt_lifeline_until = Application:time() + C.lifeline_time
			end
			B._tt_partner_down = down
		else
			B._tt_partner_down = false
		end
		-- Tag Out: link ends
		if B._tt_was_linked and not linked and tier >= 9 then
			local me = managers.player and managers.player:player_unit()
			local dmg = alive(me) and me:character_damage()
			if dmg and not dmg:dead() and not dmg:need_revive() then
				dmg:restore_health(C.tag_out)
				heal_partner(B.tt_partner, dmg:_max_health() * C.tag_out)
			end
		end
		B._tt_was_linked = linked
	end)

	local orig_resist = PlayerManager.damage_reduction_skill_multiplier
	function PlayerManager:damage_reduction_skill_multiplier(...)
		local m = orig_resist(self, ...)
		if type(m) ~= "number" then return m end
		local tier = B.tt_tier()
		if tier < 5 then return m end
		if B.tt_lifeline() then m = m * (1 - C.lifeline_dr) end
		if tier >= 7 and B.tt_linked() then
			m = m * (1 - (B.on and C.shared_pain_ds or C.shared_pain))
		end
		return m
	end

	local orig_speed = PlayerManager.movement_speed_multiplier
	function PlayerManager:movement_speed_multiplier(...)
		local m = orig_speed(self, ...)
		if type(m) == "number" and B.tt_lifeline() then
			return m * C.lifeline_speed
		end
		return m
	end

elseif script == "lib/units/enemies/cop/copdamage" then
	-- Crossfire: remember when your partner last hit each enemy
	local function note_partner_hit(self, attacker)
		if alive(attacker) and attacker == B.tt_partner then
			self._gdsb_tt_partner_hit = Application:time()
		end
	end

	local function bonus(self, attack_data)
		if not attack_data or type(attack_data.damage) ~= "number" then return end
		note_partner_hit(self, attack_data.attacker_unit)
		local player = managers.player and managers.player:player_unit()
		if not (alive(player) and attack_data.attacker_unit == player) then return end
		local tier = B.tt_tier()
		if tier < 1 or not B.tt_linked() then return end
		local mul = 1 + C.bond
		if tier >= 3 and Application:time() - (self._gdsb_tt_partner_hit or -100) <= C.crossfire_window then
			mul = mul + (B.on and C.crossfire_ds or C.crossfire)
		end
		attack_data.damage = attack_data.damage * mul
	end

	for _, fn in ipairs({ "damage_bullet", "damage_melee", "damage_explosion", "damage_fire" }) do
		if CopDamage[fn] then
			Hooks:PreHook(CopDamage, fn, "GilzaDSBuffs_tt_" .. fn, function(self, attack_data)
				bonus(self, attack_data)
			end)
		end
	end
	for _, fn in ipairs({ "sync_damage_bullet", "sync_damage_melee", "sync_damage_explosion", "sync_damage_fire" }) do
		if CopDamage[fn] then
			Hooks:PreHook(CopDamage, fn, "GilzaDSBuffs_tt_" .. fn, function(self, attacker_unit)
				note_partner_hit(self, attacker_unit)
			end)
		end
	end
end
