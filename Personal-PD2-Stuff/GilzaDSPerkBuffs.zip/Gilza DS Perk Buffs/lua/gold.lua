GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs

B.GOLD = Color(1, 1, 0.8, 0.28)
B.GOLD_WORDS = { "Death Sentence" }

local function char_index(text, byte_pos)
	return utf8.len and utf8.len(string.sub(text, 1, byte_pos - 1)) or #utf8.characters(string.sub(text, 1, byte_pos - 1))
end

function B.gold_words(text_object)
	if not (text_object and alive(text_object)) then return end
	local text = text_object:text()
	if type(text) ~= "string" then return end
	for _, word in ipairs(B.GOLD_WORDS) do
		local from = 1
		while true do
			local s, e = string.find(text, word, from, true)
			if not s then break end
			local cs = char_index(text, s)
			text_object:set_range_color(cs, cs + utf8.len(word), B.GOLD)
			from = e + 1
		end
	end
end

-- on the perk deck screen (paint.lua sets B._paint_active) every highlighted number takes the colour of what it does;
-- everywhere else "Death Sentence" turns gold as before
local orig_colors = MenuComponentManager.add_colors_to_text_object
function MenuComponentManager:add_colors_to_text_object(text_object, ...)
	local raw = B._paint_active and B.paint_apply and text_object and alive(text_object) and text_object:text() or nil
	local result = orig_colors(self, text_object, ...)
	local painted = false
	if raw then
		local ok, done = pcall(B.paint_apply, text_object, raw)
		painted = ok and done
		if not ok and not B._paint_err then
			B._paint_err = true
			log("[Gilza DS Perk Buffs] perk colours: " .. tostring(done))
		end
	end
	if not painted then pcall(B.gold_words, text_object) end
	return result
end
