GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

B.HACKER = {
	deck = 21,
	mark_every = 3,
	mark_type = "mark_enemy_damage_bonus"
}
local C = B.HACKER

function B.hacker_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == C.deck) then
		return 0
	end
	return st:get_specialization_value(C.deck, "tiers", "current_tier") or 0
end

local function unit_tier(unit)
	local me = managers.player and managers.player:player_unit()
	if unit == me then return B.hacker_tier() end
	local session = managers.network and managers.network:session()
	local peer = session and session:peer_by_unit(unit)
	local skills = peer and peer.unpacked_skills and peer:unpacked_skills()
	local spec = skills and skills.specializations
	if spec and tonumber(spec[1]) == C.deck then
		return tonumber(spec[2]) or 0
	end
	return 0
end

function B.hacker_feedback_active()
	local unit = managers.player and managers.player:player_unit()
	local inv = alive(unit) and unit:inventory()
	local data = inv and inv._jammer_data
	return data and data.effect == "feedback" or false
end

if script == "lib/managers/playermanager" then
	-- Overclock: enemies inside your feedback get marked for the whole crew
	B._hacker_marked = B._hacker_marked or {}
	local function overclock()
		if B.hacker_tier() < 5 or not B.hacker_feedback_active() then return end
		local unit = managers.player:player_unit()
		local inv = unit:inventory()
		local _, range = inv:get_feedback_values()
		if not range or range <= 0 then return end
		local pos = unit:position()
		local now = Application:time()
		for key, u_data in pairs(managers.enemy:all_enemies() or {}) do
			local enemy = u_data.unit
			if alive(enemy) and enemy:in_slot(managers.slot:get_mask("enemies")) and now >= (B._hacker_marked[key] or 0) then
				local dmg = enemy:character_damage()
				if dmg and not dmg._dead and mvector3.distance(enemy:position(), pos) <= range then
					local contour = enemy:contour()
					if contour then
						contour:add(C.mark_type, true, 1)
						B._hacker_marked[key] = now + C.mark_every
					end
				end
			end
		end
	end

	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_hacker_update", function()
		local now = Application:time()
		if now < (B._hacker_next or 0) then return end
		B._hacker_next = now + 0.5
		pcall(overclock)
	end)

elseif script == "lib/units/beings/player/playerinventory" then
	-- Firewall (host): each feedback pulse from a Hacker with card 7 stuns Tazers and Cloakers in range
	local function is_special(enemy)
		local tweak = enemy:base() and enemy:base()._tweak_table or ""
		return string.find(tweak, "taser", 1, true) or string.find(tweak, "spooc", 1, true)
	end

	Hooks:PreHook(PlayerInventory, "_do_feedback", "GilzaDSBuffs_hacker_firewall", function(self)
		pcall(function()
			if not Network:is_server() or not alive(self._unit) then return end
			local data = self._jammer_data
			if not (data and data.range) then return end
			if unit_tier(self._unit) < 7 then return end
			local pos = self:_get_feedback_pos()
			for _, u_data in pairs(managers.enemy:all_enemies() or {}) do
				local enemy = u_data.unit
				local dmg = alive(enemy) and enemy:character_damage()
				if dmg and not dmg._dead and enemy:in_slot(managers.slot:get_mask("enemies")) and is_special(enemy) then
					local head = enemy:movement():m_head_pos()
					if mvector3.distance(head, pos) <= data.range then
						dmg:damage_explosion({
							damage = 0,
							variant = "stun",
							attacker_unit = self._unit,
							col_ray = {
								position = mvector3.copy(head),
								ray = (head - pos):normalized()
							}
						})
					end
				end
			end
		end)
	end)

elseif script == "lib/tweak_data/skilltreetweakdata" then
	-- Overclock and Firewall replace the flat dodge on cards 5 and 7
	Hooks:PostHook(SkillTreeTweakData, "init", "GilzaDSBuffs_hacker_cards", function(self)
		local deck = self.specializations and self.specializations[C.deck]
		for _, card in ipairs({ 5, 7 }) do
			local ups = deck and deck[card] and deck[card].upgrades
			if ups then
				for i = #ups, 1, -1 do
					if string.find(ups[i], "dodge", 1, true) then table.remove(ups, i) end
				end
			end
		end
	end)
end
