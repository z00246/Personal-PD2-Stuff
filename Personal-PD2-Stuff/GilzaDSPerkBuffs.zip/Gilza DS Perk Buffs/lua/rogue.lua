GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

-- difficulty scaling (shared with buffs.lua): t = 0 up to Overkill, 1/3 Mayhem, 2/3 Death Wish, 1 Death Sentence
if not B.diff_t then
	B.DIFF_T = { easy_wish = 1 / 3, overkill_290 = 2 / 3, sm_wish = 1 }
	function B.diff_t()
		local gs = Global and Global.game_settings
		return gs and B.DIFF_T[gs.difficulty] or 0
	end
	function B.sc(base, ds) return base + (ds - base) * B.diff_t() end
	function B.sci(base, ds) return math.floor(base + (ds - base) * B.diff_t() + 0.5) end
end

-- a line in the BLT log the first times a feature does something (buffs.lua)
local function live(key, ...) if B.live then B.live("rogue " .. key, ...) end end

-- Rogue (7.20 rework v1, Geo 2026-10-25: "lets move onto rogue, anything we can do for him?" - picked "Rework standard"
-- and "Cutpurse" ("why would armor matter for rogue" -> Cutpurse heals health); "yea go ahead and build them"). The 6.x
-- effects stay, named, with Death Sentence ends:
--  card 1 Blindside: the deck's dodge (Gilza's passive_dodge_chance 15/30/45%) gets +0% » 5% (the buffs.lua niche adds
--   the 5% on Death Sentence only; below it, the scaled part is added here); 25% » 35% more damage to enemies not
--   facing you (bullets and melee).
--  card 3 Momentum: 40% less likely to be targeted; each dodge +5% » 7.5% dodge for 6 s, up to 4. Quickdraw: 30% faster
--   reload and swap for 4 s after a dodge (the reload counts once now while the game caches it for a reload).
--  card 5 Cutpurse: Blindside 35% » 45%; killing an enemy not facing you heals 3% » 4% of your health and puts 3 rounds
--   into the magazine of the weapon in your hands (free, never past a full magazine), at most every 0.5 s.
--  card 7 Riposte: shots within 2 » 3 s of a dodge are critical hits.
--  card 9 Afterimage: 3 dodges within 3 s -> invulnerable for 1.5 » 2 s, at most every 15 s; card 9 drops Gilza's 40%
--   armor piercing and crouch dodge (6.x).
-- *_ds values are the Death Sentence end of the difficulty scale (B.sc).
B.ROGUE = {
	deck = 4,
	targeted = 0.6,
	dodge_ds = 0.05,                                -- card 1: the deck's dodge at the Death Sentence end
	stack_dodge = 0.05, stack_dodge_ds = 0.075,     -- card 3 Momentum
	stack_max = 4,
	stack_time = 6,
	ghost_dodges = 3,                               -- card 9 Afterimage
	ghost_window = 3,
	ghost_time = 1.5, ghost_time_ds = 2,
	ghost_cooldown = 15,
	flank = { [1] = 0.25, [5] = 0.35 },             -- Blindside
	flank_ds = { [1] = 0.35, [5] = 0.45 },
	flank_dot = 0.3,
	rush_speed = 1.3,                               -- Quickdraw
	rush_time = 4,
	riposte_time = 2, riposte_time_ds = 3,          -- card 7 Riposte
	cutpurse_heal = 0.03, cutpurse_heal_ds = 0.04,  -- card 5 Cutpurse
	cutpurse_rounds = 3,
	cutpurse_every = 0.5,
	-- (7.24) Houston's signature (card 9, only as Houston): Professional - your first shot at an enemy who isn't facing
	-- you is a critical hit; kills during Riposte stretch it by 1 s and add a Momentum stack
	pro_riposte = 1
}
local C = B.ROGUE

function B.rogue_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == C.deck) then
		return 0
	end
	return st:get_specialization_value(C.deck, "tiers", "current_tier") or 0
end

local function by_tier(tbl, tier)
	local best
	for card, v in pairs(tbl) do
		if tier >= card and (not best or card > best) then best = card end
	end
	return best and tbl[best] or 0, best
end

-- Blindside for this card and difficulty
function B.rogue_flank(tier)
	local base, card = by_tier(C.flank, tier)
	if not card then return 0 end
	return B.sc(base, C.flank_ds[card] or base)
end

-- an enemy that isn't facing this position
function B.rogue_not_facing(unit, pos)
	local mov = alive(unit) and unit:movement()
	if not (mov and mov.m_rot and mov.m_pos and pos) then return false end
	local fwd = mov:m_rot():y()
	local to = pos - mov:m_pos()
	mvector3.set_z(to, 0)
	mvector3.normalize(to)
	return mvector3.dot(fwd, to) < C.flank_dot
end

function B.rogue_pre_apply()
	local values = tweak_data and tweak_data.upgrades and tweak_data.upgrades.values
	if not values or B._rogue_done_for == values then return end
	B._rogue_done_for = values
	values.player.camouflage_multiplier = { C.targeted }
end

function B.rogue_rush()
	return Application:time() < (B.rogue_rush_until or 0)
end

-- how much the Death Sentence niche (buffs.lua) adds to an upgrade right now (B.saved holds the applied niches)
local function niche_bump(pm, key)
	local rec = B.saved and B.saved["player." .. key]
	if not rec then return 0 end
	local level = pm:upgrade_level("player", key, 0) or 0
	if level <= 0 then return 0 end
	local o, b = rec.orig and rec.orig[level], rec.buffed and rec.buffed[level]
	if type(o) == "number" and type(b) == "number" then return b - o end
	return 0
end

if script == "lib/managers/playermanager" then
	local orig_dodge = PlayerManager.skill_dodge_chance
	function PlayerManager:skill_dodge_chance(...)
		local chance = orig_dodge(self, ...)
		if type(chance) ~= "number" then return chance end
		local ok, tier = pcall(B.rogue_tier)
		if not ok then return chance end
		-- card 3 Momentum
		if tier >= 3 and Application:time() < (B.rogue_stack_until or 0) then
			local per = B.sc(C.stack_dodge, C.stack_dodge_ds)
			chance = chance + (B.rogue_stacks or 0) * per
			live("momentum", "+%.1f%% dodge from %d stacks", (B.rogue_stacks or 0) * per * 100, B.rogue_stacks or 0)
		end
		-- card 1 Blindside: the deck's dodge grows to +5% on Death Sentence (the niche gives that there; here the rest)
		if tier >= 1 then
			local ok2, fix = pcall(function()
				if (self:upgrade_level("player", "passive_dodge_chance", 0) or 0) <= 0 then return 0 end
				local want = C.dodge_ds * math.min(B.t or B.diff_t(), 1)
				return math.max(want - niche_bump(self, "passive_dodge_chance"), 0)
			end)
			if ok2 and type(fix) == "number" and fix > 0 then
				chance = chance + fix
				live("dodge ramp", "+%.1f%% deck dodge (difficulty scale)", fix * 100)
			end
		end
		return chance
	end

	local orig_crit = PlayerManager.critical_hit_chance
	function PlayerManager:critical_hit_chance(...)
		local chance = orig_crit(self, ...)
		if type(chance) == "number" and Application:time() < (B.rogue_riposte_until or 0) then
			live("riposte", "a critical hit after a dodge")
			return chance + 1
		end
		-- (7.24) Houston's Professional: the first shot at an enemy who isn't facing you (set by the copdamage hook for
		-- the hit being worked out right now)
		if type(chance) == "number" and B._hou_crit then
			B.sig_live("professional crit", "a first shot from his blind side")
			return chance + 1
		end
		return chance
	end

	-- (7.24) Houston's Professional: kills during Riposte stretch it by 1 s and add a Momentum stack
	Hooks:PostHook(PlayerManager, "on_killshot", "GilzaDSBuffs_rogue_professional", function(self)
		pcall(function()
			local now = Application:time()
			if now >= (B.rogue_riposte_until or 0) or not (B.sig_active and B.sig_active(C.deck)) then return end
			B.rogue_riposte_until = B.rogue_riposte_until + C.pro_riposte
			if now >= (B.rogue_stack_until or 0) then B.rogue_stacks = 0 end
			B.rogue_stacks = math.min((B.rogue_stacks or 0) + 1, C.stack_max)
			B.rogue_stack_until = now + C.stack_time
			B.sig_live("professional", "a kill during Riposte: +1 s, Momentum %d", B.rogue_stacks)
		end)
	end)

	local function on_dodge()
		local tier = B.rogue_tier()
		local now = Application:time()
		if tier >= 3 then
			B.rogue_rush_until = now + C.rush_time
			if now >= (B.rogue_stack_until or 0) then
				B.rogue_stacks = 0
			end
			B.rogue_stacks = math.min((B.rogue_stacks or 0) + 1, C.stack_max)
			B.rogue_stack_until = now + C.stack_time
		end
		if tier >= 9 and now >= (B.rogue_ghost_ready or 0) then
			B.rogue_dodges = B.rogue_dodges or {}
			table.insert(B.rogue_dodges, now)
			while B.rogue_dodges[1] and now - B.rogue_dodges[1] > C.ghost_window do
				table.remove(B.rogue_dodges, 1)
			end
			if #B.rogue_dodges >= C.ghost_dodges then
				local unit = managers.player:player_unit()
				local dmg = alive(unit) and unit:character_damage()
				local dur = B.sc(C.ghost_time, C.ghost_time_ds)
				if dmg and dmg.Gilza_add_damage_invuln_timer then
					dmg:Gilza_add_damage_invuln_timer(dur)
					unit:sound():play("perkdeck_activate", nil, false)
					B.rogue_ghost_until = now + dur
					live("afterimage", "invulnerable for %.2f seconds", dur)
				end
				B.rogue_dodges = {}
				B.rogue_ghost_ready = now + C.ghost_cooldown
			end
		end
		if tier >= 7 then
			B.rogue_riposte_until = now + B.sc(C.riposte_time, C.riposte_time_ds)
		end
	end

	Hooks:PostHook(PlayerManager, "init", "GilzaDSBuffs_rogue_dodge", function(self)
		self:register_message(Message.OnPlayerDodge, "GilzaDSBuffs_rogue_dodge", function()
			pcall(on_dodge)
		end)
	end)

	-- card 5 Cutpurse: a kill on an enemy that isn't facing you heals you and slips rounds into your magazine
	local function cutpurse(pm, killed)
		if B.rogue_tier() < 5 or not alive(killed) then return end
		local now = Application:time()
		if now < (B._rogue_cutpurse_next or 0) then return end
		local base = killed:base()
		if base and CopDamage.is_civilian and CopDamage.is_civilian(base._tweak_table) then return end
		local player = pm:player_unit()
		local dmg = alive(player) and player:character_damage()
		if not dmg or dmg._dead or (dmg.dead and dmg:dead()) or (dmg.need_revive and dmg:need_revive()) then return end
		if not B.rogue_not_facing(killed, player:position()) then return end
		B._rogue_cutpurse_next = now + C.cutpurse_every
		local heal = B.sc(C.cutpurse_heal, C.cutpurse_heal_ds)
		dmg:restore_health(heal, false)
		local added = 0
		local inv = player:inventory()
		local w = inv and inv:equipped_unit()
		local wb = alive(w) and w:base()
		local ab = wb and wb.ammo_base and wb:ammo_base()
		if ab and ab.get_ammo_remaining_in_clip then
			local clip, max_clip = ab:get_ammo_remaining_in_clip(), ab:get_ammo_max_per_clip()
			local total, max_total = ab:get_ammo_total(), ab:get_ammo_max()
			local add = math.min(C.cutpurse_rounds, max_clip - clip)
			if add > 0 then
				local new_total = math.min(total + add, max_total)
				ab:set_ammo_total(new_total)
				ab:set_ammo_remaining_in_clip(math.min(clip + add, new_total))
				added = ab:get_ammo_remaining_in_clip() - clip
				if managers.hud and wb.selection_index then
					managers.hud:set_ammo_amount(wb:selection_index(), wb:ammo_info())
				end
			end
		end
		live("cutpurse", "a kill from behind healed %.1f%% and slipped %d rounds into the magazine", heal * 100, added)
	end

	Hooks:PostHook(PlayerManager, "on_killshot", "GilzaDSBuffs_rogue_cutpurse", function(self, killed_unit)
		local ok, err = pcall(cutpurse, self, killed_unit)
		if not ok and not B._rogue_cutpurse_err then
			B._rogue_cutpurse_err = true
			log("[Gilza DS Perk Buffs] Rogue Cutpurse error: " .. tostring(err))
		end
	end)

elseif script == "lib/units/enemies/cop/copdamage" then
	-- card 1/5 Blindside
	local function flank_bonus(self, attack_data)
		if not attack_data or type(attack_data.damage) ~= "number" then return end
		local player = managers.player and managers.player:player_unit()
		if not (alive(player) and attack_data.attacker_unit == player) then return end
		local tier = B.rogue_tier()
		if tier < 1 then return end
		if B.rogue_not_facing(self._unit, player:position()) then
			local more = B.rogue_flank(tier)
			attack_data.damage = attack_data.damage * (1 + more)
			live("blindside", "+%.1f%% damage to an enemy not facing you", more * 100)
		end
	end
	for _, fn in ipairs({ "damage_bullet", "damage_melee" }) do
		Hooks:PreHook(CopDamage, fn, "GilzaDSBuffs_rogue_flank_" .. fn, function(self, attack_data)
			pcall(flank_bonus, self, attack_data)
		end)
	end

	-- (7.24) Houston's Professional: your first bullet that hits each enemy is a critical hit if he isn't facing you
	-- (the flag lives only while this hit is worked out; PlayerManager:critical_hit_chance reads it)
	Hooks:PreHook(CopDamage, "damage_bullet", "GilzaDSBuffs_rogue_professional", function(self, attack_data)
		B._hou_crit = nil
		pcall(function()
			if self._gdsb_hou_hit or self._dead then return end
			local player = managers.player and managers.player:player_unit()
			if not (alive(player) and attack_data and attack_data.attacker_unit == player) then return end
			if not (B.sig_active and B.sig_active(C.deck)) then return end
			self._gdsb_hou_hit = true
			if B.rogue_not_facing(self._unit, player:position()) then B._hou_crit = true end
		end)
	end)
	Hooks:PostHook(CopDamage, "damage_bullet", "GilzaDSBuffs_rogue_professional_post", function()
		B._hou_crit = nil
	end)

elseif script == "lib/units/weapons/newraycastweaponbase" then
	-- card 3 Quickdraw: faster reload after a dodge (the game caches the multiplier for a reload: count it once)
	local orig_reload = NewRaycastWeaponBase.reload_speed_multiplier
	function NewRaycastWeaponBase:reload_speed_multiplier(...)
		local m = orig_reload(self, ...)
		if self._current_reload_speed_multiplier or type(m) ~= "number" then return m end   -- cached: already counted
		if B.rogue_rush() then
			live("quickdraw reload", "reload x%.2f after a dodge", C.rush_speed)
			return m * C.rush_speed
		end
		return m
	end

elseif script == "lib/units/beings/player/states/playerstandard" then
	-- card 3 Quickdraw: faster weapon swap after a dodge
	local orig_swap = PlayerStandard._get_swap_speed_multiplier
	function PlayerStandard:_get_swap_speed_multiplier(...)
		local m = orig_swap(self, ...)
		if type(m) == "number" and B.rogue_rush() then
			return m * C.rush_speed
		end
		return m
	end
elseif script == "lib/tweak_data/skilltreetweakdata" then
	local REMOVE = {
		[9] = { weapon_passive_armor_piercing_chance = true, player_crouch_dodge_chance_1 = true }
	}
	Hooks:PostHook(SkillTreeTweakData, "init", "GilzaDSBuffs_rogue_cards", function(self)
		local deck = self.specializations and self.specializations[C.deck]
		for card, names in pairs(REMOVE) do
			local ups = deck and deck[card] and deck[card].upgrades
			if ups then
				for i = #ups, 1, -1 do
					if names[ups[i]] then table.remove(ups, i) end
				end
			end
		end
	end)
end
