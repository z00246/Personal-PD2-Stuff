GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

B.EXPRES = {
	deck = 13,
	trail = 0.02,
	trail_ds = 0.03,
	trail_max = 5,
	trail_time = 10,
	service = 0.10,
	service_ds = 0.15,
	body_double = 0.25,
	body_double_time = 2,
	second_term_range = 1800
}
local C = B.EXPRES

function B.expres_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == C.deck) then
		return 0
	end
	return st:get_specialization_value(C.deck, "tiers", "current_tier") or 0
end

local function player_dmg()
	local unit = managers.player and managers.player:player_unit()
	return alive(unit) and unit:character_damage() or nil
end

function B.expres_stored()
	local dmg = player_dmg()
	if not (dmg and dmg._armor_stored_health and dmg.max_armor_stored_health) then return 0, 0 end
	return dmg._armor_stored_health, dmg:max_armor_stored_health()
end

function B.expres_trail_stacks()
	if Application:time() >= (B.expres_trail_until or 0) then return 0 end
	return B.expres_trail or 0
end

if script == "lib/managers/playermanager" then
	-- Secret Service: less damage while you have stored health
	local orig_resist = PlayerManager.damage_reduction_skill_multiplier
	function PlayerManager:damage_reduction_skill_multiplier(...)
		local m = orig_resist(self, ...)
		if type(m) ~= "number" then return m end
		local tier = B.expres_tier()
		if tier >= 5 and B.expres_stored() > 0 then
			m = m * (1 - (B.on and C.service_ds or C.service))
		end
		if tier >= 7 and Application:time() < (B.expres_bd_until or 0) then
			m = m * (1 - C.body_double)
		end
		return m
	end

	-- Campaign Trail: your kills while stored health is full stack damage
	Hooks:PostHook(PlayerManager, "on_killshot", "GilzaDSBuffs_expres_trail", function(self)
		if B.expres_tier() < 3 then return end
		local stored, max = B.expres_stored()
		if max <= 0 or stored < max - 0.001 then return end
		B.expres_trail = math.min(B.expres_trail_stacks() + 1, C.trail_max)
		B.expres_trail_until = Application:time() + C.trail_time
	end)

elseif script == "lib/units/beings/player/playerdamage" then
	-- Second Term: stored health that doesn't fit is shared with your crew as healing
	local function second_term(dmg, before, amount)
		if B.expres_tier() < 9 or type(amount) ~= "number" or not dmg.max_armor_stored_health then return end
		local max = dmg:max_armor_stored_health()
		if type(max) ~= "number" then return end
		local leftover = before + amount - max
		if leftover > 0 and B.team_heal then
			B.team_heal(math.min(leftover, amount), C.second_term_range, false)
		end
	end
	local orig_add = PlayerDamage.add_armor_stored_health
	function PlayerDamage:add_armor_stored_health(amount, ...)
		local before = self._armor_stored_health or 0
		local result = orig_add(self, amount, ...)
		second_term(self, before, amount)
		return result
	end

	-- Body Double: stored health soaking a hit gives brief damage reduction.
	-- Also handles partial soaks correctly (Gilza's version let the full hit through once stored health ran out).
	local orig_calc = PlayerDamage._calc_health_damage
	function PlayerDamage:_calc_health_damage(attack_data, ...)
		local tier = B.expres_tier()
		local soaked = false
		if tier >= 7 and attack_data and type(attack_data.damage) == "number" and attack_data.damage > 0
			and (self._armor_stored_health or 0) > 0 and not (self:get_real_armor() > 0)
			and managers.player:has_category_upgrade("player", "armor_health_store_shield") then
			soaked = true
			local stored = self._armor_stored_health
			if stored < attack_data.damage then
				attack_data.damage = attack_data.damage - stored
				self._armor_stored_health = 0
				self:update_armor_stored_health()
				if managers.player.Gilza_new_expres_armor_regen_bonus_timer_on_kill_reset then
					managers.player:Gilza_new_expres_armor_regen_bonus_timer_on_kill_reset()
				end
			end
		end
		local result = orig_calc(self, attack_data, ...)
		if soaked then
			B.expres_bd_until = Application:time() + C.body_double_time
		end
		return result
	end

elseif script == "lib/units/enemies/cop/copdamage" then
	local function trail(self, attack_data)
		if not attack_data or type(attack_data.damage) ~= "number" then return end
		local player = managers.player and managers.player:player_unit()
		if not (alive(player) and attack_data.attacker_unit == player) then return end
		local n = B.expres_trail_stacks()
		if n > 0 and B.expres_tier() >= 3 then
			attack_data.damage = attack_data.damage * (1 + n * (B.on and C.trail_ds or C.trail))
		end
	end
	for _, fn in ipairs({ "damage_bullet", "damage_melee" }) do
		Hooks:PreHook(CopDamage, fn, "GilzaDSBuffs_expres_" .. fn, function(self, attack_data)
			trail(self, attack_data)
		end)
	end

elseif script == "lib/tweak_data/skilltreetweakdata" then
	-- Secret Service replaces the static dodge
	Hooks:PostHook(SkillTreeTweakData, "init", "GilzaDSBuffs_expres_cards", function(self)
		local deck = self.specializations and self.specializations[C.deck]
		for _, card in pairs(deck or {}) do
			local ups = type(card) == "table" and card.upgrades
			if ups then
				for i = #ups, 1, -1 do
					if ups[i] == "player_static_dodge_chance" then table.remove(ups, i) end
				end
			end
		end
	end)
end
