if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics

local SUPPRESS_TIME = 10
local MIN_DIS, MAX_DIS = 300, 3500
local CHANCE = 0.6
local CHANCE_DS = 0.85
local BURST, PAUSE = 2.2, 1.6
local SPREAD_XY, REAIM = 70, 0.6

local SKIP_TAGS = { "medic", "spooc", "taser", "sniper", "shield" }

local function eligible(data, my_data)
	if my_data.pdth_sup == nil then
		local ok = not (data.is_converted or data.unit:in_slot(16))
		for _, tag in ipairs(SKIP_TAGS) do
			if ok and T.has_tag(data.unit, tag) then ok = false end
		end
		my_data.pdth_sup = ok and math.random() < (T.is_ds() and CHANCE_DS or CHANCE) or false
	end
	return my_data.pdth_sup
end

local function target_pos(data, my_data)
	local fe = data.attention_obj
	if not (fe and fe.criminal_record and T.camping and T.camping[fe.u_key]) then return end
	if fe.verified or fe.nearly_visible then return end
	if not fe.reaction or fe.reaction < AIAttentionObject.REACT_SHOOT then return end
	if not fe.verified_t or data.t - fe.verified_t > SUPPRESS_TIME then return end
	if my_data.spooc_attack or my_data.tasing then return end
	if my_data.advancing and not my_data.advancing:stopping() and my_data.advancing:haste() == "run" then return end
	local pos = fe.last_verified_pos or fe.verified_pos
	if not pos then return end
	local d = mvector3.distance(data.m_pos, pos)
	if d < MIN_DIS or d > MAX_DIS then return end
	return pos
end

local function suppress(data, my_data, pos)
	local t = data.t
	if not my_data.pdth_burst_t or t > my_data.pdth_burst_t + BURST + PAUSE then
		my_data.pdth_burst_t = t
	end
	local firing = t - my_data.pdth_burst_t < BURST

	if data.logic.chk_should_turn and data.logic.chk_should_turn(data, my_data) then
		CopLogicAttack._chk_request_action_turn_to_enemy(data, my_data, data.m_pos, pos)
	end

	if not my_data.pdth_aim_t or t > my_data.pdth_aim_t then
		local aim = mvector3.copy(pos)
		mvector3.set_static(aim, aim.x + math.rand(-SPREAD_XY, SPREAD_XY), aim.y + math.rand(-SPREAD_XY, SPREAD_XY), aim.z + math.rand(-10, 70))
		CopLogicBase._set_attention_on_pos(data, aim)
		my_data.attention_unit = aim
		my_data.pdth_aim_t = t + REAIM
	end

	if not my_data.shooting and not data.unit:anim_data().reload and not data.unit:movement():chk_action_forbidden("action") then
		if data.unit:brain():action_request({ body_part = 3, type = "shoot" }) then
			my_data.shooting = true
		end
	end

	CopLogicAttack.aim_allow_fire(firing, true, data, my_data)
end

local orig = CopLogicAttack._upd_aim
CopLogicAttack._upd_aim = function(data, my_data, ...)
	if T.active() and my_data and data.unit and eligible(data, my_data) then
		local pos = target_pos(data, my_data)
		if pos then
			suppress(data, my_data, pos)   -- (1.91: no pcall) blind fire at where you were
			return
		end
	end
	return orig(data, my_data, ...)
end
