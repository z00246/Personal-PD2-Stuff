GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

-- difficulty scaling (shared with buffs.lua): t = 0 up to Overkill, 1/3 Mayhem, 2/3 Death Wish, 1 Death Sentence
if not B.diff_t then
	B.DIFF_T = { easy_wish = 1 / 3, overkill_290 = 2 / 3, sm_wish = 1 }
	function B.diff_t()
		local gs = Global and Global.game_settings
		return gs and B.DIFF_T[gs.difficulty] or 0
	end
	function B.sc(base, ds) return base + (ds - base) * B.diff_t() end
	function B.sci(base, ds) return math.floor(base + (ds - base) * B.diff_t() + 0.5) end
end

-- a line in the BLT log the first times a feature does something (buffs.lua)
local function live(key, ...) if B.live then B.live("hitman " .. key, ...) end end

-- Hitman (7.18 rework v2, Geo 2026-10-25: "is there a way to make the contract a bit more buffed then?" - "I meant he
-- should get buffed himself, the enemy" - "also make sure his contour is the same as whatever the player color is";
-- the money effect: "what about the money one"; approved with "yeah this is all fine"). Replaces Gilza's Hitman cards
-- (Master of Arms, the akimbo card, Rhythm of Death, Bounty Hunter) and the 6.x armor-overflow card.
--  card 1 Contract: the nearest enemy you can see within 30 m becomes your Contract, outlined in your player colour for
--   you only (specials first, never Bulldozers or Captain Winters). A new one after 20 s, or when someone else kills him.
--   He takes 20% » 30% less damage from you and deals 20% » 30% more to you. Killing him (any weapon) restores
--   25% » 35% of your armor and marks the next one at once. +5% armor (Gilza's player_tier_armor_multiplier_1).
--   Bills drift off his chest while he is your Contract and burst out when you kill him (our own effects, local).
--  card 3 Clean Kill: headshot kills restore 10% armor, at most every 0.5 s; your headshots ignore the toughness.
--  card 5 Hit List: each Contract kill = 1 Streak (max 5): +5% damage and 5% faster armor recovery per Streak; all
--   lost after 15 » 20 s without a Contract kill.
--  card 7 Untouchable: a Contract kill makes you unable to take damage for 1.5 » 2 s, at most every 15 s.
--  card 9 Tooth and Claw: armor recovers 1.5 s after breaking (the game's), a Contract kill while your armor is broken
--   brings it back at once; completion bonus.
-- *_ds values are the Death Sentence end of the difficulty scale (B.sc).
B.HITMAN = {
	deck = 5,
	range = 3000,              -- the Contract is picked within 30 m...
	cone = 0.35,               -- ...in front of you (cosine of the angle off your view, ~70 degrees)
	checks = 12,               -- line-of-sight checks per look, nearest first
	scan_every = 0.25,
	expire = 20,               -- a new Contract after 20 s
	skip = 10,                 -- an expired Contract isn't picked again for 10 s
	tough = 0.20, tough_ds = 0.30,     -- he takes this much less damage from you
	hits = 0.20, hits_ds = 0.30,       -- he deals this much more damage to you
	refill = 0.25, refill_ds = 0.35,   -- share of max armor a Contract kill restores
	clean = 0.10, clean_every = 0.5,   -- card 3 Clean Kill
	streak_max = 5, streak_dmg = 0.05, streak_regen = 0.05,
	streak_time = 15, streak_time_ds = 20,
	untouch = 1.5, untouch_ds = 2, untouch_every = 15,
	puff_every = 0.45          -- a puff of 4 bills off his chest this often (~9 bills a second)
}
local C = B.HITMAN
B.hm_skip = B.hm_skip or {}
B.hm_streak = B.hm_streak or 0

function B.hitman_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == C.deck) then
		return 0
	end
	return st:get_specialization_value(C.deck, "tiers", "current_tier") or 0
end

-- the Contract unit while there is one
function B.hitman_contract()
	local c = B.hm_contract
	return c and alive(c.unit) and c.unit or nil
end

local function is_head(cop_damage, attack_data)
	local body = attack_data and attack_data.col_ray and attack_data.col_ray.body
	return (cop_damage._head_body_name and body and body:name() == cop_damage._ids_head_body_name) and true or false
end

if script == "lib/managers/playermanager" then
	------------------------------------------------------------------ the outline: your player colour, you only
	local function contract_type()
		local types = ContourExt and ContourExt._types
		if not types then return nil end
		if not types.gdsb_contract then
			-- priority 2: shown over marks (4-5), under a Medic's heal flash (1); swaps to the contour material like
			-- the game's own enemy marks; unique: adding it twice doesn't stack
			types.gdsb_contract = { priority = 2, material_swap_required = true, unique = true,
				color = Vector3(1, 1, 1) }
		end
		return "gdsb_contract"
	end

	local function my_color()
		local session = managers.network and managers.network:session()
		local peer = session and session:local_peer()
		local id = peer and peer:id() or 1
		local v = tweak_data.peer_vector_colors and tweak_data.peer_vector_colors[id]
		if v then return v end
		local c = tweak_data.chat_colors and tweak_data.chat_colors[id]
		if c then return Vector3(c.red or c.r or 1, c.green or c.g or 1, c.blue or c.b or 1) end
		return Vector3(1, 1, 1)
	end

	------------------------------------------------------------------ the money (our own effects, local)
	local IDS_EFFECT, IDS_TEXTURE = Idstring("effect"), Idstring("texture")
	local FX_PUFF = Idstring("effects/gilza/contract_money")
	local FX_PAYOUT = Idstring("effects/gilza/contract_payout")
	local BILL = Idstring("effects/textures/dollar_bill_effect_edf")
	local IDS_SPINE = Idstring("Spine2")

	-- a file the game has, or one BeardLib added from add.xml (our two effects)
	local function in_db(ext, path)
		if DB:has(ext, path) then return true end
		local fm = rawget(_G, "BeardLib") and BeardLib.Managers and BeardLib.Managers.File
		return fm and fm.Has and fm:Has(ext, path) and true or false
	end

	-- loads the bill texture and both effects once (synchronously: a nil callback), only what the database has; if
	-- anything is missing the money just doesn't show (a live line says why)
	local function fx_ready()
		if B._hm_fx ~= nil then return B._hm_fx end
		B._hm_fx = false
		local ok, err = pcall(function()
			local dr = managers.dyn_resource
			local pkg = dr.DYN_RESOURCES_PACKAGE
			for _, r in ipairs({ { IDS_TEXTURE, BILL }, { IDS_EFFECT, FX_PUFF }, { IDS_EFFECT, FX_PAYOUT } }) do
				if not PackageManager:has(r[1], r[2]) then
					if not in_db(r[1], r[2]) then error("not in the database: " .. tostring(r[2])) end
					dr:load(r[1], r[2], pkg, nil)
					-- never spawn an effect the game doesn't have loaded
					if not PackageManager:has(r[1], r[2]) then error("didn't load: " .. tostring(r[2])) end
				end
			end
		end)
		B._hm_fx = ok
		if ok then live("money", "the money effects are loaded") else live("money failed", "no money effects: %s", tostring(err)) end
		return ok
	end

	local function chest(unit)
		local obj = unit:get_object(IDS_SPINE)
		if obj then return obj:position() end
		local mov = unit:movement()
		return mov and mov.m_com and mov:m_com() or unit:position()
	end

	local function spawn(fx, unit)
		if not fx_ready() then return end
		local em = World:effect_manager()
		local ok, err = pcall(em.spawn, em, { effect = fx, position = chest(unit), normal = math.UP })
		if not ok then live("money spawn failed", "%s", tostring(err)) end
		return ok
	end

	------------------------------------------------------------------ card 1: picking the Contract
	local function usable(u, now)
		if not alive(u) then return false end
		local dmg = u:character_damage()
		if not dmg or dmg._dead or (dmg.dead and dmg:dead()) then return false end
		local brain = u:brain()
		if brain and ((brain.is_hostage and brain:is_hostage()) or (brain.converted and brain:converted())) then return false end
		return true
	end

	local function excluded(u)
		local base = u:base()
		local tt = base and base._tweak_table or ""
		if tt == "phalanx_vip" or tt:sub(1, 4) == "tank" then return true end
		return base and base.has_tag and (base:has_tag("tank") or base:has_tag("captain")) or false
	end

	local function is_special(u)
		local base = u:base()
		if base and base.has_tag and base:has_tag("special") then return true end
		local ct = base and tweak_data.character and tweak_data.character[base._tweak_table]
		return ct and ct.priority_shout ~= nil or false
	end

	local tmp = Vector3()
	local function pick(now, player)
		local cam = player:camera()
		local from = cam and cam:position() or player:movement():m_head_pos()
		local fwd = cam and cam:forward()
		local mask = managers.slot:get_mask("enemies")
		local list = {}
		for _, data in pairs(managers.enemy:all_enemies() or {}) do
			local u = data.unit
			if usable(u, now) and u:in_slot(mask) and not excluded(u) and (B.hm_skip[u:key()] or 0) <= now then
				local mov = u:movement()
				local head = mov and mov:m_head_pos() or u:position()
				local d = mvector3.distance(from, head)
				if d <= C.range then
					local ahead = true
					if fwd and d > 1 then
						mvector3.set(tmp, head)
						mvector3.subtract(tmp, from)
						mvector3.normalize(tmp)
						ahead = mvector3.dot(tmp, fwd) >= C.cone
					end
					if ahead then list[#list + 1] = { u = u, d = d, special = is_special(u) } end
				end
			end
		end
		if #list == 0 then return nil end
		table.sort(list, function(a, b)
			if a.special ~= b.special then return a.special end
			return a.d < b.d
		end)
		local vis = managers.slot:get_mask("AI_visibility")
		for i = 1, math.min(#list, C.checks) do
			local u = list[i].u
			local mov = u:movement()
			local head = mov:m_head_pos()
			local seen = not World:raycast("ray", from, head, "slot_mask", vis, "ray_type", "ai_vision", "report")
			if not seen and mov.m_com then
				seen = not World:raycast("ray", from, mov:m_com(), "slot_mask", vis, "ray_type", "ai_vision", "report")
			end
			if seen then return u, list[i].d, list[i].special end
		end
		return nil
	end

	local function clear_contract()
		local c = B.hm_contract
		B.hm_contract = nil
		if c and alive(c.unit) then
			local ce = c.unit:contour()
			if ce then pcall(ce.remove, ce, "gdsb_contract", false) end
		end
	end
	B.hitman_clear_contract = clear_contract

	local function set_contract(u, now, d, special)
		clear_contract()
		B.hm_contract = { unit = u, key = u:key(), until_t = now + C.expire, puff_t = now }
		local ce = u:contour()
		local ty = contract_type()
		local ok, err = false, "no contour extension"
		if ce and ty then
			local okc, color = pcall(my_color)
			ok, err = pcall(ce.add, ce, ty, false, nil, okc and color or nil)
		end
		local base = u:base()
		live("contract", "marked a %s%s %.1f m away", special and "special " or "", tostring(base and base._tweak_table), (d or 0) / 100)
		if not ok then live("outline failed", "couldn't outline the Contract: %s", tostring(err)) end
	end

	local function reset()
		clear_contract()
		B.hm_skip = {}
		B.hm_streak, B.hm_streak_until = 0, nil
		B.hm_untouch_until, B.hm_untouch_ready = nil, nil
		B._hm_clean_next, B._hm_scan_t = nil, nil
		B._hm_fx = nil
	end

	local function update()
		local session = managers.network and managers.network:session()
		if B._hm_session ~= session then
			B._hm_session = session
			reset()
		end
		local now = Application:time()
		local tier = B.hitman_tier()
		local player = managers.player:player_unit()
		if tier < 1 or not alive(player) then
			if B.hm_contract then clear_contract() end
			return
		end
		-- card 5: the Streaks run out
		if (B.hm_streak or 0) > 0 and now >= (B.hm_streak_until or 0) then
			live("streak lost", "%d Streaks ran out", B.hm_streak)
			B.hm_streak, B.hm_streak_until = 0, nil
		end
		local c = B.hm_contract
		if c then
			local u = c.unit
			if not usable(u, now) then
				-- dead without our kill (someone else), cuffed, converted or gone: the next one at once
				if alive(u) and u:character_damage() and (u:character_damage()._dead or u:character_damage():dead()) then
					live("lost", "someone else killed your Contract")
				end
				clear_contract()
				B._hm_scan_t = nil
				c = nil
			elseif now >= c.until_t then
				B.hm_skip[c.key] = now + C.skip
				live("expired", "the Contract lived %d seconds, picking another", C.expire)
				clear_contract()
				B._hm_scan_t = nil
				c = nil
			end
		end
		if c then
			if now >= c.puff_t then
				c.puff_t = now + C.puff_every
				if spawn(FX_PUFF, c.unit) then live("money puff", "bills off the Contract's chest") end
			end
			return
		end
		if now < (B._hm_scan_t or 0) then return end
		B._hm_scan_t = now + C.scan_every
		local u, d, special = pick(now, player)
		if u then set_contract(u, now, d, special) end
	end

	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_hitman_update", function()
		local ok, err = pcall(update)
		if not ok and not B._hm_err then
			B._hm_err = true
			log("[Gilza DS Perk Buffs] Hitman update error: " .. tostring(err))
		end
	end)

	------------------------------------------------------------------ kills: Contract, Clean Kill, Hit List, Untouchable, Tooth and Claw
	local function on_kill(pm, killed, variant, headshot)
		local tier = B.hitman_tier()
		if tier < 1 or not alive(killed) then return end
		local base = killed:base()
		if base and CopDamage.is_civilian and CopDamage.is_civilian(base._tweak_table) then return end
		local player = pm:player_unit()
		local dmg = alive(player) and player:character_damage()
		if not dmg or dmg._dead or (dmg.dead and dmg:dead()) then return end
		local now = Application:time()
		-- card 3 Clean Kill: a headshot kill with any weapon (melee headshots too)
		if tier >= 3 and (headshot or (variant == "melee" and B._hm_melee_head == killed)) and now >= (B._hm_clean_next or 0) then
			B._hm_clean_next = now + C.clean_every
			dmg:restore_armor(dmg:_max_armor() * C.clean)
			live("clean kill", "a %s headshot kill restored %d%% armor", tostring(variant), math.floor(C.clean * 100 + 0.5))
		end
		local c = B.hm_contract
		if not (c and c.unit == killed) then return end
		-- the Contract: the payout, then the next one at once
		if spawn(FX_PAYOUT, killed) then live("payout", "bills burst out of the Contract") end
		clear_contract()
		B._hm_scan_t = nil
		local broken = dmg:get_real_armor() <= 0
		if tier >= 9 and broken and not (dmg._bleed_out or dmg._check_berserker_done) then
			-- card 9 Tooth and Claw: broken armor comes back at once
			dmg:regenerate_armor()
			live("tooth and claw", "a Contract kill brought the broken armor back")
		else
			local share = B.sc(C.refill, C.refill_ds)
			dmg:restore_armor(dmg:_max_armor() * share)
			live("contract kill", "a %s kill restored %.1f%% armor", tostring(variant), share * 100)
		end
		-- card 5 Hit List
		if tier >= 5 then
			B.hm_streak = math.min((B.hm_streak or 0) + 1, C.streak_max)
			B.hm_streak_until = now + B.sc(C.streak_time, C.streak_time_ds)
			live("streak", "%d Streaks (+%d%% damage)", B.hm_streak, math.floor(B.hm_streak * C.streak_dmg * 100 + 0.5))
		end
		-- card 7 Untouchable
		if tier >= 7 and now >= (B.hm_untouch_ready or 0) then
			local dur = B.sc(C.untouch, C.untouch_ds)
			dmg._can_take_dmg_timer = math.max(dmg._can_take_dmg_timer or 0, dur)
			B.hm_untouch_until = now + dur
			B.hm_untouch_ready = now + C.untouch_every
			live("untouchable", "no damage for %.2f seconds", dur)
		end
	end

	Hooks:PostHook(PlayerManager, "on_killshot", "GilzaDSBuffs_hitman_kill", function(self, killed_unit, variant, headshot)
		local ok, err = pcall(on_kill, self, killed_unit, variant, headshot)
		if not ok and not B._hm_kill_err then
			B._hm_kill_err = true
			log("[Gilza DS Perk Buffs] Hitman kill error: " .. tostring(err))
		end
	end)

	------------------------------------------------------------------ card 5: faster armor recovery per Streak
	local orig_regen = PlayerManager.body_armor_regen_multiplier
	if orig_regen then
		function PlayerManager:body_armor_regen_multiplier(...)
			local m = orig_regen(self, ...)
			local n = B.hm_streak or 0
			if n > 0 and type(m) == "number" then
				local ok, tier = pcall(B.hitman_tier)
				if ok and tier >= 5 then
					m = m * (1 - C.streak_regen * n)
					live("streak recovery", "armor recovery timer x%.2f with %d Streaks", 1 - C.streak_regen * n, n)
				end
			end
			return m
		end
	end

	------------------------------------------------------------------ Copycat: unchanged
	-- Gilza's Hitman card 3 is gone from the deck now, but Copycat's Hitman mimic still carries its akimbo armor
	-- recovery upgrade; 6.x-7.17 kept it switched off, and so does this, so Copycat plays as before.
	local orig_temp_value = PlayerManager.temporary_upgrade_value
	function PlayerManager:temporary_upgrade_value(category, upgrade, default, ...)
		if upgrade == "akimbo_pistol_armor_regen_timer_multiplier" then
			return default
		end
		return orig_temp_value(self, category, upgrade, default, ...)
	end

	local orig_activate = PlayerManager.activate_temporary_upgrade
	function PlayerManager:activate_temporary_upgrade(category, upgrade, ...)
		if upgrade == "akimbo_pistol_armor_regen_timer_multiplier" then
			return
		end
		return orig_activate(self, category, upgrade, ...)
	end

elseif script == "lib/units/enemies/cop/copdamage" then
	-- card 1: your Contract takes less damage from you (card 3: not your headshots); card 5: +5% damage per Streak
	local function my_hit(self, attack_data, fn)
		if not attack_data or type(attack_data.damage) ~= "number" then return end
		local player = managers.player and managers.player:player_unit()
		if not (alive(player) and attack_data.attacker_unit == player) then return end
		local tier = B.hitman_tier()
		if tier < 1 then return end
		local melee = fn == "damage_melee"
		local mul = 1
		local c = B.hm_contract
		if c and c.unit == self._unit then
			local head = (fn == "damage_bullet" or melee) and is_head(self, attack_data)
			if melee and head then B._hm_melee_head = self._unit end
			if head and tier >= 3 then
				live("headshot through", "a %s headshot went through the Contract's toughness", fn)
			else
				local tough = B.sc(C.tough, C.tough_ds)
				mul = mul * (1 - tough)
				live("tough", "the Contract took %.1f%% less from a %s hit", tough * 100, fn)
			end
		elseif melee and is_head(self, attack_data) then
			B._hm_melee_head = self._unit
		end
		local n = B.hm_streak or 0
		if tier >= 5 and n > 0 then
			mul = mul * (1 + C.streak_dmg * n)
			live("streak damage", "+%d%% damage with %d Streaks", math.floor(C.streak_dmg * n * 100 + 0.5), n)
		end
		if mul ~= 1 then attack_data.damage = attack_data.damage * mul end
	end

	for _, fn in ipairs({ "damage_bullet", "damage_melee", "damage_fire", "damage_dot", "damage_explosion" }) do
		if CopDamage[fn] then
			Hooks:PreHook(CopDamage, fn, "GilzaDSBuffs_hitman_" .. fn, function(self, attack_data)
				if fn == "damage_melee" then B._hm_melee_head = nil end
				local ok, err = pcall(my_hit, self, attack_data, fn)
				if not ok and not B._hm_hit_err then
					B._hm_hit_err = true
					log("[Gilza DS Perk Buffs] Hitman hit error: " .. tostring(err))
				end
			end)
		end
	end
	-- the melee headshot flag only lives through the hit (the kill callback runs inside it)
	Hooks:PostHook(CopDamage, "damage_melee", "GilzaDSBuffs_hitman_damage_melee_post", function()
		B._hm_melee_head = nil
	end)

elseif script == "lib/units/beings/player/playerdamage" then
	-- card 1: your Contract hits you harder (melee goes through damage_bullet)
	for _, fn in ipairs({ "damage_bullet", "damage_explosion", "damage_fire" }) do
		if PlayerDamage[fn] then
			Hooks:PreHook(PlayerDamage, fn, "GilzaDSBuffs_hitman_hurt_" .. fn, function(self, attack_data)
				local c = B.hm_contract
				if not (c and attack_data and type(attack_data.damage) == "number") then return end
				if attack_data.attacker_unit ~= c.unit or not alive(c.unit) then return end
				local ok, tier = pcall(B.hitman_tier)
				if not ok or tier < 1 then return end
				local more = B.sc(C.hits, C.hits_ds)
				attack_data.damage = attack_data.damage * (1 + more)
				live("contract hits harder", "%.1f%% more damage from your Contract (%s)", more * 100, fn)
			end)
		end
	end

elseif script == "lib/tweak_data/skilltreetweakdata" then
	-- the reworked cards replace Gilza's: card 1 keeps the 5% armor, card 9 keeps the 1.5 s armor recovery after a
	-- break and the completion bonus; cards 3, 5 and 7 are ours alone
	local REMOVE = {
		[1] = { temporary_badass_hitman_kill_armor_regen = true },
		[3] = { akimbo_recoil_index_addend_4 = true, akimbo_extra_ammo_multiplier_2 = true,
			temporary_akimbo_pistol_armor_regen_timer_multiplier = true },
		[5] = { temporary_death_dance_combo_invulnerability = true },
		[7] = { temporary_player_bounty_hunter = true }
	}
	Hooks:PostHook(SkillTreeTweakData, "init", "GilzaDSBuffs_hitman_cards", function(self)
		local deck = self.specializations and self.specializations[C.deck]
		for card, names in pairs(REMOVE) do
			local ups = deck and deck[card] and deck[card].upgrades
			if ups then
				for i = #ups, 1, -1 do
					if names[ups[i]] then table.remove(ups, i) end
				end
			end
		end
	end)
end
