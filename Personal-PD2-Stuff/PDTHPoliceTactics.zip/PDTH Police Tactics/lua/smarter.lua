if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics
local script = RequiredScript and RequiredScript:lower() or ""

-- "Smarter, not tankier": close-range melee, squad morale, holding angles, pressuring revives,
-- Cloaker jump kicks that cuff, and enraged Death Sentence Bulldozers.

local function now() return TimerManager:game():time() end

if script == "lib/tweak_data/charactertweakdata" then
	-- Close-range melee: cops right next to you bash you sooner and more often (also for modded clients)
	Hooks:PostHook(CharacterTweakData, "init", "PDTHTactics_melee", function(self)
		local done = {}
		for name, char in pairs(self) do
			if type(char) == "table" and type(char.weapon) == "table" and name ~= "presets" then
				for _, usage in pairs(char.weapon) do
					if type(usage) == "table" and usage.FALLOFF and usage.melee_speed and usage.melee_dmg and not done[usage] then
						done[usage] = true
						T.set_client(usage, "melee_speed", usage.melee_speed * 1.25)
						T.set_client(usage, "melee_retry_delay", { 0.8, 1.5 })
					end
				end
			end
		end
	end)

elseif script == "lib/units/enemies/cop/copdamage" then
	-- Squad morale: a squad that loses half its members within a few seconds ducks for cover
	local WINDOW, COOLDOWN = 8, 20
	Hooks:PostHook(CopDamage, "die", "PDTHTactics_morale", function(self)
		if not T.active() then return end
		pcall(function()
			local state = managers.groupai:state()
			local u_data = state._police and state._police[self._unit:key()]
			local group = u_data and u_data.group
			if not (group and group.units) then return end
			local t = now()
			group.pdth_deaths = group.pdth_deaths or {}
			table.insert(group.pdth_deaths, t)
			for i = #group.pdth_deaths, 1, -1 do
				if t - group.pdth_deaths[i] > WINDOW then table.remove(group.pdth_deaths, i) end
			end
			local alive_n = 0
			for _, m in pairs(group.units) do
				if alive(m.unit) and m.unit ~= self._unit and not m.unit:character_damage():dead() then alive_n = alive_n + 1 end
			end
			local total = alive_n + #group.pdth_deaths
			if total < 3 or #group.pdth_deaths < math.ceil(total * 0.5) or alive_n == 0 then return end
			if t < (group.pdth_morale_t or 0) then return end
			group.pdth_morale_t = t + COOLDOWN
			for _, m in pairs(group.units) do
				local dmg = alive(m.unit) and m.unit ~= self._unit and m.unit:character_damage()
				if dmg and not dmg:dead() and dmg.build_suppression then
					dmg:build_suppression("max", 0)
				end
			end
		end)
	end)

elseif script == "lib/units/enemies/cop/logics/coplogicattack" then
	-- Hold angles: about a third of regular cops stop pushing when they lose sight of you and
	-- keep aiming where you were for a few seconds
	local orig_move = CopLogicAttack._upd_combat_movement
	local function holding(data)
		if data.pdth_holder == nil then
			local tags = data.char_tweak and data.char_tweak.tags
			data.pdth_holder = not (T.has(tags, "special") or T.has(tags, "tank") or T.has(tags, "shield"))
				and math.random() < 0.33 or false
		end
		if not data.pdth_holder then return false end
		local fe = data.attention_obj
		return fe and fe.is_person and not fe.verified and fe.verified_t and data.t - fe.verified_t < 8
			and fe.dis and fe.dis < 1500 or false
	end
	CopLogicAttack._upd_combat_movement = function(data, ...)
		if T.active() then
			local ok, hold = pcall(holding, data)
			if ok and hold then return end
		end
		return orig_move(data, ...)
	end

	-- Wounded cops fall back: some regular cops below 35% health stop pushing and fight from cover
	local HURT_RATIO, HURT_CHANCE = 0.35, 0.5
	local orig_cover = CopLogicAttack._chk_wants_to_take_cover
	if orig_cover then
		local function hurt_retreat(data)
			if data.pdth_retreater == nil then
				local tags = data.char_tweak and data.char_tweak.tags
				data.pdth_retreater = not (T.has(tags, "special") or T.has(tags, "tank") or T.has(tags, "shield"))
					and math.random() < HURT_CHANCE or false
			end
			if not data.pdth_retreater then return false end
			local fe = data.attention_obj
			if not (fe and fe.reaction and fe.reaction >= AIAttentionObject.REACT_COMBAT) then return false end
			local dmg = data.unit:character_damage()
			return dmg and dmg.health_ratio and dmg:health_ratio() < HURT_RATIO or false
		end
		CopLogicAttack._chk_wants_to_take_cover = function(data, my_data, ...)
			local res = orig_cover(data, my_data, ...)
			if res or not T.active() then return res end
			local ok, hurt = pcall(hurt_retreat, data)
			if ok and hurt then return true end
			return res
		end
	end

elseif script == "lib/units/enemies/cop/logics/coplogicidle" then
	-- Pressure revives: enemies prefer shooting a player who is reviving someone, and may flashbang them
	T.revivers = T.revivers or {}
	local REVIVE_DIS, FLASH_CHANCE, FLASH_CD = 180, 0.5, 25

	local function downed_players()
		local list = {}
		for _, u_data in pairs(managers.groupai:state():all_player_criminals() or {}) do
			local rec = managers.groupai:state():criminal_record(u_data.unit:key())
			if rec and (rec.status == "dead" or rec.status == "disabled") then
				table.insert(list, u_data.unit:position())
			end
		end
		return list
	end

	local function scan()
		local t = now()
		for key, until_t in pairs(T.revivers) do
			if t > until_t then T.revivers[key] = nil end
		end
		local downed = downed_players()
		if #downed == 0 then return end
		for _, u_data in pairs(managers.groupai:state():all_player_criminals() or {}) do
			local unit = u_data.unit
			local rec = managers.groupai:state():criminal_record(unit:key())
			if alive(unit) and not (rec and rec.status) then
				local pos = unit:position()
				for _, dpos in ipairs(downed) do
					if mvector3.distance(pos, dpos) < REVIVE_DIS then
						local key = unit:key()
						T.revivers[key] = t + 1
						T._flash_t = T._flash_t or {}
						if t > (T._flash_t[key] or 0) then
							T._flash_t[key] = t + FLASH_CD
							if math.random() < FLASH_CHANCE then
								for _, e in pairs(managers.enemy:all_enemies() or {}) do
									if alive(e.unit) and mvector3.distance(e.unit:position(), pos) < 2000 then
										managers.groupai:state():detonate_smoke_grenade(pos + math.UP * 10, e.unit:position(), 2, true)
										break
									end
								end
							end
						end
						break
					end
				end
			end
		end
	end

	-- Punish huddling: players bunched up within 4m of each other get a flashbang thrown at them
	-- by a cop who can see them (once every 30s, 20s on Death Sentence)
	local HUDDLE_DIS, HUDDLE_CD, HUDDLE_CD_DS = 400, 30, 20
	local function huddle_scan()
		local state = managers.groupai:state()
		if not state:enemy_weapons_hot() or state:whisper_mode() then return end
		local t = now()
		if t < (T._huddle_t or 0) then return end
		local players = {}
		for _, u_data in pairs(state:all_player_criminals() or {}) do
			local rec = state:criminal_record(u_data.unit:key())
			if alive(u_data.unit) and not (rec and rec.status) then table.insert(players, u_data.unit) end
		end
		if #players < 2 then return end
		for i = 1, #players do
			local pos = players[i]:position()
			local near = 0
			for j = 1, #players do
				if i ~= j and mvector3.distance(pos, players[j]:position()) < HUDDLE_DIS then near = near + 1 end
			end
			if near >= 1 then
				local key = players[i]:key()
				for _, e in pairs(managers.enemy:all_enemies() or {}) do
					local u = e.unit
					local ld = alive(u) and u:brain() and u:brain()._logic_data
					local att = ld and ld.attention_obj
					if att and att.u_key == key and att.verified and att.dis and att.dis > 500 and att.dis < 2500 then
						T._huddle_t = t + (T.is_ds() and HUDDLE_CD_DS or HUDDLE_CD)
						state:detonate_smoke_grenade(pos + math.UP * 10, u:movement():m_head_pos(), 2, true)
						return
					end
				end
			end
		end
	end

	Hooks:Add("GameSetupUpdate", "PDTHTactics_huddle_scan", function()
		if not (T.active() and Network and Network:is_server()) then return end
		local t = Application:time()
		if t < (T._huddle_scan_t or 0) then return end
		T._huddle_scan_t = t + 1
		pcall(huddle_scan)
	end)

	Hooks:Add("GameSetupUpdate", "PDTHTactics_revive_scan", function()
		if not T.active() then return end
		local t = Application:time()
		if t < (T._revive_scan_t or 0) then return end
		T._revive_scan_t = t + 0.5
		pcall(scan)
	end)

	local orig_prio = CopLogicIdle._get_priority_attention
	CopLogicIdle._get_priority_attention = function(data, objects, reaction_func, ...)
		if T.active() and next(T.revivers) and objects and data and data.key then
			for k, att in pairs(objects) do
				if T.revivers[k] and att.verified and att.identified and math.random() < 0.5 then
					local best, slot, reaction = orig_prio(data, { [k] = att }, reaction_func, ...)
					if best then return best, slot, reaction end
				end
			end
		end
		return orig_prio(data, objects, reaction_func, ...)
	end

elseif script == "lib/units/beings/player/playermovement" then
	-- Cloaker jump kicks cuff you instead of downing you (needs the mod on the kicked player's side)
	local orig_spooc = PlayerMovement.on_SPOOCed
	local function flying(enemy_unit, arg)
		if arg == "flying_strike" then return true end
		local mov = alive(enemy_unit) and enemy_unit:movement()
		for _, act in pairs(mov and mov._active_actions or {}) do
			if type(act) == "table" and act._is_flying_strike then return true end
		end
		return false
	end

	function PlayerMovement:on_SPOOCed(enemy_unit, ...)
		if (T.active() or T.client_on()) and alive(enemy_unit) then
			local ok, is_fly = pcall(flying, enemy_unit, ...)
			if ok and is_fly then
				local countered = managers.player:has_category_upgrade("player", "counter_strike_spooc")
					and self._current_state.in_melee and self._current_state:in_melee()
				local dmg = self._unit:character_damage()
				if not countered and not (dmg._god_mode or dmg:get_mission_blocker("invulnerable")) then
					local name = self._current_state_name
					if name == "standard" or name == "carry" or name == "bipod" then
						managers.player:set_player_state("arrested")
						return true
					end
				end
			end
		end
		return orig_spooc(self, enemy_unit, ...)
	end

elseif script == "lib/units/enemies/cop/actions/upper_body/copactionshoot" then
	-- Shield bashes (Restoration Mod): a Shield you get right up to bashes you with the shield, using
	-- Restoration's shield melee animation (added by supermod.xml / anim_tweaks.xml). The base game never
	-- lets a cop holding a shield melee and gives Shields no melee stats, so both are added here.
	local SHIELD_RETRY = { 2, 2 }
	local function shield_usage(self)
		local u = self._w_usage_tweak
		if not u or u.melee_speed or u._pdth_shield then return end
		local swat = tweak_data.character.swat and tweak_data.character.swat.weapon
		local ref = swat and swat.is_rifle
		self._w_usage_tweak = setmetatable({
			_pdth_shield = true,
			melee_speed = 1,
			melee_dmg = ref and ref.melee_dmg or 5,
			melee_retry_delay = SHIELD_RETRY
		}, { __index = u })
	end

	local orig_update = CopActionShoot.update
	function CopActionShoot:update(t, ...)
		if self._shield_unit and T.active() then
			pcall(shield_usage, self)
			-- the shield check only guards the melee decision in here
			local shield = self._shield_unit
			self._shield_unit = nil
			local ok, a, b = pcall(orig_update, self, t, ...)
			self._shield_unit = shield
			if not ok then error(a, 0) end
			return a, b
		end
		return orig_update(self, t, ...)
	end

	-- modded clients play the host's shield bash too
	local orig_sync = CopActionShoot.sync_start_melee
	function CopActionShoot:sync_start_melee(...)
		if self._shield_unit and T.client_on() then
			local shield = self._shield_unit
			self._shield_unit = nil
			pcall(shield_usage, self)
			local ok, err = pcall(orig_sync, self, ...)
			self._shield_unit = shield
			if not ok then error(err, 0) end
			return
		end
		return orig_sync(self, ...)
	end

elseif script == "lib/units/enemies/tank/tankcopdamage" then
	-- Enraged Bulldozers (Death Sentence): breaking the visor makes them hit 10% harder
	if TankCopDamage.seq_clbk_vizor_shatter then
		Hooks:PostHook(TankCopDamage, "seq_clbk_vizor_shatter", "PDTHTactics_dozer_rage", function(self)
			if T.is_ds() and not self._dead then
				self._pdth_enraged = true
			end
		end)
	end

elseif script == "lib/units/beings/player/playerdamage" then
	-- Shield bashes, Restoration Mod's knockback exactly:
	--  * push strength = Shield's 2x push, scaled by your armor's hit-shake, clamped to 1x-1.5x
	--  * your own momentum is cut to 20% first (the base game ADDS the push to your running speed,
	--    which is what flung you), weaker push while airborne and only one push per jump
	--  * you're forced into a crouch
	local SHIELD_PUSH_MUL = 2
	local orig_melee = PlayerDamage.damage_melee
	function PlayerDamage:damage_melee(attack_data, ...)
		local shield_push
		if (T.active() or T.client_on()) and attack_data and attack_data.push_vel then
			local ok, is_shield = pcall(function()
				local a = attack_data.attacker_unit
				return alive(a) and a:base() and a:base().has_tag and a:base():has_tag("shield")
			end)
			if ok and is_shield then
				shield_push = attack_data.push_vel
				attack_data.push_vel = Vector3() -- the base game's push is replaced below
			end
		end
		local result = orig_melee(self, attack_data, ...)
		if shield_push and result ~= "countered" and not self:is_downed() then
			pcall(function()
				local mov = self._unit:movement()
				local st = mov and mov:current_state()
				local name = mov and mov:current_state_name()
				if not (st and (name == "standard" or name == "carry") and self._unit:mover()) then return end
				local pm = managers.player
				local shake = pm:body_armor_value("damage_shake") * pm:upgrade_value("player", "damage_shake_multiplier", 1)
				local base = tweak_data.gui.armor_damage_shake_base
				local gui_shake = base / shake + pm:upgrade_value("player", "damage_shake_addend", 0)
				shake = base / gui_shake
				local mul = math.clamp(SHIELD_PUSH_MUL * shake, 1, 1.5)
				local in_air = st.in_air and st:in_air()
				if not in_air then st._pdth_hit_in_air = nil end
				if in_air and st._pdth_hit_in_air then return end
				if in_air then
					mul = mul * 0.6
					st._pdth_hit_in_air = true
				end
				local vel = shield_push * mul
				st._last_velocity_xy = (st._last_velocity_xy or Vector3()) * 0.2 + vel
				self._unit:mover():set_velocity(st._last_velocity_xy)
				local t = managers.player:player_timer():time()
				if st._interupt_action_running then st:_interupt_action_running(t) end
				if st._state_data and not st._state_data.ducking and st._start_action_ducking then
					st:_start_action_ducking(t)
				end
			end)
		end
		return result
	end

	Hooks:PreHook(PlayerDamage, "damage_bullet", "PDTHTactics_dozer_rage_dmg", function(self, attack_data)
		if not (T.active() or T.client_on()) then return end
		local attacker = attack_data and attack_data.attacker_unit
		local dmg = alive(attacker) and attacker:character_damage()
		if dmg and dmg._pdth_enraged and type(attack_data.damage) == "number" then
			attack_data.damage = attack_data.damage * 1.1
		end
	end)
end
