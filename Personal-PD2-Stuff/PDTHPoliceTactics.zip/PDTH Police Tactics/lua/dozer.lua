if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics
local script = RequiredScript and RequiredScript:lower() or ""

-- Restoration-style Bulldozers:
--  * chase AI that thinks every frame, never drops a chase halfway, flanks to ~10m of you,
--    takes a straight line when it can, slows to a walk up close and re-paths when you move away
--  * a visible heister within 6m always pulls a Dozer off whatever it was doing
--  * headshots only count from the front (through the visor)
--  * on Death Sentence, losing the visor plays a rage animation

if script == "lib/units/enemies/tank/logics/tankcoplogicattack" then
	local orig_update = TankCopLogicAttack.update
	local orig_queue = TankCopLogicAttack.queue_update
	local orig_exit_chk = TankCopLogicAttack._chk_exit_attack_logic or CopLogicAttack._chk_exit_attack_logic

	local CHASE_DIS = 1000
	local REPATH_DIS_SQ = 1200 * 1200

	function TankCopLogicAttack._chk_exit_attack_logic(data, ...)
		if not T.active() then return orig_exit_chk(data, ...) end
		-- don't drop out of attack logic in the middle of a chase
		if data.internal_data and data.internal_data.walking_to_chase_pos then return end
		local fe = data.attention_obj
		if not fe or fe.dis > 2000 or fe.reaction < AIAttentionObject.REACT_COMBAT then
			return CopLogicAttack._chk_exit_attack_logic(data, ...)
		end
	end

	Hooks:PostHook(TankCopLogicAttack, "enter", "PDTHTactics_dozer_enter", function(data)
		if T.active() and data.brain then
			data.brain:set_update_enabled_state(true)
		end
	end)

	function TankCopLogicAttack.queue_update(data, my_data, ...)
		if T.active() then return end -- updated every frame instead
		return orig_queue(data, my_data, ...)
	end

	local function new_update(data)
		local my_data = data.internal_data
		if my_data.has_old_action then
			CopLogicAttack._upd_stop_old_action(data, my_data)
			return
		end
		if CopLogicIdle._chk_relocate(data) then return end

		local fe = data.attention_obj
		if not fe or fe.reaction < AIAttentionObject.REACT_AIM then
			CopLogicAttack._upd_enemy_detection(data, true)
			return
		end

		TankCopLogicAttack._process_pathing_results(data, my_data)

		local unit = data.unit
		if unit:movement():chk_action_forbidden("walk") then return end
		if unit:anim_data().crouch and CopLogicAttack._chk_request_action_stand(data) then return end

		local visible = fe.verified
		if fe.reaction >= AIAttentionObject.REACT_COMBAT then
			-- stop running once close
			if visible and fe.dis < 400 and unit:anim_data().run then
				unit:brain():action_request({ body_part = 2, type = "idle" })
			end

			if my_data.walking_to_chase_pos then
				-- you moved well away from where we're heading: pick a new spot
				local dest = my_data.walking_to_chase_pos.get_destination_pos and my_data.walking_to_chase_pos:get_destination_pos()
				if dest and my_data.chase_enemy and my_data.chase_enemy.m_pos
					and mvector3.distance_sq(dest, my_data.chase_enemy.m_pos) > REPATH_DIS_SQ then
					TankCopLogicAttack._cancel_chase_attempt(data, my_data)
				end
			elseif my_data.pathing_to_chase_pos then
				-- waiting for the path
			elseif my_data.chase_path then
				TankCopLogicAttack._chk_request_action_walk_to_chase_pos(data, my_data, visible and fe.dis < 800 and "walk" or "run")
			elseif my_data.chase_pos then
				local from_pos = unit:movement():nav_tracker():field_position()
				local to_pos = my_data.chase_pos
				my_data.chase_pos = nil
				if math.abs(from_pos.z - to_pos.z) < 100
					and not managers.navigation:raycast({ allow_entry = false, pos_from = from_pos, pos_to = to_pos }) then
					-- straight line, no path search needed
					my_data.chase_path = { mvector3.copy(from_pos), to_pos }
				else
					my_data.chase_path_search_id = tostring(unit:key()) .. "chase"
					my_data.pathing_to_chase_pos = true
					data.brain:add_pos_rsrv("path", { radius = 60, position = mvector3.copy(to_pos) })
					unit:brain():search_for_path(my_data.chase_path_search_id, to_pos)
				end
			elseif fe.nav_tracker then
				my_data.chase_pos = CopLogicAttack._find_flank_pos(data, my_data, fe.nav_tracker, CHASE_DIS)
				my_data.chase_enemy = fe
			end
		else
			TankCopLogicAttack._cancel_chase_attempt(data, my_data)
		end
	end

	-- the chase logic runs 10 times a second (it used to run every frame for every Dozer, including
	-- the expensive "who can I see" check, which cost frames with several Dozers up)
	local THINK_EVERY, IDLE_EVERY = 0.1, 0.25
	function TankCopLogicAttack.update(data, ...)
		if not T.active() then return orig_update(data, ...) end
		local my_data = data.internal_data
		local now = TimerManager:game():time()
		if my_data then
			if now < (my_data.pdth_think_t or 0) then return end
			local fe = data.attention_obj
			my_data.pdth_think_t = now + ((fe and fe.reaction >= AIAttentionObject.REACT_AIM) and THINK_EVERY or IDLE_EVERY)
		end
		data.t = now
		local ok, err = pcall(new_update, data)
		if not ok then
			if not T._dozer_err then
				T._dozer_err = true
				log(T.name .. " dozer chase error: " .. tostring(err))
			end
			return orig_update(data, ...)
		end
	end

elseif script == "lib/units/enemies/cop/logics/coplogicbase" then
	-- a visible heister within 6m always pulls a Dozer off its objective
	local CLOSE = 600
	local orig_obstructed = CopLogicBase.is_obstructed
	function CopLogicBase.is_obstructed(data, objective, strictness, attention, ...)
		local a, b = orig_obstructed(data, objective, strictness, attention, ...)
		if a or not T.active() then return a, b end
		attention = attention or data.attention_obj
		if objective and objective.interrupt_dis and attention and attention.verified and attention.dis
			and attention.reaction and attention.reaction >= AIAttentionObject.REACT_COMBAT
			and attention.dis < CLOSE and T.has_tag(data.unit, "tank") then
			return true, true
		end
		return a, b
	end

	-- Snipers that walk with the assault (Death Wish +'s "death squads") get a laser from DW+, but DW+
	-- only knows the base game's sniper units. When we swap them for Restoration's ZEAL Sniper they lost
	-- it, so give the ZEAL Sniper the same always-on laser outside of the normal map-sniper logic.
	local ZEAL_SNIPER = {
		[Idstring("units/pd2_dlc_gitgud/characters/ene_zeal_sniper/ene_zeal_sniper"):key()] = true,
		[Idstring("units/pd2_dlc_gitgud/characters/ene_zeal_sniper/ene_zeal_sniper_husk"):key()] = true
	}
	Hooks:PostHook(CopLogicBase, "enter", "PDTHTactics_field_sniper_laser", function(data, new_logic_name)
		if not (T.active() and data and alive(data.unit) and ZEAL_SNIPER[data.unit:name():key()]) then return end
		if new_logic_name == "sniper" then return end -- map snipers: the focus/laser logic in sniper.lua handles them
		pcall(function()
			local on = new_logic_name ~= "inactive"
			if (data.pdth_field_laser or false) == on then return end
			local weapon = data.unit:inventory():equipped_unit()
			if not (weapon and weapon:base().set_laser_enabled) then return end
			data.pdth_field_laser = on
			weapon:base():set_laser_enabled(on)
			managers.network:session():send_to_peers_synched("sync_unit_event_id_16", data.unit, "brain",
				on and HuskCopBrain._NET_EVENTS.weapon_laser_on or HuskCopBrain._NET_EVENTS.weapon_laser_off)
		end)
	end)

elseif script == "lib/units/enemies/cop/copdamage" then
	-- A headshot knocks the helmet/hat off by spawning it as a prop. If that prop isn't loaded,
	-- BeardLib loads it on the spot mid-fight, which crashes the sound engine. Only drop the
	-- helmet when it's actually loaded; otherwise it just disappears.
	local UNIT_IDS = Idstring("unit")
	local function gear_ready(path)
		local ids = Idstring(path)
		if not DB:has(UNIT_IDS, ids) then return false end -- the prop doesn't even exist
		local dyn = managers.dyn_resource
		if dyn and dyn.has_resource and dyn:has_resource(UNIT_IDS, ids, dyn.DYN_RESOURCES_PACKAGE) then return true end
		local fm = BeardLib and BeardLib.Managers and BeardLib.Managers.File
		if fm and fm.Has then
			local ok, r = pcall(fm.Has, fm, UNIT_IDS, ids)
			if ok and r then return false end -- a mod file that was never loaded
		end
		return PackageManager:has(UNIT_IDS, ids)
	end
	local orig_gadget = CopDamage._spawn_head_gadget
	if orig_gadget then
		function CopDamage:_spawn_head_gadget(params, ...)
			if self._head_gear and not self._head_gear_spawned then
				local ok, ready = pcall(gear_ready, self._head_gear)
				if ok and not ready then
					pcall(self.hide_head_gear, self)
					self._head_gear_spawned = true
					return
				end
			end
			return orig_gadget(self, params, ...)
		end
	end

	-- Dozer headshots only count from the front: a bullet travelling the same way the Dozer faces
	-- (shot from behind or the far side) hits the helmet, not the visor
	local NO_HEAD = Idstring("pdth_no_head")
	local tmp1, tmp2 = Vector3(), Vector3()

	local function from_behind(self, attack_data)
		local ray = attack_data.col_ray and attack_data.col_ray.ray
		if not ray then return false end
		mvector3.set(tmp1, ray)
		mvector3.set_z(tmp1, 0)
		mvector3.normalize(tmp1)
		mrotation.y(self._unit:rotation(), tmp2)
		mvector3.set_z(tmp2, 0)
		mvector3.normalize(tmp2)
		return mvector3.dot(tmp1, tmp2) + (tmp1.x * tmp2.y - tmp1.y * tmp2.x) * 0.35 >= 0.3
	end

	local orig_bullet = CopDamage.damage_bullet
	function CopDamage:damage_bullet(attack_data, ...)
		if (T.active() or T.client_on()) and self._ids_head_body_name and attack_data and attack_data.col_ray
			and attack_data.col_ray.body and attack_data.col_ray.body:name() == self._ids_head_body_name then
			local ok, behind = pcall(function()
				return T.has_tag(self._unit, "tank") and from_behind(self, attack_data)
			end)
			if ok and behind then
				local real = self._ids_head_body_name
				self._ids_head_body_name = NO_HEAD
				local res = { pcall(orig_bullet, self, attack_data, ...) }
				self._ids_head_body_name = real
				if not res[1] then error(res[2], 0) end
				return unpack(res, 2)
			end
		end
		return orig_bullet(self, attack_data, ...)
	end

elseif script == "lib/units/enemies/tank/tankcopdamage" then
	-- Death Sentence: losing the visor plays a rage animation and a sound cue (on every modded machine)
	if TankCopDamage.seq_clbk_vizor_shatter then
		Hooks:PostHook(TankCopDamage, "seq_clbk_vizor_shatter", "PDTHTactics_dozer_rage_anim", function(self)
			if not ((T.active() or T.client_on()) and T.is_ds()) or self._dead then return end
			pcall(function()
				local unit = self._unit
				unit:sound():play("clk_turn", nil, nil)
				unit:movement():play_redirect("use_syringe")
			end)
		end)
	end
end
