-- Gilza DS Perk Buffs: colourful perk deck descriptions (Geo 2026-10-24: "more colorful to show off what its doing").
-- Every ##highlighted## number in a perk deck description gets the colour of what it does - read from the words around
-- it - instead of the one blue the game uses for all of them; with WORDS on, the effect words next to it ("more damage",
-- "health", "dodge", ...) take the same colour. Named effects ("Rage", "Backstab", "Closing In", ...) are amber.
--   damage orange | damage taken / immunity blue | health green | armor teal | dodge yellow | speed / handling violet
--   stealth / crowd control pink | times, ranges, counts white (the rest of the text a little dimmer)
-- Pure logic (B.paint_plan) + the GUI part (B.paint_apply); gold.lua calls them for the perk deck screen only.
GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs

B.PAINT = B.PAINT or {
	on = true,
	words = true,        -- colour the effect words next to the numbers too
	dim_body = 0.80,     -- the rest of the text (1 = as the game draws it)
}

local function rgb(hex)
	local r, g, b = tonumber(hex:sub(1, 2), 16), tonumber(hex:sub(3, 4), 16), tonumber(hex:sub(5, 6), 16)
	return { r / 255, g / 255, b / 255 }
end
B.PAINT_COLORS = {
	damage = rgb("FF8A3D"),
	defense = rgb("5EA8FF"),
	health = rgb("6EE06E"),
	armor = rgb("45D9C8"),
	dodge = rgb("FFE04A"),
	speed = rgb("C79BFF"),
	stealth = rgb("FF85C8"),
	neutral = rgb("FFFFFF"),
	mechanic = rgb("FFBE3C"),
	ds = rgb("FFCC47"),
}

-- keyword phrases (lower case, matched on word boundaries); the first group that matches wins on equal position
local KEYS = {
	{ "defense", { "damage reduction", "damage resistance", "bullet damage resistance", "less damage", "reduces damage",
		"reduce damage", "damage taken", "invulnerable", "invulnerability", "immune", "immunity", "absorb", "absorbs",
		"less likely to be targeted", "chances to be targeted", "chance to be targeted", "less accurate",
		"lose track of you" } },
	{ "damage", { "more damage", "times damage", "x damage", "damage you deal", "increases your damage",
		"critical hit chance", "critical hits", "critical hit", "armor piercing", "pierce enemy body armor",
		"pierce body armor", "pierce", "body armor", "headshots", "headshot", "die outright", "deal", "damage" } },
	{ "dodge", { "chance to dodge", "dodge chance", "dodge" } },
	{ "health", { "health points", "life points", "life point", "health", "heals", "heal", "healed", "healing" } },
	{ "armor", { "armor recovery", "armor", "plates", "plate" } },
	{ "speed", { "movement speed", "faster", "speed", "reload", "swap", "stamina" } },
	{ "stealth", { "concealment", "detect", "pagers", "pager", "pick locks", "bag corpses", "suspicion", "panic",
		"stuns", "stun", "stagger", "cloak", "cloaked", "cloaking" } },
}
-- words right after a number that make it a plain amount (time, distance, count; 7.20: "4 hostages", "3 rounds",
-- "3 attacks"; 7.21 Gambler: "1 win in 10", "1 loss in 20")
local UNITS = { seconds = true, second = true, ["second(s)"] = true, minutes = true, stacks = true, stack = true,
	times = true, enemies = true, enemy = true, kills = true, kill = true, hits = true, segments = true, rolls = true,
	shots = true, teammates = true, plates = true, combo = true, hostages = true, hostage = true, rounds = true,
	round = true, attacks = true, attack = true, win = true, wins = true, loss = true, losses = true }
-- generic "damage" is damage TAKEN after / before these
local TAKEN_BEFORE = { less = true, reduces = true, reduce = true, absorb = true, absorbs = true, take = true, taken = true }
local TAKEN_AFTER = { reduction = true, resistance = true, taken = true }
-- stealth chores: "faster" there is a stealth thing, not movement
local CHORES = { "pick locks", "pagers", "bag corpses", "lockpick" }
local NOT_NAMES = { ["Note"] = true, ["Deck Completion Bonus"] = true, ["In"] = true }
B.PAINT_NAMES = B.PAINT_NAMES or { "Rage", "Closing In", "Exposed", "Cloak", "Backstab", "Hysteria Stacks", "Hysteria",
	"Momentum", "Stacks of Regeneration", "Stack of Regeneration", "Unstoppable", "Contract", "Streak", "Frenzy",
	"Tension", "Thick Skin", "Hardened", "Dread", "Clean Hit", "Melt Away", "Point Blank", "Bloodrush", "Ghost", "Wraith",
	"Slip Away", "Unseen Mend", "Fade Out", "Bodyguard", "Taunt", "Juggernaut", "Fearsome", "Combo", "Massacre",
	-- (7.24) signature names the label rule can't pick up (small words, four words) and states named mid-sentence
	"Sangre por Sangre", "Ride or Die", "Smash and Grab", "No One Left Behind", "Last Man Standing", "Power Play",
	"Jackpot", "Unchained", "Rampage", "Bender", "Riposte", "Black Bloc", "Oni" }
-- what a named effect does, for numbers that only name it ("Closing In goes up to ##20%##")
B.PAINT_NAME_CAT = B.PAINT_NAME_CAT or {
	["closing in"] = "defense", ["exposed"] = "damage", ["rage"] = "damage", ["backstab"] = "damage", ["bloodied"] = "damage",
	["riot"] = "damage", ["black bloc"] = "damage", ["road rage"] = "damage", ["crossfire"] = "damage", ["grit"] = "damage",
	["haze"] = "damage", ["campaign trail"] = "damage", ["overclock"] = "damage", ["burnout"] = "damage", ["bond"] = "damage",
	["adrenal surge"] = "damage", ["silent partner"] = "damage", ["iron will"] = "defense", ["secret service"] = "defense",
	["colors"] = "defense", ["shared pain"] = "defense", ["comedown"] = "defense", ["composure"] = "defense",
	["withdrawal"] = "defense", ["melt away"] = "defense", ["hysteria"] = "defense", ["last stand"] = "defense",
	["overgrowth"] = "health", ["chopper"] = "speed", ["cloak"] = "stealth", ["slip away"] = "stealth", ["ghost"] = "stealth",
	["thick skin"] = "defense", ["hardened"] = "defense", ["frenzy"] = "defense", ["tension"] = "armor", ["clean hit"] = "health",
	["massacre"] = "damage", ["bloodrush"] = "armor", ["point blank"] = "damage", ["unseen mend"] = "health",
	["fade out"] = "defense", ["wraith"] = "stealth", ["bodyguard"] = "defense", ["juggernaut"] = "health",
	["fearsome"] = "stealth", ["unstoppable"] = "defense", ["shadow"] = "stealth", ["guard sense"] = "stealth",
	["second chance"] = "stealth", ["silent takedown"] = "stealth",
	-- Crook (7.17)
	["sidestep"] = "dodge", ["padding"] = "armor", ["deflect"] = "armor", ["slip"] = "dodge",
}
-- these make every number in their clause a damage number ("below ##60%## health die outright")
local EXECUTE = { "die outright", "execute" }
-- an enemy made stronger against you is not your bonus: plain white ("your Contract takes ##20%## less damage from you
-- and deals ##20%## more damage to you"); whole words only ("damage from your crew" is not one)
local ENEMY_SIDE = { "less damage from you", "more damage to you" }

local function is_alpha(c)
	return c ~= nil and c ~= "" and c:match("[%a']") ~= nil
end

-- every keyword match in s (lower case): { s = byte start, e = byte end (inclusive), cat, phrase }
local function find_keys(low)
	local out = {}
	for _, g in ipairs(KEYS) do
		for _, ph in ipairs(g[2]) do
			local from = 1
			while true do
				local a, b = string.find(low, ph, from, true)
				if not a then break end
				if not is_alpha(low:sub(a - 1, a - 1)) and not is_alpha(low:sub(b + 1, b + 1)) then
					out[#out + 1] = { s = a, e = b, cat = g[1], ph = ph }
				end
				from = a + 1
			end
		end
	end
	-- drop matches inside longer matches (keep the longest phrase at a place)
	table.sort(out, function(x, y) if x.s ~= y.s then return x.s < y.s end return (x.e - x.s) > (y.e - y.s) end)
	local kept = {}
	for _, m in ipairs(out) do
		local inside = false
		for _, k in ipairs(kept) do
			if m.s >= k.s and m.e <= k.e then inside = true break end
		end
		if not inside then kept[#kept + 1] = m end
	end
	return kept
end

-- generic "damage": dealt or taken?
local function damage_side(low, m)
	if m.ph ~= "damage" then return m.cat end
	local before = low:sub(math.max(1, m.s - 24), m.s - 1)
	local w1, w2 = before:match("(%a+)%W+(%a+)%W*$")
	local last = before:match("(%a+)%W*$")
	local nxt = low:sub(m.e + 1):match("^%W*(%a+)")
	if (last and TAKEN_BEFORE[last]) or (w1 and TAKEN_BEFORE[w1]) or (nxt and TAKEN_AFTER[nxt]) then return "defense" end
	-- "absorb ##1## damage": a number between them
	local num_before = before:match("(%a+)%s+[%d%.%%%+%-]+%s*$")
	if num_before and TAKEN_BEFORE[num_before] then return "defense" end
	return "damage"
end

-- clause boundaries: sentence ends (not decimal points), commas, "and" / "or", line breaks, colons
local function clause_of(low, a, b)
	local cs, ce = 1, #low
	local i = a - 1
	while i >= 1 do
		local c = low:sub(i, i)
		if c == "\n" or c == ";" or c == ":" or c == "," or c == "!" or c == "?" then cs = i + 1 break end
		if c == "." and not (low:sub(i - 1, i - 1):match("%d") and low:sub(i + 1, i + 1):match("%d")) then cs = i + 1 break end
		if low:sub(i - 4, i) == " and " or low:sub(i - 3, i) == " or " then cs = i + 1 break end
		i = i - 1
	end
	i = b + 1
	while i <= #low do
		local c = low:sub(i, i)
		if c == "\n" or c == ";" or c == ":" or c == "," or c == "!" or c == "?" then ce = i - 1 break end
		if c == "." and not (low:sub(i - 1, i - 1):match("%d") and low:sub(i + 1, i + 1):match("%d")) then ce = i - 1 break end
		if low:sub(i, i + 4) == " and " or low:sub(i, i + 3) == " or " then ce = i - 1 break end
		i = i + 1
	end
	return cs, ce
end

local function sentence_of(low, a)
	local i = a - 1
	while i >= 1 do
		local c = low:sub(i, i)
		if c == "\n" or c == "!" or c == "?" then return i + 1 end
		if c == "." and not (low:sub(i - 1, i - 1):match("%d") and low:sub(i + 1, i + 1):match("%d")) then return i + 1 end
		i = i - 1
	end
	return 1
end

-- byte -> 0-based character index (UTF-8)
local function char_table(s)
	local t, n = {}, 0
	for i = 1, #s + 1 do
		t[i] = n
		local c = s:byte(i)
		if c and (c < 0x80 or c >= 0xC0) then n = n + 1 end
	end
	return t
end

-- names of effects: "Name:" labels in the text plus the known ones
local function names_in(text)
	local found = {}
	for _, n in ipairs(B.PAINT_NAMES) do found[#found + 1] = n end
	for label in text:gmatch("(%u[%a']*[%a' ]-):%s") do
		label = label:gsub("^%s+", "")
		-- at most three words, every word capitalised (or a short linking word)
		local ok, words = true, 0
		for w in label:gmatch("%S+") do
			words = words + 1
			if not (w:match("^%u") or w == "of" or w == "the") then ok = false end
		end
		if ok and words <= 3 and not NOT_NAMES[label] then found[#found + 1] = label end
	end
	table.sort(found, function(x, y) return #x > #y end)
	return found
end

-- raw text with ##...## -> stripped text, list of { cs, ce (0-based chars, end exclusive), cat }
function B.paint_plan(raw, opts)
	opts = opts or B.PAINT
	if type(raw) ~= "string" then return nil end
	-- pairs of ## (as the game finds them) -> stripped text + number spans (bytes, in the stripped text)
	local parts, nums, pos, stripped_len = {}, {}, 1, 0
	local open = nil
	while true do
		local a = string.find(raw, "##", pos, true)
		if not a then break end
		parts[#parts + 1] = raw:sub(pos, a - 1)
		stripped_len = stripped_len + (a - pos)
		if open then
			nums[#nums + 1] = { s = open, e = stripped_len } -- bytes [open, e] inclusive, 1-based
			open = nil
		else
			open = stripped_len + 1
		end
		pos = a + 2
	end
	parts[#parts + 1] = raw:sub(pos)
	if open then return nil end -- odd number of ##: leave it to the game
	local text = table.concat(parts)
	local low = text:lower()
	local keys = find_keys(low)
	local plan = {}
	local prev_sentence, prev_cat, prev_end = nil, nil, nil
	local used_keys = {}
	local function first_key(from, to) -- earliest keyword inside [from, to]
		for _, k in ipairs(keys) do
			if k.s >= from and k.e <= to then return k end
		end
	end
	local function last_key(from, to) -- latest keyword inside [from, to]
		for i = #keys, 1, -1 do
			local k = keys[i]
			if k.s >= from and k.e <= to then return k end
		end
	end
	for _, n in ipairs(nums) do
		local num = low:sub(n.s, n.e)
		local cat, key
		local cs, ce = clause_of(low, n.s, n.e)
		local sent = sentence_of(low, n.s)
		local same_sentence = prev_sentence == sent
		local same_para = prev_end and not low:sub(prev_end, n.s):find("\n", 1, true)
		local lead = low:sub(cs, n.s - 1)
		local after = low:sub(n.e + 1, ce)
		local first = after:match("^%s*(%S+)")
		first = first and first:gsub("[%.,;:]$", "")
		local two = after:match("^%s*(%a+%s+%a+)")
		if num:match("%d%s*m$") or num:match("^%d+[snrt][tdh]$") or (two and (two == "chance roll" or two == "failure roll")) then
			cat = "neutral" -- a distance, an ordinal ("every ##3rd##"), or a dice roll
		elseif lead:match("instead of%s*$") and same_sentence then
			cat = prev_cat -- "1 second instead of ##1.5##"
		else
			-- 1. an effect word right after the number ("##25%## more damage")
			for _, k in ipairs(keys) do
				if k.s > n.e and k.s <= ce and low:sub(n.e + 1, k.s - 1):match("^%s*$") then
					cat, key = damage_side(low, k), k
					break
				end
			end
			-- 2. a plain amount ("##4## seconds", "##1## stack", "##8## Rage stacks")
			if not cat and first and UNITS[first] then cat = "neutral" end
			if not cat then
				local w1, w2 = text:sub(n.e + 1, ce):match("^%s*(%S+)%s+(%S+)")
				w2 = w2 and w2:lower():gsub("[%.,;:]$", "")
				if w1 and w1:match("^%u") and w2 and UNITS[w2] then cat = "neutral" end
			end
			if not cat then
				-- a unit after only names or "extra" ("adds ##1## extra Frenzy stack", "##2## Frenzy stacks")
				local i = 0
				for w in text:sub(n.e + 1, ce):gmatch("[%a']+") do
					i = i + 1
					if i > 3 then break end
					local lw = w:lower()
					if UNITS[lw] then cat = "neutral" break end
					if not (lw == "extra" or lw == "additional" or lw == "bonus" or w:match("^%u")) then break end
				end
			end
			-- 3. the number is the object of what comes before it: "X is increased by ##5%##" -> X (the subject, first
			--    effect word of the clause); "heals you for ##75%##", "up to ##20%##", "below ##50%##" -> the nearest one
			if not cat then
				local k
				if lead:match("%f[%a]by%s+[%a]*%s*[%a]*%s*$") then
					-- the subject: "your X is increased by" -> X; else the first effect word that isn't part of a
					-- "while ..." / "when ..." condition ("armor recovery bonus while at low health is increased by")
					for i = #keys, 1, -1 do
						local kk = keys[i]
						if kk.s >= cs and kk.e < n.s and low:sub(math.max(1, kk.s - 5), kk.s - 1) == "your " then k = kk break end
					end
					if not k then
						for _, kk in ipairs(keys) do
							if kk.s >= cs and kk.e < n.s then
								local before = low:sub(math.max(cs, kk.s - 24), kk.s - 1)
								if not (before:match("%f[%a]while%s+[%a]*%s*[%a]*%s*$") or before:match("%f[%a]when%s+[%a]*%s*[%a]*%s*$")) then
									k = kk
									break
								end
							end
						end
					end
					k = k or first_key(cs, n.s - 1)
				elseif lead:match("%f[%a]for%s+[%a]*%s*[%a]*%s*$") or lead:match("%f[%a]to%s+[%a]*%s*$")
					or lead:match("%f[%a]below%s*$") or lead:match("%f[%a]above%s*$") or lead:match("%f[%a]under%s*$") then
					k = last_key(cs, n.s - 1)
				end
				if k then cat, key = damage_side(low, k), k end
			end
			-- 4. the nearest effect word after it in the clause, then before it
			if not cat then
				local k = first_key(n.e + 1, ce) or last_key(cs, n.s - 1)
				if k then cat, key = damage_side(low, k), k end
			end
			-- 5. a named effect in the clause ("Closing In goes up to ##20%##")
			if not cat then
				local clause, best = low:sub(cs, ce), nil
				for name, c in pairs(B.PAINT_NAME_CAT) do
					if string.find(clause, name, 1, true) and (not best or #name > best) then cat, best = c, #name end
				end
			end
			-- 6. nothing in its clause: the number before it in the same sentence; the first number of a sentence takes the
			--    nearest effect word of the sentence ("the more movement speed you gain, up to ##20%##")
			if not cat then
				-- the nearest effect word before it in the sentence, unless an earlier number sits in between (then that
				-- number's colour: "grants ##1## stack, up to ##10##")
				local k = last_key(sent, n.s - 1)
				if k and (not same_sentence or k.s > prev_end) then
					cat, key = damage_side(low, k), k
				elseif same_sentence then
					cat = prev_cat
				end
			end
			-- 7. a sentence without any effect word continues the one before it ("This bonus ...", "On a failure roll
			--    you lose ##2%## to ##6%##" after a critical hit chance sentence)
			if not cat and same_para and prev_cat and prev_cat ~= "neutral" then
				local s_end = low:find("[%.!?\n]", n.e + 1) or #low
				if not first_key(sent, s_end) then cat = prev_cat end
			end
			-- an execute threshold is a damage number ("below ##60%## health die outright")
			local clause = low:sub(cs, ce)
			for _, ex in ipairs(EXECUTE) do
				if string.find(clause, ex, 1, true) then cat = "damage"; key = nil break end
			end
			for _, es in ipairs(ENEMY_SIDE) do
				local a, b = string.find(clause, es, 1, true)
				if a and not is_alpha(clause:sub(a - 1, a - 1)) and not is_alpha(clause:sub(b + 1, b + 1)) then
					cat = "neutral"; key = nil break
				end
			end
		end
		cat = cat or "neutral"
		if not num:match("%d%s*m$") then
			prev_sentence, prev_cat, prev_end = sent, cat, n.e
		end
		-- "25% faster" for lockpicking / pagers / bagging: a stealth chore; "your armor recovers ##20%## faster": armor
		if cat == "speed" and key and key.ph == "faster" then
			local clause = low:sub(cs, ce)
			for _, ch in ipairs(CHORES) do
				if string.find(clause, ch, 1, true) then cat = "stealth" break end
			end
			if cat == "speed" then
				local k = last_key(cs, n.s - 1)
				if k and k.cat ~= "speed" and k.cat ~= "damage" then cat, key = damage_side(low, k), k end
			end
		end
		plan[#plan + 1] = { s = n.s, e = n.e, cat = cat }
		if key and cat ~= "neutral" and opts.words and not used_keys[key.s] then
			used_keys[key.s] = true
			plan[#plan + 1] = { s = key.s, e = key.e, cat = cat, word = true }
		end
	end
	-- effect names
	local taken = {}
	for _, p in ipairs(plan) do for i = p.s, p.e do taken[i] = true end end
	for _, name in ipairs(names_in(text)) do
		local from = 1
		while true do
			local a, b = string.find(text, name, from, true)
			if not a then break end
			local free = not is_alpha(text:sub(a - 1, a - 1)) and not is_alpha(text:sub(b + 1, b + 1))
			for i = a, b do if taken[i] then free = false break end end
			if free then
				plan[#plan + 1] = { s = a, e = b, cat = "mechanic", word = true }
				for i = a, b do taken[i] = true end
			end
			from = b + 1
		end
	end
	-- Death Sentence
	local from = 1
	while true do
		local a, b = string.find(text, "Death Sentence", from, true)
		if not a then break end
		plan[#plan + 1] = { s = a, e = b, cat = "ds", word = true }
		from = b + 1
	end
	-- bytes -> characters (0-based start, exclusive end)
	local ct = char_table(text)
	for _, p in ipairs(plan) do
		p.cs, p.ce = ct[p.s], ct[p.e + 1]
	end
	table.sort(plan, function(x, y) return x.cs < y.cs end)
	return text, plan
end

-- the GUI part: colour a text object the game has already stripped of its ## markers
function B.paint_apply(text_object, raw, opts)
	opts = opts or B.PAINT
	if not opts.on then return false end
	local text, plan = B.paint_plan(raw, opts)
	if not text or text ~= text_object:text() then return false end
	local base = text_object:color()
	if opts.dim_body and opts.dim_body < 1 then
		local d = opts.dim_body
		text_object:set_color(Color(base.alpha, base.red * d, base.green * d, base.blue * d))
	end
	for _, p in ipairs(plan) do
		local c = B.PAINT_COLORS[p.cat]
		if c then text_object:set_range_color(p.cs, p.ce, Color(base.alpha, c[1], c[2], c[3])) end
	end
	return true
end

-- the perk deck screen: colour only the texts that SpecializationGuiNew:update_detail_panels draws (gold.lua's
-- add_colors_to_text_object override reads B._paint_active)
local script = RequiredScript and RequiredScript:lower() or ""
if script == "lib/managers/menu/specializationguinew" and SpecializationGuiNew and not SpecializationGuiNew._gdsb_paint then
	SpecializationGuiNew._gdsb_paint = true
	local orig_update = SpecializationGuiNew.update_detail_panels
	function SpecializationGuiNew:update_detail_panels(...)
		B._paint_active = true
		local ok, r1, r2 = pcall(orig_update, self, ...)
		B._paint_active = false
		if not ok then error(r1, 0) end
		return r1, r2
	end
end
