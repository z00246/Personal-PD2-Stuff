if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics
local orig = GroupAIStateBesiege._create_objective_from_group_objective

local FOLLOW_SHIELD = 180
local FOLLOW_TANK = 450
local FOLLOW_TAZER = 500
local SEARCH_TANK = 3000
local ESCORT_RANGE = 1500
local ESCORT_DIST = 350
local ESCORT_CHANCE = 0.6
local ESCORT_CHANCE_DS = 0.8
local FOLLOW_COVER = 500

local function group_member(group, me, check)
	for u_key, u_data in pairs(group and group.units or {}) do
		local u = u_data.unit
		if u ~= me and alive(u) and not u:character_damage():dead() and check(u, u_data) then
			return u
		end
	end
end

local function nearest_tank(me, range)
	range = range or SEARCH_TANK
	local state = managers.groupai:state()
	local my_pos = me:movement():m_pos()
	local best, best_d
	for _, u_data in pairs(state._police or {}) do
		local u = u_data.unit
		if alive(u) and T.has_tag(u, "tank") and not u:character_damage():dead() then
			local d = mvector3.distance(my_pos, u:movement():m_pos())
			if d < range and (not best_d or d < best_d) then
				best, best_d = u, d
			end
		end
	end
	return best
end

local WALL_SEARCH = 1300
local WALL_CHANCE = 0.5
local WALL_CHANCE_DS = 0.75

local function nearest_wall_shield(me)
	local state = managers.groupai:state()
	local my_pos = me:movement():m_pos()
	local best, best_d
	for _, u_data in pairs(state._police or {}) do
		local u = u_data.unit
		if alive(u) and T.has_tag(u, "shield") and not u:character_damage():dead() then
			local ld = u:brain() and u:brain()._logic_data
			if ld and ld.internal_data and ld.internal_data.pdth_in_wall then
				local d = mvector3.distance(my_pos, u_data.m_pos)
				if d < WALL_SEARCH and (not best_d or d < best_d) then
					best, best_d = u, d
				end
			end
		end
	end
	return best
end

local function follow(objective, unit, distance)
	objective.follow_unit = unit
	objective.distance = distance
end

function T.adjust(objective, grp_objective, unit)
	if objective.type ~= "defend_area" and objective.type ~= "hunt" then
		return
	end
	local state = managers.groupai:state()
	local u_data = state._police and state._police[unit:key()]
	if not u_data then
		return
	end
	local tactics = u_data.tactics_map or {}
	local group = u_data.group

	if tactics.shield then
		local escort = group_member(group, unit, function(u) return not T.has_tag(u, "shield") end)
		if not escort then
			local seg = unit:movement():nav_tracker():nav_segment()
			local area = state:get_area_from_nav_seg_id(seg)
			if area then
				objective.type = "defend_area"
				objective.area = area
				objective.nav_seg = seg
				objective.pos = nil
				objective.path_data = nil
				objective.follow_unit = nil
				objective.attitude = "avoid"
			end
		end
	elseif tactics.shield_cover then
		-- the squad's Shield with the fewest cover men; they stand behind it (see shield_cover.lua)
		local shield = T.pick_cover_shield and T.pick_cover_shield(group, unit)
			or group_member(group, unit, function(u) return T.has_tag(u, "shield") end)
		if shield then
			objective.type = "defend_area"
			follow(objective, shield, T.SHIELD_FOLLOW_DIS or FOLLOW_SHIELD)
			objective.pdth_shield = shield
		end
	elseif tactics.pdth_medic or T.has_tag(unit, "medic") then
		objective.attitude = "avoid"
		objective.interrupt_dis = nil
		objective.interrupt_suppression = nil
		objective.pose = "crouch"
		local tank = group_member(group, unit, function(u) return T.has_tag(u, "tank") end) or nearest_tank(unit)
		if tank then
			objective.type = "defend_area"
			follow(objective, tank, FOLLOW_TANK)
			objective.pdth_tank = tank
		else
			-- no Dozer: hide behind a Shield like its cover men do, else stick to the squad leader
			local shield = T.pick_cover_shield and T.pick_cover_shield(group, unit)
			if shield then
				objective.type = "defend_area"
				follow(objective, shield, T.SHIELD_FOLLOW_DIS or FOLLOW_COVER)
				objective.pdth_shield = shield
			else
				local leader
				if group and group.units and GroupAIStateBesiege._determine_group_leader then
					local _, l_data = GroupAIStateBesiege._determine_group_leader(group.units)
					leader = l_data and l_data.unit
				end
				if not (alive(leader) and leader ~= unit and not T.has_tag(leader, "medic")) then
					leader = group_member(group, unit, function(u) return not T.has_tag(u, "medic") end)
				end
				if leader then
					objective.type = "defend_area"
					follow(objective, leader, FOLLOW_COVER)
				end
			end
		end
	elseif tactics.pdth_escort then
		local tank = nearest_tank(unit, ESCORT_RANGE)
		if tank and math.random() < (T.is_ds() and ESCORT_CHANCE_DS or ESCORT_CHANCE) then
			objective.type = "defend_area"
			objective.attitude = "engage"
			follow(objective, tank, ESCORT_DIST)
			objective.pdth_tank = tank
		elseif math.random() < (T.is_ds() and WALL_CHANCE_DS or WALL_CHANCE) then
			local shield = nearest_wall_shield(unit)
			if shield then
				objective.type = "defend_area"
				follow(objective, shield, FOLLOW_SHIELD)
			end
		end
	elseif tactics.pdth_lurk then
		objective.pose = "crouch"
		if tactics.pdth_team then
			local tazer = group_member(group, unit, function(u) return T.has_tag(u, "taser") end)
			if tazer then
				objective.type = "defend_area"
				follow(objective, tazer, FOLLOW_TAZER)
			end
		end
	end
end

GroupAIStateBesiege._create_objective_from_group_objective = function(grp_objective, receiving_unit, ...)
	local objective = orig(grp_objective, receiving_unit, ...)
	if objective and receiving_unit and alive(receiving_unit) and T.active() then
		T.adjust(objective, grp_objective, receiving_unit)
	end
	return objective
end
