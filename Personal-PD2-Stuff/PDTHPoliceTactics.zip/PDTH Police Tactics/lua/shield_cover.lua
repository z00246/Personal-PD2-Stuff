if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics

-- Restoration-style shield cover (host only):
--  * cops covering a Shield pick a spot 0.5-3m BEHIND it (away from the threat), spread out sideways
--  * every Shield in a squad gets its fair share of cover men, and when a Shield dies its men
--    switch to another one right away
--  * when the Shield pushes up (gets closer to the threat than its cover men), they move up with it
--  * Dozer escorts and medics re-follow their Dozer as soon as it gets away from them

local BEHIND_MIN, BEHIND_MAX = 50, 300
local SIDE_STEP = 70
local CHECK_EVERY = 1

T.SHIELD_FOLLOW_DIS = BEHIND_MAX + 100 -- inside this, a cover man is "in place"

local function alive_shield(u)
	return alive(u) and T.has_tag(u, "shield") and u:character_damage() and not u:character_damage():dead()
end

-- the Shield in this group with the fewest cover men (ties: closest to `me`)
function T.pick_cover_shield(group, me)
	if not (group and group.units) then return end
	local counts = {}
	for _, u_data in pairs(group.units) do
		local u = u_data.unit
		if alive_shield(u) then counts[u:key()] = { unit = u, n = 0 } end
	end
	if not next(counts) then return end
	for _, u_data in pairs(group.units) do
		local u = u_data.unit
		if alive(u) and u ~= me then
			local ld = u:brain() and u:brain()._logic_data
			local s = ld and ld.objective and ld.objective.pdth_shield
			if alive(s) and counts[s:key()] then
				counts[s:key()].n = counts[s:key()].n + 1
			end
		end
	end
	local best, best_n, best_d
	local my_pos = alive(me) and me:movement():m_pos()
	for _, c in pairs(counts) do
		local d = my_pos and mvector3.distance(my_pos, c.unit:movement():m_pos()) or 0
		if not best or c.n < best_n or (c.n == best_n and d < best_d) then
			best, best_n, best_d = c.unit, c.n, d
		end
	end
	return best
end

-- where the threat is for this shield: its own target, else the cover man's target
local function threat_pos(data, shield)
	local sd = shield:brain() and shield:brain()._logic_data
	local att = sd and sd.attention_obj
	if att and att.m_pos and att.reaction and att.reaction >= AIAttentionObject.REACT_AIM then return att.m_pos end
	att = data.attention_obj
	if att and att.m_pos and att.reaction and att.reaction >= AIAttentionObject.REACT_AIM then return att.m_pos end
end

-- this cover man's slot among the shield's cover men (for a sideways offset)
local function slot_of(data, shield)
	local group = data.group
	local keys = {}
	for u_key, u_data in pairs(group and group.units or {}) do
		local ld = alive(u_data.unit) and u_data.unit:brain() and u_data.unit:brain()._logic_data
		if ld and ld.objective and ld.objective.pdth_shield == shield then table.insert(keys, tostring(u_key)) end
	end
	table.sort(keys)
	local mine = tostring(data.key)
	for i, k in ipairs(keys) do
		if k == mine then return i, #keys end
	end
	return 1, 1
end

function T.pos_behind_shield(data, shield)
	local s_mov = shield:movement()
	local s_pos = s_mov:m_pos()
	local back = Vector3()
	local threat = threat_pos(data, shield)
	if threat then
		mvector3.direction(back, threat, s_pos) -- from threat towards the shield = "behind"
	else
		mvector3.set(back, s_mov:m_rot():y())
		mvector3.negate(back)
	end
	mvector3.set_z(back, 0)
	mvector3.normalize(back)
	local side = Vector3()
	mvector3.cross(side, back, math.UP)

	local slot, n = slot_of(data, shield)
	local dist = math.lerp(BEHIND_MIN, BEHIND_MAX, 0.35)
	local target = s_pos + back * dist + side * ((slot - (n + 1) / 2) * SIDE_STEP)

	-- walk the navmesh from the shield to that spot so it's always reachable
	local params = { tracker_from = s_mov:nav_tracker(), pos_to = target, trace = true }
	managers.navigation:raycast(params)
	local pos = params.trace and params.trace[1] or target
	return pos
end

local orig_occ = CopLogicTravel._determine_destination_occupation
function CopLogicTravel._determine_destination_occupation(data, objective, ...)
	if T.active() and objective and objective.type == "defend_area" and alive_shield(objective.pdth_shield) then
		local pos = T.pos_behind_shield(data, objective.pdth_shield)
		if pos then
			local seg = managers.navigation:get_nav_seg_from_pos(pos, true)
			return { type = "defend", seg = seg, pos = pos }
		end
	end
	return orig_occ(data, objective, ...)
end

-- re-send the follow objective so the cop paths to a fresh spot behind the shield
local function refollow(unit, ld, shield)
	local obj = ld.objective
	local seg = shield:movement():nav_tracker():nav_segment()
	local area = managers.groupai:state():get_area_from_nav_seg_id(seg)
	local new = {
		type = "defend_area",
		attitude = obj.attitude or "engage",
		follow_unit = shield,
		pdth_shield = shield,
		distance = T.SHIELD_FOLLOW_DIS,
		nav_seg = seg,
		area = area,
		grp_objective = obj.grp_objective,
		stance = obj.stance,
		pose = obj.pose,
		scan = true
	}
	unit:brain():set_objective(new)
end

-- Dozer escorts and medics: keep up with the Dozer (checked every second instead of
-- waiting for the base game's occasional relocation check)
local function alive_tank(u)
	return alive(u) and T.has_tag(u, "tank") and u:character_damage() and not u:character_damage():dead()
end

local function refollow_tank(unit, ld, tank)
	local obj = ld.objective
	local seg = tank:movement():nav_tracker():nav_segment()
	local new = {
		type = "defend_area",
		attitude = obj.attitude or "engage",
		follow_unit = tank,
		pdth_tank = tank,
		distance = obj.distance or 350,
		nav_seg = seg,
		area = managers.groupai:state():get_area_from_nav_seg_id(seg),
		grp_objective = obj.grp_objective,
		stance = obj.stance,
		pose = obj.pose,
		scan = true
	}
	unit:brain():set_objective(new)
end

local function check_tank(u, ld, obj)
	local tank = obj.pdth_tank
	if not alive_tank(tank) then
		obj.pdth_tank = nil
		return
	end
	if ld.name == "travel" then return end
	local dist = mvector3.distance(u:movement():m_pos(), tank:movement():m_pos())
	if dist > (obj.distance or 350) + 100 then
		refollow_tank(u, ld, tank)
	end
end

local function check()
	local state = managers.groupai and managers.groupai:state()
	if not (state and state._police) then return end
	for _, u_data in pairs(state._police) do
		local u = u_data.unit
		local ld = alive(u) and u:brain() and u:brain()._logic_data
		local obj = ld and ld.objective
		if obj and obj.pdth_tank ~= nil and not (u:character_damage() and u:character_damage():dead()) then
			check_tank(u, ld, obj)
		end
		if obj and obj.pdth_shield ~= nil and not (u:character_damage() and u:character_damage():dead()) then
			local shield = obj.pdth_shield
			if not alive_shield(shield) then
				-- their shield died: grab another one from the squad (if any)
				local new_shield = T.pick_cover_shield(u_data.group, u)
				if new_shield then
					refollow(u, ld, new_shield)
				else
					obj.pdth_shield = nil
				end
			elseif ld.name ~= "travel" then
				-- the shield pushed up past us, or wandered off: move up behind it
				local threat = threat_pos(ld, shield)
				local my_pos, s_pos = u:movement():m_pos(), shield:movement():m_pos()
				local far = mvector3.distance(my_pos, s_pos) > T.SHIELD_FOLLOW_DIS
				-- in front of the shield instead of behind it
				local exposed = threat and mvector3.distance(my_pos, threat) < mvector3.distance(s_pos, threat) - 50
				if far or exposed then
					refollow(u, ld, shield)
				end
			end
		end
	end
end

Hooks:Add("GameSetupUpdate", "PDTHTactics_shield_cover", function()
	if not (T.active() and Network and Network:is_server()) then return end
	local t = Application:time()
	if t < (T._shield_cover_t or 0) then return end
	T._shield_cover_t = t + CHECK_EVERY
	check()   -- (1.91, Geo: no engine calls wrapped in pcalls) every unit is checked with alive() before it's used
end)
