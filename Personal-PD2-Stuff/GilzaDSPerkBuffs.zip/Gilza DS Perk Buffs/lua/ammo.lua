GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs

B.AMMO_PICKUP_MUL = 1.6

local orig_add_ammo = RaycastWeaponBase.add_ammo
function RaycastWeaponBase:add_ammo(ratio, add_amount_override, ...)
	if add_amount_override then
		return orig_add_ammo(self, ratio, add_amount_override, ...)
	end
	local mul = B.AMMO_PICKUP_MUL
	-- (7.26) Aubrey (Sociopath's card 9 mask): pickups give 50% more
	if B.mask_on and B.MASK and B.mask_on("aubrey") then mul = mul * B.MASK.aubrey_pickup end
	return orig_add_ammo(self, (ratio or 1) * mul, add_amount_override, ...)
end
