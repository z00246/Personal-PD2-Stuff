GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

-- difficulty scaling (shared with buffs.lua): t = 0 up to Overkill, 1/3 Mayhem, 2/3 Death Wish, 1 Death Sentence
if not B.diff_t then
	B.DIFF_T = { easy_wish = 1 / 3, overkill_290 = 2 / 3, sm_wish = 1 }
	function B.diff_t()
		local gs = Global and Global.game_settings
		return gs and B.DIFF_T[gs.difficulty] or 0
	end
	function B.sc(base, ds) return base + (ds - base) * B.diff_t() end
	function B.sci(base, ds) return math.floor(base + (ds - base) * B.diff_t() + 0.5) end
end

-- Sociopath (7.00 rework, Geo 2026-10-24: kill chain + unbreakable + terror + melee master)
--  card 1 Frenzy (chained kills -> damage reduction stacks) + Tension (kills restore a share of armor)
--  card 3 damage reduction, melee-hold resistance, Thick Skin (big hits hurt less)
--  card 5 Clean Hit (melee kills heal, extra Frenzy) + Combo (chained melee kills charge melee faster)
--  card 7 Tension up close + Hardened (less damage the longer you fight)
--  card 9 Panic + Dread (more damage to panicking enemies) + Massacre (melee crits at high Combo)
-- *_ds values are the Death Sentence end of the difficulty scale (B.sc).
B.SOCIO = {
	deck = 9,
	passive = { [3] = 0.15, [5] = 0.25, [9] = 0.35 },
	hold_tier = 3,
	hold_gain = 0.1,
	hold_max = 0.3,
	hold_linger = 2,
	hold_decay = 0.15,
	panic_range = 2500,
	frenzy_window = 3,          -- card 1 Frenzy
	frenzy_max = 5, frenzy_max_ds = 6,
	frenzy_dr = 0.03,
	frenzy_decay_after = 3,
	frenzy_decay_every = 1,
	tension = 0.05,             -- card 1 Tension (share of max armor)
	tension_melee = 0.15,
	thick_at = 0.2,             -- card 3 Thick Skin: hits over 20% of your health
	thick = 0.4, thick_ds = 0.5,
	clean_heal = 0.10, clean_heal_ds = 0.15,   -- card 5 Clean Hit
	combo_window = 5,           -- card 5 Combo
	combo_max = 10,
	combo_charge = 0.10,
	combo_charge_max = 0.5,
	close_range = 1800,         -- card 7
	tension_close = 0.10, tension_close_ds = 0.15,
	tension_close_melee = 0.20, tension_close_melee_ds = 0.25,
	hard_every = 10,            -- card 7 Hardened
	hard_step = 0.05,
	hard_levels = 3,
	hard_reset = 10,
	dread = 0.25, dread_ds = 0.35,             -- card 9 Dread
	massacre_at = 8, massacre_at_ds = 6,       -- card 9 Massacre
	panic_time = 4.25           -- how long an enemy counts as panicking after the panic animation starts
}
local C = B.SOCIO
B.socio_hold = B.socio_hold or 0
B.socio_release_t = B.socio_release_t or 0
B.frenzy = B.frenzy or 0
B.combo = B.combo or 0
B.hard_level = B.hard_level or 0
B.socio_panic = B.socio_panic or {}

function B.socio_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == C.deck) then
		return 0
	end
	return st:get_specialization_value(C.deck, "tiers", "current_tier") or 0
end

function B.socio_passive(tier)
	local best = 0
	for card, value in pairs(C.passive) do
		if tier >= card and value > best then best = value end
	end
	return best
end

function B.socio_frenzy_max()
	return B.sci(C.frenzy_max, C.frenzy_max_ds)
end

function B.socio_massacre_at()
	return B.sci(C.massacre_at, C.massacre_at_ds)
end

function B.socio_massacre()
	return B.socio_tier() >= 9 and (B.combo or 0) >= B.socio_massacre_at()
end

function B.socio_combo_mul()
	if B.socio_tier() < 5 then return 1 end
	return 1 + math.min((B.combo or 0) * C.combo_charge, C.combo_charge_max)
end

function B.socio_panicking(unit)
	local e = alive(unit) and B.socio_panic[unit:key()]
	return e and Application:time() < e or false
end

-- gun fire ends the Combo
function B.socio_on_fire()
	if (B.combo or 0) > 0 or B.combo_last_t then
		B.combo, B.combo_last_t = 0, nil
	end
end

local function holding_melee()
	local state = managers.player and managers.player:get_current_state()
	return state and state.in_melee and state:in_melee() or false
end

if script == "lib/managers/playermanager" then
	local function nearest_enemy_dis(pos)
		local best
		local mask = managers.slot:get_mask("enemies")
		for _, u_data in pairs(managers.enemy:all_enemies() or {}) do
			local u = u_data.unit
			if alive(u) and u:in_slot(mask) then
				local dmg = u:character_damage()
				if not (dmg and dmg._dead) then
					local brain = u:brain()
					if not (brain and brain.is_hostage and brain:is_hostage()) then
						local d = mvector3.distance(pos, u:position())
						if not best or d < best then best = d end
					end
				end
			end
		end
		return best
	end

	function B.socio_update(t, dt)
		if tweak_data and tweak_data.upgrades and tweak_data.upgrades.killshot_close_panic_range ~= C.panic_range then
			tweak_data.upgrades.killshot_close_panic_range = C.panic_range
		end
		local tier = B.socio_tier()
		local now = Application:time()
		local unit = managers.player and managers.player:player_unit()
		local dmg = alive(unit) and unit:character_damage()
		if tier < 1 or not dmg or dmg:dead() then
			B.socio_hold, B.frenzy, B.combo, B.combo_last_t = 0, 0, 0, nil
			B.hard_level, B._hard_fight, B._hard_quiet = 0, 0, 0
			return
		end
		-- card 1 Frenzy fades a stack a second once you stop killing
		if B.frenzy > 0 and now >= (B._frenzy_decay_t or 0) then
			B.frenzy = B.frenzy - 1
			B._frenzy_decay_t = now + C.frenzy_decay_every
		end
		-- card 5 Combo ends after 5 s without a melee kill
		if B.combo_last_t and now - B.combo_last_t > C.combo_window then
			B.combo, B.combo_last_t = 0, nil
		end
		-- card 3 melee hold
		if tier >= C.hold_tier then
			if holding_melee() then
				B.socio_hold = math.min(B.socio_hold + C.hold_gain * dt, C.hold_max)
				B.socio_release_t = now
			elseif B.socio_hold > 0 and now - B.socio_release_t > C.hold_linger then
				B.socio_hold = math.max(B.socio_hold - C.hold_decay * dt, 0)
			end
		else
			B.socio_hold = 0
		end
		-- card 7 Hardened: time spent fighting with an enemy within 18 m
		if tier >= 7 then
			if now >= (B._hard_next or 0) then
				local step = now - (B._hard_last or now)
				B._hard_last, B._hard_next = now, now + 0.25
				local state = managers.groupai and managers.groupai:state()
				local d = state and state:enemy_weapons_hot() and nearest_enemy_dis(unit:position()) or nil
				if d and d <= C.close_range then
					B._hard_fight, B._hard_quiet = (B._hard_fight or 0) + step, 0
					B.hard_level = math.min(math.floor(B._hard_fight / C.hard_every), C.hard_levels)
				else
					B._hard_quiet = (B._hard_quiet or 0) + step
					if B._hard_quiet >= C.hard_reset then
						B.hard_level, B._hard_fight = 0, 0
					end
				end
			end
		else
			B.hard_level, B._hard_fight, B._hard_quiet = 0, 0, 0
		end
	end

	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_sociopath", function(t, dt)
		local ok, err = pcall(B.socio_update, t, dt or 0)
		if not ok and not B._socio_err then
			B._socio_err = true
			log("[Gilza DS Perk Buffs] Sociopath update error: " .. tostring(err))
		end
	end)

	local orig_resist = PlayerManager.damage_reduction_skill_multiplier
	function PlayerManager:damage_reduction_skill_multiplier(...)
		local m = orig_resist(self, ...)
		if type(m) ~= "number" then return m end
		local ok, tier = pcall(B.socio_tier)
		if ok and tier > 0 then
			m = m * (1 - B.socio_passive(tier)) * (1 - (B.socio_hold or 0))
			m = m * (1 - (B.frenzy or 0) * C.frenzy_dr)
			if tier >= 7 then m = m * (1 - (B.hard_level or 0) * C.hard_step) end
		end
		return m
	end

	-- kills: Frenzy, Tension, Clean Hit, Combo, Dread
	function B.socio_on_kill(killed_unit, variant)
		local tier = B.socio_tier()
		if tier < 1 then return end
		local unit = managers.player:player_unit()
		local dmg = alive(unit) and unit:character_damage()
		if not dmg or dmg:dead() then return end
		local now = Application:time()
		local melee = variant == "melee"
		-- Frenzy: kills within 3 s of the last one stack; melee kills (card 5) and panicking kills (card 9) add one more
		local chain = B._socio_last_kill and now - B._socio_last_kill <= C.frenzy_window
		local gain = (chain and 1 or 0) + ((melee and tier >= 5) and 1 or 0) + ((tier >= 9 and B.socio_panicking(killed_unit)) and 1 or 0)
		B._socio_last_kill = now
		if gain > 0 then B.frenzy = math.min((B.frenzy or 0) + gain, B.socio_frenzy_max()) end
		B._frenzy_decay_t = now + C.frenzy_decay_after
		if dmg:need_revive() then return end
		-- Tension
		local close = tier >= 7 and alive(killed_unit) and mvector3.distance(unit:position(), killed_unit:position()) <= C.close_range
		local share
		if close then
			share = melee and B.sc(C.tension_close_melee, C.tension_close_melee_ds) or B.sc(C.tension_close, C.tension_close_ds)
		else
			share = melee and C.tension_melee or C.tension
		end
		dmg:restore_armor(dmg:_max_armor() * share)
		if melee and tier >= 5 then
			-- Clean Hit
			dmg:restore_health(B.sc(C.clean_heal, C.clean_heal_ds), false)
			-- Combo: melee kills within 5 s of the last melee kill
			if B.combo_last_t and now - B.combo_last_t <= C.combo_window then
				B.combo = math.min((B.combo or 0) + 1, C.combo_max)
			else
				B.combo = 0
			end
			B.combo_last_t = now
		end
	end

	Hooks:PostHook(PlayerManager, "on_killshot", "GilzaDSBuffs_socio_kill", function(self, killed_unit, variant)
		local ok, err = pcall(B.socio_on_kill, killed_unit, variant)
		if not ok and not B._socio_kill_err then
			B._socio_kill_err = true
			log("[Gilza DS Perk Buffs] Sociopath kill error: " .. tostring(err))
		end
	end)

	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_socio_reset", function()
		local session = managers.network and managers.network:session()
		if B._socio_session ~= session then
			B._socio_session = session
			B.frenzy, B.combo, B.combo_last_t, B._socio_last_kill = 0, 0, nil, nil
			B.hard_level, B._hard_fight, B._hard_quiet = 0, 0, 0
			B.socio_panic = {}
		end
	end)

elseif script == "lib/units/beings/player/playerdamage" then
	-- card 3 Thick Skin: a single hit worth more than 20% of your health hurts less
	local function thick_skin(self, attack_data, kind)
		if not (attack_data and type(attack_data.damage) == "number" and attack_data.damage > 0) then return end
		if B.socio_tier() < 3 then return end
		local max = self:_max_health()
		if not max or max <= 0 then return end
		local dr = managers.player:damage_reduction_skill_multiplier(kind)
		if type(dr) ~= "number" then dr = 1 end
		if attack_data.damage * dr > max * C.thick_at then
			attack_data.damage = attack_data.damage * (1 - B.sc(C.thick, C.thick_ds))
		end
	end
	for fn, kind in pairs({ damage_bullet = "bullet", damage_melee = "melee", damage_explosion = "explosion" }) do
		if PlayerDamage[fn] then
			Hooks:PreHook(PlayerDamage, fn, "GilzaDSBuffs_socio_thick_" .. fn, function(self, attack_data)
				pcall(thick_skin, self, attack_data, kind)
			end)
		end
	end

elseif script == "lib/units/enemies/cop/copdamage" then
	local function mine(attack_data)
		local player = managers.player and managers.player:player_unit()
		return alive(player) and attack_data and attack_data.attacker_unit == player
	end
	-- card 9 Dread: more damage to panicking enemies
	local function dread(self, attack_data)
		if not (mine(attack_data) and type(attack_data.damage) == "number") then return end
		if B.socio_tier() < 9 or not B.socio_panicking(self._unit) then return end
		attack_data.damage = attack_data.damage * (1 + B.sc(C.dread, C.dread_ds))
	end
	for _, fn in ipairs({ "damage_bullet", "damage_melee" }) do
		Hooks:PreHook(CopDamage, fn, "GilzaDSBuffs_socio_dread_" .. fn, function(self, attack_data)
			pcall(dread, self, attack_data)
		end)
	end
	-- card 9 Massacre: at high Combo every melee hit is a critical hit (Gilza: crits deal 2.25x)
	local orig_crit = CopDamage.roll_critical_hit
	if orig_crit then
		function CopDamage:roll_critical_hit(attack_data, damage, ...)
			local crit, dmg = orig_crit(self, attack_data, damage, ...)
			if crit then return crit, dmg end
			local ok, force = pcall(function()
				if not (attack_data and attack_data.variant == "melee" and mine(attack_data) and B.socio_massacre()) then return false end
				return not (self.can_be_critical and not self:can_be_critical(attack_data))
			end)
			if ok and force then
				local base = damage or (attack_data and attack_data.damage)
				if type(base) == "number" then
					return true, base * 2.25
				end
			end
			return crit, dmg
		end
	end

elseif script == "lib/units/enemies/cop/copmovement" then
	-- remember who's panicking (the panic animation), for Dread
	Hooks:PostHook(CopMovement, "action_request", "GilzaDSBuffs_socio_panic", function(self, action_desc)
		if action_desc and action_desc.variant == "suppressed_fumble_still" and alive(self._unit) then
			B.socio_panic[self._unit:key()] = Application:time() + C.panic_time
		end
	end)

elseif script == "lib/units/beings/player/states/playerstandard" then
	-- card 5 Combo: the melee weapon charges faster
	local orig_lerp = PlayerStandard._get_melee_charge_lerp_value
	if orig_lerp then
		function PlayerStandard:_get_melee_charge_lerp_value(t, offset, ...)
			local start = self._state_data and self._state_data.melee_start_t
			if start and t then
				local ok, mul = pcall(B.socio_combo_mul)
				if ok and mul and mul > 1 then
					t = start + (t - start) * mul
				end
			end
			return orig_lerp(self, t, offset, ...)
		end
	end

elseif script == "lib/units/weapons/newraycastweaponbase" then
	-- firing a gun ends the Combo
	Hooks:PostHook(NewRaycastWeaponBase, "fire", "GilzaDSBuffs_socio_fire", function(self)
		pcall(function()
			local user = self._setup and self._setup.user_unit
			if alive(user) and user == managers.player:player_unit() and B.socio_tier() >= 5 then
				B.socio_on_fire()
			end
		end)
	end)

elseif script == "lib/tweak_data/skilltreetweakdata" then
	-- the rework replaces Gilza's shared first card (surrounded resistance + melee stacking), the game's Tension /
	-- Clean Hit / close contact upgrades: Frenzy, Tension, Clean Hit and Hardened do that job now
	local REMOVE = {
		[1] = { player_damage_dampener_outnumbered_strong = true, melee_stacking_hit_damage_multiplier_1 = true, melee_stacking_hit_expire_t = true },
		[3] = { player_killshot_regen_armor_bonus = true },
		[5] = { player_melee_kill_life_leech = true, player_damage_dampener_close_contact_1 = true },
		[7] = { player_killshot_close_regen_armor_bonus = true }
	}
	Hooks:PostHook(SkillTreeTweakData, "init", "GilzaDSBuffs_socio_cards", function(self)
		local deck = self.specializations and self.specializations[C.deck]
		if not deck then return end
		for card, names in pairs(REMOVE) do
			local ups = deck[card] and deck[card].upgrades
			if ups then
				for i = #ups, 1, -1 do
					if names[ups[i]] then table.remove(ups, i) end
				end
			end
		end
		-- card 1 had Infiltrator's description: give it its own
		if deck[1] then
			deck[1].desc_id = "menu_deck9_1_desc"
			deck[1].short_id = "menu_deck9_1_short"
		end
	end)
end
