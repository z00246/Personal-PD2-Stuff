if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics
local script = RequiredScript and RequiredScript:lower() or ""

-- Medics dress like the squad they spawn with (Geo 2026-10-23: the ZEAL Medic only shows up in his ZEAL group,
-- instead of Death Sentence putting every Medic in the ZEAL suit). The squad's tier - blue SWAT, FBI, GenSec or ZEAL
-- (Bravo counts as ZEAL) - comes from the units he spawns with, not from the difficulty:
--   host, assault squads: the squad being spawned (who already spawned + what is still to come)
--   host, scripted spawns, and every client: the enemies that spawned close by in the last few seconds, else the
--     enemies on the map (the ones close to him count more), else the difficulty (Normal-Hard blue SWAT, Very
--     Hard-Overkill FBI, Mayhem-Death Wish GenSec, Death Sentence ZEAL)
-- The base game's own assault squads with a Medic are always the difficulty's tier (Overkill FBI, Mayhem-Death Wish
-- GenSec, Death Sentence ZEAL), so those look as before; scripted spawns and test maps (Proving Grounds) now match.
-- Used by zeal_medic.lua (the real ZEAL Medic, host) and looks.lua (the Medic looks).
if not T.SQUAD then
	if not T.FD then
		local ok, data = pcall(dofile, ModPath .. "lua/faction_data.lua")
		if ok and type(data) == "table" then T.FD = data end
	end

	local S = { recent = {}, head = 0, logged = 0 }
	T.SQUAD = S

	local RECENT_N = 32        -- spawns remembered
	local RECENT_T = 8         -- seconds: spawned "with him"
	local RECENT_R2 = 3000 ^ 2 -- within 30 m
	local NEAR_R2 = 2000 ^ 2   -- enemies on the map within 20 m count 4x
	S.DIFF_TIER = { easy = "swat", normal = "swat", hard = "swat", overkill = "fbi", overkill_145 = "fbi", easy_wish = "gensec", overkill_290 = "gensec", sm_wish = "zeal" }
	local ORDER = { "zeal", "gensec", "fbi", "swat" }
	-- base-game names (Restoration's "_sc" copies the same); every ene_zeal_* and ene_bravo_* is ZEAL
	local BY_NAME = {
		ene_swat_1 = "swat", ene_swat_2 = "swat", ene_swat_heavy_1 = "swat", ene_swat_heavy_r870 = "swat", ene_shield_2 = "swat",
		ene_fbi_swat_1 = "fbi", ene_fbi_swat_2 = "fbi", ene_fbi_heavy_1 = "fbi", ene_fbi_heavy_r870 = "fbi", ene_shield_1 = "fbi",
		ene_city_swat_1 = "gensec", ene_city_swat_2 = "gensec", ene_city_swat_3 = "gensec", ene_city_swat_r870 = "gensec",
		ene_city_heavy_g36 = "gensec", ene_city_heavy_r870 = "gensec", ene_city_shield = "gensec", ene_shield_gensec = "gensec"
	}
	-- the DC heists' units only (the faction heists' NYPD/LAPD/Federales copies keep their own Medics)
	local FOLDERS = { "units/payday2/characters/", "units/pd2_dlc_gitgud/characters/", "units/pd2_dlc_drm/characters/", "units/pd2_mod_bravo/characters/" }

	function S.tier_of_path(path)
		if type(path) ~= "string" then return end
		local inside = false
		for _, f in ipairs(FOLDERS) do
			if string.sub(path, 1, #f) == f then inside = true break end
		end
		if not inside then return end
		local name = string.match(path, "([^/]+)$")
		if not name or string.find(name, "medic", 1, true) then return end -- Medics don't count (not even the ZEAL one)
		if string.find(name, "^ene_zeal_") or string.find(name, "^ene_bravo_") then return "zeal" end
		return BY_NAME[(string.gsub(name, "_sc$", ""))]
	end

	-- unit name key (the unit, or the "_husk" copy clients spawn) -> tier
	local K = {}
	local function add(path)
		local tier = S.tier_of_path(path)
		if tier then
			K[Idstring(path):key()] = tier
			K[Idstring(path .. "_husk"):key()] = tier
		end
	end
	local D = T.FD
	for path in pairs(D and D.role or {}) do add(path) end
	for _, new in pairs(D and D.america or {}) do
		if type(new) == "table" then
			for _, p in ipairs(new) do add(p) end
		else
			add(new)
		end
	end
	for _, list in pairs(D and D.units or {}) do
		for _, p in ipairs(list) do add(p) end
	end
	for _, n in ipairs({ "ene_zeal_swat", "ene_zeal_swat_heavy", "ene_zeal_swat_shield", "ene_zeal_tazer", "ene_zeal_cloaker", "ene_zeal_bulldozer", "ene_zeal_bulldozer_2", "ene_zeal_bulldozer_3", "ene_zeal_sniper" }) do
		add("units/pd2_dlc_gitgud/characters/" .. n .. "/" .. n)
	end
	add("units/pd2_dlc_drm/characters/ene_zeal_swat_heavy_sniper/ene_zeal_swat_heavy_sniper")
	S.tier = K

	local function now()
		local tm = TimerManager and TimerManager:game()
		return tm and tm:time() or 0
	end

	local function diff()
		return Global.game_settings and Global.game_settings.difficulty or "overkill"
	end

	-- the tier with the most weight; a tie goes to the difficulty's own tier
	function S.best(v)
		local pref = S.DIFF_TIER[diff()]
		local best, bw = nil, 0
		for _, t in ipairs(ORDER) do
			local w = v[t] or 0
			if w > bw or (w > 0 and w == bw and t == pref) then best, bw = t, w end
		end
		return best
	end

	-- every enemy spawn (CopBase / HuskCopBase post_init, looks.lua): when, where, which tier
	function S.note(unit)
		if not alive(unit) then return end
		local tier = K[unit:name():key()]
		if not tier then return end
		S.head = S.head % RECENT_N + 1
		S.recent[S.head] = { t = now(), pos = unit:position(), tier = tier }
	end

	-- host: the assault squad being spawned right now (set around GroupAIStateBesiege:_perform_group_spawning)
	function S.task_now()
		local task = S.task
		if not task then return end
		local gs = managers.groupai and managers.groupai:state()
		if gs and gs._t == S.task_t then return task end
	end

	-- host: a squad's tier from its spawn task: the members already on the map, and the unit categories still to come
	-- (what each one spawns in this heist's group type)
	function S.task_tier(task)
		local v, any = {}, false
		local grp = task.group
		for _, u_data in pairs(grp and grp.units or {}) do
			local u = u_data.unit
			local t = alive(u) and K[u:name():key()]
			if t then
				v[t] = (v[t] or 0) + 1
				any = true
			end
		end
		local cats = tweak_data.group_ai and tweak_data.group_ai.unit_categories
		local gtype = tweak_data.levels.get_ai_group_type and tweak_data.levels:get_ai_group_type() or "america"
		for cat, info in pairs(task.units_remaining or {}) do
			local n = type(info) == "table" and info.amount or 0
			local c = cats and cats[cat]
			local list = n > 0 and c and c.unit_types and c.unit_types[gtype]
			if list and #list > 0 then
				for _, ids in ipairs(list) do
					local t = K[ids:key()]
					if t then
						v[t] = (v[t] or 0) + n / #list
						any = true
					end
				end
			end
		end
		return any and S.best(v) or nil
	end

	-- the units around a spawn: the ones that spawned with him, else everyone on the map (nearby ones count more)
	function S.context_tier(pos)
		local t_now = now()
		local v, any = {}, false
		for _, e in pairs(S.recent) do
			local age = t_now - e.t
			if age >= 0 and age <= RECENT_T and (not pos or mvector3.distance_sq(e.pos, pos) <= RECENT_R2) then
				v[e.tier] = (v[e.tier] or 0) + 1
				any = true
			end
		end
		if any then return S.best(v), "spawned with him" end
		for _, u_data in pairs(managers.enemy and managers.enemy:all_enemies() or {}) do
			local u = u_data.unit
			local t = alive(u) and K[u:name():key()]
			if t then
				v[t] = (v[t] or 0) + ((pos and mvector3.distance_sq(u:position(), pos) <= NEAR_R2) and 4 or 1)
				any = true
			end
		end
		if any then return S.best(v), "enemies on the map" end
	end

	-- "swat" / "fbi" / "gensec" / "zeal" for a Medic spawning now (unit: the Medic, or pos: where he spawns)
	function T.medic_tier(unit, pos)
		if T._medic_tier_now then return T._medic_tier_now, "decided at spawn" end
		local tier, how
		local task = S.task_now()
		if task then
			tier = S.task_tier(task)
			how = "his squad"
		end
		if not tier then
			if not pos and unit and alive(unit) then pos = unit:position() end
			tier, how = S.context_tier(pos)
		end
		if not tier then tier, how = S.DIFF_TIER[diff()] or "fbi", "difficulty" end
		if S.logged < 6 then
			S.logged = S.logged + 1
			log(T.name .. " Medic dressed as " .. tier .. " (" .. tostring(how) .. ")")
		end
		return tier, how
	end
end

-- host: which assault squad is spawning (its Medic's tier is read from it during produce / post_init)
if script == "lib/managers/group_ai_states/groupaistatebesiege" and GroupAIStateBesiege and not T._squad_hooked then
	T._squad_hooked = true
	Hooks:PreHook(GroupAIStateBesiege, "_perform_group_spawning", "PDTHTactics_squad_task", function(self, spawn_task)
		T.SQUAD.task, T.SQUAD.task_t = spawn_task, self._t
	end)
	Hooks:PostHook(GroupAIStateBesiege, "_perform_group_spawning", "PDTHTactics_squad_task_done", function()
		T.SQUAD.task = nil
	end)
end
