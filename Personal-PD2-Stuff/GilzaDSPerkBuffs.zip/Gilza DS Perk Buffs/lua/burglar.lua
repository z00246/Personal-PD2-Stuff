GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

B.BURGLAR = {
	deck = 7,
	hidden_delay = 1,
	hidden_dodge = 0.05,
	hidden_dodge_ds = 0.10,
	crouch_detect = 0.8,
	ambush = 0.25,
	ambush_ds = 0.35,
	mark_mul = 1.5,
	silent_time = 3,
	silent_weight = 0.2,
	silent_cooldown = 10,
	ecm_mul = 1.25,
	vanish_time = 2,
	vanish_time_ds = 2.5,
	vanish_cooldown = 30,
	vanish_fallback_dodge = 0.3,
	patience_delay = 3,
	patience = 0.3,
	patience_ds = 0.5,
	pellet_window = 0.05
}
B.NET_ID = B.NET_ID or "GilzaDSBuffs"
local C = B.BURGLAR

function B.burglar_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == C.deck) then
		return 0
	end
	return st:get_specialization_value(C.deck, "tiers", "current_tier") or 0
end

local function peer_tier(peer)
	if not peer then return 0 end
	local session = managers.network and managers.network:session()
	if session and peer == session:local_peer() then
		return B.burglar_tier()
	end
	local skills = peer.unpacked_skills and peer:unpacked_skills()
	local spec = skills and skills.specializations
	if spec and tonumber(spec[1]) == C.deck then
		return tonumber(spec[2]) or 0
	end
	return 0
end
B.burglar_peer_tier = peer_tier

local function peer_by_id(id)
	local session = managers.network and managers.network:session()
	return session and id and session:peer(id)
end

local function host_modded()
	if Network:is_server() then return true end
	return B.host_has_mod and managers.network and B.host_has_mod == managers.network:session() and true or false
end

local function weapons_hot()
	local state = managers.groupai and managers.groupai:state()
	return state and state:enemy_weapons_hot() and true or false
end

local function game_t()
	return TimerManager:game():time()
end

-- Vanish (host side): attention objects of these units report nothing to enemies
B.burg_vanish = B.burg_vanish or {}
-- Silent kills (host side): these units are a low priority target
B.burg_weight = B.burg_weight or {}

function B.burglar_start_vanish(unit, duration)
	if not (Network:is_server() and alive(unit) and weapons_hot()) then return end
	B.burg_vanish[unit:key()] = game_t() + duration
	local handler = unit:movement() and unit:movement().attention_handler and unit:movement():attention_handler()
	if handler and handler._call_listeners then
		pcall(handler._call_listeners, handler)
	end
end

function B.burglar_start_silent(unit, duration)
	if not (Network:is_server() and alive(unit)) then return end
	B.burg_weight[unit:key()] = { unit = unit, until_t = game_t() + duration }
end

-- Vanish is now applied per enemy in targeting.lua (enemies within 5m still see the Burglar),
-- so the attention object itself stays untouched
local function wrap_get_attention(orig)
	return orig
end

-- enemies this close always see and shoot a Burglar, whatever the deck's stealth effects
C.close_range = 500
function B.burglar_vanished(unit)
	local e = alive(unit) and B.burg_vanish[unit:key()]
	return e and game_t() < e or false
end

if script == "lib/managers/playermanager" then
	B.burg_hidden = false
	B.burg_charge = 0

	function B.burglar_hidden()
		return B.burg_hidden or Application:time() < (B.burg_forced_until or 0)
	end

	function B.burglar_patience_ratio()
		if B.burglar_tier() < 9 or not B.burg_hidden_since then return 0 end
		local from = math.max(B.burg_hidden_since, B.burg_patience_used or 0)
		return math.clamp((Application:time() - from) / C.patience_delay, 0, 1)
	end

	local orig_dodge = PlayerManager.skill_dodge_chance
	function PlayerManager:skill_dodge_chance(running, crouching, on_zipline, override_armor, ...)
		local chance = orig_dodge(self, running, crouching, on_zipline, override_armor, ...)
		if type(chance) ~= "number" or override_armor then return chance end
		local ok, tier = pcall(B.burglar_tier)
		if ok and tier >= 1 then
			if B.burglar_hidden() then
				chance = chance + (B.on and C.hidden_dodge_ds or C.hidden_dodge)
			end
			if Application:time() < (B.burg_fallback_until or 0) then
				chance = chance + C.vanish_fallback_dodge
			end
		end
		return chance
	end

	local HIDE_STATES = { standard = true, carry = true, bipod = true }

	local function update_hidden(now, dt)
		local tier = B.burglar_tier()
		local unit = managers.player:player_unit()
		if tier < 1 or not alive(unit) then
			B.burg_hidden, B.burg_charge, B.burg_hidden_since = false, 0, nil
			return
		end
		local mov = unit:movement()
		local state = mov and mov:current_state()
		local ok_state = HIDE_STATES[mov:current_state_name() or ""]
		local ducking = mov:crouching()
		local moving = state and state._moving
		local still = ok_state and (ducking or not moving) and not mov:running() and not mov:in_air()
		if still then
			B.burg_charge = B.burg_charge + dt
			if B.burg_charge >= C.hidden_delay and not B.burg_hidden then
				B.burg_hidden = true
				B.burg_hidden_since = now
			end
		else
			B.burg_charge = 0
			B.burg_hidden = false
			if now >= (B.burg_forced_until or 0) then
				B.burg_hidden_since = nil
			end
		end
		if not B.burg_hidden and now < (B.burg_forced_until or 0) then
			B.burg_hidden_since = B.burg_hidden_since or now
		end
	end

	local function set_base_mul(unit, crouched)
		local base = unit:base()
		if not (base and base.set_suspicion_multiplier and base.set_detection_multiplier) then return end
		local want = crouched and C.crouch_detect or 1
		if base._gdsb_burg_mul == want then return end
		base._gdsb_burg_mul = want
		base:set_suspicion_multiplier("gdsb_burglar", want)
		base:set_detection_multiplier("gdsb_burglar", want)
	end

	local function apply_weight(unit, factor)
		local mov = unit:movement()
		local handler = mov and mov.attention_handler and mov:attention_handler()
		local data = handler and handler._attention_data
		if not data then return end
		for _, setting in pairs(data) do
			if type(setting) == "table" and setting._gdsb_f ~= factor then
				if setting._gdsb_base == nil then
					setting._gdsb_base = setting.weight_mul or false
				end
				local base = setting._gdsb_base or nil
				if factor == 1 then
					setting.weight_mul = base
					setting._gdsb_base = nil
					setting._gdsb_f = nil
				else
					setting.weight_mul = (base or 1) * factor
					setting._gdsb_f = factor
				end
			end
		end
	end

	local function update_host()
		if not Network:is_server() then return end
		local session = managers.network and managers.network:session()
		if not session then return end
		-- crouch detection for every Burglar in the lobby
		local me = managers.player:player_unit()
		if alive(me) then
			set_base_mul(me, B.burglar_tier() >= 1 and me:movement():crouching())
		end
		for _, peer in pairs(session:peers() or {}) do
			local u = peer:unit()
			if alive(u) then
				local mov = u:movement()
				local crouched = mov and (mov._pose_code == 2 or (u:anim_data() and u:anim_data().crouch)) or false
				set_base_mul(u, peer_tier(peer) >= 1 and crouched)
			end
		end
		-- silent kill target priority (read by targeting.lua)
		local now = game_t()
		for key, w in pairs(B.burg_weight) do
			if not alive(w.unit) or now >= w.until_t then
				B.burg_weight[key] = nil
			end
		end
		for key, e in pairs(B.burg_vanish) do
			if now >= e then B.burg_vanish[key] = nil end
		end
	end

	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_burglar_update", function(t, dt)
		local now = Application:time()
		local last = B._burg_last or now
		B._burg_last = now
		local step = math.min(math.max(now - last, 0), 0.5)
		pcall(update_hidden, now, step)
		if now >= (B._burg_host_next or 0) then
			B._burg_host_next = now + 0.2
			local ok, err = pcall(update_host)
			if not ok and not B._burg_err then
				B._burg_err = true
				log("[Gilza DS Perk Buffs] Burglar update error: " .. tostring(err))
			end
		end
	end)

	-- client -> host requests
	if LuaNetworking and LuaNetworking.AddReceiveHook then
		LuaNetworking:AddReceiveHook(B.NET_ID, "GilzaDSBuffs_burglar_net", function(data, sender) pcall(function()
			if not Network:is_server() or type(data) ~= "string" then return end
			local kind, value = string.match(data, "^(b%a+):([%d%.]+)$")
			if not kind then return end
			local peer = peer_by_id(tonumber(sender))
			local unit = peer and peer:unit()
			if not alive(unit) then return end
			local tier = peer_tier(peer)
			local dur = math.min(tonumber(value) or 0, 5)
			if kind == "bvanish" and tier >= 7 then
				B.burglar_start_vanish(unit, dur)
			elseif kind == "bsilent" and tier >= 5 then
				B.burglar_start_silent(unit, dur)
			end
		end) end)
	end

	function B.burglar_send_host(msg)
		if LuaNetworking and not Network:is_server() then
			pcall(LuaNetworking.SendToPeer, LuaNetworking, 1, B.NET_ID, msg)
		end
	end

	function B.burglar_on_silent_kill()
		if B.burglar_tier() < 5 then return end
		local now = Application:time()
		if now < (B._burg_silent_cd or 0) then return end
		B._burg_silent_cd = now + C.silent_cooldown
		B.burg_forced_until = Application:time() + C.silent_time
		if not weapons_hot() then return end
		if Network:is_server() then
			B.burglar_start_silent(managers.player:player_unit(), C.silent_time)
			B.burg_silent_until = Application:time() + C.silent_time
		elseif host_modded() then
			B.burglar_send_host("bsilent:" .. C.silent_time)
			B.burg_silent_until = Application:time() + C.silent_time
		end
	end

	function B.burglar_on_armor_break()
		if B.burglar_tier() < 7 or not weapons_hot() then return end
		local now = Application:time()
		if now < (B.burg_vanish_ready or 0) then return end
		B.burg_vanish_ready = now + C.vanish_cooldown
		local dur = B.on and C.vanish_time_ds or C.vanish_time
		B.burg_vanish_until = now + dur
		if Network:is_server() then
			B.burglar_start_vanish(managers.player:player_unit(), dur)
		elseif host_modded() then
			B.burglar_send_host("bvanish:" .. dur)
		else
			B.burg_fallback_until = now + dur
		end
		local unit = managers.player:player_unit()
		if alive(unit) and unit:sound() then
			unit:sound():play("perkdeck_activate", nil, false)
		end
	end

	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_burglar_reset", function()
		local session = managers.network and managers.network:session()
		if B._burg_session ~= session then
			B._burg_session = session
			B.burg_vanish, B.burg_weight = {}, {}
			B.burg_forced_until, B.burg_vanish_until, B.burg_vanish_ready, B.burg_fallback_until, B.burg_patience_used = nil, nil, nil, nil, nil
		end
	end)

elseif script == "lib/units/beings/player/playerdamage" then
	Hooks:PreHook(PlayerDamage, "_calc_armor_damage", "GilzaDSBuffs_burglar_pre", function(self)
		B._burg_pre_armor = self:get_real_armor()
	end)
	Hooks:PostHook(PlayerDamage, "_calc_armor_damage", "GilzaDSBuffs_burglar_post", function(self)
		local before = B._burg_pre_armor
		B._burg_pre_armor = nil
		if before and before > 0 and self:get_real_armor() <= 0 and B.burglar_on_armor_break then
			pcall(B.burglar_on_armor_break)
		end
	end)

elseif script == "lib/units/enemies/cop/copdamage" then
	local function targeting_me(self, player)
		local mov = self._unit:movement()
		local att = mov and mov.attention and mov:attention()
		return att and att.unit == player
	end

	local function bonus(self, attack_data, ranged)
		if not attack_data or type(attack_data.damage) ~= "number" then return end
		local player = managers.player and managers.player:player_unit()
		if not (alive(player) and attack_data.attacker_unit == player) then return end
		local tier = B.burglar_tier()
		if tier < 3 then return end
		local mul = 1
		if not targeting_me(self, player) then
			mul = mul + (B.on and C.ambush_ds or C.ambush)
		end
		if ranged and tier >= 9 and B.burglar_patience_ratio then
			local now = Application:time()
			local used = B.burg_patience_used
			local in_window = used and now - used <= C.pellet_window
			if in_window or B.burglar_patience_ratio() >= 1 then
				if not in_window then
					B.burg_patience_used = now
				end
				mul = mul + (B.on and C.patience_ds or C.patience)
				attack_data.armor_piercing = true
			end
		end
		if mul ~= 1 then
			attack_data.damage = attack_data.damage * mul
		end
	end

	Hooks:PreHook(CopDamage, "damage_bullet", "GilzaDSBuffs_burglar_bullet", function(self, attack_data)
		self._gdsb_burg_alive = not self._dead
		pcall(bonus, self, attack_data, true)
	end)
	Hooks:PreHook(CopDamage, "damage_melee", "GilzaDSBuffs_burglar_melee", function(self, attack_data)
		pcall(bonus, self, attack_data, false)
	end)

	Hooks:PostHook(CopDamage, "damage_bullet", "GilzaDSBuffs_burglar_silent", function(self, attack_data)
		local was_alive = self._gdsb_burg_alive
		self._gdsb_burg_alive = nil
		if not (was_alive and self._dead and attack_data) then return end
		pcall(function()
			local player = managers.player:player_unit()
			if attack_data.attacker_unit ~= player then return end
			local wpn = attack_data.weapon_unit
			local base = alive(wpn) and wpn:base()
			if base and base.got_silencer and base:got_silencer() and B.burglar_on_silent_kill then
				B.burglar_on_silent_kill()
			end
		end)
	end)

elseif script == "lib/units/contourext" then
	local orig_add = ContourExt.add
	function ContourExt:add(type_name, sync, multiplier, ...)
		if sync and type(type_name) == "string" and string.sub(type_name, 1, 5) == "mark_" then
			local ok, tier = pcall(B.burglar_tier)
			if ok and tier >= 3 then
				multiplier = (multiplier or 1) * C.mark_mul
			end
		end
		return orig_add(self, type_name, sync, multiplier, ...)
	end

elseif script == "lib/units/equipment/ecm_jammer/ecmjammerbase" then
	local function extend(self, peer_id)
		if self._gdsb_burg_ecm then return end
		if peer_tier(peer_by_id(peer_id)) < 5 then return end
		self._gdsb_burg_ecm = true
		self._max_battery_life = (self._max_battery_life or 0) * C.ecm_mul
		self._battery_life = self._max_battery_life
		self._duration_multiplier = (self._duration_multiplier or 1) * C.ecm_mul
	end
	Hooks:PostHook(ECMJammerBase, "setup", "GilzaDSBuffs_burglar_ecm", function(self)
		pcall(extend, self, self._owner_id)
	end)
	Hooks:PostHook(ECMJammerBase, "sync_setup", "GilzaDSBuffs_burglar_ecm_sync", function(self, upgrade_lvl, peer_id)
		pcall(extend, self, peer_id)
	end)

elseif script == "lib/units/props/aiattentionobject" then
	B._orig_get_attention = B._orig_get_attention or AIAttentionObject.get_attention
	AIAttentionObject.get_attention = wrap_get_attention(B._orig_get_attention)

elseif script == "lib/units/characters/characterattentionobject" then
	local own = rawget(CharacterAttentionObject, "get_attention")
	if own and own ~= AIAttentionObject.get_attention then
		CharacterAttentionObject.get_attention = wrap_get_attention(own)
	elseif not own and B._orig_get_attention then
		CharacterAttentionObject.get_attention = AIAttentionObject.get_attention
	end
end
