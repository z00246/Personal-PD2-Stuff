GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

-- (7.23 rework, Geo: "what about yakuza now", picked "Rework standard", "Oni (after Last Stand)", "Adrenaline" and
-- "Blood Debt scales") The numbers that were Death Sentence only grow with the difficulty: armor recovery 20% » 25% a
-- card (buffs.lua niche), Bloodied 25% » 35%, Last Stand every 90 » 60 s, Iron Will 15% » 20%, and the bullet
-- resistance from behind 25% » 50%. That last one replaces Gilza's own: Gilza doubles the 0.75 damage multiplier on
-- Death Sentence instead of the 25% it takes off (1 - 0.75 x 2 = -0.5), so there a shot from behind added 0.5 to your
-- damage multiplier, cancelling up to 50% of your other damage resistance.
--  Oni (card 5): for 6 s after Last Stand saves you, 50% more damage, and tasers / Cloaker kicks can't take you down
--   (the same blocks as Muscle's Unstoppable).
--  Adrenaline (card 3): below half health, reload and weapon swap up to 25% faster near death (Bloodied's curve).
--  Blood Debt (card 7): a kill below half health restores 5% armor at half health, up to 15% near death.
B.YAKUZA = {
	deck = 12,
	bloodied_start = 0.5,      -- Bloodied / Adrenaline / Blood Debt work below this much health
	bloodied = 0.25,
	bloodied_ds = 0.35,
	adrenaline = 0.25,
	last_stand_cd = 90,
	last_stand_cd_ds = 60,
	last_stand_invuln = 2,
	oni_time = 6,
	oni_damage = 0.5,
	blood_debt = 0.05,
	blood_debt_max = 0.15,
	blood_debt_health = 0.5,
	iron_will_health = 0.25,
	iron_will = 0.15,
	iron_will_ds = 0.2,
	behind = 0.25,
	behind_ds = 0.5,
	-- (7.24) Jiro's signature (card 9, only as Jiro): Kintsugi - kills below 25% health take 2 s off Last Stand's
	-- cooldown; each kill during Oni adds 1 s to it, up to 4 s more
	kintsugi_health = 0.25, kintsugi_cd = 2, kintsugi_oni = 1, kintsugi_oni_max = 4
}
local C = B.YAKUZA
local GILZA_YAKUZA_KEY = "armor_regen_damage_health_ratio_multiplier"
local GILZA_BEHIND_KEY = "yakuza_behind_player_resist"
local NO_DIRECTION = 69   -- what Gilza sets the last hit direction to once it has been used

local function sc(base, ds) if B.sc then return B.sc(base, ds) end return base end
local function sci(base, ds) if B.sci then return B.sci(base, ds) end return base end
local function live(key, ...) if B.live then B.live("yakuza " .. key, ...) end end

function B.yakuza_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == C.deck) then
		return 0
	end
	return st:get_specialization_value(C.deck, "tiers", "current_tier") or 0
end

function B.yakuza_health_ratio()
	local unit = managers.player and managers.player:player_unit()
	local dmg = alive(unit) and unit:character_damage()
	return dmg and dmg:health_ratio() or 1
end

-- how far below half health you are: 0 at half health or more, 1 near death (Bloodied, Adrenaline, Blood Debt)
function B.yakuza_low()
	local hr = B.yakuza_health_ratio()
	if hr >= C.bloodied_start then return 0 end
	return math.clamp((C.bloodied_start - hr) / C.bloodied_start, 0, 1)
end

-- Bloodied (card 3): up to 25% » 35% more damage near death
function B.yakuza_bloodied_max() return sc(C.bloodied, C.bloodied_ds) end
function B.yakuza_bloodied()
	if B.yakuza_tier() < 3 then return 0 end
	return B.yakuza_low() * B.yakuza_bloodied_max()
end

-- Adrenaline (card 3): up to 25% faster reload and weapon swap near death
function B.yakuza_adrenaline()
	if B.yakuza_tier() < 3 then return 0 end
	return B.yakuza_low() * C.adrenaline
end

-- Last Stand (card 5): once every 90 » 60 s (Mayhem 80, Death Wish 70)
function B.yakuza_last_stand_cd() return sci(C.last_stand_cd, C.last_stand_cd_ds) end
function B.yakuza_last_stand_ready()
	return B.yakuza_tier() >= 5 and Application:time() >= (B.yakuza_ls_ready or 0)
end

-- Oni (card 5): the 6 s after Last Stand saved you
function B.yakuza_oni()
	return Application:time() < (B.yakuza_oni_until or 0)
end

-- Blood Debt (card 7): the share of your armor a kill below half health restores, 5% at half health to 15% near death
function B.yakuza_blood_debt()
	return C.blood_debt + (C.blood_debt_max - C.blood_debt) * B.yakuza_low()
end

-- Iron Will (card 9): 15% » 20% less damage below 25% health; 25% » 50% less bullet damage from behind
function B.yakuza_iron_will() return sc(C.iron_will, C.iron_will_ds) end
function B.yakuza_behind() return sc(C.behind, C.behind_ds) end

if script == "lib/managers/playermanager" then
	-- lets Yakuza heal again: Gilza blocks healing by checking this upgrade, so hide it during heals
	local orig_has = PlayerManager.has_category_upgrade
	function PlayerManager:has_category_upgrade(category, upgrade, ...)
		if B._yak_allow_heal and upgrade == GILZA_YAKUZA_KEY and category == "player" then
			return false
		end
		return orig_has(self, category, upgrade, ...)
	end

	-- the bullet resistance from behind (card 9) and Iron Will
	local orig_resist = PlayerManager.damage_reduction_skill_multiplier
	function PlayerManager:damage_reduction_skill_multiplier(damage_type, ...)
		-- Gilza's PlayerDamage:damage_bullet pre-hook notes where the shot came from just before this is called and
		-- Gilza's version reads it once. Taking it here skips Gilza's branch (the Death Sentence doubling bug) and the
		-- 25% » 50% goes in below instead, added to the rest of your damage resistance the way Gilza adds them.
		local behind = false
		local dir = self._last_damage_taken_direction
		if damage_type == "bullet" and type(dir) == "number" and dir ~= NO_DIRECTION then
			if self:has_category_upgrade("player", GILZA_BEHIND_KEY) then
				behind = dir < 0
				self._last_damage_taken_direction = NO_DIRECTION
			end
		end
		local m = orig_resist(self, damage_type, ...)
		if type(m) ~= "number" then return m end
		if behind then
			local gs = Global and Global.game_settings
			local cap = (gs and gs.difficulty == "sm_wish") and 0.25 or 0.4   -- Gilza's damage resistance cap
			if m > cap then
				local out = math.max(m - B.yakuza_behind(), cap)
				live("behind", "a shot from behind: damage taken x%.3f instead of x%.3f", out, m)
				m = out
			end
		end
		if B.yakuza_tier() >= 9 and B.yakuza_health_ratio() < C.iron_will_health then
			local iw = B.yakuza_iron_will()
			m = m * (1 - iw)
			live("iron will", "below 25%% health: damage taken x%.2f", 1 - iw)
		end
		return m
	end

	-- Blood Debt: kills while below half health restore armor, more the lower your health
	Hooks:PostHook(PlayerManager, "on_killshot", "GilzaDSBuffs_yakuza_blood_debt", function(self)
		if B.yakuza_tier() < 7 then return end
		local unit = self:player_unit()
		local dmg = alive(unit) and unit:character_damage()
		if dmg and not dmg:dead() and dmg:health_ratio() < C.blood_debt_health then
			local share = B.yakuza_blood_debt()
			dmg:restore_armor(dmg:_max_armor() * share)
			live("blood debt", "a kill at %d%% health restored %.1f%% armor", math.floor(dmg:health_ratio() * 100 + 0.5), share * 100)
		end
	end)

	-- (7.24) Jiro's Kintsugi: low-health kills bring Last Stand back sooner, kills during Oni make it last longer
	Hooks:PostHook(PlayerManager, "on_killshot", "GilzaDSBuffs_yakuza_kintsugi", function(self)
		do
			if not (B.sig_active and B.sig_active(C.deck)) then return end
			local unit = self:player_unit()
			local dmg = alive(unit) and unit:character_damage()
			if not dmg or dmg:need_revive() then return end
			local now = Application:time()
			if B.yakuza_oni() then
				if (B._yak_oni_ext or 0) < C.kintsugi_oni_max then
					B._yak_oni_ext = (B._yak_oni_ext or 0) + C.kintsugi_oni
					B.yakuza_oni_until = B.yakuza_oni_until + C.kintsugi_oni
					B.sig_live("kintsugi oni", "a kill during Oni: +%d s (%d of %d)", C.kintsugi_oni, B._yak_oni_ext, C.kintsugi_oni_max)
				end
			elseif dmg:health_ratio() < C.kintsugi_health and (B.yakuza_ls_ready or 0) > now then
				B.yakuza_ls_ready = math.max(now, B.yakuza_ls_ready - C.kintsugi_cd)
				B.sig_live("kintsugi", "a kill below %d%% health: Last Stand %d s sooner", C.kintsugi_health * 100, C.kintsugi_cd)
			end
		end
	end)

	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_yakuza_reset", function()
		local session = managers.network and managers.network:session()
		if B._yak_session ~= session then
			B._yak_session = session
			B.yakuza_ls_ready = nil
			B.yakuza_oni_until = nil
			B._yak_oni_ext = nil
		end
	end)

elseif script == "lib/units/beings/player/playerdamage" then
	local function allow_heal(fn_name)
		local orig = PlayerDamage[fn_name]
		if not orig then return end
		PlayerDamage[fn_name] = function(self, ...)
			if B.yakuza_tier() < 1 then
				return orig(self, ...)
			end
			B._yak_allow_heal = true
			local a, b, c = orig(self, ...)
			B._yak_allow_heal = nil
			return a, b, c
		end
	end
	allow_heal("restore_health")
	allow_heal("set_revive_boost")

	-- Last Stand: a hit that would down you leaves you at 1 health instead; then Oni
	local function last_stand(dmg)
		if dmg:get_real_health() > 0 or dmg._check_berserker_done or dmg._bleed_out then return false end
		if not B.yakuza_last_stand_ready() then return false end
		local mov = dmg._unit:movement()
		if mov and mov.zipline_unit and mov:zipline_unit() then return false end
		local now = Application:time()
		local cd = B.yakuza_last_stand_cd()
		B.yakuza_ls_ready = now + cd
		B.yakuza_oni_until = now + C.oni_time
		B._yak_oni_ext = 0   -- (7.24) Jiro's Kintsugi: a fresh Oni can be stretched again
		dmg:change_health(0.1)
		dmg:restore_armor(dmg:_max_armor())
		if dmg.Gilza_add_damage_invuln_timer then
			dmg:Gilza_add_damage_invuln_timer(C.last_stand_invuln)
		end
		if dmg._unit:sound() then
			dmg._unit:sound():play("perkdeck_activate", nil, false)
		end
		live("last stand", "saved at 1 health, ready again in %ds; Oni for %ds", cd, C.oni_time)
		return true
	end
	local orig_bleed = PlayerDamage._check_bleed_out
	function PlayerDamage:_check_bleed_out(can_activate_berserker, ignore_movement_state, ignore_reduce_revive, ...)
		if last_stand(self) then return end
		return orig_bleed(self, can_activate_berserker, ignore_movement_state, ignore_reduce_revive, ...)
	end

	-- Oni: tasers can't hold you
	local orig_tase = PlayerDamage.damage_tase
	if orig_tase then
		function PlayerDamage:damage_tase(attack_data, ...)
			if B.yakuza_oni() then
				live("oni tase blocked", "a taser's hit did nothing (Oni)")
				return
			end
			return orig_tase(self, attack_data, ...)
		end
	end
	local orig_can_tase = PlayerDamage.can_be_tased
	if orig_can_tase then
		function PlayerDamage:can_be_tased(...)
			if B.yakuza_oni() then return false end
			return orig_can_tase(self, ...)
		end
	end

elseif script == "lib/units/beings/player/playermovement" then
	-- Oni: Cloaker kicks don't take you down, tasers and Cloakers don't try
	local orig_spooc = PlayerMovement.on_SPOOCed
	if orig_spooc then
		function PlayerMovement:on_SPOOCed(enemy_unit, ...)
			if B.yakuza_oni() then
				live("oni kick blocked", "a Cloaker kick did nothing (Oni)")
				return
			end
			return orig_spooc(self, enemy_unit, ...)
		end
	end
	local orig_spooc_ok = PlayerMovement.is_SPOOC_attack_allowed
	if orig_spooc_ok then
		function PlayerMovement:is_SPOOC_attack_allowed(...)
			if B.yakuza_oni() then return false end
			return orig_spooc_ok(self, ...)
		end
	end
	local orig_taser_ok = PlayerMovement.is_taser_attack_allowed
	if orig_taser_ok then
		function PlayerMovement:is_taser_attack_allowed(...)
			if B.yakuza_oni() then return false end
			return orig_taser_ok(self, ...)
		end
	end

elseif script == "lib/units/enemies/cop/copdamage" then
	-- Bloodied: more damage the lower your health; Oni: 50% more for 6 s after Last Stand
	local function bonus(self, attack_data)
		if not attack_data or type(attack_data.damage) ~= "number" then return end
		local player = managers.player and managers.player:player_unit()
		if not (alive(player) and attack_data.attacker_unit == player) then return end
		local bl = B.yakuza_bloodied()
		local mul = 1 + bl
		if bl > 0 then
			live("bloodied", "+%d%% damage at %d%% health", math.floor(bl * 100 + 0.5), math.floor(B.yakuza_health_ratio() * 100 + 0.5))
		end
		if B.yakuza_oni() then
			mul = mul * (1 + C.oni_damage)
			live("oni damage", "+%d%% damage (Oni)", math.floor(C.oni_damage * 100 + 0.5))
		end
		if mul ~= 1 then
			attack_data.damage = attack_data.damage * mul
		end
	end
	for _, fn in ipairs({ "damage_bullet", "damage_melee" }) do
		Hooks:PreHook(CopDamage, fn, "GilzaDSBuffs_yakuza_" .. fn, function(self, attack_data)
			bonus(self, attack_data)
		end)
	end

elseif script == "lib/units/weapons/newraycastweaponbase" then
	local function mine(base)
		local user = base._setup and base._setup.user_unit
		return alive(user) and managers.player and user == managers.player:player_unit() or false
	end
	-- Adrenaline: faster reload the lower your health (the game caches the multiplier for a reload: count it once)
	local orig_reload = NewRaycastWeaponBase.reload_speed_multiplier
	if orig_reload then
		function NewRaycastWeaponBase:reload_speed_multiplier(...)
			local m = orig_reload(self, ...)
			if self._current_reload_speed_multiplier or type(m) ~= "number" then return m end   -- cached: already counted
			local more = mine(self) and B.yakuza_adrenaline() or 0
			if type(more) == "number" and more > 0 then
				live("adrenaline reload", "reload x%.2f", 1 + more)
				return m * (1 + more)
			end
			return m
		end
	end

elseif script == "lib/units/beings/player/states/playerstandard" then
	-- Adrenaline: faster weapon swap the lower your health
	local orig_swap = PlayerStandard._get_swap_speed_multiplier
	if orig_swap then
		function PlayerStandard:_get_swap_speed_multiplier(...)
			local m = orig_swap(self, ...)
			if type(m) ~= "number" then return m end
			local more = B.yakuza_adrenaline()
			if type(more) == "number" and more > 0 then
				live("adrenaline swap", "weapon swap x%.2f", 1 + more)
				return m * (1 + more)
			end
			return m
		end
	end

elseif script == "lib/tweak_data/skilltreetweakdata" then
	-- low-health armor recovery and speed start below 50% from card 1
	Hooks:PostHook(SkillTreeTweakData, "init", "GilzaDSBuffs_yakuza_cards", function(self)
		local deck = self.specializations and self.specializations[C.deck]
		local ups = deck and deck[1] and deck[1].upgrades
		if not ups then return end
		for _, name in ipairs({ "player_armor_regen_damage_health_ratio_threshold_multiplier", "player_movement_speed_damage_health_ratio_threshold_multiplier" }) do
			local found = false
			for _, u in ipairs(ups) do
				if u == name then found = true break end
			end
			if not found then table.insert(ups, name) end
		end
	end)
end
