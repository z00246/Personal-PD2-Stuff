if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics

-- PD:TH Factions is ~900MB, so it isn't auto-updated through BLT (BLT would re-hash the whole
-- folder on every launch, adding ~10s to startup). Instead we compare a tiny version file once
-- per launch and offer the download in the main menu.
local VERSION_URL = "https://raw.githubusercontent.com/z00246/Personal-PD2-Stuff/main/Personal-PD2-Stuff/PDTHFactions.version.txt"
local DOWNLOAD_URL = "https://github.com/z00246/Personal-PD2-Stuff/releases/download/factions/PDTHFactions.zip"

local function local_version()
	local f = io.open("mods/PDTH Factions/mod.txt", "r")
	if not f then return nil end
	local text = f:read("*all")
	f:close()
	return text and string.match(text, '"version"%s*:%s*"([^"]+)"'), text and string.find(text, '"updates"', 1, true) ~= nil
end

local function newer(a, b)
	local function parts(v)
		local t = {}
		for n in string.gmatch(v or "", "%d+") do table.insert(t, tonumber(n)) end
		return t
	end
	local pa, pb = parts(a), parts(b)
	for i = 1, math.max(#pa, #pb) do
		local x, y = pa[i] or 0, pb[i] or 0
		if x ~= y then return x > y end
	end
	return false
end

local function offer(remote, have)
	local title = "PD:TH Factions update"
	local text = have
		and ("A new version of PD:TH Factions is available (" .. remote .. ", you have " .. have .. ").\n\nDownload the zip and extract it into your mods folder, replacing the old PDTH Factions folder.")
		or ("PD:TH Factions (the Restoration enemy pack used by PD:TH Police Tactics) isn't installed. Download it?")
	local buttons = {
		{ text = "Open download", callback = function()
			if Steam and Steam.overlay_activate then
				Steam:overlay_activate("url", DOWNLOAD_URL)
			end
		end },
		{ text = "Later", is_cancel_button = true }
	}
	if QuickMenu then
		QuickMenu:new(title, text, buttons, true)
	end
end

Hooks:Add("MenuManagerOnOpenMenu", "PDTHTactics_factions_version", function(menu_manager, nodes)
	if T._fac_version_checked or not dohttpreq then return end
	T._fac_version_checked = true
	local have, auto = local_version()
	if not have then return end -- not installed: don't nag people who chose not to use it
	if auto then return end -- this copy updates itself through BLT
	pcall(dohttpreq, VERSION_URL, function(data)
		pcall(function()
			local remote = data and string.match(data, "^%s*([%d%.]+)")
			if remote and newer(remote, have) then
				DelayedCalls:Add("PDTHTactics_factions_offer", 1, function() pcall(offer, remote, have) end)
			end
		end)
	end)
end)
