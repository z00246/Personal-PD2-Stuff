GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs

local function card_icon(deck, card)
	local spec = tweak_data.skilltree.specializations[deck]
	local data = spec and spec[card]
	if not (data and data.icon_xy) then return end
	local folder = data.texture_bundle_folder
	local path = folder and ("guis/dlcs/" .. folder .. "/textures/pd2/specialization/icons_atlas") or "guis/textures/pd2/specialization/icons_atlas"
	return path, { data.icon_xy[1] * 64, data.icon_xy[2] * 64, 64, 64 }
end

local function poco_now()
	return managers.player:player_timer():time()
end


-- Combined "less likely to be targeted" multiplier for the local player.
-- Mirrors how enemies weigh targets (PlayerMovement attention settings + CopLogicIdle stand-still/crouch bonus).
function B.targeted_mul()
	local pm = managers.player
	local unit = pm and pm:player_unit()
	if not alive(unit) then return end
	local mul, best, src = 1, 0, nil
	local function take(v, deck, card)
		if type(v) ~= "number" or v == 1 then return end
		mul = mul * v
		local strength = math.abs(1 - v)
		if strength > best then
			best, src = strength, { deck, card }
		end
	end
	local server = Network:is_server()
	local host_mod = server or (B.host_has_mod and managers.network and B.host_has_mod == managers.network:session())
	local brawler = pm:has_category_upgrade("player", "damage_resist_brawler") and pm:has_category_upgrade("player", "uncover_multiplier")
	if not brawler then
		if pm:has_category_upgrade("player", "camouflage_bonus") then
			take(pm:upgrade_value("player", "camouflage_bonus", 1), "optic_illusions")
		end
		if pm:has_category_upgrade("player", "camouflage_multiplier") then
			local v = pm:upgrade_value("player", "camouflage_multiplier", 1)
			if not host_mod then v = 0.85 end
			take(v, 4, 3)
		end
	end
	if pm:has_category_upgrade("player", "uncover_multiplier") then
		take(pm:upgrade_value("player", "uncover_multiplier", 1), 2, 3)
	end
	local state = unit:movement():current_state()
	if state and not state._moving and state.ducking and state:ducking() and pm:has_category_upgrade("player", "stand_still_crouch_camouflage_bonus") then
		take(pm:upgrade_value("player", "stand_still_crouch_camouflage_bonus", 1), 7, 3)
	end
	if Application:time() < (B.burg_silent_until or 0) and B.BURGLAR then
		take(B.BURGLAR.silent_weight, 7, 5)
	end
	if not src then return 1 end
	return mul, src[1], src[2]
end

local active = {}

local function skill_icon(skill_id)
	local data = tweak_data.skilltree.skills and tweak_data.skilltree.skills[skill_id]
	if not (data and data.icon_xy) then return end
	return "guis/textures/pd2/skilltree_2/icons_atlas_2", { data.icon_xy[1] * 80, data.icon_xy[2] * 80, 80, 80 }
end

local function show(key, deck, card, good, text, until_t, ratio)
	local poco = rawget(_G, "PocoHud3")
	if not (poco and poco.Buff3 and poco.buffs) then return end
	local icon, rect
	if type(deck) == "string" then
		icon, rect = skill_icon(deck)
	else
		icon, rect = card_icon(deck, card)
	end
	local data = { key = key, good = good, icon = icon, iconRect = rect, text = text or "" }
	if ratio then
		data.st, data.et = math.clamp(ratio, 0, 1), 1
	else
		local remaining = until_t - Application:time()
		if remaining <= 0 then return end
		local now = poco_now()
		data.st, data.et = now, now + remaining
		local existing = poco.buffs[key]
		if existing and existing.data and existing.data.et and math.abs(existing.data.et - data.et) < 0.15 then
			active[key] = true
			return
		end
	end
	poco:Buff3(data)
	active[key] = true
end

local function hide(key)
	if not active[key] then return end
	active[key] = nil
	local poco = rawget(_G, "PocoHud3")
	if poco and poco.RemoveBuff then poco:RemoveBuff(key) end
end

local function timed(key, deck, card, good, until_t, text)
	if until_t and until_t > Application:time() then
		show(key, deck, card, good, text, until_t)
	else
		hide(key)
	end
end

function B.update_poco()
	local now = Application:time()

	if B.rogue_tier and B.rogue_tier() >= 3 and now < (B.rogue_stack_until or 0) and (B.rogue_stacks or 0) > 0 then
		show("gdb_rogue_stacks", 4, 3, true, "x" .. B.rogue_stacks, B.rogue_stack_until)
	else
		hide("gdb_rogue_stacks")
	end
	timed("gdb_rogue_riposte", 4, 7, true, B.rogue_riposte_until)

	if B.muscle_tier and B.muscle_tier() >= 1 and (B.rage or 0) > 0 then
		local max = B.on and B.MUSCLE.max_stacks_ds or B.MUSCLE.max_stacks
		show("gdb_muscle_rage", 2, 1, true, "x" .. B.rage, nil, B.rage / max)
	else
		hide("gdb_muscle_rage")
	end
	timed("gdb_muscle_unstoppable", 2, 9, true, B._unstoppable_until)

	timed("gdb_crook_counter", 6, 7, true, B.crook_counter_until)
	timed("gdb_crook_slip", 6, 9, true, B.crook_slip_until)

	timed("gdb_cc_rally", 1, 5, true, B.cc_rally_until)

	if (B.hitman_overflow or 0) > 0 then
		local cap = B.on and B.HITMAN_OVERFLOW.ds or B.HITMAN_OVERFLOW.normal
		show("gdb_hitman_overflow", 5, 3, true, tostring(math.floor(B.hitman_overflow * 10 + 0.5)), nil, B.hitman_overflow / cap)
	else
		hide("gdb_hitman_overflow")
	end

	local crit = B.gambler_crit or 0
	if crit ~= 0 then
		local c = B.crit_values and B.crit_values() or { cap = 0.3 }
		show("gdb_gambler_crit", 10, 1, crit > 0, string.format("%+d%%", math.floor(crit * 100 + (crit > 0 and 0.5 or -0.5))), nil, math.abs(crit) / c.cap)
	else
		hide("gdb_gambler_crit")
	end

	if B.burglar_tier and B.burglar_tier() >= 1 and B.burglar_hidden and B.burglar_hidden() then
		show("gdb_burg_hidden", 7, 1, true, "", nil, 1)
	else
		hide("gdb_burg_hidden")
	end
	local patience = B.burglar_patience_ratio and B.burglar_patience_ratio() or 0
	if patience > 0 then
		show("gdb_burg_patience", 7, 9, true, patience >= 1 and "!" or "", nil, patience)
	else
		hide("gdb_burg_patience")
	end
	timed("gdb_burg_vanish", 7, 7, true, B.burg_vanish_until)

	local tmul, tdeck, tcard = B.targeted_mul()
	if tmul and math.abs(tmul - 1) > 0.001 then
		local pct = math.floor((1 - tmul) * 100 + 0.5)
		local text = pct > 0 and ("-" .. pct .. "%") or ("+" .. (-pct) .. "%")
		local key_text = text .. tostring(tdeck) .. tostring(tcard)
		if B._targeted_last ~= key_text then
			hide("gdb_targeted")
			B._targeted_last = key_text
		end
		show("gdb_targeted", tdeck, tcard, tmul < 1, text, nil, 1)
	else
		B._targeted_last = nil
		hide("gdb_targeted")
	end

	if (B.socio_hold or 0) > 0 then
		show("gdb_socio_hold", 9, 3, true, math.floor(B.socio_hold * 100 + 0.5) .. "%", nil, B.socio_hold / B.SOCIO.hold_max)
	else
		hide("gdb_socio_hold")
	end
end

Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_poco", function(t)
	if t and B._poco_next and t < B._poco_next then return end
	B._poco_next = (t or 0) + 0.2
	local ok, err = pcall(B.update_poco)
	if not ok and not B._poco_err then
		B._poco_err = true
		log("[Gilza DS Perk Buffs] PocoHud buffs error: " .. tostring(err))
	end
end)
