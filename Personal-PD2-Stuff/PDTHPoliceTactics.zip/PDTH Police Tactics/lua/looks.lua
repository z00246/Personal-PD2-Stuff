if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics
local script = RequiredScript and RequiredScript:lower() or ""

-- Client looks. Whenever the enemies in your game are the base game's ones (you joined someone else's lobby, or you
-- host but someone lacks PD:TH Factions), your game dresses each of them in the PD:TH/Restoration look the faction swap
-- would have picked for this heist and difficulty. Only on your screen: the enemy itself (hitboxes, animations, AI,
-- network) stays the game's own. Its meshes are hidden and a visual-only copy of the Restoration enemy (a "_look"
-- unit: model, materials, sequences, no AI, no network, no hitboxes) is linked onto its skeleton bone by bone - the way
-- the game attaches outfits and Restoration attaches its separate heads. Needs PD:TH Factions and BeardLib.
--   looks_test.txt in this mod's folder: test switch - while hosting, the faction swap is off so you see the looks
--   looks_off.txt in this mod's folder: looks off

if not T.FD then
	local ok, data = pcall(dofile, ModPath .. "lua/faction_data.lua")
	if ok and type(data) == "table" then T.FD = data end
end
if not T.LOOKS then pcall(dofile, ModPath .. "lua/looks_data.lua") end
if not T.LOOKS_HELMETS then pcall(dofile, ModPath .. "lua/looks_helmets.lua") end
if not T.LOOKS_POP then pcall(dofile, ModPath .. "lua/looks_pop.lua") end
local D, LD = T.FD, T.LOOKS
if not (D and LD and LD.look) then return end

local function file_exists(name)
	local f = io.open(ModPath .. name, "r")
	if f then f:close() return true end
	return false
end
if T.looks_test == nil then T.looks_test = file_exists("looks_test.txt") end
if T.looks_off == nil then T.looks_off = file_exists("looks_off.txt") end

local UNIT = Idstring("unit")
local IDS_MODEL = Idstring("model")
local IDS_ROOT = Idstring("root_point")

-- the same picks as factions.lua / zeal_medic.lua (their tables are local there)
local DIFF_ORDER = { "sm_wish", "overkill_290", "easy_wish", "overkill_145", "overkill", "hard", "normal", "easy" }
local TASER_GROUPS = { america = true, fbi = true, nypd = true, lapd = true }
local DOZERS = {
	["units/payday2/characters/ene_bulldozer_1/ene_bulldozer_1"] = "units/payday2/characters/ene_bulldozer_1_sc/ene_bulldozer_1_sc",
	["units/payday2/characters/ene_bulldozer_2/ene_bulldozer_2"] = "units/payday2/characters/ene_bulldozer_2_sc/ene_bulldozer_2_sc",
	["units/payday2/characters/ene_bulldozer_3/ene_bulldozer_3"] = "units/payday2/characters/ene_bulldozer_3_sc/ene_bulldozer_3_sc",
	["units/pd2_dlc_gitgud/characters/ene_zeal_bulldozer/ene_zeal_bulldozer"] = "units/pd2_dlc_gitgud/characters/ene_zeal_bulldozer_sc/ene_zeal_bulldozer_sc",
	["units/pd2_dlc_gitgud/characters/ene_zeal_bulldozer_2/ene_zeal_bulldozer_2"] = "units/pd2_dlc_gitgud/characters/ene_zeal_bulldozer_2_sc/ene_zeal_bulldozer_2_sc",
	["units/pd2_dlc_gitgud/characters/ene_zeal_bulldozer_3/ene_zeal_bulldozer_3"] = "units/pd2_dlc_gitgud/characters/ene_zeal_bulldozer_3_sc/ene_zeal_bulldozer_3_sc"
}
local ZEAL_SNIPER = "units/pd2_dlc_gitgud/characters/ene_zeal_sniper/ene_zeal_sniper"
local ZEAL_SNIPER_FROM = { ["units/payday2/characters/ene_sniper_1/ene_sniper_1"] = true, ["units/payday2/characters/ene_sniper_2/ene_sniper_2"] = true }
local ZEAL_TAZER_FROM = "units/pd2_dlc_gitgud/characters/ene_zeal_tazer/ene_zeal_tazer"
local ZEAL_TAZER = "units/pd2_dlc_gitgud/characters/ene_zeal_tazer_sc/ene_zeal_tazer_sc"
local TAZER = "units/payday2/characters/ene_tazer_1_sc/ene_tazer_1_sc"
local ZEAL_MEDIC = "units/pd2_dlc_gitgud/characters/ene_zeal_medic/ene_zeal_medic"
local MEDICS = { ["units/payday2/characters/ene_medic_m4/ene_medic_m4"] = true, ["units/payday2/characters/ene_medic_r870/ene_medic_r870"] = true }
local SHORT_BODY = { Idstring("g_body_short"), Idstring("g_body_b_short"), Idstring("g_body_short_fbi"), Idstring("g_body_b_short_fbi") }

-- Our own Medics by difficulty (assets/units/pdth_medics: the game's Medic wearing the SWAT / FBI / GenSec suit of
-- Restoration's SWAT atlas): DC-style heists only. Death Sentence keeps the ZEAL Medic; faction heists their faction's.
local MEDIC_TIER = { easy = "swat", normal = "swat", hard = "swat", overkill = "fbi", overkill_145 = "fbi", easy_wish = "gensec", overkill_290 = "gensec" }
local function medic_look(tier) return "units/pdth_medics/ene_medic_" .. tier .. "/ene_medic_" .. tier end
-- Each tier wears its own helmet (in the Medic's two helmet objects) and loses it as its own debris helmet:
-- Normal - Hard the blue SWATs' PASGT in black, Very Hard - Overkill the FBI helmet in tan, Mayhem - Death Wish the
-- GenSec helmet in Medic red and white
local function medic_gear(path) return { gear = path, gear_obj = "g_helmet_lod", gear_n = 2 } end
local MEDIC_GEARS = {
	swat = medic_gear("units/pdth_medics/ene_acc_sw_medic_helmet/ene_acc_sw_medic_helmet"),
	fbi = medic_gear("units/pdth_medics/ene_acc_fbi_medic_helmet/ene_acc_fbi_medic_helmet"),
	gensec = medic_gear("units/pdth_medics/ene_acc_gs_medic_helmet/ene_acc_gs_medic_helmet") }

-- base-game enemy (its unit or the "_husk" copy clients spawn) -> its path
if not T._look_keys then
	local K = { van = {}, joints = {} }
	local function add(path)
		K.van[Idstring(path):key()] = path
		K.van[Idstring(path .. "_husk"):key()] = path
	end
	for path in pairs(D.role or {}) do add(path) end
	for path in pairs(D.america or {}) do add(path) end
	for _, map in pairs(D.america_diff or {}) do
		for path in pairs(map) do add(path) end
	end
	for path in pairs(DOZERS) do add(path) end
	for path in pairs(MEDICS) do add(path) end
	for i, j in ipairs(LD.joints) do K.joints[i] = Idstring(j) end
	T._look_keys = K
end
local K = T._look_keys

T.look = T.look or { ready = {} }
local LK = T.look

local function is_loaded(name)
	local dyn = managers.dyn_resource
	if not (dyn and dyn.has_resource) then return false end
	return dyn:has_resource(UNIT, Idstring(name), dyn.DYN_RESOURCES_PACKAGE) and true or false
end

local function unit_ready(name)
	if not name then return false end
	if LK.ready[name] then return true end
	local ok, r = pcall(is_loaded, name)
	if ok and r then LK.ready[name] = true return true end
	return false
end

function T.look_ready(path)
	local d = LD.look[path]
	return d ~= nil and unit_ready(path .. "_look") or false
end

local function diff_now()
	return Global.game_settings and Global.game_settings.difficulty or "overkill"
end

local function vanilla_group()
	return tweak_data.levels.get_ai_group_type and tweak_data.levels:get_ai_group_type() or "america"
end

-- this difficulty's list, or the closest lower difficulty's (as factions.lua), without the dual-pistol veterans
-- (factions.lua strips those from the shared data too; this doesn't depend on which file ran first)
local function diff_list(f, role, diff)
	local start = false
	for _, d in ipairs(DIFF_ORDER) do
		if d == diff then start = true end
		if start then
			local list = D.faction[f] and D.faction[f][d] and D.faction[f][d][role]
			if list and #list > 0 then
				local out = {}
				for _, p in ipairs(list) do
					if type(p) == "string" and not string.find(p, "veteran", 1, true) then out[#out + 1] = p end
				end
				if #out > 0 then return out end
			end
		end
	end
end

-- every Restoration enemy the faction swap could put in place of this base-game one, in this heist and difficulty
local function picks_for(path, f, diff, group, ds)
	local role = D.role[path]
	if role and f then
		local list = diff_list(f, role, diff)
		if list then return list end
	end
	if role and TASER_GROUPS[group] then
		if DOZERS[path] then return { DOZERS[path] } end
		if ZEAL_SNIPER_FROM[path] and ds then return { ZEAL_SNIPER } end
		if role == "taser" or role == "ttaser" then return { path == ZEAL_TAZER_FROM and ZEAL_TAZER or TAZER } end
	end
	if f then return end
	if MEDICS[path] and ds then return { ZEAL_MEDIC } end
	if group ~= "america" then return end
	if MEDICS[path] and LK.medic_pack and MEDIC_TIER[diff] then return { medic_look(MEDIC_TIER[diff]) } end
	local new = D.america_diff and D.america_diff[diff] and D.america_diff[diff][path] or D.america[path]
	if type(new) == "table" then return new end
	return new and { new } or nil
end

function T.look_pick(path)
	local list = picks_for(path, LK.faction, diff_now(), LK.group or vanilla_group(), T.is_ds())
	if not list or #list == 0 then return end
	local pick = list[math.random(#list)]
	if type(pick) ~= "string" or string.find(pick, "veteran", 1, true) then return end
	return pick
end

-- the look this enemy gets (picked once, the first time anyone asks: its gun or its spawn)
function T.look_choice(unit)
	local base = alive(unit) and unit:base()
	if not base then return end
	if base._pdth_look_pick == nil then
		base._pdth_look_pick = false
		if LK.on and not T.looks_off then
			local path = K.van[unit:name():key()]
			local pick = path and T.look_pick(path)
			if pick and T.look_ready(pick) then base._pdth_look_pick = pick end
		end
	end
	return base._pdth_look_pick or nil
end

-- loading screen: queue every look this heist and difficulty can use (loaded with the faction units, before the
-- world exists - see factions.lua). Clients and hosts alike: the host shows them when its faction swap is off.
function T.looks_preload()
	if LK.preloaded then return end
	LK.preloaded = true
	if T.looks_off or not (BeardLib and T.faction_queue_asset) then return end
	-- PD:TH Factions installed? (its files are BeardLib entries; same check as factions.lua's db_has)
	local fm = BeardLib.Managers and BeardLib.Managers.File
	local function db_has(path)
		local ids = Idstring(path)
		if fm and fm.Has then
			local ok, r = pcall(fm.Has, fm, UNIT, ids)
			if ok and r then return true end
		end
		return DB:has(UNIT, ids) and true or false
	end
	if not db_has("units/payday2/characters/ene_swat_1_sc/ene_swat_1_sc") then
		log(T.name .. " looks: PD:TH Factions not found, looks off")
		return
	end
	-- our Medics: the three looks, and the host's faction swap leaves Medics to the looks
	LK.medic_pack = db_has(medic_look("swat") .. "_look") and db_has(medic_look("fbi") .. "_look") and db_has(medic_look("gensec") .. "_look")
	if LK.medic_pack then
		for _, t in ipairs({ "swat", "fbi", "gensec" }) do LD.look[medic_look(t)] = LD.look[medic_look(t)] or MEDIC_GEARS[t] end
	end
	T.look_medics = LK.medic_pack or nil
	LK.faction = T.level_faction()
	-- NYPD/LAPD aren't part of the looks (Geo): those heists get the default looks like any other
	if LK.faction == "nypd" or LK.faction == "lapd" then LK.faction = nil end
	LK.group = vanilla_group()
	local diff, ds = diff_now(), T.is_ds()
	local want, seen = {}, {}
	for _, path in pairs(K.van) do
		if not seen[path] then
			seen[path] = true
			for _, p in ipairs(picks_for(path, LK.faction, diff, LK.group, ds) or {}) do
				if LD.look[p] and not string.find(p, "veteran", 1, true) then want[p] = true end
			end
		end
	end
	local n, queued = 0, {}
	local function q(name)
		if name and not queued[name] then
			queued[name] = true
			pcall(T.faction_queue_asset, Idstring(name), name)
		end
	end
	for p in pairs(want) do
		n = n + 1
		local d = LD.look[p]
		q(p .. "_look")
		q(d.head)
		q(d.gear)
		local gun = D.unit_weapon and D.unit_weapon[p]
		q(gun and T.LOOK_GUNS and T.LOOK_GUNS[gun] or gun)
	end
	LK.on = n > 0
	log(T.name .. " looks: level=" .. tostring(Global.level_data and Global.level_data.level_id) .. " faction=" .. tostring(LK.faction)
		.. " group=" .. tostring(LK.group) .. " diff=" .. tostring(diff) .. " looks=" .. n .. (T.looks_test and " (TEST: faction swap off)" or ""))
end

local function bodies_off(u)
	for i = 0, u:num_bodies() - 1 do
		local b = u:body(i)
		if b then b:set_enabled(false) end
	end
end

-- spawn a visual unit and link it onto the enemy's skeleton (the game's ManageSpawnedUnits:spawn_unit + _link_joints)
local function link_onto(parent, name)
	local root = parent:get_object(IDS_ROOT)
	if not root then return end
	local u = safe_spawn_unit(Idstring(name), root:position(), root:rotation())
	if not u then return end
	bodies_off(u)
	local ud = u:unit_data()
	if ud then ud.parent_unit = parent end
	parent:link(IDS_ROOT, u, u:orientation_object():name())
	local J = K.joints
	for i = 2, #J do
		local po, co = parent:get_object(J[i]), u:get_object(J[i])
		if po and co then
			co:set_local_position(Vector3())
			co:set_local_rotation(Rotation())
			co:link(po)
		end
	end
	parent:set_moving()
	return u
end

local function drop(u)
	if u and alive(u) then
		u:unlink()
		u:set_visible(false)
		u:set_enabled(false)
		u:set_slot(0)
	end
end

-- outlines. The game: each linked child has its own ContourExt that the parent forwards to (apply_to_linked).
-- Smooth Contours (installed here) replaces that: the parent sets the materials of its children itself.
local function contour_parent_mode()
	return ContourExt ~= nil and ContourExt.add_child_unit ~= nil and ContourExt._get_child_units ~= nil
end

local function hook_contour_children()
	if ContourExt._pdth_looks_children then return end
	ContourExt._pdth_looks_children = true
	local orig = ContourExt._get_child_units
	ContourExt._get_child_units = function(self, ...)
		local units = orig(self, ...)
		local base = alive(self._unit) and self._unit:base()
		local look = type(base) == "table" and base._pdth_look
		if look and alive(look) and type(units) == "table" then table.insert(units, look) end
		return units
	end
end

-- the look's materials follow the enemy's: normal, or the "_contour" set while outlined
local function sync_material(base, u, done)
	local ub = u and alive(u) and u:base()
	if not (ub and ub.swap_material_config and ub.is_in_original_material) then return end
	local want_original = base._is_in_original_material ~= false
	if ub:is_in_original_material() ~= want_original then ub:swap_material_config(done) end
end

function T.look_apply(unit)
	local base = alive(unit) and unit:base()
	if not base or base._pdth_look ~= nil then return end
	base._pdth_look = false
	local pick = T.look_choice(unit)
	if not pick then return end
	local d = LD.look[pick]
	local look = link_onto(unit, pick .. "_look")
	if not look then return end
	base._pdth_look = look
	base._pdth_look_path = pick
	-- the enemy's own meshes off (its hitboxes, animations and attachments stay)
	for _, o in ipairs(unit:get_objects_by_type(IDS_MODEL)) do o:set_visibility(false) end
	-- Restoration's gear/head variations, as the faction swap runs them (factions.lua run_sequences)
	local dmg = look:damage()
	local seq = D.enemy_seq and D.enemy_seq[pick]
	if seq and dmg and dmg:has_sequence(seq) then dmg:run_sequence_simple(seq) end
	if d.head and unit_ready(d.head) then
		local head = link_onto(unit, d.head)
		if head then
			base._pdth_look_head = head
			local short = false
			for _, n in ipairs(SHORT_BODY) do
				local o = look:get_object(n)
				if o and o:visibility() then short = true break end
			end
			local hd = head:damage()
			if hd then
				local arms = short and "arms_short_on" or "arms_short_off"
				if hd:has_sequence(arms) then hd:run_sequence_simple(arms) end
				local hs = D.head_seq and D.head_seq[pick]
				if hs and hd:has_sequence(hs) then hd:run_sequence_simple(hs) end
			end
			bodies_off(head)
		end
	end
	bodies_off(look) -- the sequences can switch hitboxes on
	-- outlines (marked, converted, ...); heads stay without, as with the faction swap (factions.lua)
	local pc, lc = unit:contour(), look:contour()
	if pc and contour_parent_mode() then
		-- Smooth Contours: the enemy's own outline sets its children's materials (its _get_child_units, hooked below);
		-- the look only has to be in the same material state (normal or "_contour") as the enemy
		hook_contour_children()
		base._pdth_look_parent_mode = true
		sync_material(base, look, function()
			local c = alive(unit) and unit:contour()
			if c and c.update_materials then c:update_materials() end
		end)
		pc:add_child_unit(look)
	elseif pc and lc then
		-- the game's own outlines: a child outline that the enemy's forwards to (ManageSpawnedUnits:spawn_unit)
		lc:set_is_child(true)
		for _, c in ipairs(pc:contour_list() or {}) do lc:add(c.type, false, nil, c.color) end
	end
	local vis = base._visibility_state ~= false
	look:set_visible(vis)
	if base._pdth_look_head then base._pdth_look_head:set_visible(vis) end
	if not LK.first then
		LK.first = true
		log(T.name .. " first look: " .. pick)
	end
end

function T.look_remove(base)
	if not base then return end
	drop(base._pdth_look_head)
	drop(base._pdth_look)
	base._pdth_look_head = nil
	if base._pdth_look then base._pdth_look = false end
end

local function safe(fn, ...)
	local ok, err = pcall(fn, ...)
	if not ok and not LK.err_logged then
		LK.err_logged = true
		log(T.name .. " looks error: " .. tostring(err))
	end
end

-- Bulldozers: their faceplate / visor breaking is carried over as the look's OWN break, step by step. By name alone
-- the black Dozers (ene_bulldozer_2_sc, ene_zeal_bulldozer_3_sc) kept their whole plate and visor - theirs have other
-- names - and the Restoration visors their outline-only glass layer. Every base-game Dozer breaks the same way, so the
-- step shows in which of its meshes changes: plate (g_helmet_plate hidden), crack (g_helmet_glass_crk shown), shatter
-- (g_helmet_glass_crk hidden). Data: lua/looks_helmets.lua (icons_work/pdth_looks/dozer_helmets.py).
local HELM_BASE, HELM_TRIG, HELM_LOOK = {}, {}, {}
for _, n in ipairs({ "g_helmet_plate", "g_helmet_plate_lod1", "g_helmet_glass", "g_helmet_glass_lod1", "g_helmet_glass_crk", "g_helmet_glass_crk_lod1" }) do
	HELM_BASE[Idstring(n):key()] = true
end
HELM_TRIG[Idstring("g_helmet_plate"):key()] = { [false] = "plate" }
HELM_TRIG[Idstring("g_helmet_glass_crk"):key()] = { [true] = "crack", [false] = "shatter" }
for path, steps in pairs(T.LOOKS_HELMETS or {}) do
	local s = {}
	for step, list in pairs(steps) do
		local l = {}
		for i, t in ipairs(list) do l[i] = { Idstring(t[1]), t[2] } end
		s[step] = l
	end
	HELM_LOOK[path] = s
end

local function helmet_step(base, look, steps, step)
	local done = base._pdth_helmet_steps or {}
	base._pdth_helmet_steps = done
	if done[step] then return end
	done[step] = true
	for _, t in ipairs(steps[step] or {}) do
		local o = look:get_object(t[1])
		if o then o:set_visibility(t[2]) end
	end
end

-- a sequence on the enemy shows/hides one of its meshes (Bulldozer visor/faceplate/armour breaking, gore): the same
-- on the look's mesh of that name (a Dozer's helmet: its own break, above), and the enemy's own stays hidden.
-- (Core sequence manager, ObjectElement:set_object.)
local function mirror_objects(unit, objects, value)
	if not alive(unit) then return end
	local base = unit:base()
	local look = base and base._pdth_look
	if not (look and alive(look)) then return end
	local head = base._pdth_look_head
	local steps = HELM_LOOK[base._pdth_look_path]
	local v = value and true or false
	for _, obj in ipairs(objects) do
		local name = obj:name()
		local k = name:key()
		if steps and HELM_BASE[k] then
			local step = HELM_TRIG[k] and HELM_TRIG[k][v]
			if step then helmet_step(base, look, steps, step) end
		else
			local lo = look:get_object(name) or (head and alive(head) and head:get_object(name))
			if lo then lo:set_visibility(v) end
		end
		obj:set_visibility(false)
	end
end

local function hook_sequences()
	if T._look_seq_hooked then return end
	local mods = core and rawget(core, "__modules")
	local SM = mods and mods.CoreSequenceManager
	local OE = SM and rawget(SM, "ObjectElement")
	if not (OE and OE.set_object) then return end
	T._look_seq_hooked = true
	local orig = OE.set_object
	OE.set_object = function(self, unit, objects, func_name, value, ...)
		orig(self, unit, objects, func_name, value, ...)
		if func_name == "set_visibility" and type(objects) == "table" then
			local ok, err = pcall(mirror_objects, unit, objects, value)
			if not ok and not LK.seq_err then
				LK.seq_err = true
				log(T.name .. " looks sequence mirror error: " .. tostring(err))
			end
		end
	end
end

local function look_gear(unit)
	local base = unit:base()
	local look = base and base._pdth_look
	if not (look and alive(look)) then return end
	return LD.look[base._pdth_look_path], look
end

if script == "lib/setups/gamesetup" then
	Hooks:PostHook(GameSetup, "load_packages", "PDTHTactics_looks_preload", function()
		safe(T.looks_preload)
	end)
	Hooks:Add("GameSetupUpdate", "PDTHTactics_looks_notice", function()
		if LK.noticed then return end
		if not T.looks_test then LK.noticed = true return end
		local t = Application:time()
		LK.notice_t = LK.notice_t or t
		if t - LK.notice_t < 6 or not managers.chat then return end
		LK.noticed = true
		pcall(function()
			managers.chat:_receive_message(1, T.name, "Looks test is on (looks_test.txt): the faction swap is off and the enemies get their looks on your screen.", T.color or Color.white)
		end)
	end)

elseif script == "lib/units/enemies/cop/copbase" then
	-- outlines for our Medic looks (their "_contour" material configs, as factions.lua does for its units)
	if CopBase._material_translation_map then
		for _, t in ipairs({ "swat", "fbi", "gensec" }) do
			local n, c = Idstring(medic_look(t)), Idstring(medic_look(t) .. "_contour")
			CopBase._material_translation_map[tostring(n:key())] = c
			CopBase._material_translation_map[tostring(c:key())] = n
		end
	end
	-- the host's own enemies: only those the faction swap left as they are (it was off, or had nothing for them)
	Hooks:PostHook(CopBase, "post_init", "PDTHTactics_looks_host", function(self)
		hook_sequences()
		safe(T.look_apply, self._unit)
	end)
	Hooks:PreHook(CopBase, "pre_destroy", "PDTHTactics_looks_remove", function(self)
		safe(T.look_remove, self)
	end)
	-- distance/occlusion LOD hides and shows the enemy: the look with it
	Hooks:PostHook(CopBase, "_update_visibility_state", "PDTHTactics_looks_vis", function(self, state)
		local l, h = self._pdth_look, self._pdth_look_head
		if l and alive(l) then l:set_visible(state and true or false) end
		if h and alive(h) then h:set_visible(state and true or false) end
	end)
	-- Smooth Contours: the enemy swapped to/from its outline materials -> the look too, then the outline re-reads them
	-- (ContourSwapBase kept the unhooked CopBase.swap_material_config, so this doesn't recurse)
	Hooks:PostHook(CopBase, "swap_material_config", "PDTHTactics_looks_swap", function(self)
		if not self._pdth_look_parent_mode then return end
		local unit = self._unit
		pcall(sync_material, self, self._pdth_look, function()
			local c = alive(unit) and unit:contour()
			if c and c.update_materials then c:update_materials() end
		end)
	end)

elseif script == "lib/units/enemies/cop/huskcopbase" then
	Hooks:PostHook(HuskCopBase, "post_init", "PDTHTactics_looks_husk", function(self)
		hook_sequences()
		safe(T.look_apply, self._unit)
	end)
	Hooks:PreHook(HuskCopBase, "pre_destroy", "PDTHTactics_looks_remove_husk", function(self)
		safe(T.look_remove, self)
	end)

elseif script == "lib/units/contourext" then
	-- outlines (marked, converted, ...) also on the look: the game forwards them to its spawn_manager children;
	-- the base-game enemies have no spawn_manager, so the look gets them here
	Hooks:PostHook(ContourExt, "apply_to_linked", "PDTHTactics_looks_contour", function(self, func_name, ...)
		local base = self._unit:base()
		local look = base and base._pdth_look
		if look and alive(look) then
			local c = look:contour()
			if c and c[func_name] then
				local ok, err = pcall(c[func_name], c, ...)
				if not ok and not LK.contour_err then
					LK.contour_err = true
					log(T.name .. " looks outline error: " .. tostring(err))
				end
			end
		end
	end)
	-- a child outline has no character_damage to tell about marked damage bonuses (the game logs an error otherwise)
	local orig_bonus = ContourExt._chk_damage_bonuses
	function ContourExt:_chk_damage_bonuses(...)
		if self._is_child_contour then
			local cd = self._unit:character_damage()
			if not (cd and cd.on_marked_state) then return end
		end
		return orig_bonus(self, ...)
	end

elseif script == "lib/units/enemies/cop/copdamage" then
	-- the helmet's own clean-up: Restoration's "spawn_helmet" sequence takes the visor / face shield / goggles / headset
	-- and their glass with it (some burst, some fly off as their own unit) - before, those stayed floating on the face.
	-- The look's emulated glass it switches off takes no more hits. (lua/looks_pop.lua, icons_work/pdth_looks/helmet_pop.py)
	local function helmet_off(unit, look)
		local base = unit:base()
		local pop = base and T.LOOKS_POP and T.LOOKS_POP[base._pdth_look_path]
		if not pop or base._pdth_helmet_off then return end
		base._pdth_helmet_off = true
		local dmg = look:damage()
		if dmg and dmg:has_sequence("spawn_helmet") then
			dmg:run_sequence_simple("spawn_helmet")
			bodies_off(look)
		end
		local st = base._pdth_glass or {}
		base._pdth_glass = st
		for _, i in ipairs(pop) do
			local c = st[i] or { bullet = 0, damage = 0, explosion = 0, done = {} }
			c.off = true
			st[i] = c
		end
	end
	-- headshot: the enemy's helmet/hat pops off -> the look's comes off instead (and its own helmet unit flies)
	Hooks:PostHook(CopDamage, "hide_head_gear", "PDTHTactics_looks_gear", function(self)
		local ok, d, look = pcall(look_gear, self._unit)
		if not (ok and d and d.gear_obj) then return end
		if d.gear_n then
			for i = 1, d.gear_n do
				local o = look:get_object(Idstring(d.gear_obj .. tostring(i)))
				if o then o:set_visibility(false) end
			end
		else
			local o = look:get_object(Idstring(d.gear_obj))
			if o then o:set_visibility(false) end
		end
		local ok2, err = pcall(helmet_off, self._unit, look)
		if not ok2 and not LK.pop_err then
			LK.pop_err = true
			log(T.name .. " looks helmet error: " .. tostring(err))
		end
	end)
	local orig_gadget = CopDamage._spawn_head_gadget
	function CopDamage:_spawn_head_gadget(params, ...)
		local ok, d = pcall(look_gear, self._unit)
		if ok and d and self._head_gear and not self._head_gear_spawned then
			if not d.gear then
				-- the look has nothing to lose: no base-game helmet flying off either
				self:hide_head_gear()
				self._head_gear_spawned = true
				return
			end
			if d.gear ~= self._head_gear and unit_ready(d.gear) then
				local old = self._head_gear
				self._head_gear = d.gear
				local res = { pcall(orig_gadget, self, params, ...) }
				self._head_gear = old
				if not res[1] then error(res[2], 0) end
				return unpack(res, 2)
			end
		end
		return orig_gadget(self, params, ...)
	end

	-- Restoration's breakable glass (visors, goggles, gas-mask glass - the bodies on the head that its sequence manager
	-- gives endurance), working on the looks too. When you host they are Restoration's own units and break by
	-- themselves; in someone else's lobby the enemy is the base game's and the look on it has no hitboxes, so nothing
	-- cracked. Now a shot whose path crosses one of that glass's boxes (head frame, from the meshes it toggles) on its
	-- way to the enemy counts as a hit on it: bullets, damage and explosions add up, and each endurance runs the look's
	-- own sequence once - Restoration's cracks, breaks and their effects, nothing added. Every machine from its own copy
	-- of the hit: damage_bullet / damage_explosion for its own, the sync_ ones for everyone else's.
	-- (lua/looks_helmets.lua, icons_work/pdth_looks/glass_build.py)
	local GLASS = T.LOOKS_GLASS or {}
	local IDS_HEAD = Idstring("Head")
	local UP = Vector3(0, 0, 140)
	local gp0, gp1, gp2 = Vector3(), Vector3(), Vector3()
	local function pack(...) return { n = select("#", ...), ... } end

	-- does the segment a -> b (world) cross box {x0, y0, z0, x1, y1, z1} (frame of `head`: x side, y up, z forward)?
	local function crosses(head, a, b, box)
		local hp, rot = head:position(), head:rotation()
		local ax, ay, az = rot:x(), rot:y(), rot:z()
		local ux, uy, uz = a.x - hp.x, a.y - hp.y, a.z - hp.z
		local vx, vy, vz = b.x - hp.x, b.y - hp.y, b.z - hp.z
		local p = { ux * ax.x + uy * ax.y + uz * ax.z, ux * ay.x + uy * ay.y + uz * ay.z, ux * az.x + uy * az.y + uz * az.z }
		local q = { vx * ax.x + vy * ax.y + vz * ax.z, vx * ay.x + vy * ay.y + vz * ay.z, vx * az.x + vy * az.y + vz * az.z }
		local t0, t1 = 0, 1
		for i = 1, 3 do
			local lo, hi, d = box[i], box[i + 3], q[i] - p[i]
			if math.abs(d) < 1e-6 then
				if p[i] < lo or p[i] > hi then return false end
			else
				local ta, tb = (lo - p[i]) / d, (hi - p[i]) / d
				if ta > tb then ta, tb = tb, ta end
				if ta > t0 then t0 = ta end
				if tb < t1 then t1 = tb end
				if t0 > t1 then return false end
			end
		end
		return true
	end

	-- add to one glass's counters; run every endurance it reaches now (once each)
	local function glass_add(base, look, i, g, kind, amount)
		local st = base._pdth_glass
		if not st then st = {}; base._pdth_glass = st end
		local c = st[i]
		if not c then c = { bullet = 0, damage = 0, explosion = 0, done = {} }; st[i] = c end
		if c.off then return end -- a sequence of its own switched that glass off: nothing reaches it any more
		c[kind] = c[kind] + amount
		local dmg = look:damage()
		local ran, off = false, false
		for k, e in ipairs(g.ends) do
			if not c.done[k] and ((e.bullet and c.bullet >= e.bullet) or (e.damage and c.damage >= e.damage) or (e.explosion and c.explosion >= e.explosion)) then
				c.done[k] = true
				for _, s in ipairs(e.seq) do
					if dmg and dmg:has_sequence(s) then dmg:run_sequence_simple(s); ran = true end
				end
				if e.off then off = true end
			end
		end
		if off then c.off = true end
		if ran then bodies_off(look) end -- its sequences may switch a hitbox on; a look keeps none
	end

	local function glass_of(cd)
		local unit = cd._unit
		local base = alive(unit) and unit:base()
		local look = base and base._pdth_look
		if not (look and alive(look)) then return end
		local list = GLASS[base._pdth_look_path]
		if list then return base, look, list end
	end

	-- a shot from a to b (where it hit the enemy)
	local function glass_shot(cd, a, b, damage)
		local base, look, list = glass_of(cd)
		if not list then return end
		local head = cd._unit:get_object(IDS_HEAD)
		if not head then return end
		for i, g in ipairs(list) do
			if crosses(head, a, b, g.box) then
				glass_add(base, look, i, g, "bullet", 1)
				if damage and damage > 0 then glass_add(base, look, i, g, "damage", damage) end
			end
		end
	end

	local function glass_blast(cd, damage)
		local base, look, list = glass_of(cd)
		if not list then return end
		for i, g in ipairs(list) do glass_add(base, look, i, g, "explosion", damage) end
	end

	local function glass_err(err)
		if not LK.glass_err then
			LK.glass_err = true
			log(T.name .. " looks glass error: " .. tostring(err))
		end
	end

	if next(GLASS) then
		local g_bullet = CopDamage.damage_bullet
		function CopDamage:damage_bullet(attack_data, ...)
			local r = pack(g_bullet(self, attack_data, ...))
			local col = attack_data and attack_data.col_ray
			if col and col.position and col.ray then
				local ok, err = pcall(function()
					mvector3.set(gp0, col.ray)
					mvector3.multiply(gp0, -300)
					mvector3.add(gp0, col.position)
					glass_shot(self, gp0, col.position, attack_data.damage)
				end)
				if not ok then glass_err(err) end
			end
			return unpack(r, 1, r.n)
		end

		local g_sync = CopDamage.sync_damage_bullet
		if g_sync then
			function CopDamage:sync_damage_bullet(attacker_unit, damage_percent, i_body, hit_offset_height, ...)
				local was_dead = self._dead
				local r = pack(g_sync(self, attacker_unit, damage_percent, i_body, hit_offset_height, ...))
				if not was_dead and attacker_unit and alive(attacker_unit) then
					local ok, err = pcall(function()
						local unit = self._unit
						local body = i_body and unit:body(i_body)
						mvector3.set(gp0, attacker_unit:position())
						mvector3.add(gp0, UP) -- about the shooter's eyes
						local head = unit:get_object(IDS_HEAD)
						if body and self._ids_head_body_name and body:name() == self._ids_head_body_name and head then
							-- the front of his head as seen from the shooter: head centre (6.5 up, 2 forward) less 10 cm
							local rot = head:rotation()
							mvector3.set(gp1, head:position())
							mvector3.add(gp1, rot:y() * 6.5 + rot:z() * 2)
							mvector3.set(gp2, gp1)
							mvector3.subtract(gp2, gp0)
							mvector3.normalize(gp2)
							mvector3.multiply(gp2, 10)
							mvector3.subtract(gp1, gp2)
						else
							mvector3.set(gp1, unit:position())
							mvector3.set_z(gp1, gp1.z + (hit_offset_height or 100))
						end
						glass_shot(self, gp0, gp1, (damage_percent or 0) * (self._HEALTH_INIT_PRECENT or 0))
					end)
					if not ok then glass_err(err) end
				end
				return unpack(r, 1, r.n)
			end
		end

		local g_expl = CopDamage.damage_explosion
		if g_expl then
			function CopDamage:damage_explosion(attack_data, ...)
				local was_dead = self._dead
				local r = pack(g_expl(self, attack_data, ...))
				if not was_dead and attack_data and attack_data.variant ~= "stun" and (attack_data.damage or 0) > 0 then
					local ok, err = pcall(glass_blast, self, attack_data.damage)
					if not ok then glass_err(err) end
				end
				return unpack(r, 1, r.n)
			end
		end

		local g_sync_expl = CopDamage.sync_damage_explosion
		if g_sync_expl then
			function CopDamage:sync_damage_explosion(attacker_unit, damage_percent, ...)
				local was_dead = self._dead
				local r = pack(g_sync_expl(self, attacker_unit, damage_percent, ...))
				if not was_dead and (damage_percent or 0) > 0 then
					local ok, err = pcall(glass_blast, self, damage_percent * (self._HEALTH_INIT_PRECENT or 1))
					if not ok then glass_err(err) end
				end
				return unpack(r, 1, r.n)
			end
		end
	end
end
