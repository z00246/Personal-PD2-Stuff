if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics
local script = RequiredScript and RequiredScript:lower() or ""

-- ZEAL Medic (Restoration Mod model) replaces the regular Medic on Death Sentence.
-- Custom units crash players who don't have them, so it is only used while everyone has this mod.
local ZEAL = "units/pd2_dlc_gitgud/characters/ene_zeal_medic/ene_zeal_medic"
local UNIT = Idstring("unit")
local MAT = Idstring("material_config")

local function has(kind, ids)
	local dyn = managers.dyn_resource
	if dyn and dyn.has_resource then return dyn:has_resource(kind, ids, dyn.DYN_RESOURCES_PACKAGE) and true or false end
	return PackageManager:has(kind, ids)
end

-- queued during loading (see factions.lua), only checked afterwards
local function queue_zeal()
	if not (BeardLib and T.is_ds() and DB:has(UNIT, Idstring(ZEAL))) then return end
	T._zeal_queued = true
	T._fac_queue = T._fac_queue or {}
	for _, name in ipairs({ ZEAL, ZEAL .. "_husk" }) do table.insert(T._fac_queue, { ids = Idstring(name), name = name }) end
end

local function load_zeal()
	if T._zeal_loaded then return true end
	if not T._zeal_queued then T._zeal_loaded = false return false end
	T._zeal_loaded = has(UNIT, Idstring(ZEAL)) and has(UNIT, Idstring(ZEAL .. "_husk"))
	return T._zeal_loaded
end
-- also run from the loading-screen preload
T.zeal_preload = function() pcall(queue_zeal) end

if script == "lib/units/enemies/cop/copbase" then
	-- outlines: cops swap to a "_contour" material when marked; register the ZEAL Medic's pair
	if CopBase._material_translation_map then
		local normal_id, contour_id = Idstring(ZEAL), Idstring(ZEAL .. "_contour")
		CopBase._material_translation_map[tostring(normal_id:key())] = contour_id
		CopBase._material_translation_map[tostring(contour_id:key())] = normal_id
	end

elseif script == "lib/managers/mission/elementspawnenemydummy" then
	T.zeal_peers = T.zeal_peers or {}

	local function everyone_has_zeal()
		local session = managers.network and managers.network:session()
		for _, peer in pairs(session and session:peers() or {}) do
			local uid = peer.user_id and peer:user_id()
			if not (T.zeal_peers[peer:id()] or (uid and Global.pdth_mod_users and Global.pdth_mod_users[uid])) then return false end
		end
		return true
	end

	-- load once the game is running (host and modded clients), then tell the host we can show it
	Hooks:Add("GameSetupUpdate", "PDTHTactics_zeal_medic_load", function()
		if T._zeal_done then return end
		local now = Application:time()
		T._zeal_check_start = T._zeal_check_start or now
		local ok, err = pcall(load_zeal)
		if not ok then log(T.name .. " ZEAL Medic check failed: " .. tostring(err)) end
		-- BeardLib finishes the queued load during startup; give it a few seconds before giving up
		if not T._zeal_loaded and T._zeal_queued and now - T._zeal_check_start < 15 then return end
		if not T._zeal_loaded or (Network and Network:is_server()) then
			T._zeal_done = true
			return
		end
		if T.client_on() and LuaNetworking then
			pcall(LuaNetworking.SendToPeer, LuaNetworking, 1, T.NET_ID, "zeal")
			T._zeal_done = true
		end
	end)

	if LuaNetworking and LuaNetworking.AddReceiveHook then
		LuaNetworking:AddReceiveHook(T.NET_ID, "PDTHTactics_zeal_net", function(data, sender)
			if data == "zeal" and sender and Network and Network:is_server() then
				T.zeal_peers[sender] = true
			end
		end)
	end
	Hooks:Add("BaseNetworkSessionOnPeerRemoved", "PDTHTactics_zeal_peer_removed", function(peer, peer_id)
		T.zeal_peers[peer_id] = nil
	end)

	-- someone joins: wait for their confirmation before new ZEAL Medics; existing ones stay
	Hooks:Add("NetworkManagerOnPeerAdded", "PDTHTactics_zeal_joiner", function(peer, peer_id)
		T.zeal_peers[peer_id] = nil
	end)

	local SWAP = {
		[Idstring("units/payday2/characters/ene_medic_m4/ene_medic_m4"):key()] = true,
		[Idstring("units/payday2/characters/ene_medic_r870/ene_medic_r870"):key()] = true
	}
	local zeal_ids = Idstring(ZEAL)

	local function zeal_ok()
		if not (T.active() and T.is_ds() and T._zeal_loaded and everyone_has_zeal()) then return false end
		if T.faction_now and T.faction_now() then return false end
		return true
	end

	-- group spawns (params.name) and mission/scripted spawns (the element's own unit) alike
	local orig_produce = ElementSpawnEnemyDummy.produce
	function ElementSpawnEnemyDummy:produce(params, ...)
		local ok, use = pcall(zeal_ok)
		if ok and use and T.unit_ready and not T.unit_ready(zeal_ids) then use = false end
		if ok and use then
			if params and params.name then
				if SWAP[params.name:key()] then params.name = zeal_ids end
			elseif self._enemy_name and SWAP[self._enemy_name:key()] then
				local old = self._enemy_name
				self._enemy_name = zeal_ids
				local res = { pcall(orig_produce, self, params, ...) }
				self._enemy_name = old
				if not res[1] then error(res[2], 0) end
				return unpack(res, 2)
			end
		end
		return orig_produce(self, params, ...)
	end

elseif script == "lib/units/enemies/cop/copdamage" then
	-- His visor cracks, then breaks, like the Bulldozers' glass. Restoration built it to (a cracked visor g_glass_crk,
	-- sequences crk_visor / destroy_visor), but its hitbox (body "visor") ships switched off and nothing turns it on -
	-- and switched on, face hits would land on it and count as body shots. So it stays off and his head's own hits
	-- drive it: the first hit to his face from the front cracks the visor, the second shatters it (glass bursts, the
	-- Dozer visor's shatter sound); a headshot kill that knocks his helmet off shatters it too (the game only hides the
	-- helmet, so the visor used to stay on his face). Headshots count as before. On the real ZEAL Medic (host and
	-- modded clients) and on the ZEAL look a base-game Medic wears (looks.lua); every machine from its own copy of the
	-- hit (damage_bullet for its own shots, sync_damage_bullet for everyone else's).
	local ZEAL_KEYS = { [Idstring(ZEAL):key()] = true, [Idstring(ZEAL .. "_husk"):key()] = true }
	local GLASS = { Idstring("g_glass"), Idstring("g_glass_crk") }
	local FRONT = -0.3 -- bullet direction . his facing (both flat) at most this: from the front (about +-70 degrees)
	local tmp1, tmp2 = Vector3(), Vector3()

	local function pack(...) return { n = select("#", ...), ... } end

	local function visor_unit(unit)
		if not alive(unit) then return end
		if ZEAL_KEYS[unit:name():key()] then return unit end
		local base = unit:base()
		local look = base and base._pdth_look
		if look and alive(look) and base._pdth_look_path == ZEAL then return look end
	end

	local function frontal(unit, dir)
		if not dir then return false end
		mvector3.set(tmp1, dir)
		mvector3.set_z(tmp1, 0)
		if mvector3.length(tmp1) < 0.001 then return false end
		mvector3.normalize(tmp1)
		mrotation.y(unit:rotation(), tmp2)
		mvector3.set_z(tmp2, 0)
		mvector3.normalize(tmp2)
		return mvector3.dot(tmp1, tmp2) <= FRONT
	end

	local function run(vu, name)
		local dmg = vu:damage()
		if dmg and dmg:has_sequence(name) then dmg:run_sequence_simple(name) end
	end

	local function shatter(cd, vu)
		cd._pdth_visor = 2
		run(vu, "destroy_visor") -- Restoration's glass bursts at his head
		for _, n in ipairs(GLASS) do
			local o = vu:get_object(n)
			if o then o:set_visibility(false) end
		end
		local snd = cd._unit:sound()
		if snd and snd.play then snd:play("bulldozer_visor_shatter", nil, false) end
	end

	local function visor_hit(cd)
		local vu = visor_unit(cd._unit)
		if not vu then return end
		local s = cd._pdth_visor or 0
		if s >= 2 then return end
		if s == 0 then
			cd._pdth_visor = 1
			run(vu, "crk_visor")
		else
			shatter(cd, vu)
		end
	end

	local function head_hit(cd, body)
		return body and cd._ids_head_body_name and body:name() == cd._ids_head_body_name
	end

	local orig_bullet = CopDamage.damage_bullet
	function CopDamage:damage_bullet(attack_data, ...)
		local was_dead = self._dead
		local r = pack(orig_bullet(self, attack_data, ...))
		if not was_dead and type(r[1]) == "table" then
			pcall(function()
				local col = attack_data and attack_data.col_ray
				if col and head_hit(self, col.body) and frontal(self._unit, col.ray) then visor_hit(self) end
			end)
		end
		return unpack(r, 1, r.n)
	end

	local orig_sync = CopDamage.sync_damage_bullet
	if orig_sync then
		function CopDamage:sync_damage_bullet(attacker_unit, damage_percent, i_body, ...)
			local was_dead = self._dead
			local r = pack(orig_sync(self, attacker_unit, damage_percent, i_body, ...))
			if not was_dead then
				pcall(function()
					if not (attacker_unit and alive(attacker_unit)) then return end
					if not head_hit(self, i_body and self._unit:body(i_body)) then return end
					mvector3.set(tmp1, self._unit:position())
					mvector3.subtract(tmp1, attacker_unit:position())
					if frontal(self._unit, tmp1) then visor_hit(self) end
				end)
			end
			return unpack(r, 1, r.n)
		end
	end

	local orig_gadget = CopDamage._spawn_head_gadget
	if orig_gadget then
		function CopDamage:_spawn_head_gadget(...)
			local r = pack(orig_gadget(self, ...))
			pcall(function()
				local vu = visor_unit(self._unit)
				if vu and (self._pdth_visor or 0) < 2 then shatter(self, vu) end
			end)
			return unpack(r, 1, r.n)
		end
	end
end
