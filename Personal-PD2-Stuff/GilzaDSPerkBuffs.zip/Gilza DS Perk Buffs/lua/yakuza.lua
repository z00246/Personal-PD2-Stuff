GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

B.YAKUZA = {
	deck = 12,
	bloodied_start = 0.5,
	bloodied = 0.25,
	bloodied_ds = 0.35,
	last_stand_cd = 90,
	last_stand_cd_ds = 60,
	last_stand_invuln = 2,
	blood_debt = 0.05,
	blood_debt_health = 0.5,
	iron_will_health = 0.25,
	iron_will = 0.15,
	iron_will_ds = 0.2
}
local C = B.YAKUZA
local GILZA_YAKUZA_KEY = "armor_regen_damage_health_ratio_multiplier"

function B.yakuza_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == C.deck) then
		return 0
	end
	return st:get_specialization_value(C.deck, "tiers", "current_tier") or 0
end

function B.yakuza_health_ratio()
	local unit = managers.player and managers.player:player_unit()
	local dmg = alive(unit) and unit:character_damage()
	return dmg and dmg:health_ratio() or 1
end

function B.yakuza_bloodied()
	if B.yakuza_tier() < 3 then return 0 end
	local hr = B.yakuza_health_ratio()
	if hr >= C.bloodied_start then return 0 end
	local f = math.clamp((C.bloodied_start - hr) / C.bloodied_start, 0, 1)
	return f * (B.on and C.bloodied_ds or C.bloodied)
end

function B.yakuza_last_stand_ready()
	return B.yakuza_tier() >= 5 and Application:time() >= (B.yakuza_ls_ready or 0)
end

if script == "lib/managers/playermanager" then
	-- lets Yakuza heal again: Gilza blocks healing by checking this upgrade, so hide it during heals
	local orig_has = PlayerManager.has_category_upgrade
	function PlayerManager:has_category_upgrade(category, upgrade, ...)
		if B._yak_allow_heal and upgrade == GILZA_YAKUZA_KEY and category == "player" then
			return false
		end
		return orig_has(self, category, upgrade, ...)
	end

	-- Iron Will: less damage at very low health
	local orig_resist = PlayerManager.damage_reduction_skill_multiplier
	function PlayerManager:damage_reduction_skill_multiplier(...)
		local m = orig_resist(self, ...)
		if type(m) ~= "number" then return m end
		local ok, tier = pcall(B.yakuza_tier)
		if ok and tier >= 9 and B.yakuza_health_ratio() < C.iron_will_health then
			m = m * (1 - (B.on and C.iron_will_ds or C.iron_will))
		end
		return m
	end

	-- Blood Debt: kills while below half health restore armor
	Hooks:PostHook(PlayerManager, "on_killshot", "GilzaDSBuffs_yakuza_blood_debt", function(self)
		pcall(function()
			if B.yakuza_tier() < 7 then return end
			local unit = self:player_unit()
			local dmg = alive(unit) and unit:character_damage()
			if dmg and not dmg:dead() and dmg:health_ratio() < C.blood_debt_health then
				dmg:restore_armor(dmg:_max_armor() * C.blood_debt)
			end
		end)
	end)

	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_yakuza_reset", function()
		local session = managers.network and managers.network:session()
		if B._yak_session ~= session then
			B._yak_session = session
			B.yakuza_ls_ready = nil
		end
	end)

elseif script == "lib/units/beings/player/playerdamage" then
	local function allow_heal(fn_name)
		local orig = PlayerDamage[fn_name]
		if not orig then return end
		PlayerDamage[fn_name] = function(self, ...)
			if B.yakuza_tier() < 1 then
				return orig(self, ...)
			end
			B._yak_allow_heal = true
			local r = { pcall(orig, self, ...) }
			B._yak_allow_heal = nil
			if not r[1] then error(r[2], 0) end
			return unpack(r, 2)
		end
	end
	allow_heal("restore_health")
	allow_heal("set_revive_boost")

	-- Last Stand: a hit that would down you leaves you at 1 health instead
	local orig_bleed = PlayerDamage._check_bleed_out
	function PlayerDamage:_check_bleed_out(can_activate_berserker, ignore_movement_state, ignore_reduce_revive, ...)
		local ok, saved = pcall(function()
			if self:get_real_health() > 0 or self._check_berserker_done or self._bleed_out then return false end
			if not B.yakuza_last_stand_ready() then return false end
			if self._unit:movement():zipline_unit() then return false end
			B.yakuza_ls_ready = Application:time() + (B.on and C.last_stand_cd_ds or C.last_stand_cd)
			self:change_health(0.1)
			self:restore_armor(self:_max_armor())
			if self.Gilza_add_damage_invuln_timer then
				self:Gilza_add_damage_invuln_timer(C.last_stand_invuln)
			end
			if self._unit:sound() then
				self._unit:sound():play("perkdeck_activate", nil, false)
			end
			return true
		end)
		if ok and saved then return end
		return orig_bleed(self, can_activate_berserker, ignore_movement_state, ignore_reduce_revive, ...)
	end

elseif script == "lib/units/enemies/cop/copdamage" then
	-- Bloodied: more damage the lower your health
	local function bloodied(self, attack_data)
		if not attack_data or type(attack_data.damage) ~= "number" then return end
		local player = managers.player and managers.player:player_unit()
		if not (alive(player) and attack_data.attacker_unit == player) then return end
		local bonus = B.yakuza_bloodied()
		if bonus > 0 then
			attack_data.damage = attack_data.damage * (1 + bonus)
		end
	end
	for _, fn in ipairs({ "damage_bullet", "damage_melee" }) do
		Hooks:PreHook(CopDamage, fn, "GilzaDSBuffs_yakuza_" .. fn, function(self, attack_data)
			pcall(bloodied, self, attack_data)
		end)
	end

elseif script == "lib/tweak_data/skilltreetweakdata" then
	-- low-health armor recovery and speed start below 50% from card 1
	Hooks:PostHook(SkillTreeTweakData, "init", "GilzaDSBuffs_yakuza_cards", function(self)
		local deck = self.specializations and self.specializations[C.deck]
		local ups = deck and deck[1] and deck[1].upgrades
		if not ups then return end
		for _, name in ipairs({ "player_armor_regen_damage_health_ratio_threshold_multiplier", "player_movement_speed_damage_health_ratio_threshold_multiplier" }) do
			local found = false
			for _, u in ipairs(ups) do
				if u == name then found = true break end
			end
			if not found then table.insert(ups, name) end
		end
	end)
end
