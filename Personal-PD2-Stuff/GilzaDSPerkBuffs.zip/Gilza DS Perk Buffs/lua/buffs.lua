GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs

local function mul(f) return function(v) return v * f end end
local function add(a, cap) return function(v) return math.min(v + a, cap or 1) end end
local function resist(f) return function(v) return math.max(1 - (1 - v) * f, 0.05) end end

-- Difficulty scaling (7.00): the reworked decks (Muscle, Burglar, Infiltrator, Sociopath) don't get a Death Sentence-only
-- bonus any more. Their numbers grow with the difficulty: t = 0 from Normal to Overkill, 1/3 on Mayhem, 2/3 on Death
-- Wish and 1 (the old Death Sentence value) on Death Sentence. B.sc(base, ds) is the value for the current difficulty.
if not B.diff_t then
	B.DIFF_T = { easy_wish = 1 / 3, overkill_290 = 2 / 3, sm_wish = 1 }
	function B.diff_t()
		local gs = Global and Global.game_settings
		return gs and B.DIFF_T[gs.difficulty] or 0
	end
	function B.sc(base, ds) return base + (ds - base) * B.diff_t() end
	function B.sci(base, ds) return math.floor(base + (ds - base) * B.diff_t() + 0.5) end
end

-- { upgrade path, which values, Death Sentence change [, "scaled"] }: "scaled" niches grow with the difficulty
-- (reworked decks), the others only apply on Death Sentence
B.niches = {
	-- (7.20: Crew Chief's hostage damage reduction stacks in crewchief.lua with its own 8% » 12% first hostage, so the old
	-- Death Sentence-only team.damage_dampener.hostage_multiplier niche is gone; card 3's close-contact damage reduction
	-- grows with the difficulty now - level 1 is Crew Chief's card 3 and Copycat's Crew Chief choice only)
	{ "temporary.dmg_dampener_close_contact", 1, resist(1.5), "scaled" },
	{ "player.passive_health_regen", "all", mul(1.5) },
	{ "temporary.armor_break_invulnerable", 1, mul(1.5) },
	{ "player.passive_dodge_chance", "all", add(0.05) },
	{ "player.level_2_dodge_addend", "all", add(0.05) },
	{ "player.level_3_dodge_addend", "all", add(0.05) },
	{ "player.level_4_dodge_addend", "all", add(0.05) },
	-- (Burglar's tier_dodge_chance: its card 5 bonus is scaled in burglar.lua now)
	{ "temporary.dmg_dampener_outnumbered_strong", 1, resist(1.5), "scaled" },   -- Infiltrator card 1 surrounded: 10% -> 15%
	{ "player.killshot_regen_armor_bonus", "all", mul(1.5) },
	{ "player.killshot_close_regen_armor_bonus", "all", mul(1.5) },
	{ "player.melee_kill_life_leech", "all", mul(1.5) },
	-- (7.21 Gambler rework standard: the dice grow with the difficulty; the 5th value rounds the result: 1 = whole health
	-- points (heals 16-24 » 28-42, card 7 32-40 » 56-70; losses are 2x in Gilza's roll), 100 = whole percents (card 9's
	-- dodge: wins 2-8% » 4-16%, losses 4-16% » 8-32%, jackpots 35% » 56%)
	{ "temporary.loose_ammo_restore_health", "range", function(v) return math.floor(v * 1.75 + 0.5) end, "scaled", 1 },
	{ "player.loose_ammo_add_dodge_amount", "addition_min", mul(2), "scaled", 100 },
	{ "player.loose_ammo_add_dodge_amount", "addition_max", mul(2), "scaled", 100 },
	{ "player.loose_ammo_add_dodge_amount", "removal_min", mul(2), "scaled", 100 },
	{ "player.loose_ammo_add_dodge_amount", "removal_max", mul(2), "scaled", 100 },
	{ "player.loose_ammo_add_dodge_amount", "addition_jackpot", mul(1.6), "scaled", 100 },
	{ "player.loose_ammo_add_dodge_amount", "removal_jackpot", mul(1.6), "scaled", 100 },
	{ "player.damage_to_hot", "all", mul(1.5) },
	{ "player.armor_regen_damage_health_ratio_multiplier", "all", mul(1.25) },
	{ "player.armor_health_store_amount", "all", mul(1.5) },
	{ "player.armor_grinding", "grind", mul(1.3) },
	{ "player.wild_health_amount", "all", mul(1.5) },
	{ "player.wild_armor_amount", "all", mul(1.5) },
	{ "temporary.chico_injector", 2, mul(1.33) },
	{ "player.dodge_shot_gain_gilza", 1, mul(1.5) },
	{ "player.damage_control_passive", 1, add(10, 90) },
	{ "player.tag_team_base", "kill_health_gain", mul(1.5) },
	{ "player.pocket_ecm_heal_on_kill", "all", mul(1.5) },
	{ "temporary.pocket_ecm_kill_dodge", 1, mul(1.33) },
	{ "player.copr_activate_bonus_health_ratio", "all", mul(1.5) },
	{ "^max_cocaine_stacks_per_tick", "value", function(v) return math.floor(v * 1.25 + 0.5) end },
	{ "player.damage_resist_brawler", "all", resist(1.5) },
	{ "temporary.player_speed_junkie_armor_on_dodge", 1, mul(1.5) },
	{ "player.speed_junkie_meter_on_kill", "pair", function(v) return math.floor(v * 1.25 + 0.5) end },
	{ "player.guardian_area_passive_health_regen", "all", mul(1.5) }
}

local function lookup(path)
	local t = tweak_data and tweak_data.upgrades
	if string.sub(path, 1, 1) == "^" then
		path = string.sub(path, 2)
	else
		t = t and t.values
	end
	local parent, key
	for part in string.gmatch(path, "[^%.]+") do
		if type(t) ~= "table" then return nil end
		parent, key, t = t, part, t[part]
	end
	return parent, key, t
end

local function transform(tbl, sel, fn)
	if sel == "all" then
		for i, v in ipairs(tbl) do
			if type(v) == "number" then tbl[i] = fn(v) end
		end
	elseif sel == "range" then
		for _, entry in ipairs(tbl) do
			local r = type(entry) == "table" and entry[1]
			if type(r) == "table" then
				for i, v in ipairs(r) do
					if type(v) == "number" then r[i] = fn(v) end
				end
			end
		end
	elseif sel == "pair" then
		for _, entry in ipairs(tbl) do
			if type(entry) == "table" then
				for i, v in ipairs(entry) do
					if type(v) == "number" then entry[i] = fn(v) end
				end
			end
		end
	elseif sel == "grind" then
		for _, level in ipairs(tbl) do
			if type(level) == "table" then
				for _, tier in ipairs(level) do
					if type(tier) == "table" and type(tier[1]) == "number" then tier[1] = fn(tier[1]) end
				end
			end
		end
	else
		for _, entry in ipairs(tbl) do
			if type(entry) == "table" and type(entry[sel]) == "number" then
				entry[sel] = fn(entry[sel])
			end
		end
	end
end

B.saved = B.saved or {}

-- on: true / false (Death Sentence or not, as Player Stats Panel Enhancements' DS column asks) or the difficulty
-- scale t (0..1). Death Sentence-only niches apply at t = 1, "scaled" niches are blended in by t.
function B.apply(on)
	local t = on == true and 1 or (type(on) == "number" and math.clamp(on, 0, 1)) or 0
	for path, rec in pairs(B.saved) do
		local parent, key, cur = lookup(path)
		if parent and cur == rec.buffed then
			parent[key] = rec.orig
		end
	end
	B.saved = {}
	if t > 0 then
		for _, n in ipairs(B.niches) do
			local path, fn = n[1], n[3]
			if n[4] == "scaled" then
				local f, q = fn, n[5]
				fn = function(v)
					local r = v + (f(v) - v) * t
					if q then r = math.floor(r * q + 0.5) / q end
					return r
				end
			elseif t < 1 then
				fn = nil
			end
			local parent, key, cur = lookup(path)
			if not fn then
				-- Death Sentence only
			elseif parent and type(cur) == "number" and n[2] == "value" and not B.saved[path] then
				local ok, v = pcall(fn, cur)
				if ok and type(v) == "number" then
					B.saved[path] = { orig = cur, buffed = v }
					parent[key] = v
				end
			elseif parent and type(cur) == "table" then
				local rec = B.saved[path]
				if not rec then
					rec = { orig = cur, buffed = deep_clone(cur) }
					B.saved[path] = rec
					parent[key] = rec.buffed
				end
				pcall(transform, rec.buffed, n[2], fn)
			end
		end
	end
	B.t = t
	B.on = t >= 1
end

function B.check()
	if B.leech_pre_apply then pcall(B.leech_pre_apply) end
	if B.rogue_pre_apply then pcall(B.rogue_pre_apply) end
	if B.armorer_pre_apply then pcall(B.armorer_pre_apply) end
	local t = B.diff_t()
	if B.t ~= t then
		B.apply(t)
	end
end

Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_check", function() pcall(B.check) end)
Hooks:Add("MenuUpdate", "GilzaDSBuffs_check_menu", function() pcall(B.check) end)

-- Live check (7.02): one line in the BLT log the first two times each reworked perk feature really does something in
-- a heist ("[Gilza DS Perk Buffs] live <deck> <feature>: ..."), so a normal run shows what works in game.
B._live = B._live or {}
local function live_log(key, fmt, ...)
	local session = managers.network and managers.network:session()
	if B._live_session ~= session then
		B._live_session, B._live = session, {}
	end
	local n = B._live[key] or 0
	if n >= 2 then return end
	B._live[key] = n + 1
	local msg = fmt
	if fmt and select("#", ...) > 0 then
		local ok, s = pcall(string.format, fmt, ...)
		msg = ok and s or fmt
	end
	log("[Gilza DS Perk Buffs] live " .. tostring(key) .. (msg and (": " .. tostring(msg)) or ""))
end
-- (never lets an error out into the game function that called it)
function B.live(key, fmt, ...)
	pcall(live_log, key, fmt, ...)
end

-- and once per heist: the deck, card and difficulty it runs with
Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_live_start", function()
	pcall(function()
		local session = managers.network and managers.network:session()
		if B._live_start_session == session then return end
		local unit = managers.player and managers.player:player_unit()
		if not alive(unit) then return end
		B._live_start_session = session
		local st = managers.skilltree
		local deck = st and st:get_specialization_value("current_specialization") or 0
		local card = st and st:get_specialization_value(deck, "tiers", "current_tier") or 0
		local gs = Global and Global.game_settings
		log(string.format("[Gilza DS Perk Buffs] heist start: perk deck %s, card %s, %s (scale %.2f), %s", tostring(deck),
			tostring(card), tostring(gs and gs.difficulty), B.diff_t(), Network:is_server() and "hosting" or "client"))
	end)
end)

-- (7.21) Gambler's dice (the crit gamble, card 9's dodge cap, the next-roll timer) live in gambler.lua now
