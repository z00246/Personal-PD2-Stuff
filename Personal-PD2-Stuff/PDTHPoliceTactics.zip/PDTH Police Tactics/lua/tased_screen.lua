if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics

Hooks:PreHook(PlayerTased, "_check_action_shock", "PDTHTactics_shock_pre", function(self)
	self._pdth_shocks = self._num_shocks or 0
end)

Hooks:PostHook(PlayerTased, "_check_action_shock", "PDTHTactics_shock_post", function(self)
	if not (T.active() or T.client_on()) or (self._num_shocks or 0) == self._pdth_shocks then return end
	local cam = self._unit:camera()
	cam:play_shaker("player_taser_shock", 1.3, 11)
	cam:camera_unit():base():set_target_tilt((math.random(2) == 1 and -1 or 1) * (3 + math.random(9)))
end)
