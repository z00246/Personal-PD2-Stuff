GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

B.INFIL = {
	deck = 8,
	-- card 3/5/7: Closing In, damage reduction by distance to the nearest enemy
	close = { [3] = 0.12, [5] = 0.20, [7] = 0.28 },
	close_ds = { [3] = 0.15, [5] = 0.25, [7] = 0.35 },
	near = 500,
	far = 1800,
	far_ratio = 0.4,
	-- card 3: Point Blank (2026-10-24): your guns hit harder up close
	point_blank = 0.15,
	point_blank_ds = 0.20,
	point_blank_range = 500,
	-- card 5: Opening (+ Cleave, 2026-10-24: the hit exposes everyone close to the target too)
	expose_time = 7,
	expose_time_ds = 9,
	expose_dmg = 0.3,
	expose_dmg_ds = 0.4,
	cleave_range = 300,
	-- card 7: Melt Away + Infiltrate
	melt_time = 3,
	melt_speed = 1.2,
	melt_dr = 0.25,
	melt_dr_ds = 0.35,
	hide_time = 2,
	hide_radius = 1000,
	-- card 9: Life Leech (2026-10-24: 4% -> 6% a hit, 20% -> 30% per 10 s, Exposed kills 5% -> 8%)
	leech = 0.06,
	leech_cap = 0.3,
	leech_window = 10,
	exposed_heal = 0.08
}
B.NET_ID = B.NET_ID or "GilzaDSBuffs"
local C = B.INFIL

function B.infil_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == C.deck) then
		return 0
	end
	return st:get_specialization_value(C.deck, "tiers", "current_tier") or 0
end

local function by_tier(tbl, tier)
	local best, v = 0, 0
	for card, val in pairs(tbl) do
		if tier >= card and card > best then best, v = card, val end
	end
	return v
end

local function game_t()
	return TimerManager:game():time()
end

-- Infiltrate (host side): units that nearby enemies ignore for a moment
B.infil_hide = B.infil_hide or {}

function B.infil_hidden(unit, data)
	if not alive(unit) then return false end
	local h = B.infil_hide[unit:key()]
	if not h then return false end
	if game_t() >= h.until_t then
		B.infil_hide[unit:key()] = nil
		return false
	end
	if data and data.m_pos then
		return mvector3.distance(data.m_pos, h.pos) <= C.hide_radius
	end
	return true
end

function B.infil_start_hide(unit, duration)
	if not (Network:is_server() and alive(unit)) then return end
	B.infil_hide[unit:key()] = { until_t = game_t() + duration, pos = mvector3.copy(unit:position()) }
end

function B.infil_close_dr()
	return B.infil_close or 0
end

function B.infil_melting()
	return Application:time() < (B.infil_melt_until or 0)
end

if script == "lib/managers/playermanager" then
	local function nearest_enemy_dis(pos)
		local best
		local mask = managers.slot:get_mask("enemies")
		for _, u_data in pairs(managers.enemy:all_enemies() or {}) do
			local u = u_data.unit
			if alive(u) and u:in_slot(mask) then
				local dmg = u:character_damage()
				if not (dmg and dmg._dead) then
					local brain = u:brain()
					if not (brain and brain.is_hostage and brain:is_hostage()) then
						local d = mvector3.distance(pos, u:position())
						if not best or d < best then best = d end
					end
				end
			end
		end
		return best
	end

	local function update_close()
		local tier = B.infil_tier()
		local unit = managers.player:player_unit()
		if tier < 3 or not alive(unit) then
			B.infil_close = 0
			return
		end
		local max = by_tier(B.on and C.close_ds or C.close, tier)
		local d = nearest_enemy_dis(unit:position())
		if not d or d > C.far then
			B.infil_close = 0
		elseif d <= C.near then
			B.infil_close = max
		else
			local f = (d - C.near) / (C.far - C.near)
			B.infil_close = max * (1 - f * (1 - C.far_ratio))
		end
	end

	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_infil_update", function()
		local now = Application:time()
		if now < (B._infil_next or 0) then return end
		B._infil_next = now + 0.2
		local ok, err = pcall(update_close)
		if not ok and not B._infil_err then
			B._infil_err = true
			log("[Gilza DS Perk Buffs] Infiltrator update error: " .. tostring(err))
		end
	end)

	local orig_resist = PlayerManager.damage_reduction_skill_multiplier
	function PlayerManager:damage_reduction_skill_multiplier(...)
		local m = orig_resist(self, ...)
		if type(m) ~= "number" then return m end
		local close = B.infil_close or 0
		if close > 0 then
			m = m * (1 - close)
		end
		if B.infil_melting() then
			m = m * (1 - (B.on and C.melt_dr_ds or C.melt_dr))
		end
		return m
	end

	local orig_speed = PlayerManager.movement_speed_multiplier
	function PlayerManager:movement_speed_multiplier(...)
		local m = orig_speed(self, ...)
		if type(m) == "number" and B.infil_melting() then
			return m * C.melt_speed
		end
		return m
	end

	if LuaNetworking and LuaNetworking.AddReceiveHook then
		LuaNetworking:AddReceiveHook(B.NET_ID, "GilzaDSBuffs_infil_net", function(data, sender) pcall(function()
			if not Network:is_server() or type(data) ~= "string" then return end
			local value = string.match(data, "^infil:([%d%.]+)$")
			if not value then return end
			local session = managers.network and managers.network:session()
			local peer = session and session:peer(tonumber(sender))
			local skills = peer and peer.unpacked_skills and peer:unpacked_skills()
			local spec = skills and skills.specializations
			if not (spec and tonumber(spec[1]) == C.deck and (tonumber(spec[2]) or 0) >= 7) then return end
			B.infil_start_hide(peer:unit(), math.min(tonumber(value) or 0, 4))
		end) end)
	end

	function B.infil_on_melee_kill()
		if B.infil_tier() < 7 then return end
		B.infil_melt_until = Application:time() + C.melt_time
		local state = managers.groupai and managers.groupai:state()
		if not (state and state:enemy_weapons_hot()) then return end
		B.infil_hide_until = Application:time() + C.hide_time
		if Network:is_server() then
			B.infil_start_hide(managers.player:player_unit(), C.hide_time)
		elseif LuaNetworking then
			pcall(LuaNetworking.SendToPeer, LuaNetworking, 1, B.NET_ID, "infil:" .. C.hide_time)
		end
	end

	function B.infil_on_melee_hit()
		if B.infil_tier() < 9 then return end
		local now = Application:time()
		if now - (B.infil_leech_t0 or -100) > C.leech_window then
			B.infil_leech_t0, B.infil_leech_sum = now, 0
		end
		local amount = math.min(C.leech, C.leech_cap - (B.infil_leech_sum or 0))
		if amount <= 0 then return end
		local unit = managers.player:player_unit()
		local dmg = alive(unit) and unit:character_damage()
		if dmg and not dmg:dead() and not dmg:need_revive() then
			B.infil_leech_sum = (B.infil_leech_sum or 0) + amount
			dmg:restore_health(amount)
		end
	end

	function B.infil_on_exposed_kill()
		if B.infil_tier() < 9 then return end
		local unit = managers.player:player_unit()
		local dmg = alive(unit) and unit:character_damage()
		if dmg and not dmg:dead() and not dmg:need_revive() then
			dmg:restore_health(C.exposed_heal)
		end
	end

	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_infil_reset", function()
		local session = managers.network and managers.network:session()
		if B._infil_session ~= session then
			B._infil_session = session
			B.infil_hide, B.infil_exposed = {}, {}
			B.infil_melt_until, B.infil_hide_until, B.infil_leech_t0, B.infil_leech_sum = nil, nil, nil, nil
		end
	end)

elseif script == "lib/units/enemies/cop/copdamage" then
	B.infil_exposed = B.infil_exposed or {}

	local function is_me(attack_data)
		local player = managers.player and managers.player:player_unit()
		return alive(player) and attack_data and attack_data.attacker_unit == player
	end

	local function exposed(self)
		local e = B.infil_exposed[self._unit:key()]
		return e and Application:time() < e
	end

	Hooks:PreHook(CopDamage, "damage_bullet", "GilzaDSBuffs_infil_bullet", function(self, attack_data)
		self._gdsb_infil_alive = not self._dead
		self._gdsb_infil_exposed = nil
		pcall(function()
			if not (is_me(attack_data) and type(attack_data.damage) == "number") then return end
			local tier = B.infil_tier()
			if tier < 3 then return end
			-- card 3 Point Blank: guns hit harder at close range
			local player = attack_data.attacker_unit
			if mvector3.distance(player:position(), self._unit:position()) <= C.point_blank_range then
				attack_data.damage = attack_data.damage * (1 + (B.on and C.point_blank_ds or C.point_blank))
			end
			if tier < 5 or not exposed(self) then return end
			self._gdsb_infil_exposed = true
			attack_data.damage = attack_data.damage * (1 + (B.on and C.expose_dmg_ds or C.expose_dmg))
		end)
	end)
	Hooks:PostHook(CopDamage, "damage_bullet", "GilzaDSBuffs_infil_bullet_post", function(self, attack_data)
		local was_alive, was_exposed = self._gdsb_infil_alive, self._gdsb_infil_exposed
		self._gdsb_infil_alive, self._gdsb_infil_exposed = nil, nil
		if was_alive and was_exposed and self._dead and B.infil_on_exposed_kill then
			pcall(B.infil_on_exposed_kill)
		end
	end)

	Hooks:PreHook(CopDamage, "damage_melee", "GilzaDSBuffs_infil_melee", function(self, attack_data)
		self._gdsb_infil_melee_alive = not self._dead
		self._gdsb_infil_melee_exposed = exposed(self)
	end)
	Hooks:PostHook(CopDamage, "damage_melee", "GilzaDSBuffs_infil_melee_post", function(self, attack_data)
		local was_alive, was_exposed = self._gdsb_infil_melee_alive, self._gdsb_infil_melee_exposed
		self._gdsb_infil_melee_alive, self._gdsb_infil_melee_exposed = nil, nil
		if not (was_alive and is_me(attack_data)) then return end
		pcall(function()
			local tier = B.infil_tier()
			if tier < 1 then return end
			if B.infil_on_melee_hit then B.infil_on_melee_hit() end
			if self._dead then
				if was_exposed and B.infil_on_exposed_kill then B.infil_on_exposed_kill() end
				if B.infil_on_melee_kill then B.infil_on_melee_kill() end
			elseif tier >= 5 then
				local until_t = Application:time() + (B.on and C.expose_time_ds or C.expose_time)
				B.infil_exposed[self._unit:key()] = until_t
				B.infil_last_exposed = self._unit
				-- Cleave: everyone close to the target is Exposed too
				local mask = managers.slot:get_mask("enemies")
				for _, u in ipairs(World:find_units_quick("sphere", self._unit:position(), C.cleave_range, mask) or {}) do
					local d = u ~= self._unit and alive(u) and u:character_damage()
					if d and not d._dead then B.infil_exposed[u:key()] = until_t end
				end
			end
		end)
	end)

elseif script == "lib/tweak_data/skilltreetweakdata" then
	-- Closing In and Life Leech replace Gilza's close contact damage reduction and melee life leech
	local REMOVE = {
		[3] = { player_damage_dampener_close_contact_1 = true },
		[5] = { player_damage_dampener_close_contact_2 = true },
		[7] = { player_damage_dampener_close_contact_3 = true },
		[9] = { player_melee_life_leech = true }
	}
	Hooks:PostHook(SkillTreeTweakData, "init", "GilzaDSBuffs_infil_cards", function(self)
		local deck = self.specializations and self.specializations[C.deck]
		for card, names in pairs(REMOVE) do
			local ups = deck and deck[card] and deck[card].upgrades
			if ups then
				for i = #ups, 1, -1 do
					if names[ups[i]] then table.remove(ups, i) end
				end
			end
		end
	end)
end
