GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs

B.NET_ID = "GilzaDSBuffs"
B.GUARDIAN_TEAM_HEAL = 0.5
B.GUARDIAN_TEAM_RESIST = { normal = 0.85, ds = 0.8 }
B.guardian_protect_until = 0

local function flat(pos)
	return Vector3(pos.x, pos.y, 0)
end

function B.guardian_team_tick()
	local pm = managers.player
	local area = pm and pm.Gilza_guardian_area
	local me = pm and pm:player_unit()
	if not (area and area.is_active and alive(me)) then return end

	local heal = pm:upgrade_value("player", "guardian_area_passive_health_regen", 0) * B.GUARDIAN_TEAM_HEAL
	if heal <= 0 then return end
	local center, radius = flat(area.position), area.radius or 300

	local session = managers.network and managers.network:session()
	if session and LuaNetworking then
		for _, peer in pairs(session:peers()) do
			local unit = peer:unit()
			if alive(unit) and mvector3.distance(flat(unit:position()), center) <= radius then
				LuaNetworking:SendToPeer(peer:id(), B.NET_ID, "guardian:" .. tostring(heal))
			end
		end
	end

	if Network:is_server() and managers.groupai and managers.groupai:state() then
		for _, data in pairs(managers.groupai:state():all_AI_criminals() or {}) do
			local unit = data.unit
			local dmg = alive(unit) and unit:character_damage()
			if dmg and dmg._health and dmg._HEALTH_INIT and not dmg._bleed_out and not dmg._fatal and not dmg._dead
				and mvector3.distance(flat(unit:position()), center) <= radius then
				local my_max = me:character_damage():_max_health()
				local bot_heal = my_max > 0 and heal / my_max * dmg._HEALTH_INIT or 0
				dmg._health = math.min(dmg._health + bot_heal, dmg._HEALTH_INIT)
				dmg._health_ratio = dmg._health / dmg._HEALTH_INIT
			end
		end
	end
end

function B.guardian_team_loop()
	pcall(B.guardian_team_tick)
	DelayedCalls:Add("GilzaDSBuffs_guardian_team", 2, function()
		B.guardian_team_loop()
	end)
end

if PlayerManager.Gilza_start_guardian_tracking then
	local orig_start = PlayerManager.Gilza_start_guardian_tracking
	function PlayerManager:Gilza_start_guardian_tracking(...)
		local r = orig_start(self, ...)
		B.guardian_team_loop()
		return r
	end
end

function B.on_guardian_heal(amount)
	local unit = managers.player and managers.player:player_unit()
	local dmg = alive(unit) and unit:character_damage()
	if not dmg or dmg:need_revive() or dmg:dead() then return end
	dmg:restore_health(amount, true)
	B.guardian_protect_until = TimerManager:game():time() + 2.5
end

local orig_resist = PlayerManager.damage_reduction_skill_multiplier
function PlayerManager:damage_reduction_skill_multiplier(...)
	local m = orig_resist(self, ...)
	if type(m) == "number" and TimerManager:game():time() < (B.guardian_protect_until or 0) then
		m = m * (B.on and B.GUARDIAN_TEAM_RESIST.ds or B.GUARDIAN_TEAM_RESIST.normal)
	end
	return m
end

if LuaNetworking and LuaNetworking.AddReceiveHook then
	LuaNetworking:AddReceiveHook(B.NET_ID, "GilzaDSBuffs_net", function(data, sender)
		local amount = tonumber(string.match(data or "", "^guardian:([%d%.]+)$") or "")
		if amount and amount > 0 and amount <= 10 then
			pcall(B.on_guardian_heal, amount)
		end
	end)
end
