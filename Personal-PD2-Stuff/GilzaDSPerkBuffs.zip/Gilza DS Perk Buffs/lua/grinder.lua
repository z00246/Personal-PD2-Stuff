GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

-- (7.22 rework, Geo: "I also want it to have overheal ... instead of it sharing the health with everyone else", then
-- "Engorged" and Geo HUD option A) Overheal replaces Overgrowth: healing you get at full health is kept as extra health
-- on top of your maximum (up to 15% » 20% of it), lost before your health, fading 2% of your max health a second, gone
-- when your health drops below full, you go down or into custody. Engorged (card 7): while you have Overheal, each
-- stack gives 5% more damage instead of 3%. Stacks 5 » 6 and the stack heals (buffs.lua niche) scale with the
-- difficulty. Overheal is local: player damage is worked out on your own machine, peers see your normal health.
B.GRINDER = {
	deck = 11,
	cooldown = 0.75,
	max_stacks = 5,
	max_stacks_ds = 6,
	bloodlust = 0.03,
	engorged = 0.05,
	overheal_cap = 0.15,
	overheal_cap_ds = 0.2,
	overheal_fade = 0.02,
	frenzy_stacks = 3,
	gorge_health = 0.35,
	gorge_mul = 2,
	fire_cooldown = 2 -- fire damage (flamethrowers, Dragon's Breath, molotovs, burning) grants a stack at most this often
}
local C = B.GRINDER

function B.grinder_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == C.deck) then
		return 0
	end
	return st:get_specialization_value(C.deck, "tiers", "current_tier") or 0
end

function B.grinder_stacks()
	local unit = managers.player and managers.player:player_unit()
	local dmg = alive(unit) and unit:character_damage()
	local stack = dmg and dmg._damage_to_hot_stack
	return stack and #stack or 0
end

-- 5 stacks up to Overkill, 6 from Death Wish (Mayhem 5.33 rounds to 5)
function B.grinder_cap()
	if B.sci then return B.sci(C.max_stacks, C.max_stacks_ds) end
	return B.on and C.max_stacks_ds or C.max_stacks
end

-- Overheal cap as a share of your maximum health (15% » 20%)
function B.grinder_overheal_frac()
	if B.sc then return B.sc(C.overheal_cap, C.overheal_cap_ds) end
	return C.overheal_cap
end

-- Bloodlust per stack: 3%, or 5% while Engorged (card 7 with Overheal)
function B.grinder_bloodlust_per()
	if (B.grinder_overheal or 0) > 0 and B.grinder_tier() >= 7 then return C.engorged end
	return C.bloodlust
end

-- full health = the game's max health times any max-health reduction (the same as PlayerDamage:set_health clamps to)
local function eff_max(dmg)
	return dmg:_max_health() * (dmg._max_health_reduction or 1)
end
B.grinder_eff_max = eff_max

B.grinder_overheal = B.grinder_overheal or 0

if script == "lib/managers/playermanager" then
	-- faster stacking with a stack cap (only affects whoever owns the damage_to_hot upgrade)
	local function apply_tweak()
		local data = tweak_data and tweak_data.upgrades and tweak_data.upgrades.damage_to_hot_data
		if not data then return end
		if data.stacking_cooldown ~= C.cooldown then data.stacking_cooldown = C.cooldown end
		local cap = B.grinder_cap()
		if data.max_stacks ~= cap then data.max_stacks = cap end
	end
	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_grinder_tweak", function() apply_tweak() end)
	Hooks:Add("MenuUpdate", "GilzaDSBuffs_grinder_tweak_menu", function() apply_tweak() end)

	-- Overheal fades, and is gone when your health is below full, you are down or no longer a Grinder (card 5+)
	local function overheal_update(t, dt)
		local over = B.grinder_overheal or 0
		if over <= 0 then return end
		local unit = managers.player and managers.player:player_unit()
		local dmg = alive(unit) and unit:character_damage()
		local why
		if not dmg then why = "no player"
		elseif B.grinder_tier() < 5 then why = "not card 5"
		elseif dmg:need_revive() or dmg:dead() then why = "down"
		elseif dmg:get_real_health() < eff_max(dmg) - 0.001 then why = "health below full" end
		if why then
			B.grinder_overheal = 0
			B.live("grinder overheal cleared", "%s", why)
			return
		end
		local max = eff_max(dmg)
		over = math.min(over, max * B.grinder_overheal_frac())
		B.grinder_overheal = math.max(0, over - C.overheal_fade * max * (dt or 0))
		if B.grinder_overheal <= 0 then B.live("grinder overheal faded", "gone") end
	end
	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_grinder_overheal", function(t, dt) overheal_update(t, dt) end)

	Hooks:PostHook(PlayerManager, "_setup", "GilzaDSBuffs_grinder_overheal_reset", function()
		B.grinder_overheal = 0
	end)
	Hooks:PreHook(PlayerManager, "on_enter_custody", "GilzaDSBuffs_grinder_overheal_custody", function()
		B.grinder_overheal = 0
	end)

	-- Flamethrowers hit constantly and set whole crowds burning, which kept every stack up forever:
	-- fire damage can only grant a stack every 2 seconds (other damage keeps the normal 0.75s)
	local orig_doh = PlayerManager._check_damage_to_hot
	function PlayerManager:_check_damage_to_hot(t, unit, damage_info, ...)
		if damage_info and damage_info.variant == "fire" then
			if t < (B._grinder_fire_next or 0) then return end
			local before = self._next_allowed_doh_t
			local r = orig_doh(self, t, unit, damage_info, ...)
			if self._next_allowed_doh_t ~= before then
				B._grinder_fire_next = t + C.fire_cooldown
			end
			return r
		end
		return orig_doh(self, t, unit, damage_info, ...)
	end

	-- Gorge: stacks heal twice as much per tick while at low health
	local orig_uv = PlayerManager.upgrade_value
	function PlayerManager:upgrade_value(category, upgrade, default, ...)
		local v = orig_uv(self, category, upgrade, default, ...)
		if upgrade == "damage_to_hot" and category == "player" and type(v) == "number" and v > 0 then
			if B.grinder_tier() >= 9 then
				local unit = self:player_unit()
				local dmg = alive(unit) and unit:character_damage()
				if dmg and dmg:health_ratio() < C.gorge_health then
					return v * C.gorge_mul
				end
			end
		end
		return v
	end

	-- Frenzy: kills with 3+ stacks refresh every stack
	Hooks:PostHook(PlayerManager, "on_killshot", "GilzaDSBuffs_grinder_frenzy", function(self, killed_unit, variant)
		if variant == "fire" then return end -- burning kills don't refresh stacks
		if B.grinder_tier() < 7 then return end
		local unit = self:player_unit()
		local dmg = alive(unit) and unit:character_damage()
		local stack = dmg and dmg._damage_to_hot_stack
		if not stack or #stack < C.frenzy_stacks then return end
		local data = dmg._doh_data or {}
		local extra = self:upgrade_value("player", "damage_to_hot_extra_ticks", 0)
		local full = (data.total_ticks or 1) + (type(extra) == "number" and extra or 0)
		for _, s in ipairs(stack) do
			s.ticks_left = full
		end
		B.grinder_frenzy_t = Application:time()
	end)

elseif script == "lib/units/beings/player/playerdamage" then
	-- Overheal: healing that doesn't fit because your health is full is kept, up to the cap
	local function add_overheal(self, before, amount, is_static)
		local max = eff_max(self)
		local now_hp = self:get_real_health()
		if now_hp < max - 0.0001 then return end
		local intended = amount * (self._healing_reduction or 1)
		if not is_static then intended = intended * self:_max_health() end
		local over = intended - (now_hp - before)
		if over <= 0.0001 then return end
		local cap = max * B.grinder_overheal_frac()
		local cur = B.grinder_overheal or 0
		local new = math.min(cap, cur + over)
		if new <= cur then return end
		B.grinder_overheal = new
		B.live("grinder overheal gain", "+%.1f -> %.1f of %.1f", (new - cur) * 10, new * 10, cap * 10)
	end
	local orig_restore = PlayerDamage.restore_health
	function PlayerDamage:restore_health(health_restored, is_static, ...)
		if B.grinder_tier() < 5 or type(health_restored) ~= "number" or health_restored <= 0 then
			return orig_restore(self, health_restored, is_static, ...)
		end
		local before = self:get_real_health()
		local result = orig_restore(self, health_restored, is_static, ...)
		add_overheal(self, before, health_restored, is_static)
		return result
	end

	-- Overheal is lost before your health (after armor: this is the health part of a hit)
	local function soak(self, attack_data)
		local over = B.grinder_overheal or 0
		if over <= 0 or not attack_data or type(attack_data.damage) ~= "number" or attack_data.damage <= 0 then return end
		local s = math.min(over, attack_data.damage)
		B.grinder_overheal = over - s
		attack_data.damage = attack_data.damage - s
		B.live("grinder overheal soak", "%.1f taken, %.1f left, %.1f through to health", s * 10, B.grinder_overheal * 10,
			attack_data.damage * 10)
	end
	local orig_calc = PlayerDamage._calc_health_damage
	function PlayerDamage:_calc_health_damage(attack_data, ...)
		soak(self, attack_data)
		return orig_calc(self, attack_data, ...)
	end

elseif script == "lib/units/enemies/cop/copdamage" then
	-- Bloodlust: +3% damage per active stack (Engorged: +5% while you have Overheal)
	local function bloodlust(self, attack_data)
		if not attack_data or type(attack_data.damage) ~= "number" then return end
		local player = managers.player and managers.player:player_unit()
		if not (alive(player) and attack_data.attacker_unit == player) then return end
		if B.grinder_tier() < 3 then return end
		local n = math.min(B.grinder_stacks(), B.grinder_cap())
		if n > 0 then
			local per = B.grinder_bloodlust_per()
			attack_data.damage = attack_data.damage * (1 + per * n)
			if per ~= C.bloodlust then B.live("grinder engorged", "%d stacks x %d%%", n, math.floor(per * 100 + 0.5)) end
		end
	end
	for _, fn in ipairs({ "damage_bullet", "damage_melee" }) do
		Hooks:PreHook(CopDamage, fn, "GilzaDSBuffs_grinder_" .. fn, function(self, attack_data)
			bloodlust(self, attack_data)
		end)
	end
end
