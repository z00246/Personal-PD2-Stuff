if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics
T.message = "Police are more tactical and dangerous."

local function greet(peer)
	if not peer or not peer.send then return end
	peer:send("send_chat_message", ChatManager.GAME, T.name .. " " .. T.message)
	if LuaNetworking then
		LuaNetworking:SendToPeer(peer:id(), T.NET_ID, "host")
	end
end

Hooks:Add("BaseNetworkSessionOnLoadComplete", "PDTHTactics_announce", function()
	if not T.active() then return end
	DelayedCalls:Add("PDTHTactics_announce", 2, function()
		local session = managers.network and managers.network:session()
		for _, peer in pairs(session and session:peers() or {}) do
			pcall(greet, peer)
		end
	end)
end)

Hooks:Add("BaseNetworkSessionOnPeerEnteredLobby", "PDTHTactics_announce_joiner", function(peer, peer_id)
	if not T.active() then return end
	DelayedCalls:Add("PDTHTactics_announce_" .. tostring(peer_id), 3, function()
		local session = managers.network and managers.network:session()
		pcall(greet, session and session:peer(peer_id))
	end)
end)

Hooks:Add("NetworkManagerOnPeerAdded", "PDTHTactics_peer_added", function(peer, peer_id)
	T.modded_peers[peer_id] = nil
	if not T.active() then return end
	DelayedCalls:Add("PDTHTactics_handshake_" .. tostring(peer_id), 8, function()
		if T.active() and LuaNetworking then
			pcall(LuaNetworking.SendToPeer, LuaNetworking, peer_id, T.NET_ID, "host")
		end
	end)
end)

Hooks:Add("BaseNetworkSessionOnPeerRemoved", "PDTHTactics_peer_removed", function(peer, peer_id)
	T.modded_peers[peer_id] = nil
end)

if LuaNetworking and LuaNetworking.AddReceiveHook then
	LuaNetworking:AddReceiveHook(T.NET_ID, "PDTHTactics_net", function(data, sender)
		local is_host = Network and Network:is_server()
		if data == "host" and not is_host and sender == 1 then
			T.remote_host_session = managers.network and managers.network:session()
			T.apply(false)
			LuaNetworking:SendToPeer(1, T.NET_ID, "client")
		elseif data == "client" and is_host and sender then
			T.modded_peers[sender] = true
		elseif not is_host and sender == 1 and T.client_on() then
			local dur = string.match(data or "", "^focus:([%d%.]+)$")
			if dur then
				T.sniper_focus(tonumber(dur))
			elseif data == "unfocus" then
				T.sniper_unfocus()
			elseif data == "hrt" then
				T.set_hrt_banner(true)
			elseif data == "hrt_off" then
				T.set_hrt_banner(false)
			end
		end
	end)
end
