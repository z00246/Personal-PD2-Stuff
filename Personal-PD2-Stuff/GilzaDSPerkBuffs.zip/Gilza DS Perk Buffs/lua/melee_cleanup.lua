-- (7.15) The melee weapon left in the hand after a swing (Geo: "it would not show my weapon model or switch it for
-- something else" - "but that was my melee": his screenshot shows the Great Sword in the hand and no gun after picking
-- things up).
--
-- The swing animation itself swaps the gun and the melee weapon: the wind-up (fps/melee_enter's exit keys) hides the gun
-- and puts the melee weapon in the hand, and the swing's last part (fps/melee_exit's enter keys) shows the gun and takes
-- the melee weapon away. The game only tidies up by itself when it interrupts a melee (PlayerStandard:
-- _interupt_action_melee), and that does nothing once the melee's timers have run out. Any other first-person animation
-- that starts before the swing reaches fps/melee_exit (an interaction's grab or put-away, a reload, sprinting, another
-- mod's animation) skips that part, and the melee weapon stays in the hand with the gun hidden until the next melee.
--
-- Here, every frame in the normal player states (standard, carrying a bag, on a bipod): when no melee is going on any
-- more, the melee weapon is still out and the arms have left the swing for 0.1 s, do what fps/melee_exit would have
-- done: take the melee weapon away and show the gun again (unless the animation now playing hides the gun itself and
-- shows it at its end - a throwable, the mask going on, the Taser counter - or Interaction Animations hid it for a
-- lockpick, a drill fix or a radio). Arms left in the wind-up with no melee going on (0.5 s) get the game's own melee
-- interrupt: the equip animation, then the same tidy-up. Each repair writes a line to the log ("melee weapon left in the
-- hand") with the animation it found, so the next one shows what cut the swing short.
GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript

if script == "lib/units/cameras/fpcameraplayerbase" then
	-- the melee weapon is out (the same animation keys hid the gun right before) until anything takes it away again
	Hooks:PreHook(FPCameraPlayerBase, "spawn_melee_item", "GilzaDSBuffs_melee_out", function(self)
		self._gdsb_melee_out = true
	end)
	Hooks:PreHook(FPCameraPlayerBase, "unspawn_melee_item", "GilzaDSBuffs_melee_in", function(self)
		self._gdsb_melee_out = nil
	end)

elseif script == "lib/units/beings/player/states/playerstandard" then
	local function ids_set(names)
		local s = {}
		for _, n in ipairs(names) do s[Idstring(n):key()] = n end
		return s
	end
	local IDS_BASE = Idstring("base")
	-- the swing: it still ends in fps/melee_exit, which tidies up by itself
	local SWING = ids_set({ "fps/melee_attack", "fps/melee_exit" })
	-- the wind-up: only a swing or an interrupt takes the arms out of it
	local WINDUP = ids_set({ "fps/melee_enter", "fps/melee_start", "fps/melee_charge" })
	-- animations that hide the gun themselves and show it again at their end (fps_spawn.animation_states)
	local HIDES = ids_set({ "fps/throw_projectile_enter", "fps/throw_projectile_start", "fps/throw_projectile_idle",
		"fps/throw_projectile", "fps/throw_projectile_exit", "fps/throw_grenade_enter", "fps/throw_grenade",
		"fps/throw_molotov_enter", "fps/throw_molotov", "fps/throw_concussion_enter", "fps/throw_concussion",
		"fps/throw_dada_enter", "fps/throw_dada", "fps/throw_snowball_enter", "fps/throw_snowball", "fps/throw_grenade_exit",
		"fps/mask_equip", "fps/enter_tazer_counter", "fps/tazer_counter", "fps/cuffed", "fps/cuffed/enter", "fps/cuffed/idle",
		"fps/cuffed/rescued", "fps/cuffed/escape", "fps/wheel_idle", "fps/wheel_turn_left", "fps/wheel_turn_right" })
	-- names for the log line (the state machine only hands back ids)
	local NAMES = ids_set({ "fps/idle", "fps/empty", "fps/use", "fps/equip", "fps/unequip", "fps/start_running", "fps/running",
		"fps/stop_running", "fps/recoil", "fps/recoil_steelsight", "fps/recoil_enter", "fps/recoil_loop", "fps/recoil_exit",
		"fps/melee", "fps/melee_miss", "fps/melee_bayonet", "fps/melee_miss_bayonet", "fps/cash_inspect", "fps/charge",
		"fps/tased", "fps/tased_exit", "fps/passenger_vehicle",
		"fps/interact_enter/fix_drill", "fps/interact_enter/answer_radio", "fps/interact_enter/lockpick",
		"fps/interact_hold/fix_drill", "fps/interact_hold/answer_radio", "fps/interact_hold/lockpick",
		"fps/interact_exit/fix_drill", "fps/interact_exit/answer_radio", "fps/interact_exit/lockpick",
		"fps/interact_interupt/fix_drill", "fps/interact_interupt/answer_radio", "fps/interact_interupt/lockpick" })
	for _, set in ipairs({ SWING, WINDUP, HIDES }) do
		for k, n in pairs(set) do NAMES[k] = n end
	end
	local STATES = { standard = true, carry = true, bipod = true }
	local CUT_WAIT, WINDUP_WAIT = 0.1, 0.5
	local reports = 0

	local function repair(self, t, cam, key, windup)
		local inv = self._unit and self._unit:inventory()
		local gun = inv and inv:equipped_unit()
		local gb = alive(gun) and gun:base() or nil
		-- (hidden by the melee's hide_weapon: set_visibility_state(false) keeps _visible = false; a gun shown again, or
		-- one never hidden, is left as it is - show_weapon also turns the gun's gadget back on)
		local hidden = gb and gb._visible == false or false
		local equip = windup and not self._interact_expire_t
		if equip then
			-- the game's own melee interrupt: the equip animation first, then the tidy-up
			self._ext_camera:play_redirect(self:get_animation("equip"))
			if gb and gb.tweak_data_anim_stop and gb.tweak_data_anim_play then
				gb:tweak_data_anim_stop("unequip")
				gb:tweak_data_anim_play("equip")
			end
			local sd = self._state_data
			if sd and sd.melee_charge_shake then
				local shaker = self._ext_camera.shaker and self._ext_camera:shaker()
				if shaker then shaker:stop(sd.melee_charge_shake) end
				sd.melee_charge_shake = nil
			end
		end
		local had_item = cam._melee_item_units and true or false
		cam:unspawn_melee_item()
		cam._gdsb_melee_out = nil
		local show = hidden and (equip or not (key and HIDES[key])) and not cam._int_anim_weapon_hidden
		if show then
			cam:show_weapon()
		end
		reports = reports + 1
		if reports <= 5 then
			local sw = self._gdsb_swing
			log(string.format("[Gilza DS Perk Buffs] melee weapon left in the hand: %s, %s%s (arms in %s; swing %s s ago, %s, game clock %+.2f s)",
				had_item and "took it away" or "nothing in the hand", show and "showed the gun" or (hidden and "gun left to that animation" or "gun already out"),
				equip and ", equip animation" or "", tostring(key and NAMES[key] or key),
				sw and type(sw.t) == "number" and string.format("%.2f", t - sw.t) or "?",
				self._interact_expire_t and "interacting" or "not interacting", Application:time() - t))
		end
	end

	local function watch(self, t)
		local cam_unit = self._camera_unit
		local cam = alive(cam_unit) and cam_unit:base() or nil
		if not (cam and (cam._gdsb_melee_out or cam._melee_item_units)) or self:_is_meleeing() then
			self._gdsb_melee_left_t = nil
			return
		end
		local movement = self._ext_movement
		if not (movement and STATES[movement:current_state_name()]) then
			self._gdsb_melee_left_t = nil
			return
		end
		local asm = cam_unit:anim_state_machine()
		local state = asm and asm:segment_state(IDS_BASE)
		local key = state and state:key()
		if key and SWING[key] then
			self._gdsb_melee_left_t = nil
			return
		end
		local windup = key and WINDUP[key] and true or false
		local since = self._gdsb_melee_left_t
		if not since or since > t then
			self._gdsb_melee_left_t = t
			return
		end
		if t - since < (windup and WINDUP_WAIT or CUT_WAIT) then
			return
		end
		self._gdsb_melee_left_t = nil
		repair(self, t, cam, key, windup)
	end

	Hooks:PostHook(PlayerStandard, "update", "GilzaDSBuffs_melee_left_in_hand", function(self, t, dt)
		if type(t) ~= "number" then return end
		watch(self, t)
	end)
end
