if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics
local script = RequiredScript and RequiredScript:lower() or ""

-- Restoration Mod factions (NYPD, LAPD, Reapers, Sharks, Bravo), shipped in the separate "PDTH Factions" mod.
-- A faction is only used when the host and every player in the lobby have that pack loaded;
-- otherwise everyone gets the normal enemies. Appearance (heads/gear variations) is rolled locally.

if not T.FD then
	local ok, data = pcall(dofile, ModPath .. "lua/faction_data.lua")
	T.FD = ok and data or nil
	if not ok then log(T.name .. " faction data failed: " .. tostring(data)) end
end
local D = T.FD
if not D then return end

local UNIT = Idstring("unit")
T.fac_peers = T.fac_peers or {}

-- key lookups (built once per Lua state)
if not T._fac_keys then
	T._fac_keys = { role = {}, faction_units = {}, enemy_seq = {}, head_seq = {} }
	local K = T._fac_keys
	for path, role in pairs(D.role) do K.role[Idstring(path):key()] = role end
	for _, list in pairs(D.units) do
		for _, path in ipairs(list) do
			K.faction_units[Idstring(path):key()] = true
			K.faction_units[Idstring(path .. "_husk"):key()] = true
		end
	end
	for path, seq in pairs(D.enemy_seq) do
		K.enemy_seq[Idstring(path):key()] = seq
		K.enemy_seq[Idstring(path .. "_husk"):key()] = seq
	end
	K.unit_weapon, K.weapons = {}, {}
	for path, w in pairs(D.unit_weapon or {}) do
		K.unit_weapon[Idstring(path):key()] = w
		K.unit_weapon[Idstring(path .. "_husk"):key()] = w
	end
	for _, w in ipairs(D.weapons or {}) do K.weapons[Idstring(w.unit):key()] = w end
	for path, seq in pairs(D.head_seq) do
		K.head_seq[Idstring(path):key()] = seq
		K.head_seq[Idstring(path .. "_husk"):key()] = seq
	end
end
local K = T._fac_keys


-- Restoration's faction guns. Stats, ids and network sync stay vanilla: the host and every client
-- (all have this mod whenever a faction is active) just show the faction's gun model instead.
local function vanilla_weapon_name(base_id)
	local c = tweak_data.character
	local i = c and c.weap_ids and table.index_of(c.weap_ids, base_id)
	return i and i > 0 and c.weap_unit_names[i] or nil
end

function T.faction_weapon_for(char_unit, wanted_name)
	if not (alive(char_unit) and wanted_name) then return end
	local custom = K.unit_weapon[char_unit:name():key()]
	if not custom then return end
	local w = K.weapons[Idstring(custom):key()]
	local van = w and vanilla_weapon_name(w.base)
	if van and van:key() == wanted_name:key() and DB:has(UNIT, Idstring(custom)) then
		return Idstring(custom)
	end
end

function T.level_faction()
	local level = Global.level_data and Global.level_data.level_id or Global.game_settings and Global.game_settings.level_id
	local f = level and D.levels[level]
	if not f and tweak_data and tweak_data.levels and tweak_data.levels.get_ai_group_type then
		local t = tweak_data.levels:get_ai_group_type()
		if t == "russia" or t == "murkywater" then f = t end
	end
	return f
end

local function pack_present(f)
	local list = D.units[f]
	return list and list[1] and DB:has(UNIT, Idstring(list[1])) or false
end

-- load a faction's units into memory; true when all are ready
local function load_faction(f)
	T._fac_loaded = T._fac_loaded or {}
	if T._fac_loaded[f] ~= nil then return T._fac_loaded[f] end
	T._fac_loaded[f] = false
	if not (BeardLib and pack_present(f) and managers.dyn_resource) then return false end
	local dyn = managers.dyn_resource
	for _, path in ipairs(D.units[f]) do
		for _, name in ipairs({ path, path .. "_husk" }) do
			local ids = Idstring(name)
			if DB:has(UNIT, ids) and not PackageManager:has(UNIT, ids) then
				dyn:load(UNIT, ids, dyn.DYN_RESOURCES_PACKAGE, nil)
			end
		end
	end
	for _, path in ipairs(D.units[f]) do
		if not (PackageManager:has(UNIT, Idstring(path)) and PackageManager:has(UNIT, Idstring(path .. "_husk"))) then
			log(T.name .. " faction " .. f .. " failed to load " .. path)
			return false
		end
	end
	T._fac_loaded[f] = true
	return true
end

local function everyone_has(f)
	local have = T.fac_peers[f] or {}
	local session = managers.network and managers.network:session()
	for _, peer in pairs(session and session:peers() or {}) do
		if not have[peer:id()] then return false end
	end
	return true
end

function T.faction_usable(f)
	return f and T._fac_loaded and T._fac_loaded[f] and everyone_has(f) or false
end

-- the faction swapping right now (host), or nil
function T.faction_now()
	if not T.active() then return nil end
	local f = T.level_faction()
	return T.faction_usable(f) and f or nil
end

local BRAVO = {
	swat_1 = "rifle", swat_2 = "shotgun", heavy_1 = "lmg", heavy_2 = "shotgun",
	fsb_swat_1 = "rifle", fsb_swat_2 = "shotgun", fsb_heavy = "lmg"
}
local BRAVO_SUFFIX = { america = "", nypd = "", lapd = "", fbi = "", russia = "_ru", murkywater = "_murky", federales = "_mex" }
local DIFF_ORDER = { "sm_wish", "overkill_290", "easy_wish", "overkill_145", "overkill", "hard", "normal", "easy" }
T.BRAVO_CHANCE = 0.25
T.BRAVO_FROM_ASSAULT = 3

local function pick_bravo(role)
	local kind = BRAVO[role]
	if not kind or math.random() > T.BRAVO_CHANCE then return end
	if not (T.is_ds() and T.faction_usable("bravo")) then return end
	local state = managers.groupai and managers.groupai:state()
	local n = state and state._assault_number or 0
	if n < T.BRAVO_FROM_ASSAULT then return end
	local group = T.level_faction() or (tweak_data.levels:get_ai_group_type())
	local suffix = BRAVO_SUFFIX[group]
	if not suffix then return end
	local path = "units/pd2_mod_bravo/characters/ene_bravo_" .. kind .. suffix .. "/ene_bravo_" .. kind .. suffix
	return Idstring(path)
end

function T.faction_pick(name, group_spawn)
	if not name then return end
	local role = K.role[name:key()]
	if not role then return end
	if group_spawn then
		local b = pick_bravo(role)
		if b then return b end
	end
	local f = T.faction_now()
	if not f then return end
	-- use this difficulty's list; if the faction has nothing of its own there (e.g. Restoration puts
	-- ZEAL on Death Sentence everywhere), fall back to the closest lower difficulty that does
	local diff = Global.game_settings and Global.game_settings.difficulty or "overkill"
	local start = false
	for _, d in ipairs(DIFF_ORDER) do
		if d == diff then start = true end
		if start then
			local list = D.faction[f][d] and D.faction[f][d][role]
			if list and #list > 0 then return Idstring(list[math.random(#list)]) end
		end
	end
end

function T.is_faction_unit(unit)
	return alive(unit) and K.faction_units[unit:name():key()] or false
end

-- heads, gear and body variations (Restoration's CopBase:_run_unit_sequences, local only)
local short_body_objects = { Idstring("g_body_short"), Idstring("g_body_b_short"), Idstring("g_body_short_fbi"), Idstring("g_body_b_short_fbi") }
local function run_sequences(base)
	local unit = base._unit
	if not alive(unit) then return end
	local key = unit:name():key()
	if not K.faction_units[key] then return end
	local dmg = unit:damage()
	local seq = K.enemy_seq[key]
	if seq and dmg and dmg:has_sequence(seq) then dmg:run_sequence_simple(seq) end

	local short_body = false
	for _, obj_name in ipairs(short_body_objects) do
		local obj = unit:get_object(obj_name)
		if obj and obj:visibility() then short_body = true break end
	end

	local spawn = unit:spawn_manager()
	local head = unit:character_damage() and unit:character_damage()._head
	if spawn and head then
		managers.dyn_resource:load(UNIT, Idstring(head), managers.dyn_resource.DYN_RESOURCES_PACKAGE, nil)
		spawn:spawn_and_link_unit("_char_joint_names", "cop_head", head)
		base._head_unit = spawn:get_unit("cop_head")
	end
	local head_unit = base._head_unit
	if alive(head_unit) then
		head_unit:set_enabled(unit:enabled())
		local hd = head_unit:damage()
		if hd then
			local arms = short_body and "arms_short_on" or "arms_short_off"
			if hd:has_sequence(arms) then hd:run_sequence_simple(arms) end
			local hs = K.head_seq[key]
			if hs and hd:has_sequence(hs) then hd:run_sequence_simple(hs) end
		end
	end
end

if script == "lib/units/beings/player/playerinventory" then
	-- host: report a faction gun to clients as its vanilla counterpart
	local orig_idx = PlayerInventory._get_weapon_sync_index
	function PlayerInventory._get_weapon_sync_index(wanted_weap_name, ...)
		if type(wanted_weap_name) ~= "string" and wanted_weap_name and wanted_weap_name.key then
			local w = K.weapons[wanted_weap_name:key()]
			local van = w and vanilla_weapon_name(w.base)
			if van then wanted_weap_name = van end
		end
		return orig_idx(wanted_weap_name, ...)
	end

elseif script == "lib/units/enemies/cop/copinventory" then
	local orig_add = CopInventory.add_unit_by_name
	function CopInventory:add_unit_by_name(new_unit_name, ...)
		local ok, custom = pcall(T.faction_weapon_for, self._unit, new_unit_name)
		return orig_add(self, ok and custom or new_unit_name, ...)
	end

elseif script == "lib/units/enemies/cop/huskcopinventory" then
	local orig_add = HuskCopInventory.add_unit_by_name
	function HuskCopInventory:add_unit_by_name(new_unit_name, ...)
		local ok, custom = pcall(T.faction_weapon_for, self._unit, new_unit_name)
		return orig_add(self, ok and custom or new_unit_name, ...)
	end

elseif script == "lib/tweak_data/weapontweakdata" then
	-- the guns keep vanilla stats: their tweak entries are copies of the matching vanilla enemy gun
	Hooks:PostHook(WeaponTweakData, "init", "PDTHTactics_faction_weapon_stats", function(self)
		for _, w in ipairs(D.weapons or {}) do
			if not self[w.name_id] then
				local src = self[w.base .. "_npc"] or self[w.base] or self.m4_npc
				if src then self[w.name_id] = deep_clone(src) end
			end
		end
	end)

elseif script == "lib/units/enemies/cop/copbase" then
	-- outlines for the faction units and their separate heads
	if CopBase._material_translation_map then
		for _, path in ipairs(D.contour) do
			local n, c = Idstring(path), Idstring(path .. "_contour")
			CopBase._material_translation_map[tostring(n:key())] = c
			CopBase._material_translation_map[tostring(c:key())] = n
		end
	end

	-- class used by the separate head units
	if not ContourSwapBase then
		ContourSwapBase = class()
		ContourSwapBase._material_translation_map = CopBase._material_translation_map
		ContourSwapBase.swap_material_config = CopBase.swap_material_config
		ContourSwapBase.on_material_applied = CopBase.on_material_applied
		ContourSwapBase.is_in_original_material = CopBase.is_in_original_material
		ContourSwapBase.set_material_state = CopBase.set_material_state
		function ContourSwapBase:init(unit)
			UnitBase.init(self, unit, false)
			self._unit = unit
			self._is_in_original_material = true
		end
	end

	Hooks:PostHook(CopBase, "post_init", "PDTHTactics_faction_looks", function(self)
		local ok, err = pcall(run_sequences, self)
		if not ok and not T._fac_seq_err then
			T._fac_seq_err = true
			log(T.name .. " faction looks error: " .. tostring(err))
		end
	end)

elseif script == "lib/units/enemies/cop/huskcopbase" then
	Hooks:PreHook(HuskCopBase, "post_init", "PDTHTactics_faction_looks_husk", function(self)
		local ok, err = pcall(run_sequences, self)
		if not ok and not T._fac_seq_err then
			T._fac_seq_err = true
			log(T.name .. " faction looks error: " .. tostring(err))
		end
	end)

elseif script == "lib/managers/mission/elementspawnenemydummy" then
	-- load this level's faction (and Bravo on Death Sentence) once the game runs, then tell the host
	Hooks:Add("GameSetupUpdate", "PDTHTactics_faction_load", function()
		if T._fac_done then return end
		T._fac_done = true
		local wanted = {}
		local f = T.level_faction()
		if f then table.insert(wanted, f) end
		if T.is_ds() then table.insert(wanted, "bravo") end
		T._fac_wanted = wanted
		for _, w in ipairs(wanted) do
			local ok, err = pcall(load_faction, w)
			if not ok then
				T._fac_loaded[w] = false
				log(T.name .. " faction " .. w .. " load error: " .. tostring(err))
			end
		end
	end)

	-- clients: keep telling the host which packs are ready until it has heard (cheap, every few seconds)
	Hooks:Add("GameSetupUpdate", "PDTHTactics_faction_announce", function()
		if Network and Network:is_server() then return end
		if not (T._fac_done and T.client_on() and LuaNetworking) then return end
		local t = Application:time()
		if t < (T._fac_announce_t or 0) then return end
		T._fac_announce_t = t + 5
		for _, w in ipairs(T._fac_wanted or {}) do
			if T._fac_loaded and T._fac_loaded[w] then
				pcall(LuaNetworking.SendToPeer, LuaNetworking, 1, T.NET_ID, "fac:" .. w)
			end
		end
	end)

	if LuaNetworking and LuaNetworking.AddReceiveHook then
		LuaNetworking:AddReceiveHook(T.NET_ID, "PDTHTactics_faction_net", function(data, sender)
			local f = type(data) == "string" and string.match(data, "^fac:(%w+)$")
			if f and sender and Network and Network:is_server() then
				T.fac_peers[f] = T.fac_peers[f] or {}
				T.fac_peers[f][sender] = true
			end
		end)
	end

	Hooks:Add("BaseNetworkSessionOnPeerRemoved", "PDTHTactics_faction_peer_removed", function(peer, peer_id)
		for _, list in pairs(T.fac_peers) do list[peer_id] = nil end
	end)

	-- someone joins: drop faction units before their game loads them (new spawns stay vanilla until they confirm)
	Hooks:Add("NetworkManagerOnPeerAdded", "PDTHTactics_faction_joiner", function(peer, peer_id)
		for _, list in pairs(T.fac_peers) do list[peer_id] = nil end
		if not (Network and Network:is_server()) then return end
		pcall(function()
			for _, u_data in pairs(managers.enemy:all_enemies() or {}) do
				local unit = u_data.unit
				if T.is_faction_unit(unit) then
					unit:brain():set_active(false)
					unit:base():set_slot(unit, 0)
				end
			end
			local corpses = managers.enemy._enemy_data and managers.enemy._enemy_data.corpses or {}
			for _, c in pairs(corpses) do
				if T.is_faction_unit(c.unit) then c.unit:set_slot(0) end
			end
		end)
	end)

	local orig_produce = ElementSpawnEnemyDummy.produce
	function ElementSpawnEnemyDummy:produce(params, ...)
		if T.active() then
			if params and params.name then
				local ok, new = pcall(T.faction_pick, params.name, true)
				if ok and new then params.name = new end
			elseif self._enemy_name then
				local ok, new = pcall(T.faction_pick, self._enemy_name, false)
				if ok and new then
					local old = self._enemy_name
					self._enemy_name = new
					local res = { pcall(orig_produce, self, params, ...) }
					self._enemy_name = old
					if not res[1] then error(res[2], 0) end
					return unpack(res, 2)
				end
			end
		end
		return orig_produce(self, params, ...)
	end
end
