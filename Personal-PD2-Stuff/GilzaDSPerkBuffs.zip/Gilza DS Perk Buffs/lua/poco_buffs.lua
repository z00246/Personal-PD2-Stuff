GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs

local function card_icon(deck, card)
	local spec = tweak_data.skilltree.specializations[deck]
	local data = spec and spec[card]
	if not (data and data.icon_xy) then return end
	local folder = data.texture_bundle_folder
	local path = folder and ("guis/dlcs/" .. folder .. "/textures/pd2/specialization/icons_atlas") or "guis/textures/pd2/specialization/icons_atlas"
	return path, { data.icon_xy[1] * 64, data.icon_xy[2] * 64, 64, 64 }
end

local function poco_now()
	return managers.player:player_timer():time()
end


-- Combined "less likely to be targeted" multiplier for the local player.
-- Mirrors how enemies weigh targets (PlayerMovement attention settings + CopLogicIdle stand-still/crouch bonus).
function B.targeted_mul()
	local pm = managers.player
	local unit = pm and pm:player_unit()
	if not alive(unit) then return end
	local mul, best, src = 1, 0, nil
	local function take(v, deck, card)
		if type(v) ~= "number" or v == 1 then return end
		mul = mul * v
		local strength = math.abs(1 - v)
		if strength > best then
			best, src = strength, { deck, card }
		end
	end
	local server = Network:is_server()
	local host_mod = server or (B.host_has_mod and managers.network and B.host_has_mod == managers.network:session())
	local brawler = pm:has_category_upgrade("player", "damage_resist_brawler") and pm:has_category_upgrade("player", "uncover_multiplier")
	if not brawler then
		if pm:has_category_upgrade("player", "camouflage_bonus") then
			take(pm:upgrade_value("player", "camouflage_bonus", 1), "optic_illusions")
		end
		if pm:has_category_upgrade("player", "camouflage_multiplier") then
			local v = pm:upgrade_value("player", "camouflage_multiplier", 1)
			if not host_mod then v = 0.85 end
			take(v, 4, 3)
		end
	end
	if pm:has_category_upgrade("player", "uncover_multiplier") then
		take(pm:upgrade_value("player", "uncover_multiplier", 1), 2, 3)
	end
	local state = unit:movement():current_state()
	if state and not state._moving and state.ducking and state:ducking() and pm:has_category_upgrade("player", "stand_still_crouch_camouflage_bonus") then
		take(pm:upgrade_value("player", "stand_still_crouch_camouflage_bonus", 1), 7, 3)
	end
	if Application:time() < (B.burg_silent_until or 0) and B.BURGLAR then
		take(B.BURGLAR.silent_weight, 7, 5)
	end
	if not src then return 1 end
	return mul, src[1], src[2]
end

local active = {}

local function skill_icon(skill_id)
	local data = tweak_data.skilltree.skills and tweak_data.skilltree.skills[skill_id]
	if not (data and data.icon_xy) then return end
	return "guis/textures/pd2/skilltree_2/icons_atlas_2", { data.icon_xy[1] * 80, data.icon_xy[2] * 80, 80, 80 }
end

local function show(key, deck, card, good, text, until_t, ratio)
	local poco = rawget(_G, "PocoHud3")
	if not (poco and poco.Buff3 and poco.buffs) then return end
	local icon, rect
	if type(deck) == "string" then
		icon, rect = skill_icon(deck)
	else
		icon, rect = card_icon(deck, card)
	end
	local data = { key = key, good = good, icon = icon, iconRect = rect, text = text or "" }
	if ratio then
		data.st, data.et = math.clamp(ratio, 0, 1), 1
	else
		local remaining = until_t - Application:time()
		if remaining <= 0 then return end
		local now = poco_now()
		data.st, data.et = now, now + remaining
		local existing = poco.buffs[key]
		if existing and existing.data and existing.data.et and math.abs(existing.data.et - data.et) < 0.15 then
			active[key] = true
			return
		end
	end
	poco:Buff3(data)
	active[key] = true
end

local function hide(key)
	if not active[key] then return end
	active[key] = nil
	local poco = rawget(_G, "PocoHud3")
	if poco and poco.RemoveBuff then poco:RemoveBuff(key) end
end

local function timed(key, deck, card, good, until_t, text)
	if until_t and until_t > Application:time() then
		show(key, deck, card, good, text, until_t)
	else
		hide(key)
	end
end

function B.update_poco()
	local now = Application:time()

	if B.rogue_tier and B.rogue_tier() >= 3 and now < (B.rogue_stack_until or 0) and (B.rogue_stacks or 0) > 0 then
		show("gdb_rogue_stacks", 4, 3, true, "x" .. B.rogue_stacks, B.rogue_stack_until)
	else
		hide("gdb_rogue_stacks")
	end
	timed("gdb_rogue_riposte", 4, 7, true, B.rogue_riposte_until)

	if B.muscle_tier and B.muscle_tier() >= 1 and (B.rage or 0) > 0 then
		local max = B.on and B.MUSCLE.max_stacks_ds or B.MUSCLE.max_stacks
		show("gdb_muscle_rage", 2, 1, true, "x" .. B.rage, nil, B.rage / max)
	else
		hide("gdb_muscle_rage")
	end
	timed("gdb_muscle_unstoppable", 2, 9, true, B._unstoppable_until)

	timed("gdb_crook_counter", 6, 7, true, B.crook_counter_until)
	timed("gdb_crook_slip", 6, 9, true, B.crook_slip_until)

	timed("gdb_cc_rally", 1, 5, true, B.cc_rally_until)

	if (B.hitman_overflow or 0) > 0 then
		local cap = B.on and B.HITMAN_OVERFLOW.ds or B.HITMAN_OVERFLOW.normal
		local deck, card = 5, 3
		show("gdb_hitman_overflow", deck, card, true, tostring(math.floor(B.hitman_overflow * 10 + 0.5)), nil, cap > 0 and B.hitman_overflow / cap or 1)
	else
		hide("gdb_hitman_overflow")
	end

	local crit = B.gambler_crit or 0
	if crit ~= 0 then
		local c = B.crit_values and B.crit_values() or { cap = 0.3 }
		show("gdb_gambler_crit", 10, 1, crit > 0, string.format("%+d%%", math.floor(crit * 100 + (crit > 0 and 0.5 or -0.5))), nil, math.abs(crit) / c.cap)
	else
		hide("gdb_gambler_crit")
	end

	if B.burglar_tier and B.burglar_tier() >= 1 and B.burglar_hidden and B.burglar_hidden() and not rawget(_G, "GeoHUD") then
		show("gdb_burg_hidden", 7, 1, true, "", nil, 1)
	else
		hide("gdb_burg_hidden")
	end
	local patience = B.burglar_patience_ratio and B.burglar_patience_ratio() or 0
	if patience > 0 then
		show("gdb_burg_patience", 7, 9, true, patience >= 1 and "!" or "", nil, patience)
	else
		hide("gdb_burg_patience")
	end
	timed("gdb_burg_vanish", 7, 7, true, not rawget(_G, "GeoHUD") and B.burg_vanish_until or nil)

	local tmul, tdeck, tcard = B.targeted_mul()
	if tmul and math.abs(tmul - 1) > 0.001 then
		local pct = math.floor((1 - tmul) * 100 + 0.5)
		local text = pct > 0 and ("-" .. pct .. "%") or ("+" .. (-pct) .. "%")
		local key_text = text .. tostring(tdeck) .. tostring(tcard)
		if B._targeted_last ~= key_text then
			hide("gdb_targeted")
			B._targeted_last = key_text
		end
		show("gdb_targeted", tdeck, tcard, tmul < 1, text, nil, 1)
	else
		B._targeted_last = nil
		hide("gdb_targeted")
	end

	if B.infil_tier and B.infil_tier() >= 3 and (B.infil_close or 0) > 0 then
		local max = 0
		for card, v in pairs(B.on and B.INFIL.close_ds or B.INFIL.close) do
			if B.infil_tier() >= card and v > max then max = v end
		end
		show("gdb_infil_close", 8, 3, true, "-" .. math.floor(B.infil_close * 100 + 0.5) .. "%", nil, max > 0 and B.infil_close / max or 1)
	else
		hide("gdb_infil_close")
	end
	local ex = B.infil_last_exposed
	timed("gdb_infil_exposed", 8, 5, true, alive(ex) and B.infil_exposed and B.infil_exposed[ex:key()] or nil)
	timed("gdb_infil_melt", 8, 7, true, B.infil_melt_until)

	local gstacks = B.grinder_tier and B.grinder_tier() >= 1 and B.grinder_stacks() or 0
	if gstacks > 0 then
		local cap = B.grinder_cap()
		local n = math.min(gstacks, cap)
		local text = "x" .. n
		if B.grinder_tier() >= 3 then text = text .. " +" .. math.floor(n * B.GRINDER.bloodlust * 100 + 0.5) .. "%" end
		show("gdb_grinder_stacks", 11, 1, true, text, nil, n / cap)
	else
		hide("gdb_grinder_stacks")
	end

	local bl = B.yakuza_bloodied and B.yakuza_bloodied() or 0
	if bl > 0 then
		local max = B.on and B.YAKUZA.bloodied_ds or B.YAKUZA.bloodied
		show("gdb_yakuza_bloodied", 12, 3, true, "+" .. math.floor(bl * 100 + 0.5) .. "%", nil, bl / max)
	else
		hide("gdb_yakuza_bloodied")
	end
	if B.yakuza_tier and B.yakuza_tier() >= 5 then
		if Application:time() < (B.yakuza_ls_ready or 0) then
			show("gdb_yakuza_laststand", 12, 5, false, "", B.yakuza_ls_ready)
		else
			show("gdb_yakuza_laststand", 12, 5, true, "", nil, 1)
		end
	else
		hide("gdb_yakuza_laststand")
	end

	local trail = B.expres_trail_stacks and B.expres_trail_stacks() or 0
	if trail > 0 and B.expres_tier() >= 3 then
		show("gdb_expres_trail", 13, 3, true, "x" .. trail, B.expres_trail_until)
	else
		hide("gdb_expres_trail")
	end
	timed("gdb_expres_bd", 13, 7, true, B.expres_bd_until)
	if B.expres_tier and B.expres_tier() >= 5 and B.expres_stored() > 0 then
		show("gdb_expres_service", 13, 5, true, "", nil, 1)
	else
		hide("gdb_expres_service")
	end

	if B.maniac_tier and B.maniac_tier() >= 1 then
		local n = B.maniac_stacks()
		if n > 0 then
			local text = tostring(n)
			if B.maniac_rush() then text = text .. " RUSH" elseif B.maniac_habit() then text = text .. " HABIT" end
			show("gdb_maniac_stacks", 14, 1, true, text, nil, n / 600)
		else
			hide("gdb_maniac_stacks")
		end
	else
		hide("gdb_maniac_stacks")
	end
	timed("gdb_maniac_comedown", 14, 9, true, (B.maniac_comedown and B.maniac_comedown() > 0) and B.maniac_cd_until or nil)

	if B.anar_tier and B.anar_tier() >= 1 then
		if B.anar_riot() then show("gdb_anar_riot", 15, 3, true, "", nil, 1) else hide("gdb_anar_riot") end
		timed("gdb_anar_bloc", 15, 7, true, B.anar_bloc() and B.anar_bloc_until or nil)
		local cd = B.anar_invuln_cd()
		timed("gdb_anar_cd", 15, 1, false, cd > 0 and (Application:time() + cd) or nil)
	else
		hide("gdb_anar_riot"); hide("gdb_anar_bloc"); hide("gdb_anar_cd")
	end

	if B.biker_tier and B.biker_tier() >= 3 then
		local n = B.biker_slots()
		if n > 0 then
			show("gdb_biker_momentum", 16, 3, true, n .. "/" .. B.biker_max_slots() .. " +" .. math.floor(n * (B.on and B.BIKER.road_rage_ds or B.BIKER.road_rage) * 100 + 0.5) .. "%", nil, n / B.biker_max_slots())
		else
			hide("gdb_biker_momentum")
		end
		if B.biker_tier() >= 7 and n >= B.BIKER.colors_slots then show("gdb_biker_colors", 16, 7, true, "", nil, 1) else hide("gdb_biker_colors") end
		timed("gdb_biker_burnout", 16, 9, true, B.biker_burnout() and B.biker_burnout_until or nil)
	else
		hide("gdb_biker_momentum"); hide("gdb_biker_colors"); hide("gdb_biker_burnout")
	end

	if B.kp_tier and B.kp_tier() >= 3 and B.kp_active() then
		show("gdb_kp_injector", 17, 3, true, "", B.kp_injector_until())
	else
		hide("gdb_kp_injector")
	end
	timed("gdb_kp_withdrawal", 17, 9, true, B.kp_withdrawal and B.kp_withdrawal() and B.kp_withdrawal_until or nil)

	if B.sic_tier and B.sic_tier() >= 5 and B.sic_in_my_smoke(managers.player:player_unit()) then
		show("gdb_sic_haze", 18, 5, true, "", nil, 1)
	else
		hide("gdb_sic_haze")
	end

	local grit = B.stoic_grit and B.stoic_grit() or 0
	if grit > 0.005 then
		local max = B.on and B.STOIC.grit_ds or B.STOIC.grit
		show("gdb_stoic_grit", 19, 3, true, "+" .. math.floor(grit * 100 + 0.5) .. "%", nil, grit / max)
	else
		hide("gdb_stoic_grit")
	end
	timed("gdb_stoic_composure", 19, 5, true, B.stoic_composure and B.stoic_composure() and B.stoic_composure_until or nil)

	if B.tt_tier and B.tt_tier() >= 1 and B.tt_linked() then
		show("gdb_tt_link", 20, 1, true, "", nil, 1)
	else
		hide("gdb_tt_link")
	end
	timed("gdb_tt_lifeline", 20, 5, true, B.tt_lifeline and B.tt_lifeline() and B.tt_lifeline_until or nil)

	if (B.socio_hold or 0) > 0 then
		show("gdb_socio_hold", 9, 3, true, math.floor(B.socio_hold * 100 + 0.5) .. "%", nil, B.socio_hold / B.SOCIO.hold_max)
	else
		hide("gdb_socio_hold")
	end
end

Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_poco", function(t)
	if t and B._poco_next and t < B._poco_next then return end
	B._poco_next = (t or 0) + 0.2
	local ok, err = pcall(B.update_poco)
	if not ok and not B._poco_err then
		B._poco_err = true
		log("[Gilza DS Perk Buffs] PocoHud buffs error: " .. tostring(err))
	end
end)
