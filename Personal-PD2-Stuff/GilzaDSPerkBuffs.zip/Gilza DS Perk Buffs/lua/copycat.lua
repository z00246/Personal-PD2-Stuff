GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs

-- Mimicry: Copycat's 9th card also grants the reworked card 1 and card 3 effects of the copied deck.
B.COPYCAT = { deck = 23, mimic_tier = 3 }

-- which of our tier functions belongs to which perk deck
local TIER_FUNCS = {
	cc_tier = 1, muscle_tier = 2, armorer_tier = 3, rogue_tier = 4, crook_tier = 6, burglar_tier = 7,
	infil_tier = 8, socio_tier = 9, grinder_tier = 11, yakuza_tier = 12, expres_tier = 13, maniac_tier = 14,
	anar_tier = 15, biker_tier = 16, kp_tier = 17, sic_tier = 18, stoic_tier = 19, tt_tier = 20,
	hacker_tier = 21, leech_tier = 22
}

-- deck copied by Copycat's 9th card, or nil
function B.copycat_deck()
	local now = Application:time()
	if B._cc_cache_t and now - B._cc_cache_t < 1 then return B._cc_cache end
	B._cc_cache_t = now
	B._cc_cache = nil
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == B.COPYCAT.deck) then return nil end
	if (st:get_specialization_value(B.COPYCAT.deck, "tiers", "current_tier") or 0) < 9 then return nil end
	local data = st._global and st._global.specializations and st._global.specializations[B.COPYCAT.deck]
	local raw = data and data.choices and data.choices[9]
	local idx = raw and st:digest_value(raw, false)
	local specs = tweak_data and tweak_data.skilltree and tweak_data.skilltree.specializations
	local card9 = specs and specs[B.COPYCAT.deck] and specs[B.COPYCAT.deck][9]
	local choice = idx and card9 and card9.multi_choice and card9.multi_choice[idx]
	if not (choice and choice.name_id) then return nil end
	for d, spec in pairs(specs) do
		if d ~= B.COPYCAT.deck and type(spec) == "table" and spec.name_id == choice.name_id then
			B._cc_cache = d
			return d
		end
	end
	return nil
end

function B.copycat_wrap()
	for name, deck in pairs(TIER_FUNCS) do
		local fn = B[name]
		if type(fn) == "function" and not (B._cc_wrapped and B._cc_wrapped[name] == fn) then
			local orig = fn
			local wrapped = function(...)
				local t = orig(...)
				if (t or 0) == 0 then
					local ok, copied = pcall(B.copycat_deck)
					if ok and copied == deck then return B.COPYCAT.mimic_tier end
				end
				return t
			end
			B[name] = wrapped
			B._cc_wrapped = B._cc_wrapped or {}
			B._cc_wrapped[name] = wrapped
		end
	end
end

Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_copycat_wrap", function() pcall(B.copycat_wrap) end)
Hooks:Add("MenuUpdate", "GilzaDSBuffs_copycat_wrap_menu", function() pcall(B.copycat_wrap) end)
