GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs

-- New card names for reworked decks, so the names match the mechanics in the descriptions
B.CARD_NAMES = {
	[2] = { [1] = "Rage", [3] = "Bodyguard", [5] = "Juggernaut", [7] = "Fearsome", [9] = "Unstoppable" },
	[5] = { [1] = "Contract", [3] = "Clean Kill", [5] = "Hit List", [7] = "Untouchable", [9] = "Tooth and Claw" },
	[6] = { [1] = "Sidestep", [3] = "Padding", [5] = "Deflect", [7] = "Counter", [9] = "Slip" },
	[7] = { [1] = "Shadow", [3] = "Guard Sense", [5] = "Silent Takedown", [7] = "Second Chance", [9] = "Fade Out" },
	[8] = { [1] = "Point Blank", [3] = "Closing In", [5] = "Opening", [7] = "Melt Away", [9] = "Bloodrush" },
	[9] = { [1] = "Tension", [3] = "Unbreakable", [5] = "Combo", [7] = "Hardened", [9] = "Terror" },
	[11] = { [1] = "Feeding", [3] = "Bloodlust", [5] = "Overgrowth", [7] = "Frenzy", [9] = "Gorge" },
	[21] = { [5] = "Overclock", [7] = "Firewall" },
	[20] = { [3] = "Crossfire", [5] = "Lifeline", [7] = "Shared Pain", [9] = "Tag Out" },
	[19] = { [3] = "Grit", [5] = "Composure", [7] = "Stiff Upper Lip" },
	[18] = { [5] = "Haze", [7] = "Vanishing Act" },
	[17] = { [3] = "Adrenal Surge", [7] = "Overdose", [9] = "Withdrawal" },
	[16] = { [3] = "Road Rage", [5] = "Chopper", [7] = "Colors", [9] = "Burnout" },
	[15] = { [3] = "Riot", [5] = "Unrest", [7] = "Black Bloc", [9] = "Uprising" },
	[14] = { [3] = "Habit", [5] = "Binge", [7] = "Rush", [9] = "Comedown" },
	[13] = { [3] = "Campaign Trail", [5] = "Secret Service", [7] = "Body Double", [9] = "Second Term" },
	[12] = { [1] = "Irezumi", [3] = "Bloodied", [5] = "Last Stand", [7] = "Blood Debt", [9] = "Iron Will" }
}

B.name_text = B.name_text or {}
for deck, cards in pairs(B.CARD_NAMES) do
	for card, name in pairs(cards) do
		B.name_text["menu_gdsb_name_" .. deck .. "_" .. card] = name
	end
end

Hooks:PostHook(SkillTreeTweakData, "init", "GilzaDSBuffs_card_names", function(self)
	for deck, cards in pairs(B.CARD_NAMES) do
		local spec = self.specializations and self.specializations[deck]
		for card in pairs(cards) do
			if spec and spec[card] then
				spec[card].name_id = "menu_gdsb_name_" .. deck .. "_" .. card
			end
		end
	end
end)
