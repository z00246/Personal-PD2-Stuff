GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

B.SICARIO = {
	deck = 18,
	haze = 0.20,
	haze_ds = 0.30,
	vanish_cd = 2,
	-- (7.24) Sangres' signature (card 9, only as Sangres): Sangre por Sangre - enemies inside your smoke are outlined
	-- (on your screen), your headshots on them deal 25% more damage, and kills inside it heal 2%, once a second
	sig_head = 0.25, sig_heal = 0.02, sig_heal_every = 1, sig_scan = 0.25
}
local C = B.SICARIO

function B.sic_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == C.deck) then
		return 0
	end
	return st:get_specialization_value(C.deck, "tiers", "current_tier") or 0
end

-- your own smoke screens right now
local function my_smokes()
	local pm = managers.player
	local out = {}
	for _, smoke in ipairs(pm and pm._smoke_screen_effects or {}) do
		local ok, mine = pcall(smoke.mine, smoke)
		if ok and mine then out[#out + 1] = smoke end
	end
	return out
end

-- is this unit standing in one of your own smoke screens?
function B.sic_in_my_smoke(unit)
	local pm = managers.player
	if not (pm and alive(unit)) then return false end
	for _, smoke in ipairs(pm._smoke_screen_effects or {}) do
		local ok, mine = pcall(smoke.mine, smoke)
		if ok and mine then
			local ok2, inside = pcall(smoke.is_in_smoke, smoke, unit)
			if ok2 and inside then return true end
		end
	end
	return false
end

if script == "lib/managers/playermanager" then
	-- (7.24) Sangres' Sangre por Sangre: outline the enemies inside your smoke (checked 4 times a second, only while you
	-- have a smoke screen out); the outline goes when they leave it, die or the smoke clears
	B.sic_marked = B.sic_marked or {}
	local function clear_all()
		for key, u in pairs(B.sic_marked) do
			if alive(u) and B.sig_outline then B.sig_outline(u, "gdsb_smoke", false) end
			B.sic_marked[key] = nil
		end
	end
	local function scan()
		local smokes = (B.sig_active and B.sig_active(C.deck)) and my_smokes() or {}
		if #smokes == 0 then
			if next(B.sic_marked) then clear_all() end
			return
		end
		local seen = {}
		local mask = managers.slot:get_mask("enemies")
		for key, u_data in pairs(managers.enemy:all_enemies() or {}) do
			local u = u_data.unit
			if alive(u) and u:in_slot(mask) then
				local dmg = u:character_damage()
				if dmg and not dmg._dead then
					for _, smoke in ipairs(smokes) do
						local ok, inside = pcall(smoke.is_in_smoke, smoke, u)
						if ok and inside then
							seen[u:key()] = u
							break
						end
					end
				end
			end
		end
		for key, u in pairs(seen) do
			if not B.sic_marked[key] then
				B.sic_marked[key] = u
				if B.sig_outline then B.sig_outline(u, "gdsb_smoke", true) end
				B.sig_live("smoke mark", "an enemy inside your smoke is outlined")
			end
		end
		for key, u in pairs(B.sic_marked) do
			if not seen[key] then
				if alive(u) and B.sig_outline then B.sig_outline(u, "gdsb_smoke", false) end
				B.sic_marked[key] = nil
			end
		end
	end
	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_sic_scan", function()
		local now = Application:time()
		if now < (B._sic_next or 0) then return end
		B._sic_next = now + C.sig_scan
		local session = managers.network and managers.network:session()
		if B._sic_session ~= session then
			B._sic_session = session
			B.sic_marked, B._sic_heal_next = {}, nil
		end
		local ok, err = pcall(scan)
		if not ok and not B._sic_err then
			B._sic_err = true
			log("[Gilza DS Perk Buffs] Sicario smoke scan error: " .. tostring(err))
		end
	end)

elseif script == "lib/units/enemies/cop/copdamage" then
	local function is_me(attack_data)
		local player = managers.player and managers.player:player_unit()
		return alive(player) and attack_data and attack_data.attacker_unit == player
	end

	local function is_head(self, attack_data)
		local body = attack_data.col_ray and attack_data.col_ray.body
		return (self._head_body_name and body and body:name() == self._ids_head_body_name) and true or false
	end

	local function pre(self, attack_data)
		self._gdsb_sic_alive, self._gdsb_sic_smoke, self._gdsb_sic_sig = nil, nil, nil
		if not (is_me(attack_data) and type(attack_data.damage) == "number") then return end
		local tier = B.sic_tier()
		if tier < 5 then return end
		if not B.sic_in_my_smoke(self._unit) then return end
		self._gdsb_sic_alive, self._gdsb_sic_smoke = not self._dead, true
		attack_data.damage = attack_data.damage * (1 + (B.on and C.haze_ds or C.haze))
		-- (7.24) Sangres' Sangre por Sangre: headshots inside your smoke
		if tier >= 9 and B.sig_active and B.sig_active(C.deck) then
			self._gdsb_sic_sig = true
			if is_head(self, attack_data) then
				attack_data.damage = attack_data.damage * (1 + C.sig_head)
				B.sig_live("smoke headshot", "a headshot inside your smoke: x%.2f", 1 + C.sig_head)
			end
		end
	end

	local function post(self)
		local was_alive, smoke, sig = self._gdsb_sic_alive, self._gdsb_sic_smoke, self._gdsb_sic_sig
		self._gdsb_sic_alive, self._gdsb_sic_smoke, self._gdsb_sic_sig = nil, nil, nil
		if was_alive and smoke and self._dead and B.sic_tier() >= 7 then
			managers.player:speed_up_grenade_cooldown(C.vanish_cd)
		end
		-- (7.24) Sangres' Sangre por Sangre: a kill inside your smoke heals, once a second
		if was_alive and smoke and sig and self._dead then
			local now = Application:time()
			if now >= (B._sic_heal_next or 0) then
				local unit = managers.player:player_unit()
				local dmg = alive(unit) and unit:character_damage()
				if dmg and not dmg:need_revive() and not dmg:dead() then
					B._sic_heal_next = now + C.sig_heal_every
					dmg:restore_health(C.sig_heal)
					B.sig_live("smoke heal", "a kill inside your smoke healed %d%%", C.sig_heal * 100)
				end
			end
		end
	end

	for _, fn in ipairs({ "damage_bullet", "damage_melee" }) do
		Hooks:PreHook(CopDamage, fn, "GilzaDSBuffs_sic_pre_" .. fn, function(self, attack_data)
			pcall(pre, self, attack_data)
		end)
		Hooks:PostHook(CopDamage, fn, "GilzaDSBuffs_sic_post_" .. fn, function(self)
			pcall(post, self)
		end)
	end
end
