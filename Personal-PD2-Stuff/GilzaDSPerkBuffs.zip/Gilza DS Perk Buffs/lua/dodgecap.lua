GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs

B.DODGE_CAP = { normal = 0.7, ds = 0.8 }

local orig_dodge = PlayerManager.skill_dodge_chance
function PlayerManager:skill_dodge_chance(running, crouching, on_zipline, override_armor, ...)
	local chance = orig_dodge(self, running, crouching, on_zipline, override_armor, ...)
	if type(chance) ~= "number" then return chance end
	local ok, base = pcall(function()
		return (tweak_data.player.damage.DODGE_INIT or 0) + self:body_armor_value("dodge", override_armor)
	end)
	if not ok then return chance end
	local cap = B.on and B.DODGE_CAP.ds or B.DODGE_CAP.normal
	return math.min(chance, cap - base)
end
