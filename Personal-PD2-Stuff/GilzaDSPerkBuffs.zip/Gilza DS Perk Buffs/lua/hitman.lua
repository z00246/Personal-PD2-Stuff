GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs

B.HITMAN_LIGHT_ARMOR = { level_1 = true, level_2 = true }
B.HITMAN_ARMOR = {
	normal = { card1 = 3, card3 = 2, card3_light = 3 },
	ds = { card1 = 5, card3 = 3, card3_light = 5 }
}
B.HITMAN_GUN_CD = 0.5
B.HITMAN_OVERFLOW = { normal = 5, ds = 10, fade_after = 5, fade_per_sec = 1 }
B.hitman_overflow = 0
B.hitman_overflow_t = 0

local GUN_CATEGORIES = { akimbo = true, pistol = true, smg = true }

function B.hitman_light_armor()
	local armor = managers.blackmarket and managers.blackmarket:equipped_armor(true, true)
	return armor and B.HITMAN_LIGHT_ARMOR[armor] or false
end

local function is_gun_kill(variant, weapon_id)
	if variant ~= "bullet" then return false end
	local wt = weapon_id and tweak_data.weapon[weapon_id]
	for _, c in ipairs(wt and wt.categories or {}) do
		if GUN_CATEGORIES[c] then return true end
	end
	return false
end

local orig_temp_value = PlayerManager.temporary_upgrade_value
function PlayerManager:temporary_upgrade_value(category, upgrade, default, ...)
	if upgrade == "akimbo_pistol_armor_regen_timer_multiplier" then
		return default
	end
	return orig_temp_value(self, category, upgrade, default, ...)
end

local orig_activate = PlayerManager.activate_temporary_upgrade
function PlayerManager:activate_temporary_upgrade(category, upgrade, ...)
	if upgrade == "akimbo_pistol_armor_regen_timer_multiplier" then
		return
	end
	return orig_activate(self, category, upgrade, ...)
end

Hooks:PreHook(PlayerManager, "on_killshot", "GilzaDSBuffs_hitman_pre", function(self)
	B._hm = {
		combo = self._gilza_death_dance,
		next_t = self._gilza_death_dance_next_kill_expected_at,
		invuln_end = self._gilza_death_dance_invuln_end,
		active = self:has_activate_temporary_upgrade("temporary", "death_dance_combo_invulnerability")
	}
end)

function B.hitman_overflow_hud()
	if managers.hud and managers.player then
		managers.hud:set_absorb_active(HUDManager.PLAYER_PANEL, managers.player:damage_absorption())
	end
end

function B.hitman_overflow_loop()
	local unit = managers.player and managers.player:player_unit()
	local dmg = alive(unit) and unit:character_damage()
	if not dmg or dmg:dead() or dmg:need_revive() then
		B.hitman_overflow = 0
	elseif B.hitman_overflow > 0 and Application:time() - B.hitman_overflow_t > B.HITMAN_OVERFLOW.fade_after then
		B.hitman_overflow = math.max(B.hitman_overflow - B.HITMAN_OVERFLOW.fade_per_sec * 0.25, 0)
	end
	pcall(B.hitman_overflow_hud)
	if B.hitman_overflow > 0 then
		DelayedCalls:Add("GilzaDSBuffs_hitman_overflow", 0.25, B.hitman_overflow_loop)
	else
		B._overflow_loop = nil
	end
end

local function restore_armor(player_unit, amount, overflow)
	local dmg = player_unit:character_damage()
	if not (dmg and dmg.restore_armor and not dmg:dead()) then return end
	if overflow then
		local space = math.max(dmg:_max_armor() - dmg:get_real_armor(), 0)
		local extra = amount - space
		if extra > 0 then
			local cap = B.on and B.HITMAN_OVERFLOW.ds or B.HITMAN_OVERFLOW.normal
			B.hitman_overflow = math.min(B.hitman_overflow + extra, cap)
			B.hitman_overflow_t = Application:time()
			if not B._overflow_loop then
				B._overflow_loop = true
				B.hitman_overflow_loop()
			end
		end
	end
	dmg:restore_armor(amount)
end

local function hitman_kill(self, killed_unit, variant, weapon_id)
	local player_unit = self:player_unit()
	if not alive(player_unit) or not alive(killed_unit) then return end
	if CopDamage.is_civilian(killed_unit:base()._tweak_table) then return end
	if not self:has_category_upgrade("temporary", "badass_hitman_kill_armor_regen") then return end

	local gun = is_gun_kill(variant, weapon_id)
	local bounty = self:has_activate_temporary_upgrade("temporary", "player_bounty_hunter")
	local mul = bounty and 2 or 1
	local values = B.on and B.HITMAN_ARMOR.ds or B.HITMAN_ARMOR.normal
	local flat = values.card1 * mul

	local t = Application:time()
	if gun and t >= (B._hm_gun_cd or 0) then
		local amount = 0
		if self:has_category_upgrade("temporary", "badass_hitman_kill_armor_regen") then
			amount = amount + flat
		end
		if self:has_category_upgrade("temporary", "akimbo_pistol_armor_regen_timer_multiplier") then
			amount = amount + (B.hitman_light_armor() and values.card3_light or values.card3) * mul
		end
		B._hm_gun_cd = t + B.HITMAN_GUN_CD
		restore_armor(player_unit, amount, self:has_category_upgrade("temporary", "akimbo_pistol_armor_regen_timer_multiplier") and B.hitman_light_armor())
	end

	if self:has_category_upgrade("temporary", "badass_hitman_kill_armor_regen") then
		if variant == "melee" then
			local given = player_unit:character_damage():_max_armor() * (bounty and 0.4 or 0.2)
			if given < flat then
				restore_armor(player_unit, flat - given)
			end
		end
	end

	local snap = B._hm
	if not (gun and snap and self:has_category_upgrade("temporary", "death_dance_combo_invulnerability")) then return end
	if snap.active or self:has_activate_temporary_upgrade("temporary", "death_dance_combo_invulnerability") then return end

	self._gilza_death_dance = snap.combo or 0
	self._gilza_death_dance_next_kill_expected_at = snap.next_t or 0
	self._gilza_death_dance_invuln_end = snap.invuln_end or 0

	local now = Application:time()
	local function reset()
		self._gilza_death_dance = 0
		self._gilza_death_dance_next_kill_expected_at = -1
		self._gilza_death_dance_invuln_end = 0
	end

	if self._gilza_death_dance == 0 then
		self._gilza_death_dance = 1
		self._gilza_death_dance_next_kill_expected_at = now + 1
	elseif math.abs(self._gilza_death_dance_next_kill_expected_at - now) <= 0.5 then
		self._gilza_death_dance = self._gilza_death_dance + 2
		self._gilza_death_dance_next_kill_expected_at = now + 1
	elseif self._gilza_death_dance_next_kill_expected_at - now > 0.5 then
		return
	else
		reset()
		self._gilza_death_dance = 1
		self._gilza_death_dance_next_kill_expected_at = now + 1
	end

	if self._gilza_death_dance >= 4 and self._gilza_death_dance <= 5 then
		if self:has_inactivate_temporary_upgrade("temporary", "death_dance_combo_invulnerability") then
			self:activate_temporary_upgrade("temporary", "death_dance_combo_invulnerability")
			local mul = 1
			if Global.game_settings and Global.game_settings.difficulty == "sm_wish" then
				mul = mul * 1.5
			end
			if bounty then
				mul = mul * 2
			end
			local duration = self:temporary_upgrade_value("temporary", "death_dance_combo_invulnerability", 0) * mul
			player_unit:sound():play("perkdeck_activate", nil, false)
			if player_unit:character_damage().Gilza_add_damage_invuln_timer then
				player_unit:character_damage():Gilza_add_damage_invuln_timer(duration)
			end
			self._gilza_death_dance_invuln_end = now + duration
		end
	elseif self._gilza_death_dance > 5 then
		reset()
	end
end

Hooks:PostHook(PlayerManager, "on_killshot", "GilzaDSBuffs_hitman_post", function(self, killed_unit, variant, headshot, weapon_id)
	pcall(hitman_kill, self, killed_unit, variant, weapon_id)
	B._hm = nil
end)

