GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs

local function mul(f) return function(v) return v * f end end
local function add(a, cap) return function(v) return math.min(v + a, cap or 1) end end
local function resist(f) return function(v) return math.max(1 - (1 - v) * f, 0.05) end end

B.niches = {
	{ "team.damage_dampener.hostage_multiplier", "all", resist(1.5) },
	{ "temporary.dmg_dampener_close_contact", 1, resist(1.5) },
	{ "player.passive_health_regen", "all", mul(1.5) },
	{ "temporary.armor_break_invulnerable", 1, mul(1.5) },
	{ "player.passive_dodge_chance", "all", add(0.05) },
	{ "player.level_2_dodge_addend", "all", add(0.05) },
	{ "player.level_3_dodge_addend", "all", add(0.05) },
	{ "player.level_4_dodge_addend", "all", add(0.05) },
	{ "player.tier_dodge_chance", "all", add(0.05) },
	{ "temporary.dmg_dampener_outnumbered_strong", 1, resist(1.5) },
	{ "player.killshot_regen_armor_bonus", "all", mul(1.5) },
	{ "player.killshot_close_regen_armor_bonus", "all", mul(1.5) },
	{ "player.melee_kill_life_leech", "all", mul(1.5) },
	{ "temporary.loose_ammo_restore_health", "range", function(v) return math.floor(v * 1.75 + 0.5) end },
	{ "player.loose_ammo_add_dodge_amount", "addition_min", mul(2) },
	{ "player.loose_ammo_add_dodge_amount", "addition_max", mul(2) },
	{ "player.loose_ammo_add_dodge_amount", "removal_min", mul(2) },
	{ "player.loose_ammo_add_dodge_amount", "removal_max", mul(2) },
	{ "player.loose_ammo_add_dodge_amount", "addition_jackpot", mul(1.6) },
	{ "player.loose_ammo_add_dodge_amount", "removal_jackpot", mul(1.6) },
	{ "player.damage_to_hot", "all", mul(1.5) },
	{ "player.armor_regen_damage_health_ratio_multiplier", "all", mul(1.25) },
	{ "player.armor_health_store_amount", "all", mul(1.5) },
	{ "player.armor_grinding", "grind", mul(1.3) },
	{ "player.wild_health_amount", "all", mul(1.5) },
	{ "player.wild_armor_amount", "all", mul(1.5) },
	{ "temporary.chico_injector", 2, mul(1.33) },
	{ "player.dodge_shot_gain_gilza", 1, mul(1.5) },
	{ "player.damage_control_passive", 1, add(10, 90) },
	{ "player.tag_team_base", "kill_health_gain", mul(1.5) },
	{ "player.pocket_ecm_heal_on_kill", "all", mul(1.5) },
	{ "temporary.pocket_ecm_kill_dodge", 1, mul(1.33) },
	{ "player.copr_activate_bonus_health_ratio", "all", mul(1.5) },
	{ "^max_cocaine_stacks_per_tick", "value", function(v) return math.floor(v * 1.25 + 0.5) end },
	{ "player.damage_resist_brawler", "all", resist(1.5) },
	{ "temporary.player_speed_junkie_armor_on_dodge", 1, mul(1.5) },
	{ "player.speed_junkie_meter_on_kill", "pair", function(v) return math.floor(v * 1.25 + 0.5) end },
	{ "player.guardian_area_passive_health_regen", "all", mul(1.5) }
}

local function lookup(path)
	local t = tweak_data and tweak_data.upgrades
	if string.sub(path, 1, 1) == "^" then
		path = string.sub(path, 2)
	else
		t = t and t.values
	end
	local parent, key
	for part in string.gmatch(path, "[^%.]+") do
		if type(t) ~= "table" then return nil end
		parent, key, t = t, part, t[part]
	end
	return parent, key, t
end

local function transform(tbl, sel, fn)
	if sel == "all" then
		for i, v in ipairs(tbl) do
			if type(v) == "number" then tbl[i] = fn(v) end
		end
	elseif sel == "range" then
		for _, entry in ipairs(tbl) do
			local r = type(entry) == "table" and entry[1]
			if type(r) == "table" then
				for i, v in ipairs(r) do
					if type(v) == "number" then r[i] = fn(v) end
				end
			end
		end
	elseif sel == "pair" then
		for _, entry in ipairs(tbl) do
			if type(entry) == "table" then
				for i, v in ipairs(entry) do
					if type(v) == "number" then entry[i] = fn(v) end
				end
			end
		end
	elseif sel == "grind" then
		for _, level in ipairs(tbl) do
			if type(level) == "table" then
				for _, tier in ipairs(level) do
					if type(tier) == "table" and type(tier[1]) == "number" then tier[1] = fn(tier[1]) end
				end
			end
		end
	else
		for _, entry in ipairs(tbl) do
			if type(entry) == "table" and type(entry[sel]) == "number" then
				entry[sel] = fn(entry[sel])
			end
		end
	end
end

B.saved = B.saved or {}

function B.apply(on)
	for path, rec in pairs(B.saved) do
		local parent, key, cur = lookup(path)
		if parent and cur == rec.buffed then
			parent[key] = rec.orig
		end
	end
	B.saved = {}
	if on then
		for _, n in ipairs(B.niches) do
			local path = n[1]
			local parent, key, cur = lookup(path)
			if parent and type(cur) == "number" and n[2] == "value" and not B.saved[path] then
				local ok, v = pcall(n[3], cur)
				if ok and type(v) == "number" then
					B.saved[path] = { orig = cur, buffed = v }
					parent[key] = v
				end
			elseif parent and type(cur) == "table" then
				local rec = B.saved[path]
				if not rec then
					rec = { orig = cur, buffed = deep_clone(cur) }
					B.saved[path] = rec
					parent[key] = rec.buffed
				end
				pcall(transform, rec.buffed, n[2], n[3])
			end
		end
	end
	B.on = on
end

function B.check()
	if B.leech_pre_apply then pcall(B.leech_pre_apply) end
	if B.rogue_pre_apply then pcall(B.rogue_pre_apply) end
	if B.armorer_pre_apply then pcall(B.armorer_pre_apply) end
	local on = Global.game_settings and Global.game_settings.difficulty == "sm_wish" or false
	if B.on ~= on then
		B.apply(on)
	end
end

Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_check", function() pcall(B.check) end)
Hooks:Add("MenuUpdate", "GilzaDSBuffs_check_menu", function() pcall(B.check) end)

B.GAMBLER_DODGE_CAP = 0.6

if PlayerManager.Gilza_add_gambler_new_dodge then
	local orig_gambler_dodge = PlayerManager.Gilza_add_gambler_new_dodge
	function PlayerManager:Gilza_add_gambler_new_dodge(amount, ...)
		if not B.on then
			return orig_gambler_dodge(self, amount, ...)
		end
		self._gilza_gambler_new_dodge = math.max(0, math.min((self._gilza_gambler_new_dodge or 0) + amount, B.GAMBLER_DODGE_CAP))
	end
end

B.CRIT = {
	normal = { min = 0.02, max = 0.06, jackpot = 0.2, cap = 0.3 },
	ds = { min = 0.03, max = 0.09, jackpot = 0.3, cap = 0.45 }
}
B.gambler_crit = 0

function B.crit_values()
	return B.on and B.CRIT.ds or B.CRIT.normal
end

function B.gamble_crit(effect, jackpot)
	local c = B.crit_values()
	local amount
	if jackpot then
		amount = c.jackpot
	else
		amount = math.random(math.floor(c.min * 100 + 0.5), math.floor(c.max * 100 + 0.5)) / 100
	end
	if effect == "remove" then
		amount = -amount
	elseif effect ~= "add" then
		return
	end
	B.gambler_crit = math.max(-c.cap, math.min(B.gambler_crit + amount, c.cap))
end

if PlayerManager.Gilza_new_gambler_triggered then
	local orig_triggered = PlayerManager.Gilza_new_gambler_triggered
	function PlayerManager:Gilza_new_gambler_triggered(heal_gamble, ...)
		if type(heal_gamble) == "table" then
			pcall(B.gamble_crit, heal_gamble.effect, heal_gamble.jackpot)
		end
		return orig_triggered(self, heal_gamble, ...)
	end
end

local orig_crit = PlayerManager.critical_hit_chance
function PlayerManager:critical_hit_chance(...)
	local chance = orig_crit(self, ...)
	if B.gambler_crit > 0 and type(chance) == "number" then
		return chance + B.gambler_crit
	end
	return chance
end

Hooks:PostHook(PlayerManager, "_setup", "GilzaDSBuffs_reset_crit", function()
	B.gambler_crit = 0
end)

Hooks:PreHook(PlayerManager, "on_enter_custody", "GilzaDSBuffs_custody_crit", function()
	B.gambler_crit = 0
end)
