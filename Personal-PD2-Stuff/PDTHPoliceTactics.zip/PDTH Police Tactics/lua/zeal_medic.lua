if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics
local script = RequiredScript and RequiredScript:lower() or ""

-- ZEAL Medic (Restoration Mod model) replaces the regular Medic on Death Sentence.
-- Custom units crash players who don't have them, so it is only used while everyone has this mod.
local ZEAL = "units/pd2_dlc_gitgud/characters/ene_zeal_medic/ene_zeal_medic"
local UNIT = Idstring("unit")
local MAT = Idstring("material_config")

local function has(kind, ids)
	local dyn = managers.dyn_resource
	if dyn and dyn.has_resource then return dyn:has_resource(kind, ids, dyn.DYN_RESOURCES_PACKAGE) and true or false end
	return PackageManager:has(kind, ids)
end

-- queued during loading (see factions.lua), only checked afterwards
local function queue_zeal()
	if not (BeardLib and T.is_ds() and DB:has(UNIT, Idstring(ZEAL))) then return end
	T._zeal_queued = true
	T._fac_queue = T._fac_queue or {}
	for _, name in ipairs({ ZEAL, ZEAL .. "_husk" }) do table.insert(T._fac_queue, { ids = Idstring(name), name = name }) end
end

local function load_zeal()
	if T._zeal_loaded then return true end
	if not T._zeal_queued then T._zeal_loaded = false return false end
	T._zeal_loaded = has(UNIT, Idstring(ZEAL)) and has(UNIT, Idstring(ZEAL .. "_husk"))
	return T._zeal_loaded
end
-- also run from the loading-screen preload
T.zeal_preload = function() pcall(queue_zeal) end

if script == "lib/units/enemies/cop/copbase" then
	-- outlines: cops swap to a "_contour" material when marked; register the ZEAL Medic's pair
	if CopBase._material_translation_map then
		local normal_id, contour_id = Idstring(ZEAL), Idstring(ZEAL .. "_contour")
		CopBase._material_translation_map[tostring(normal_id:key())] = contour_id
		CopBase._material_translation_map[tostring(contour_id:key())] = normal_id
	end

elseif script == "lib/managers/mission/elementspawnenemydummy" then
	T.zeal_peers = T.zeal_peers or {}

	local function everyone_has_zeal()
		local session = managers.network and managers.network:session()
		for _, peer in pairs(session and session:peers() or {}) do
			local uid = peer.user_id and peer:user_id()
			if not (T.zeal_peers[peer:id()] or (uid and Global.pdth_mod_users and Global.pdth_mod_users[uid])) then return false end
		end
		return true
	end

	-- load once the game is running (host and modded clients), then tell the host we can show it
	Hooks:Add("GameSetupUpdate", "PDTHTactics_zeal_medic_load", function()
		if T._zeal_done then return end
		local now = Application:time()
		T._zeal_check_start = T._zeal_check_start or now
		local ok, err = pcall(load_zeal)
		if not ok then log(T.name .. " ZEAL Medic check failed: " .. tostring(err)) end
		-- BeardLib finishes the queued load during startup; give it a few seconds before giving up
		if not T._zeal_loaded and T._zeal_queued and now - T._zeal_check_start < 15 then return end
		if not T._zeal_loaded or (Network and Network:is_server()) then
			T._zeal_done = true
			return
		end
		if T.client_on() and LuaNetworking then
			pcall(LuaNetworking.SendToPeer, LuaNetworking, 1, T.NET_ID, "zeal")
			T._zeal_done = true
		end
	end)

	if LuaNetworking and LuaNetworking.AddReceiveHook then
		LuaNetworking:AddReceiveHook(T.NET_ID, "PDTHTactics_zeal_net", function(data, sender)
			if data == "zeal" and sender and Network and Network:is_server() then
				T.zeal_peers[sender] = true
			end
		end)
	end
	Hooks:Add("BaseNetworkSessionOnPeerRemoved", "PDTHTactics_zeal_peer_removed", function(peer, peer_id)
		T.zeal_peers[peer_id] = nil
	end)

	-- someone joins: wait for their confirmation before new ZEAL Medics; existing ones stay
	Hooks:Add("NetworkManagerOnPeerAdded", "PDTHTactics_zeal_joiner", function(peer, peer_id)
		T.zeal_peers[peer_id] = nil
	end)

	local SWAP = {
		[Idstring("units/payday2/characters/ene_medic_m4/ene_medic_m4"):key()] = true,
		[Idstring("units/payday2/characters/ene_medic_r870/ene_medic_r870"):key()] = true
	}
	local zeal_ids = Idstring(ZEAL)

	local function zeal_ok()
		if not (T.active() and T.is_ds() and T._zeal_loaded and everyone_has_zeal()) then return false end
		if T.faction_now and T.faction_now() then return false end
		return true
	end

	-- group spawns (params.name) and mission/scripted spawns (the element's own unit) alike
	local orig_produce = ElementSpawnEnemyDummy.produce
	function ElementSpawnEnemyDummy:produce(params, ...)
		local ok, use = pcall(zeal_ok)
		if ok and use and T.unit_ready and not T.unit_ready(zeal_ids) then use = false end
		if ok and use then
			if params and params.name then
				if SWAP[params.name:key()] then params.name = zeal_ids end
			elseif self._enemy_name and SWAP[self._enemy_name:key()] then
				local old = self._enemy_name
				self._enemy_name = zeal_ids
				local res = { pcall(orig_produce, self, params, ...) }
				self._enemy_name = old
				if not res[1] then error(res[2], 0) end
				return unpack(res, 2)
			end
		end
		return orig_produce(self, params, ...)
	end
end
