if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics
Hooks:PostHook(CharacterTweakData, "init", "PDTHTactics_characters", function(self)
	local presets = self.presets and self.presets.move_speed
	for name, data in pairs(self) do
		if type(data) == "table" and type(data.tags) == "table" and presets then
			for _, tag in ipairs(data.tags) do
				if tag == "tank" then
					if data.move_speed == presets.slow or data.move_speed == presets.normal then
						T.set(data, "move_speed", presets.very_slow or data.move_speed)
					end
					break
				end
			end
		end
	end
	if self.spooc and self.spooc.spooc_attack_timeout then
		local t = self.spooc.spooc_attack_timeout
		T.set(self.spooc, "spooc_attack_timeout", { (t[1] or 8) * 1.5, (t[2] or 10) * 1.6 })
	end
	local w = self.taser and self.taser.weapon and self.taser.weapon.is_rifle
	if w and w.tase_distance then
		T.vanilla_tase = w.tase_distance
		T.set_client(w, "tase_distance", w.tase_distance * 1.2)
	end
end)
