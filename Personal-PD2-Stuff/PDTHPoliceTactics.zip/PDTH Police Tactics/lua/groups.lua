if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics

Hooks:PostHook(GroupAITweakData, "init", "PDTHTactics_spawn_groups", function(self)
	local cats = self.unit_categories or {}
	local function stype(unit_name)
		local c = cats[unit_name]
		return c and c.special_type
	end

	if type(self.smoke_and_flash_grenade_timeout) == "table" then
		local t = self.smoke_and_flash_grenade_timeout
		local m = T.is_ds() and 0.35 or 0.5
		T.set(self, "smoke_and_flash_grenade_timeout", { (t[1] or 10) * m, (t[2] or 20) * m })
	end

	for name, grp in pairs(self.enemy_spawn_groups or {}) do
		if type(grp) == "table" and type(grp.spawn) == "table" and not string.find(name, "Phalanx") then
			local has_shield, has_tazer, has_spooc = false, false, false
			for _, e in ipairs(grp.spawn) do
				local s = stype(e.unit)
				has_shield = has_shield or s == "shield"
				has_tazer = has_tazer or s == "taser"
				has_spooc = has_spooc or s == "spooc"
			end

			for _, e in ipairs(grp.spawn) do
				local s = stype(e.unit)
				if s == "shield" then
					T.set(e, "tactics", T.with(e.tactics, { "shield", "smoke_grenade" }))
				elseif s == "medic" then
					T.set(e, "tactics", T.with(e.tactics, { "pdth_medic", "ranged_fire" }, { charge = true, flank = true }))
				elseif s == "spooc" then
					T.set(e, "tactics", T.with(e.tactics, { "flank", "smoke_grenade", "pdth_lurk", has_tazer and "pdth_team" or nil }, { charge = true }))
				elseif s == "taser" then
					T.set(e, "tactics", T.with(e.tactics, { "flank", "smoke_grenade" }))
				elseif s == "tank" then
					T.set(e, "tactics", T.with(e.tactics, { "pdth_tank" }))
				elseif not s and has_shield then
					T.set(e, "tactics", T.with(e.tactics, { "shield_cover", "smoke_grenade", "flash_grenade" }, { charge = true, flank = true }))
				elseif not s then
					T.set(e, "tactics", T.with(e.tactics, { "flank", "smoke_grenade", "flash_grenade", "pdth_escort" }))
				end
			end

			if has_tazer and not has_spooc and cats.spooc then
				local spawn = {}
				for i, e in ipairs(grp.spawn) do spawn[i] = e end
				table.insert(spawn, {
					amount_min = 0, amount_max = 1, freq = 0.5, rank = 2, unit = "spooc",
					tactics = { "flank", "smoke_grenade", "pdth_lurk", "pdth_team" }
				})
				T.set(grp, "spawn", spawn)
				if type(grp.amount) == "table" and grp.amount[2] then
					T.set(grp, "amount", { grp.amount[1], grp.amount[2] + 1 })
				end
			end
		end
	end
end)
