GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs

B.LEECH = {
	deck = 22,
	range = { [1] = 1500, [5] = 2000 },
	extend_per_kill = 0.5,
	extend_max = 3
}

function B.leech_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == B.LEECH.deck) then
		return 0
	end
	return st:get_specialization_value(B.LEECH.deck, "tiers", "current_tier") or 0
end

local function flat(pos)
	return Vector3(pos.x, pos.y, 0)
end

local orig_level_nil = PlayerManager.upgrade_level_nil
function PlayerManager:upgrade_level_nil(category, upgrade, ...)
	if upgrade == "copr_teammate_heal" and B._leech_block and not B._leech_sending then
		return nil
	end
	return orig_level_nil(self, category, upgrade, ...)
end

local function heal_level(pm)
	if not (pm and pm.upgrade_level_nil) then return nil end
	B._leech_sending = true
	local level = pm:upgrade_level_nil("player", "copr_teammate_heal")
	B._leech_sending = nil
	return level
end

function B.leech_pre_apply()
	local values = tweak_data and tweak_data.upgrades and tweak_data.upgrades.values
	if not values or B._leech_done_for == values then return end
	B._leech_done_for = values
	values.player.copr_activate_bonus_health_ratio = { 0.3 }
	values.player.copr_heal_during_invuln_increase = { 1 }
	values.player.copr_regain_cooldown_on_revives = { 0 }
end

function B.leech_team_heal(sends)
	local pm = managers.player
	local me = pm and pm:player_unit()
	if not alive(me) or sends <= 0 then return end
	local level = heal_level(pm)
	if not level then return end
	local radius = B.leech_tier() >= 5 and B.LEECH.range[5] or B.LEECH.range[1]
	local center = flat(me:position())

	local session = managers.network and managers.network:session()
	for _, peer in pairs(session and session:peers() or {}) do
		local unit = peer:unit()
		if alive(unit) and mvector3.distance(flat(unit:position()), center) <= radius then
			B._leech_sending = true
			for _ = 1, sends do
				peer:send("copr_teammate_heal", me, level)
			end
			B._leech_sending = nil
		end
	end

	if Network:is_server() and managers.groupai and managers.groupai:state() then
		local ratio = (pm:upgrade_value_by_level("player", "copr_teammate_heal", level, 0) or 0) * sends
		for _, data in pairs(managers.groupai:state():all_AI_criminals() or {}) do
			local unit = data.unit
			local dmg = alive(unit) and unit:character_damage()
			if dmg and dmg._health and dmg._HEALTH_INIT and not dmg._bleed_out and not dmg._fatal and not dmg._dead
				and mvector3.distance(flat(unit:position()), center) <= radius then
				dmg._health = math.min(dmg._health + dmg._HEALTH_INIT * ratio, dmg._HEALTH_INIT)
				dmg._health_ratio = dmg._health / dmg._HEALTH_INIT
			end
		end
	end
end

local function kill_sends(tier)
	return tier >= 9 and 2 or 1
end

local function activation_sends(tier)
	local level = heal_level(managers.player) or 1
	if tier >= 9 then return 2 end
	return level >= 2 and 1 or 2
end

local function extend_ampule(pm)
	local data = pm._temporary_upgrades and pm._temporary_upgrades.temporary and pm._temporary_upgrades.temporary.copr_ability
	if not data or not data.expire_time then return end
	B._leech_extended = B._leech_extended or 0
	if B._leech_extended >= B.LEECH.extend_max then return end
	local add = math.min(B.LEECH.extend_per_kill, B.LEECH.extend_max - B._leech_extended)
	B._leech_extended = B._leech_extended + add
	data.expire_time = data.expire_time + add
	if managers.enemy and managers.enemy.reschedule_delayed_clbk then
		managers.enemy:reschedule_delayed_clbk("copr_ability_active", data.expire_time)
	end
end

Hooks:PreHook(PlayerManager, "on_killshot", "GilzaDSBuffs_leech_block", function()
	B._leech_block = true
end)

Hooks:PostHook(PlayerManager, "on_killshot", "GilzaDSBuffs_leech_kill", function(self, killed_unit)
	B._leech_block = nil
	if not self:has_activate_temporary_upgrade("temporary", "copr_ability") then return end
	local base = alive(killed_unit) and killed_unit:base()
	if base and CopDamage.is_civilian(base._tweak_table) then return end
	local tier = B.leech_tier()
	if tier < 1 then return end
	B.leech_team_heal(kill_sends(tier))
	if tier >= 7 then
		extend_ampule(self)
	end
end)

local orig_attempt = PlayerManager._attempt_copr_ability
function PlayerManager:_attempt_copr_ability(...)
	local ok = orig_attempt(self, ...)
	if ok then
		B._leech_extended = 0
		local tier = B.leech_tier()
		if tier >= 3 then
			B.leech_team_heal(activation_sends(tier))
		end
	end
	return ok
end
