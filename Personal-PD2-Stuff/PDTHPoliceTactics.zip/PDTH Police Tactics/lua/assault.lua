if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics

local CS_CHANCE = 0.3
local orig_smoke = GroupAIStateBesiege._chk_group_use_smoke_grenade
function GroupAIStateBesiege:_chk_group_use_smoke_grenade(group, task_data, detonate_pos, ...)
	if T.active() and self.detonate_cs_grenade and not self:is_cs_grenade_active() and math.random() < CS_CHANCE then
		local real = self.detonate_smoke_grenade
		self.detonate_smoke_grenade = function(st, pos, shooter_pos)
			st:detonate_cs_grenade(pos, shooter_pos, 0, false)
		end
		local ok, res = pcall(orig_smoke, self, group, task_data, detonate_pos, ...)
		self.detonate_smoke_grenade = real
		if ok then return res end
	end
	return orig_smoke(self, group, task_data, detonate_pos, ...)
end

local CAMP_TIME = 12
local CAMP_DIST = 900
local CAMP_RADIUS = 1500
local CAMP_KILLS = 3
local CAMP_WINDOW = 25
local CAMP_BLOCK = 45

Hooks:PostHook(GroupAIStateBesiege, "init", "PDTHTactics_reset", function(self)
	T.apply(T.active())
	T.spawned = {}
	T.camp = {}
	T.civ_kills = 0
	T.anchor = {}
	T.camping = {}
	T._hold_next = nil
end)

Hooks:PostHook(GroupAIStateBase, "_add_group_member", "PDTHTactics_spawned", function(self, group, u_key)
	if not T.active() then return end
	T.spawned = T.spawned or {}
	local u_data = self._police and self._police[u_key]
	if u_data and alive(u_data.unit) and not T.spawned[u_key] then
		T.spawned[u_key] = { t = self._t, pos = mvector3.copy(u_data.unit:movement():m_pos()) }
	end
end)

local function on_spawn_kill(self, pos)
	local t = self._t
	for _, area in pairs(self._area_data or {}) do
		for _, sg in ipairs(area.spawn_groups or {}) do
			if sg.pos and mvector3.distance(sg.pos, pos) < CAMP_RADIUS then
				local c = T.camp[sg]
				if not c or t - c.t > CAMP_WINDOW then
					c = { t = t, n = 0 }
					T.camp[sg] = c
				end
				c.n = c.n + 1
				if c.n >= CAMP_KILLS then
					sg.delay_t = math.max(sg.delay_t or 0, t + CAMP_BLOCK)
					T.camp[sg] = nil
				end
			end
		end
	end
end

Hooks:PreHook(GroupAIStateBesiege, "on_enemy_unregistered", "PDTHTactics_spawnkill", function(self, unit)
	if not (T.spawned and alive(unit)) then return end
	local key = unit:key()
	local s = T.spawned[key]
	T.spawned[key] = nil
	if s and T.active() and unit:character_damage() and unit:character_damage():dead()
		and self._t - s.t < CAMP_TIME and mvector3.distance(s.pos, unit:movement():m_pos()) < CAMP_DIST then
		T.camp = T.camp or {}
		pcall(on_spawn_kill, self, s.pos)
	end
end)

local CIV_STEP = 0.08
local CIV_MAX = 1.5

function T.civ_mul()
	return math.min(1 + (T.civ_kills or 0) * CIV_STEP, CIV_MAX)
end

Hooks:PostHook(GroupAIStateBesiege, "_begin_assault_task", "PDTHTactics_civ_force", function(self)
	if not T.active() then return end
	local task = self._task_data and self._task_data.assault
	if task and task.force then
		task.force = math.ceil(task.force * T.civ_mul() * (T.is_ds() and 0.85 or 1))
	end
end)

Hooks:PreHook(GroupAIStateBesiege, "_upd_assault_task", "PDTHTactics_phase_pre", function(self)
	local task = self._task_data and self._task_data.assault
	T._phase = task and task.phase
end)

Hooks:PostHook(GroupAIStateBesiege, "_upd_assault_task", "PDTHTactics_phase_post", function(self)
	if not T.active() then return end
	local task = self._task_data and self._task_data.assault
	if task and task.phase == "sustain" and T._phase ~= "sustain" and task.phase_end_t then
		local mul = T.civ_mul() * (T.hrt_wave and 0.35 or 1)
		if mul ~= 1 then
			task.phase_end_t = task.phase_end_t + (task.phase_end_t - self._t) * (mul - 1)
		end
	end
end)

local HOLD_RADIUS = 700
local HOLD_TIME = 15

Hooks:PostHook(GroupAIStateBesiege, "_upd_police_activity", "PDTHTactics_holding", function(self)
	if not T.active() then return end
	local t = self._t
	if T._hold_next and t < T._hold_next then return end
	T._hold_next = t + 1
	T.anchor = T.anchor or {}
	local camping = {}
	for u_key, c in pairs(self._criminals or {}) do
		if alive(c.unit) and c.m_pos and not c.is_deployable then
			local a = T.anchor[u_key]
			if not a or mvector3.distance(a.pos, c.m_pos) > HOLD_RADIUS then
				a = { pos = mvector3.copy(c.m_pos), t = t }
				T.anchor[u_key] = a
			end
			if t - a.t > HOLD_TIME then
				camping[u_key] = true
			end
		end
	end
	T.camping = camping
end)

-- Hard cap on cops alive at once. Counting every squad (assault, recon, HRT, reinforcements)
-- a long assault reached 80+ cops alive and 250+ spawned, which overloads the host
-- (big FPS drops, and the game froze at that point). New squads wait until the count drops.
T.ALIVE_CAP_BASE = 52
T.ALIVE_CAP_PER_PLAYER = 6
function T.alive_cap()
	local session = managers.network and managers.network:session()
	local players = session and table.size(session:peers()) + 1 or 1
	return T.ALIVE_CAP_BASE + T.ALIVE_CAP_PER_PLAYER * players
end

local orig_spawn_in_group = GroupAIStateBesiege._spawn_in_group
function GroupAIStateBesiege:_spawn_in_group(spawn_group, spawn_group_type, ...)
	if T.active() and spawn_group and not (type(spawn_group_type) == "string" and string.find(spawn_group_type, "Phalanx", 1, true)) then
		local ok, over = pcall(function()
			return table.size(self._police or {}) >= T.alive_cap()
		end)
		if ok and over then
			spawn_group.delay_t = math.max(spawn_group.delay_t or 0, self._t + 5)
			if not T._cap_logged or self._t > T._cap_logged then
				T._cap_logged = self._t + 30
				log(T.name .. " alive cap reached (" .. tostring(T.alive_cap()) .. "), holding new squads")
			end
			return
		end
	end
	return orig_spawn_in_group(self, spawn_group, spawn_group_type, ...)
end
