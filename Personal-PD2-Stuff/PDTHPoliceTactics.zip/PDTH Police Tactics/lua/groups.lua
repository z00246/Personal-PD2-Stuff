if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics
local script = RequiredScript and RequiredScript:lower() or ""

-- Special caps (how many of each special may be alive at once). The base game keeps these very low
-- (Death Sentence: 3 Dozers, 3 Tazers, 2 Cloakers, 4 Shields, 3 Medics) and blocks any squad that would
-- go over them, so most of a fight is plain SWAT. Raised per difficulty, plus more per extra heister.
T.SPECIAL_CAPS = {
	--            tank taser spooc shield medic
	[5] = { tank = 2, taser = 3, spooc = 2, shield = 5, medic = 3 }, -- Overkill
	[6] = { tank = 3, taser = 4, spooc = 3, shield = 5, medic = 3 }, -- Mayhem
	[7] = { tank = 3, taser = 4, spooc = 3, shield = 6, medic = 4 }, -- Death Wish
	[8] = { tank = 4, taser = 5, spooc = 4, shield = 6, medic = 4 }  -- Death Sentence
}
-- added for every heister past the first (rounded down): 4 players on DS = 5/8/5/9/5
T.SPECIAL_PER_PLAYER = { tank = 0.34, taser = 1, spooc = 0.5, shield = 1, medic = 0.5 }

if script == "lib/managers/jobmanager" then
	local orig_limit = JobManager.current_spawn_limit
	function JobManager:current_spawn_limit(special_type, ...)
		local limit = orig_limit(self, special_type, ...)
		if not (special_type and type(limit) == "number" and T.active()) then return limit end
		local ok, extra = pcall(function()
			local per = T.SPECIAL_PER_PLAYER[special_type]
			if not per then return 0 end
			local session = managers.network and managers.network:session()
			local players = session and table.size(session:peers()) + 1 or 1
			return math.floor(per * math.max(players - 1, 0) + 0.001)
		end)
		return limit + (ok and extra or 0)
	end
	return
end

Hooks:PostHook(GroupAITweakData, "_init_unit_categories", "PDTHTactics_special_caps", function(self, difficulty_index)
	local caps = T.SPECIAL_CAPS[difficulty_index]
	local limits = self.special_unit_spawn_limits
	if not (caps and limits) then return end
	for kind, n in pairs(caps) do
		if type(limits[kind]) == "number" and limits[kind] < n then
			T.set(limits, kind, n)
		end
	end
end)

Hooks:PostHook(GroupAITweakData, "init", "PDTHTactics_spawn_groups", function(self)
	local cats = self.unit_categories or {}
	local function stype(unit_name)
		local c = cats[unit_name]
		return c and c.special_type
	end

	if type(self.smoke_and_flash_grenade_timeout) == "table" then
		local t = self.smoke_and_flash_grenade_timeout
		local m = T.is_ds() and 0.35 or 0.5
		T.set(self, "smoke_and_flash_grenade_timeout", { (t[1] or 10) * m, (t[2] or 20) * m })
	end

	-- Shield squads come in two styles (alternating by squad type, like Restoration):
	-- assault squads push in and go after downed players, support squads hang back and shoot
	local shield_names = {}
	for name, grp in pairs(self.enemy_spawn_groups or {}) do
		if type(grp) == "table" and type(grp.spawn) == "table" and not string.find(name, "Phalanx") then
			for _, e in ipairs(grp.spawn) do
				if stype(e.unit) == "shield" then table.insert(shield_names, name) break end
			end
		end
	end
	table.sort(shield_names)
	local shield_style = {}
	for i, name in ipairs(shield_names) do shield_style[name] = (i % 2 == 1) and "assault" or "support" end

	for name, grp in pairs(self.enemy_spawn_groups or {}) do
		if type(grp) == "table" and type(grp.spawn) == "table" and not string.find(name, "Phalanx") then
			local has_shield, has_tazer, has_spooc = false, false, false
			for _, e in ipairs(grp.spawn) do
				local s = stype(e.unit)
				has_shield = has_shield or s == "shield"
				has_tazer = has_tazer or s == "taser"
				has_spooc = has_spooc or s == "spooc"
			end

			for _, e in ipairs(grp.spawn) do
				local s = stype(e.unit)
				local style = shield_style[name]
				local style_add = style == "assault" and { "charge", "deathguard", "provide_coverfire" }
					or style == "support" and { "ranged_fire", "provide_coverfire" } or {}
				local style_drop = style == "support" and { charge = true, deathguard = true } or nil
				if s == "shield" then
					local add = { "shield", "smoke_grenade" }
					for _, v in ipairs(style_add) do table.insert(add, v) end
					T.set(e, "tactics", T.with(e.tactics, add, style_drop))
				elseif s == "medic" then
					T.set(e, "tactics", T.with(e.tactics, { "pdth_medic", "ranged_fire" }, { charge = true, flank = true }))
				elseif s == "spooc" then
					T.set(e, "tactics", T.with(e.tactics, { "flank", "smoke_grenade", "pdth_lurk", has_tazer and "pdth_team" or nil }, { charge = true }))
				elseif s == "taser" then
					T.set(e, "tactics", T.with(e.tactics, { "flank", "smoke_grenade" }))
				elseif s == "tank" then
					T.set(e, "tactics", T.with(e.tactics, { "pdth_tank" }))
				elseif not s and has_shield then
					local add = { "shield_cover", "smoke_grenade", "flash_grenade" }
					for _, v in ipairs(style_add) do if v ~= "charge" then table.insert(add, v) end end
					T.set(e, "tactics", T.with(e.tactics, add, { charge = true, flank = true }))
				elseif not s then
					T.set(e, "tactics", T.with(e.tactics, { "flank", "smoke_grenade", "flash_grenade", "pdth_escort" }))
				end
			end

			if has_tazer and not has_spooc and cats.spooc then
				local spawn = {}
				for i, e in ipairs(grp.spawn) do spawn[i] = e end
				table.insert(spawn, {
					amount_min = 0, amount_max = 1, freq = 0.5, rank = 2, unit = "spooc",
					tactics = { "flank", "smoke_grenade", "pdth_lurk", "pdth_team" }
				})
				T.set(grp, "spawn", spawn)
				if type(grp.amount) == "table" and grp.amount[2] then
					T.set(grp, "amount", { grp.amount[1], grp.amount[2] + 1 })
				end
			end
		end
	end
end)
