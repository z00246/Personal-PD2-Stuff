GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs

local DS = "\n\nWhile playing on Death Sentence difficulty, "
local DODGE = "your chance to dodge from this perk card is increased by an additional ##5%##."

B.desc_lines = {
	menu_deck10_1_desc = "you will be healed for a random amount from ##28## to ##42## health points instead, and you will lose a random amount from ##56## to ##84## health points instead. Jackpots still triple these amounts.\nCritical hit chance you gain or lose is from ##3%## to ##9%## instead, a jackpot is ##30%##, and it can go from ##-45%## up to ##45%##.",
	menu_deck10_7_desc = "health you gain on a successful roll is increased by ##28## instead, but health you lose on a failure roll is also increased by ##56##.",
	menu_deck10_9_desc = "on a successful roll you gain a random amount of dodge chance from ##4%## to ##16%##, a jackpot gives ##56%##. On a failure roll you lose a random amount from ##8%## to ##32%##, a failure jackpot takes away ##56%##. Maximum dodge chance you can get from this perk card is increased to ##60%##.",
	menu_deck11_1_desc = "the health you regenerate from each stack is increased by ##50%##, and you can have up to ##6## stacks.",
	menu_deck11_5_desc = "Overgrowth can share up to ##20%## of your maximum health every ##5## seconds instead.",
	menu_deck12_1_desc = "the maximum armor recovery bonus is ##25%## instead.",
	menu_deck12_3_desc = "Bloodied goes up to ##35%## more damage instead.",
	menu_deck12_5_desc = "Last Stand can occur once every ##60## seconds instead, and the armor recovery bonus is increased by an additional ##25%## instead.",
	menu_deck12_7_desc = "the maximum armor recovery bonus while at low health is increased by an additional ##25%## instead.",
	menu_deck12_9_desc = "Iron Will reduces damage taken by ##20%## instead.",
	menu_deck13_1_desc = "you get ##6## stored health for each enemy you or your crew kills instead.",
	menu_deck13_3_desc = "the amount of stored health gained on kill is increased by ##6## instead, and each Campaign Trail stack gives ##3%## more damage.",
	menu_deck13_5_desc = "Secret Service reduces damage taken by ##15%## instead.",
	menu_deck13_7_desc = "the amount of stored health gained on kill is increased by ##6## instead.",
	menu_deck14_1_desc = "you can convert up to ##150## damage into Hysteria Stacks every ##1.5## second(s) instead.",
	menu_deck14_5_desc = "kills give ##45## Hysteria Stacks instead.",
	menu_deck14_9_desc = "Comedown reduces damage by up to ##40%## instead.",
	menu_deck15_1_desc = "the armor you regenerate is increased by ##30%##, and you will be immune to health damage for ##3## seconds when your armor gets depleted instead.",
	menu_deck15_3_desc = "Riot increases your damage by ##15%## instead.",
	menu_deck15_7_desc = "Black Bloc increases your damage by ##35%## instead.",
	menu_deck16_1_desc = "each Stack of Regeneration instantly restores ##7.5## health and ##7.5## armor instead.",
	menu_deck16_3_desc = "Road Rage gives ##5%## more damage per Momentum instead.",
	menu_deck16_7_desc = "Colors reduces damage taken by ##15%## instead.",
	menu_deck17_1_desc = "activating the injector will heal you with ##75%## of all damage taken for ##8## seconds instead.",
	menu_deck17_7_desc = "Overdose takes ##3## extra seconds off the cooldown per kill instead.",
	menu_deck18_3_desc = "you gain ##22.5%## dodge chance every time you are damaged instead.",
	menu_deck18_5_desc = "your chance to dodge from this perk card is increased by an additional ##5%##, and Haze increases your damage by ##30%## instead.",
	menu_deck19_1_desc = "damage taken is reduced by ##80%## instead, and the ##80%## reduced damage will be applied over-time.",
	menu_deck19_3_desc = "Grit goes up to ##30%## more damage instead.",
	menu_deck20_1_desc = "each enemy you or the tagged unit kills will heal you for ##22.5## health and the tagged unit for ##11.25## health instead.",
	menu_deck20_3_desc = "Crossfire increases your damage by ##35%## instead.",
	menu_deck20_7_desc = "Shared Pain reduces damage taken by ##20%## instead.",
	menu_deck21_1_desc = "the feedback effect lasts ##12## seconds instead, each kill takes ##6## seconds off the cooldown instead, and you take ##15%## less damage while your feedback is active.",
	menu_deck21_5_desc = "killing an enemy while the feedback effect is active will regenerate ##45## health instead. your crew also deals ##15%## more damage to enemies Overclock marks.",

	menu_deck21_9_desc = "the health regenerated on kill while the feedback effect is active is increased by ##50%##, and " .. DODGE,
	menu_deck22_1_desc = "activating the Leech Ampule restores ##45%## health instead.",
	menu_deck23_1_desc = "perk cards you copy from other perk decks also get their Death Sentence bonuses.",
	menu_deck_brawler1_desc = "while using melee weapons your armor gains ##7.5%## bullet damage resistance instead.",
	menu_deck_brawler3_desc = "while using melee weapons your armor gains ##7.5%## more bullet damage resistance instead.",
	menu_deck_brawler5_desc = "while using melee weapons your armor gains ##15%## more bullet damage resistance instead.",
	menu_deck_SJ_5_desc = "securing a kill adds ##6## to ##25## stacks of adrenaline instead.",
	menu_deck_SJ_7_desc = "you gain ##22.5## points of armor when you dodge instead, or ##67.5## if you have no armor remaining.",
	menu_deck_Gilza_guardian_1_desc = "you regenerate ##15## points of health every ##2## seconds while inside of your defensive area instead, and teammates inside of it take ##20%## less damage instead of ##15%##.",
	menu_deck_Gilza_guardian_3_desc = "you regenerate ##30## points of health every ##2## seconds while inside of your defensive area instead.",
	menu_deck_Gilza_guardian_5_desc = "you regenerate ##45## points of health every ##2## seconds while inside of your defensive area instead."
}

B.full_text = {
	menu_deck21_1_desc = "Unlocks the Pocket ECM in your throwable slot. Use it with your throwable key.\n\nBefore the alarm, it jams cameras, pagers and phones. After the alarm, it releases a feedback pulse that can stun nearby enemies. Kills reduce its cooldown.",
	menu_deck21_1_short = "Unlocks the Pocket ECM: jams electronics before the alarm and stuns nearby enemies with feedback after it. Kills reduce its cooldown.",
	menu_deck21_5_desc = "Killing an enemy while the feedback effect is active regenerates ##30## health.\n\nOverclock: enemies within your feedback's range are marked for your whole crew and take extra damage.",
	menu_deck21_5_short = "Kills during feedback regenerate ##30## health. Overclock: enemies in your feedback are marked and take extra damage.",
	menu_deck21_7_desc = "Firewall: while your feedback is active, Tazers and Cloakers in its range can't tase, charge or kick, and any attempt in progress is cancelled. They can still shoot, and Tazers aren't stunned by your feedback.\n\nNote: requires the host to have this mod.",
	menu_deck21_7_short = "Firewall: Tazers and Cloakers in your feedback can't tase, charge or kick. Requires the host to have this mod.",
	menu_deck20_1_desc = "Unlocks the Gas Dispenser in your throwable slot. Look at a teammate within ##24m## and press your throwable key to link with them.\n\nWhile linked, each kill by either of you heals you for ##15## health and your partner for ##7.5##. Your kills extend the link by ##1.7## seconds and reduce its cooldown by ##2## seconds. The link lasts ##12## seconds, ##60## second cooldown.\n\nBond: while linked, you deal ##10%## more damage.",
	menu_deck20_1_short = "Gas Dispenser: link with a teammate. Kills by either of you heal you both. ##12## second link, ##60## second cooldown. Bond: ##10%## more damage while linked.",
	menu_deck19_1_desc = "Unlocks the Stoic Hip Flask in your throwable slot. Use it with your throwable key.\n\n##70%## of the damage you take is applied over ##10## seconds instead of right away. Drinking from the flask removes all pending damage. ##10## second cooldown, ##1## second less per kill.\n\nYou can't wear armor with this deck.",
	menu_deck19_1_short = "Unlocks the Stoic Hip Flask. ##70%## of damage taken is applied over ##10## seconds. The flask removes all pending damage. ##10## second cooldown, ##1## second less per kill.",
	menu_deck18_1_desc = "Unlocks the Smoke Bomb in your throwable slot. Use it with your throwable key.\n\nThe smoke lasts ##10## seconds. Players inside it dodge ##50%## of bullets, and enemies inside it are ##50%## less accurate. ##60## second cooldown, ##1## second less per kill.",
	menu_deck18_1_short = "Unlocks the Smoke Bomb: ##10## seconds of smoke where players dodge ##50%## of bullets and enemies are ##50%## less accurate. ##60## second cooldown, ##1## second less per kill.",
	menu_deck17_1_desc = "Unlocks the Kingpin Injector in your throwable slot. Use it with your throwable key.\n\nThe injector heals you for ##75%## of all damage taken for ##6## seconds. It can be used once every ##30## seconds, and each kill reduces the cooldown by ##1## second.",
	menu_deck17_1_short = "Unlocks the Kingpin Injector: heals you for ##75%## of damage taken for ##6## seconds. ##30## second cooldown, ##1## second less per kill.",
	menu_deck16_1_desc = "You gain ##5%## more armor and ##10%## more health.\n\nKills by you or your crew can give a Stack of Regeneration, which instantly restores ##5## health and ##5## armor and then fills one of your ##4## slots for ##4## seconds. Stacks only trigger while you are damaged.",
	menu_deck16_1_short = "##5%## more armor, ##10%## more health. Kills by you or your crew give Stacks of Regeneration (##5## health and ##5## armor), up to ##4## at a time.",
	menu_deck16_3_desc = "Every ##10%## health missing adds ##1## armor to each Stack of Regeneration.\n\nEvery kill by you or your crew gives ##1## Momentum for ##4## seconds, up to ##4##. Road Rage: each Momentum gives ##4%## more damage.",
	menu_deck16_3_short = "Missing health makes stacks restore more armor. Crew kills give Momentum (up to ##4##). Road Rage: ##4%## more damage per Momentum.",
	menu_deck16_5_desc = "Every ##10%## health missing shortens the time stacks fill a slot by ##0.1## seconds.\n\nChopper: each Momentum gives ##3%## more movement speed.",
	menu_deck16_5_short = "Missing health frees slots faster. Chopper: ##3%## more speed per Momentum.",
	menu_deck16_7_desc = "Every ##10%## armor missing adds ##1## health to each Stack of Regeneration.\n\nColors: at ##3## or more Momentum, you take ##10%## less damage.",
	menu_deck16_7_short = "Missing armor makes stacks restore more health. Colors: ##10%## less damage taken at ##3##+ Momentum.",
	menu_deck16_9_desc = "Every ##10%## armor missing shortens the time stacks fill a slot by ##0.1## seconds.\n\nBurnout: reaching ##4## Momentum gives ##25%## more damage for ##3## seconds, once every ##10## seconds.\n\nDeck Completion Bonus: Your chance of getting a higher quality item during a Payday is increased by ##10%##.",
	menu_deck16_9_short = "Missing armor frees slots faster. Burnout: reaching max Momentum gives ##25%## more damage for ##3## seconds.",
	menu_deck15_1_desc = "Your armor regenerates in small amounts throughout combat instead of all at once. Heavier armor regenerates less, more often. Values are in the armor descriptions.\n\nWhen your armor breaks, you are immune to health damage for ##2## seconds, once every ##15## seconds.\n\nSkills that increase armor recovery rate do not work with this deck.",
	menu_deck15_1_short = "Armor regenerates in small amounts throughout combat. When it breaks, you are immune to health damage for ##2## seconds, once every ##15## seconds.",
	menu_deck15_3_desc = "##50%## of your health is converted into ##100%## armor.\n\nWhile your armor is full, you deal ##10%## more damage.",
	menu_deck15_3_short = "##50%## of your health becomes ##100%## armor. Riot: ##10%## more damage while your armor is full.",
	menu_deck15_5_desc = "##50%## of your health is converted into ##110%## armor.\n\nWhile your armor is below half, you reload ##15%## faster.",
	menu_deck15_5_short = "##50%## of your health becomes ##110%## armor. You reload ##15%## faster while your armor is below half.",
	menu_deck15_7_desc = "##50%## of your health is converted into ##120%## armor.\n\nWhen your armor breaks, you deal ##25%## more damage for ##4## seconds.",
	menu_deck15_7_short = "##50%## of your health becomes ##120%## armor. Black Bloc: when your armor breaks, you deal ##25%## more damage for ##4## seconds.",
	menu_deck15_9_desc = "Dealing damage gives you a few points of armor, once every few seconds. Heavier armor gives less, more often. Values are in the armor descriptions.\n\nEach kill during Black Bloc shortens the armor break immunity cooldown by ##1## second.\n\nDeck Completion Bonus: Your chance of getting a higher quality item during a Payday is increased by ##10%##.",
	menu_deck15_9_short = "Dealing damage gives a few points of armor. Kills during Black Bloc shorten the immunity cooldown by ##1## second.",
	menu_deck14_1_desc = "Damage you deal becomes Hysteria Stacks, up to ##120## every ##1.5## seconds and ##600## in total. Every ##30## stacks absorb ##1## damage from each hit you take.\n\nIf you don't deal damage for ##3## seconds, you lose ##20% + 80## stacks.",
	menu_deck14_1_short = "Damage you deal becomes Hysteria Stacks, up to ##600##. Every ##30## stacks absorb ##1## damage per hit. Stacks decay if you stop dealing damage.",
	menu_deck14_3_desc = "Your crew also gains damage absorption from your Hysteria Stacks. Only the strongest Hysteria on each player counts.\n\nWhile you have ##300## or more stacks, you reload and swap weapons ##10%## faster.",
	menu_deck14_3_short = "Your crew shares your Hysteria. At ##300##+ stacks, you reload and swap weapons ##10%## faster.",
	menu_deck14_5_desc = "Stack decay is reduced to ##20% + 40##.\n\nEvery kill instantly gives ##30## Hysteria Stacks.",
	menu_deck14_5_short = "Stack decay reduced to ##20% + 40##. Kills give ##30## stacks instantly.",
	menu_deck14_7_desc = "Your crew gains the full strength of your Hysteria Stacks.\n\nAt ##600## stacks, you move ##10%## faster and sprinting doesn't use stamina.",
	menu_deck14_7_short = "Your crew gets your full Hysteria strength. At max stacks, ##10%## faster movement and no stamina drain.",
	menu_deck14_9_desc = "Your Hysteria absorbs ##100%## more damage for you, or ##200%## on Death Sentence.\n\nWhen your stacks decay, you take up to ##30%## less damage for ##3## seconds, based on how many stacks you lost.\n\nDeck Completion Bonus: Your chance of getting a higher quality item during a Payday is increased by ##10%##.",
	menu_deck14_9_short = "Hysteria absorbs ##100%## more damage for you. Comedown: losing stacks gives up to ##30%## less damage taken for ##3## seconds.",
	menu_deck13_1_desc = "While your armor is up, you store ##4## health for each enemy you or your crew kills. The storage cap depends on your armor.\n\nWhen your armor recovers after breaking, stored health heals you.",
	menu_deck13_1_short = "While your armor is up, kills by you or your crew store ##4## health. When your armor recovers after breaking, stored health heals you.",
	menu_deck13_3_desc = "You store ##4## more health per kill.\n\nYou gain ##10%## more health.\n\nWhile your stored health is full, each kill gives ##2%## more damage for ##10## seconds, stacking up to ##5## times.",
	menu_deck13_3_short = "##+4## stored per kill, ##10%## more health. Campaign Trail: kills while stored health is full give ##2%## damage for ##10## seconds, up to ##5## stacks.",
	menu_deck13_5_desc = "Your storage cap is increased by ##50%##.\n\nYou gain ##10%## more health.\n\nWhile you have any stored health, you take ##10%## less damage.",
	menu_deck13_5_short = "##50%## more storage, ##10%## more health. Secret Service: ##10%## less damage taken while you have stored health.",
	menu_deck13_7_desc = "You store ##4## more health per kill.\n\nYou gain ##20%## more health.\n\nWhile your armor is broken, stored health absorbs damage before your health. Whenever it does, you take ##25%## less damage for ##2## seconds.",
	menu_deck13_7_short = "##+4## stored per kill, ##20%## more health. Stored health absorbs damage before your health, and you take ##25%## less damage for ##2## seconds when it does.",
	menu_deck13_9_desc = "Each kill by you or your crew speeds up your next armor recovery, down to ##0.8## seconds. Smaller armors gain more per kill. This resets when stored health is used.\n\nStored health that doesn't fit is shared as healing with teammates within ##18m##.\n\nDeck Completion Bonus: Your chance of getting a higher quality item during a Payday is increased by ##10%##.",
	menu_deck13_9_short = "Kills speed up your next armor recovery until stored health is used. Stored health that doesn't fit heals teammates within ##18m##.",
	menu_deck12_1_desc = "The lower your health, the faster your armor will recover. This effect is active while your health is below ##50%##. Maximum armor recovery bonus is ##20%##.\n\nWhenever you are revived, your health will always be set to ##10%## of your max health.",
	menu_deck12_1_short = "Below ##50%## health, the lower your health, the faster your armor recovers, up to ##20%##. You are always revived at ##10%## health.",
	menu_deck12_3_desc = "The lower your health, the more movement speed you gain, up to ##20%##, while your health is below ##50%##.\n\nThe lower your health below ##50%##, the more damage you deal, up to ##25%## more near death.",
	menu_deck12_3_short = "Below ##50%## health, you gain up to ##20%## movement speed. Bloodied: up to ##25%## more damage the lower your health.",
	menu_deck12_5_desc = "Maximum armor recovery bonus while at low health is increased by an additional ##20%##.\n\nLast Stand: once every ##90## seconds, a hit that would down you leaves you at ##1## health instead, fully restores your armor and makes you invulnerable for ##2## seconds.",
	menu_deck12_5_short = "Armor recovery bonus ##+20%##. Once every ##90## seconds, a hit that would down you leaves you at ##1## health, refills your armor and makes you invulnerable for ##2## seconds.",
	menu_deck12_7_desc = "Maximum armor recovery bonus while at low health is increased by an additional ##20%##.\n\nKilling an enemy while below ##50%## health restores ##5%## of your armor.\n\nWhile your health is below ##50%## you are immune to the armor piercing effect.",
	menu_deck12_7_short = "Armor recovery bonus ##+20%##. Kills below ##50%## health restore ##5%## armor. Immune to armor piercing below ##50%## health.",
	menu_deck12_9_desc = "While your health is below ##25%##, you take ##15%## less damage.\n\nYou gain ##25%## bullet damage resistance against enemies located behind you (180°). This bonus is increased to ##50%## while playing on Death Sentence difficulty.\n\nWhile your health is below ##50%## you are immune to the armor suppression effect.\n\nDeck Completion Bonus: Your chance of getting a higher quality item during a Payday is increased by ##10%##.",
	menu_deck12_9_short = "Iron Will: below ##25%## health you take ##15%## less damage. ##25%## less bullet damage from behind. Immune to armor suppression below ##50%## health.",
	menu_deck11_1_desc = "Damaging an enemy grants a stack that heals ##1## life point every ##0.3## seconds for ##3## seconds. You can gain a stack every ##0.75## seconds (every ##2## seconds from fire damage) and have up to ##5## stacks.\n\nOnly works while wearing the Two-piece Suit or Lightweight Ballistic Vest.",
	menu_deck11_1_short = "Damaging an enemy grants a healing stack, every ##0.75## seconds, up to ##5## stacks. Suit or Lightweight Ballistic Vest only.",
	menu_deck11_3_desc = "Each stack now heals ##2## life points every ##0.3## seconds.\n\nEach active stack increases your damage by ##3%##.\n\nYour health is increased by ##20%##.",
	menu_deck11_3_short = "Stacks heal ##2## per tick. Each active stack gives ##3%## more damage. ##20%## more health.",
	menu_deck11_5_desc = "Each stack now heals ##3## life points every ##0.3## seconds.\n\nHealing you receive at full health goes to your nearest teammate within ##15m## instead, up to ##15%## of your maximum health every ##5## seconds.\n\nYou gain ##10%## chance to pierce enemy body armor.",
	menu_deck11_5_short = "Stacks heal ##3## per tick. Overgrowth: healing at full health goes to your nearest teammate, up to ##15%## of your max health every ##5## seconds. ##10%## armor piercing.",
	menu_deck11_7_desc = "Each stack now heals ##4## life points every ##0.3## seconds.\n\nKilling an enemy while you have ##3## or more stacks refreshes the duration of all your stacks (kills by burning don't).\n\nYour health is increased by an additional ##20%##.",
	menu_deck11_7_short = "Stacks heal ##4## per tick. Kills with ##3##+ stacks refresh all stacks. ##20%## more health.",
	menu_deck11_9_desc = "Stacks now last ##4.2## seconds.\n\nWhile below ##35%## health, your stacks heal twice as much.\n\nYour chances to pierce enemy body armor are increased by an additional ##25%##.\n\nDeck Completion Bonus: Your chance of getting a higher quality item during a Payday is increased by ##10%##.",
	menu_deck11_9_short = "Stacks last ##4.2## seconds. Below ##35%## health, stacks heal twice as much. ##25%## more armor piercing.",
	menu_deck22_1_desc = "Unlocks and equips the Leech Ampule, which replaces your throwable. Use your throwable key to activate it.\nThe Leech Ampule lasts for ##6## seconds with a ##60## second cooldown. If you go down while it is ready or its cooldown is below ##20## seconds, the cooldown is set to ##20## seconds.\n\nActivating the Leech Ampule restores ##30%## health. While it is active your armor is disabled and your health is divided into segments of ##25%##. Each hit removes one segment, or two if the damage was greater than ##150##, and grants ##1## second of invulnerability. Securing a kill during that second restores ##1## segment. Reviving a teammate while it is active restores ##50%## of your health and all of your armor when it ends.\n\nEvery kill you secure while the Leech Ampule is active heals teammates within ##15m## of you for ##5%## of their health.",
	menu_deck22_1_short = "Unlocks the Leech Ampule: restores ##30%## health, disables armor and splits your health into ##25%## segments. Kills while it is active heal teammates within ##15m## for ##5%##.",
	menu_deck22_3_desc = "Your maximum health is increased by ##20%##.\n\nActivating the Leech Ampule heals teammates within ##15m## of you for ##10%## of their health.\n\nWhile the Leech Ampule is active you can not go into bleedout. Reaching ##0## health puts you in Last Breath, slowing you by ##80%## and only allowing kills during invulnerability to heal you. If the Leech Ampule ends while you are in Last Breath, you go down unless you revived a teammate during it.",
	menu_deck22_3_short = "Your maximum health is increased by ##20%##. Activating the Leech Ampule heals teammates within ##15m## for ##10%##.",
	menu_deck22_5_desc = "The Leech Ampule lasts for ##10## seconds, and killing an enemy reduces its cooldown by ##1## second.\n\nKills while the Leech Ampule is active heal teammates for ##10%## of their health, and the range is increased to ##20m##.\n\nReviving a crew member heals them for ##20%## of their health and you for ##10%## of yours.",
	menu_deck22_5_short = "The Leech Ampule lasts ##10## seconds and kills reduce its cooldown by ##1## second. Kills during it heal teammates for ##10%## within ##20m##.",
	menu_deck22_7_desc = "Your maximum health is increased by ##60%##.\n\nEvery kill you secure while the Leech Ampule is active extends its duration by ##0.5## seconds, up to ##3## seconds per activation.",
	menu_deck22_7_short = "Your maximum health is increased by ##60%##. Kills during the Leech Ampule extend it by ##0.5## seconds, up to ##3## seconds.",
	menu_deck22_9_desc = "You can activate the Leech Ampule while downed, reviving yourself until it ends. Doing so adds ##40## seconds to its cooldown. You stay up after it ends if you use a Doctor Bag or revive a teammate during it.\n\nYour health segments are reduced to ##20%##.\n\nKills while the Leech Ampule is active heal teammates for ##20%## of their health, and activating it heals teammates in range for ##20%## of their health.\n\nDeck Completion Bonus: Your chance of getting a higher quality item during a Payday is increased by ##10%##.",
	menu_deck22_9_short = "You can activate the Leech Ampule while downed. Health segments are reduced to ##20%##. Kills during it and activating it heal teammates for ##20%##."
}

-- (7.18: the old Hitman text fixes went with the Hitman rework; decorate() still reads this)
B.replacements = {}

B.always_lines = {
	menu_deck23_9_crew_chief_desc = "\n\nMimicry: you also gain the effects this perk deck's cards 1 and 3 have in this mod.",
	menu_deck23_9_muscle_desc = "\n\nMimicry: you also gain the effects this perk deck's cards 1 and 3 have in this mod.",
	menu_deck23_9_armorer_desc = "\n\nMimicry: you also gain the effects this perk deck's cards 1 and 3 have in this mod.",
	menu_deck23_9_rogue_desc = "\n\nMimicry: you also gain the effects this perk deck's cards 1 and 3 have in this mod.",
	menu_deck23_9_crook_desc = "\n\nMimicry: you also gain the effects this perk deck's cards 1 and 3 have in this mod.",
	menu_deck23_9_burglar_desc = "\n\nMimicry: you also gain the effects this perk deck's cards 1 and 3 have in this mod.",
	menu_deck23_9_infil_desc = "\n\nMimicry: you also gain the effects this perk deck's cards 1 and 3 have in this mod.",
	menu_deck23_9_grinder_desc = "\n\nMimicry: you also gain the effects this perk deck's cards 1 and 3 have in this mod.",
	menu_deck23_9_yakuza_desc = "\n\nMimicry: you also gain the effects this perk deck's cards 1 and 3 have in this mod.",
	menu_deck23_9_expres_desc = "\n\nMimicry: you also gain the effects this perk deck's cards 1 and 3 have in this mod.",
	menu_deck23_9_maniac_desc = "\n\nMimicry: you also gain the effects this perk deck's cards 1 and 3 have in this mod.",
	menu_deck23_9_anarchist_desc = "\n\nMimicry: you also gain the effects this perk deck's cards 1 and 3 have in this mod.",
	menu_deck23_9_biker_desc = "\n\nMimicry: you also gain the effects this perk deck's cards 1 and 3 have in this mod.",
	menu_deck23_9_stoic_desc = "\n\nMimicry: you also gain the effects this perk deck's cards 1 and 3 have in this mod.",
	menu_deck23_9_leech_desc = "\n\nMimicry: you also gain the effects this perk deck's cards 1 and 3 have in this mod.",
	menu_deck20_3_desc = "\n\nCrossfire: while linked, enemies your partner hit in the last ##3## seconds take ##25%## more damage from you.",
	menu_deck20_5_desc = "\n\nLifeline: if your partner goes down while linked, you take ##30%## less damage and move ##20%## faster for ##3## seconds.",
	menu_deck20_7_desc = "\n\nShared Pain: while linked, you take ##15%## less damage.",
	menu_deck20_9_desc = "\n\nTag Out: when the link ends, you and your partner heal ##15%## of your health.",
	menu_deck19_3_desc = "\n\nGrit: the more pending damage you are holding back, the more damage you deal, up to ##20%## at ##50%## of your health.",
	menu_deck19_5_desc = "\n\nComposure: after drinking from the flask, you take ##40%## less damage for ##2## seconds.",
	menu_deck19_7_desc = "\n\nStiff Upper Lip: kills while you have pending damage restore ##2%## of your health.",
	menu_deck18_5_desc = "\n\nHaze: you deal ##20%## more damage to enemies standing inside your smoke.",
	menu_deck18_7_desc = "\n\nVanishing Act: killing an enemy inside your smoke takes ##2## extra seconds off the Smoke Bomb cooldown.",
	menu_deck17_3_desc = "\n\nAdrenal Surge: while the injector is active, you deal ##20%## more damage.",
	menu_deck17_7_desc = "\n\nOverdose: each kill while the injector is active takes ##2## extra seconds off its cooldown.",
	menu_deck17_9_desc = "\n\nWithdrawal: when the injector ends, you take ##25%## less damage for ##3## seconds.",
	menu_deck_Gilza_guardian_1_desc = "\n\nYour defensive area also protects your crew. Every ##2## seconds, teammates within ##8m## of your defensive area regenerate ##50%## of the health it regenerates for you, and take ##15%## less damage for ##2.5## seconds.\nNote: teammates need this mod to receive this effect. Bots receive it when you or the host have this mod.",
	menu_deck10_1_desc = "\n\nEvery roll also gambles your critical hit chance. On a successful roll you gain a random amount of critical hit chance from ##2%## to ##6%##, a jackpot gives ##20%##. On a failure roll you lose a random amount from ##2%## to ##6%##, a failure jackpot takes away ##20%##. Your critical hit chance from this perk card can go from ##-30%## up to ##30%## and resets when you are taken into custody.\nWhile it is negative, that percentage of your bullet and melee hits will heal the enemy instead of damaging them."
}

-- 7.00 reworks: Muscle, Burglar, Infiltrator and Sociopath. Their numbers grow with the difficulty instead of a
-- Death Sentence-only bonus: "##a » b##" is the value from Normal to Overkill » the value on Death Sentence, with
-- Mayhem and Death Wish in between. ("»" because the game fonts have no arrow.)
local FOOT = "\n\n» Scales with difficulty: the first value from Normal to Overkill, growing through Mayhem and Death Wish to the second on Death Sentence."
local COMPLETION = "\n\nDeck Completion Bonus: Your chance of getting a higher quality item during a Payday is increased by ##10%##."
B.rework_text = {
	-- Muscle
	menu_deck2_1_desc = "Your health is increased by ##10%##.\n\nRage: every ##5%## of your maximum health or ##10%## of your maximum armor you lose grants ##1## stack, up to ##10 » 12##. Each stack increases the damage you deal by ##3%## and your movement speed by ##1%##. Kills keep your Rage from fading; after ##4## seconds without taking damage or killing an enemy, you lose ##1## stack every ##2## seconds." .. FOOT,
	menu_deck2_1_short = "##10%## more health. Rage: losing health or armor builds up to ##10 » 12## stacks, each giving ##3%## more damage and ##1%## more speed.",
	menu_deck2_3_desc = "Your health is increased by an additional ##10%##.\n\nTaunt: enemies are ##50%## more likely to target you than your teammates.\n\nBodyguard: teammates within ##10m## of you take ##10% » 15%## less damage. At ##5## or more Rage stacks, you take ##15%## less damage too.\n\nNote: teammates need this mod to get Bodyguard; bots get it when the host has this mod." .. FOOT,
	menu_deck2_3_short = "##10%## more health. Taunt: enemies target you more. Bodyguard: teammates within ##10m## take ##10% » 15%## less damage; at ##5##+ Rage you take ##15%## less.",
	menu_deck2_5_desc = "Your health is increased by an additional ##20%##.\n\nJuggernaut: you regenerate ##0.2% » 0.3%## of your health every second for each Rage stack. At ##5## or more Rage stacks, flashbangs can't blind you and every kill heals you for ##3%## of your health." .. FOOT,
	menu_deck2_5_short = "##20%## more health. Juggernaut: ##0.2% » 0.3%## health per second per Rage stack; at ##5##+ Rage, flashbangs can't blind you and kills heal ##3%##.",
	menu_deck2_7_desc = "Panic: all firearms without a silencer have a starting ##20%## chance to spread panic among non-special enemies with every shot. The chance is lower the further the bullet passes from the enemy.\n\nFearsome: at ##5## or more Rage stacks, every kill makes non-special enemies within ##8m » 12m## panic.\n\nEach Rage stack now increases the damage you deal by ##5%##." .. FOOT,
	menu_deck2_7_short = "Unsilenced shots can spread panic. Fearsome: at ##5##+ Rage, kills make enemies within ##8m » 12m## panic. Each Rage stack gives ##5%## more damage.",
	menu_deck2_9_desc = "Your health is increased by an additional ##60%##.\n\nUnstoppable: reaching ##8## Rage stacks makes you take ##50%## less damage for ##5## seconds, and tasers and Cloaker kicks can't take you down while it lasts. Teammates within ##10m## also take ##25%## less damage while it lasts. This can not occur more often than once every ##25 » 20## seconds." .. FOOT .. COMPLETION,
	menu_deck2_9_short = "##60%## more health. Unstoppable: at ##8## Rage you take ##50%## less damage for ##5## seconds, can't be tased or kicked down, and teammates nearby take ##25%## less. Every ##25 » 20## seconds.",
	-- Burglar
	menu_deck7_1_desc = "Your chance to dodge is increased by ##20%##.\n\nBurglar wears no armor: your armor is always ##0##. You stay alive by not being seen.\n\nGhost: in loud, enemies further than ##15m » 12m## can't see or target you, or ##8m » 6m## while you crouch. Firing an unsuppressed gun gives you away for ##2## seconds. Cloakers see through it and go for you first, and Snipers line you up twice as fast.\n\nShadow: in stealth, guards, civilians and cameras detect you ##25%## slower, or ##50%## slower while you crouch, and suspicion of you fades ##2## times as fast while nobody can see you.\n\nNote: Ghost and Shadow need the host to have this mod." .. FOOT,
	menu_deck7_1_short = "##20%## more dodge. No armor. Ghost: in loud, enemies further than ##15m » 12m## (##8m » 6m## crouched) can't see you. Shadow: slower detection in stealth.",
	menu_deck7_3_desc = "Guard Sense: while you crouch in stealth, guards and cameras within ##15m## are outlined for you, even through walls. In loud, Snipers, Cloakers and Tasers within ##20m## are outlined while you crouch.\n\nUnseen Mend: while no enemy can see you, you regenerate ##1.5% » 2%## of your health every second.\n\nStanding still and crouching makes you ##10%## less likely to be targeted. You bag corpses ##25%## faster." .. FOOT,
	menu_deck7_3_short = "Guard Sense: crouch to outline nearby guards and cameras (Snipers, Cloakers and Tasers in loud). Unseen Mend: ##1.5% » 2%## health a second while unseen.",
	menu_deck7_5_desc = "Silent Takedown: in stealth, a guard who hasn't noticed you and dies to your melee weapon doesn't set off his pager, up to ##2## per heist. Needs the host to have this mod.\n\nYour melee hits and suppressed shots don't make enemies notice you.\n\nYour chance to dodge is increased by an additional ##10% » 15%##. You gain ##4## concealment for each silenced weapon you equip, and you pick locks ##25%## faster." .. FOOT,
	menu_deck7_5_short = "Silent Takedown: up to ##2## unaware guards a heist killed by melee don't set off their pagers. ##10% » 15%## more dodge. ##4## concealment per silenced weapon.",
	menu_deck7_7_desc = "Second Chance: in stealth, when someone is about to spot you, their suspicion drops back to half. This can not occur more often than once every ##60## seconds.\n\nSlip Away: in loud, when you lose health, enemies further than ##2m## can't see you for ##3 » 4## seconds, even while you move or sprint. This can not occur more often than once every ##15## seconds.\n\nYour chance to dodge is increased by an additional ##5%##. You answer pagers ##25%## faster.\n\nNote: needs the host to have this mod." .. FOOT,
	menu_deck7_7_short = "Second Chance: suspicion drops to half before you're spotted, every ##60## seconds. Slip Away: losing health hides you for ##3 » 4## seconds. ##5%## more dodge.",
	menu_deck7_9_desc = "Fade Out: when a hit would down you, you stay at ##1## health and can't be hurt for ##1## second, enemies further than ##2m## can't see you for ##4## seconds, and you regenerate ##25%## of your health over that time. This can not occur more often than once every ##90 » 60## seconds.\n\nWraith: dodging an attack makes enemies further than ##5m## lose sight of you for ##2## seconds. This can not occur more often than once every ##6## seconds.\n\nYour suppressed weapons deal ##15% » 25%## more damage. You gain ##10%## crouching movement speed." .. FOOT .. COMPLETION,
	menu_deck7_9_short = "Fade Out: a hit that would down you leaves you at ##1## health and hidden, every ##90 » 60## seconds. Wraith: dodging hides you for ##2## seconds. Suppressed weapons deal ##15% » 25%## more damage.",
	-- Infiltrator (card 1 keeps Gilza's shared id; Sociopath's card 1 has its own now)
	menu_sociopathinfil_1_desc = "Point Blank: your guns deal up to ##25% » 30%## more damage the closer the enemy is, at full strength within ##4m## and none beyond ##12m##.\n\nWhile you are surrounded by three or more visible enemies within ##18m## of you, you take ##10% » 15%## less damage. This lingers for ##5## seconds after you are no longer surrounded.\n\nYour second and each consecutive melee hit within ##4## seconds of the last one deals ##100%## more damage." .. FOOT,
	menu_sociopathinfil_1_short = "Point Blank: up to ##25% » 30%## more gun damage up close. ##10% » 15%## less damage while surrounded. Consecutive melee hits deal ##100%## more damage.",
	menu_deck8_3_desc = "Closing In: the closer the nearest enemy is, the less damage you take: up to ##12% » 15%## within ##5m##, fading to ##40%## of that at ##18m##.\n\nQuick Hands: while an enemy is within ##8m##, you reload shotguns and SMGs ##15%## faster." .. FOOT,
	menu_deck8_3_short = "Closing In: up to ##12% » 15%## less damage the closer the nearest enemy is. Quick Hands: shotguns and SMGs reload ##15%## faster with an enemy within ##8m##.",
	menu_deck8_5_desc = "Your Closing In damage reduction goes up to ##20% » 25%##.\n\nOpening: a melee hit leaves the target and every enemy within ##3m## of it Exposed for ##7## seconds. Your guns deal ##30% » 40%## more damage to Exposed enemies." .. FOOT,
	menu_deck8_5_short = "Closing In goes up to ##20% » 25%##. Opening: melee hits Expose the target and enemies within ##3m## for ##7## seconds, and your guns deal ##30% » 40%## more damage to them.",
	menu_deck8_7_desc = "Your Closing In damage reduction goes up to ##28% » 35%##.\n\nMelt Away: killing an enemy within ##5m## with any weapon makes you move ##20%## faster and take ##25% » 35%## less damage for ##3## seconds." .. FOOT,
	menu_deck8_7_short = "Closing In goes up to ##28% » 35%##. Melt Away: kills within ##5m## give ##20%## more speed and ##25% » 35%## less damage taken for ##3## seconds.",
	menu_deck8_9_desc = "Bloodrush: every kill within ##8m##, with any weapon, restores ##10% » 15%## of your armor, and a melee kill restores ##15% » 20%## of your armor, no more than once every ##1## second. Killing an Exposed enemy also restores ##5%## of your health (they only get Exposed from your melee hits)." .. FOOT .. COMPLETION,
	menu_deck8_9_short = "Bloodrush: kills within ##8m## restore ##10% » 15%## of your armor (melee kills ##15% » 20%##), once a second. Killing an Exposed enemy restores ##5%## of your health.",
	-- Crook (7.17 rework standard): card names, vest dodge and Deflect scale with the difficulty
	menu_deck6_1_desc = "Sidestep: while you wear a ballistic vest, your chance to dodge is increased by ##15% » 20%##.\n\nDeflect: while wearing a ballistic vest, every attack you dodge restores ##10% » 15%## of your armor." .. FOOT,
	menu_deck6_1_short = "Sidestep: ##15% » 20%## more dodge chance with a ballistic vest. Deflect: dodging an attack restores ##10% » 15%## of your armor.",
	menu_deck6_3_desc = "Padding: your armor is increased by ##20%## for ballistic vests.\n\nYour chance to dodge is increased by an additional ##5% » 10%## for ballistic vests.\n\nDeflect restores ##15% » 20%## of your armor." .. FOOT,
	menu_deck6_3_short = "Padding: ballistic vests gain ##20%## armor and ##5% » 10%## more dodge chance. Deflect restores ##15% » 20%## of your armor.",
	menu_deck6_5_desc = "Deflect: every attack you dodge now restores ##20% » 25%## of your armor.\n\nYour armor is increased by an additional ##20%## for ballistic vests, and your chance to dodge by an additional ##5% » 10%##." .. FOOT,
	menu_deck6_5_short = "Deflect: dodging restores ##20% » 25%## of your armor. Ballistic vests gain ##20%## more armor and ##5% » 10%## more dodge chance.",
	menu_deck6_7_desc = "Counter: after you dodge an attack, you deal ##25%## more damage for ##3## seconds.\n\nYour armor is increased by an additional ##25%## for ballistic vests, and your chance to dodge by an additional ##15% » 20%##." .. FOOT,
	menu_deck6_7_short = "Counter: dodging an attack gives you ##25%## more damage for ##3## seconds. Ballistic vests gain ##25%## more armor and ##15% » 20%## more dodge chance.",
	menu_deck6_9_desc = "Slip: when your ballistic vest breaks, your chance to dodge is increased by ##30%## for ##5## seconds. This can not occur more often than once every ##15## seconds.\n\nYour armor recovery rate is increased by ##10%##." .. COMPLETION,
	menu_deck6_9_short = "Slip: when your ballistic vest breaks, your dodge chance is increased by ##30%## for ##5## seconds. Your armor recovers ##10%## faster.",
	-- Hitman (7.18 rework v2): Contracts; the Contract is tougher, outlined in your player colour
	menu_deck5_1_desc = "Contract: the nearest enemy you can see within ##30m## becomes your Contract and is outlined in your player colour, for you only. Special enemies are picked first; Bulldozers and Captain Winters never. If it isn't dead within ##20## seconds, or someone else kills it, a new one is picked.\n\nYour Contract is tougher: it takes ##20% » 30%## less damage from you and deals ##20% » 30%## more damage to you.\n\nKilling your Contract, with any weapon, restores ##25% » 35%## of your armor and marks your next Contract at once.\n\nYou gain ##5%## more armor." .. FOOT,
	menu_deck5_1_short = "Contract: the nearest enemy you can see within ##30m## is outlined for you. It takes ##20% » 30%## less damage from you and deals ##20% » 30%## more damage to you. Killing it restores ##25% » 35%## of your armor. You gain ##5%## more armor.",
	-- (7.19 rework v3, Geo: "yea this is fine"): dual wielding on cards 3, 5 and 9, light armor on card 7
	menu_deck5_3_desc = "Clean Kill: killing an enemy with a headshot restores ##10%## of your armor, no more than once every ##0.5## seconds.\n\nYour headshots go straight through the toughness of your Contract.\n\nTwin Contracts: while you hold a dual-wielded weapon, you have ##2## Contracts at once. The second one is picked the same way, is just as tough and pays out the same when you kill it. When you put the dual-wielded weapon away, no new second Contract is picked.",
	menu_deck5_3_short = "Clean Kill: headshot kills restore ##10%## of your armor, once every ##0.5## seconds. Your headshots go through your Contract's toughness. Twin Contracts: while you hold a dual-wielded weapon, you have ##2## Contracts at once.",
	menu_deck5_5_desc = "Hit List: every Contract you kill adds ##1## Streak, up to ##5##. Each Streak makes you deal ##5%## more damage and speeds up your armor recovery by ##5%##. After ##15 » 20## seconds without killing a Contract, you lose all your Streaks.\n\nHot Streak: while you hold a dual-wielded weapon, each Streak also makes it fire ##5%## faster." .. FOOT,
	menu_deck5_5_short = "Hit List: every Contract you kill adds ##1## Streak, up to ##5##. Each Streak gives ##5%## more damage and speeds up your armor recovery by ##5%##, for ##15 » 20## seconds. Hot Streak: each Streak also makes your dual-wielded weapon fire ##5%## faster.",
	menu_deck5_7_desc = "Untouchable: killing your Contract makes you unable to take damage for ##1.5 » 2## seconds. This can not occur more often than once every ##15## seconds.\n\nTailored: while you wear the Lightweight Ballistic Vest, your armor is increased by ##40% » 80%##, and the armor this deck gives back is doubled: killing your Contract restores ##50% » 70%## of your armor, Clean Kill restores ##20%## of your armor, and each Streak speeds up your armor recovery by ##10%##.\n\nBlack Tie: while you wear the Two-piece Suit, your chance to dodge is increased by ##20% » 30%##." .. FOOT,
	menu_deck5_7_short = "Untouchable: killing your Contract makes you unable to take damage for ##1.5 » 2## seconds, once every ##15## seconds. Tailored: ##40% » 80%## more armor in the Lightweight Ballistic Vest, and twice the armor back. Black Tie: ##20% » 30%## more dodge in the Two-piece Suit.",
	menu_deck5_9_desc = "Tooth and Claw: your armor will recover ##1.5## seconds after being broken no matter what the situation.\n\nKilling your Contract while your armor is broken brings it back right away.\n\nGun Kata: your dual-wielded weapons reload ##20% » 30%## faster, and every shot of theirs that hits one of your Contracts goes back into the magazine." .. FOOT .. COMPLETION,
	menu_deck5_9_short = "Tooth and Claw: your armor recovers ##1.5## seconds after breaking, no matter what. Killing your Contract while your armor is broken brings it back right away. Gun Kata: your dual-wielded weapons reload ##20% » 30%## faster, and shots that hit a Contract go back into the magazine.",
	-- (7.20 rework standard) Crew Chief v1b: Squad (Cohesion), Orders (Call the Shots, Focus Fire, Confirmed, Pinned Down),
	-- stacking hostages, Chain of Command (bots and converts)
	menu_deck1_1_desc = "You and your crew take ##8%## less damage. While your health is below ##50%##, this damage reduction is doubled for you.\n\nCohesion: your teammates and AI teammates within ##18m## of you are your Squad. For each Squad member, up to ##3##, you take an additional ##5% » 7%## less damage.\n\nNote: Crew perks do not stack." .. FOOT,
	menu_deck1_1_short = "You and your crew take ##8%## less damage. Cohesion: you take ##5% » 7%## less damage for each teammate or AI teammate within ##18m##, up to ##3##.",
	menu_deck1_3_desc = "You and your crew's stamina is increased by ##50%##.\n\nWhile trying to intimidate a law enforcer or a civilian, marking a special enemy, or using \"Inspire\" skill on your teammates, your shout distance is increased by ##25%##.\n\nWhile you are within ##18m## of an enemy that you can see, you take ##8% » 12%## less damage. This lingers for ##5## seconds after you are no longer close to an enemy.\n\nCall the Shots: every ##8 » 6## seconds, you mark the nearest special enemy you can see within ##30m## for your whole crew.\n\nFocus Fire: marked enemies take ##25% » 35%## more damage from your whole crew.\n\nNote: Crew perks do not stack. Teammates get Focus Fire when they or the host have this mod, bots when the host has it." .. FOOT,
	menu_deck1_3_short = "Crew stamina ##50%##, shout distance ##25%##, ##8% » 12%## less damage near enemies. Call the Shots: every ##8 » 6## seconds you mark the nearest special you can see. Focus Fire: marked enemies take ##25% » 35%## more damage.",
	menu_deck1_5_desc = "You and your crew's health is increased by ##10%##. You gain ##10%## more health.\n\nRally: reviving a teammate makes you take ##40% » 50%## less damage for ##6## seconds.\n\nConfirmed: when anyone in your crew kills an enemy you marked, you get ##10% » 15%## of your armor back.\n\nNote: Crew perks do not stack." .. FOOT,
	menu_deck1_5_short = "Crew health ##10%##, ##10%## more for you. Rally: reviving a teammate gives you ##40% » 50%## less damage for ##6## seconds. Confirmed: an enemy you marked dying restores ##10% » 15%## of your armor.",
	menu_deck1_7_desc = "You and your crew's armor is increased by ##5%##. You gain ##5%## more armor.\n\nCohesion now makes you take ##7% » 9%## less damage for each Squad member, and each Squad member speeds up your armor recovery by ##10%##.\n\nPinned Down: marked enemies deal ##20% » 30%## less damage to you.\n\nNote: Crew perks do not stack." .. FOOT,
	menu_deck1_7_short = "Crew armor ##5%##, ##5%## more for you. Cohesion goes up to ##7% » 9%## per Squad member, and each one speeds up your armor recovery by ##10%##. Pinned Down: marked enemies deal ##20% » 30%## less damage to you.",
	menu_deck1_9_desc = "You and your crew will gain ##6%## max health and ##12%## stamina for each hostage up to ##4## times.\n\nYou and your crew will gain ##8% » 12%## damage reduction for having one or more hostages, and another ##4% » 6%## damage reduction for each further hostage, up to ##4## hostages.\n\nIntimidated law enforcers count as hostages for this perk card. Enemies who were converted to fight on your side will provide hostage bonuses from this perk card only to the crew member who converted such enemy.\n\nChain of Command: your AI teammates and the enemies you converted take ##30% » 40%## less damage and deal ##25% » 35%## more damage while they are within ##18m## of you. Enemies you convert also get ##50%## more health.\n\nNote: Crew perks do not stack. Teammates without this mod keep the flat ##8%## damage reduction. Chain of Command needs the host to have this mod." .. FOOT .. COMPLETION,
	menu_deck1_9_short = "Each hostage gives ##6%## health and ##12%## stamina, up to ##4##. ##8% » 12%## less damage with a hostage, ##4% » 6%## more for each further one. Chain of Command: your bots and converted enemies near you are tougher and hit harder.",
	-- (7.20 rework standard) Armorer v1b: named plates, Reactive Plates, Load Bearing; Field Repair and Hold Fast scaled
	menu_deck3_1_desc = "Your armor is increased by ##10%##.\n\nPlate Carrier: your armor is divided into ##2## plates. A single hit can break at most one plate. Armor recovers one plate at a time.\n\nReactive Plates: whenever one of your plates breaks, you deal ##20% » 30%## more damage for ##5## seconds." .. FOOT,
	menu_deck3_1_short = "##10%## more armor. Plate Carrier: your armor is ##2## plates, and a hit breaks at most one. Reactive Plates: a plate breaking gives you ##20% » 30%## more damage for ##5## seconds.",
	menu_deck3_3_desc = "Your armor is increased by an additional ##10%##.\n\nShatter: whenever one of your armor plates breaks, enemies within ##6m## of you are suppressed and have a ##60% » 75%## chance to panic.\n\nLoad Bearing: your armor's penalty to your movement speed is reduced by ##50%##." .. FOOT,
	menu_deck3_3_short = "##10%## more armor. Shatter: breaking a plate suppresses enemies within ##6m##, ##60% » 75%## chance to panic. Load Bearing: your armor's movement speed penalty is halved.",
	menu_deck3_5_desc = "Your armor is increased by an additional ##10%##.\n\nTrauma Plates: your armor is now divided into ##3## plates, and a single hit can remove at most ##75%## of a plate.",
	menu_deck3_5_short = "##10%## more armor. Trauma Plates: your armor is ##3## plates, and a hit takes at most ##75%## of a plate.",
	menu_deck3_7_desc = "Your armor recovers ##20%## faster.\n\nField Repair: every ##5 » 4## seconds, even while taking damage, your current damaged plate is fully restored as long as your armor is not broken.\n\nHold Fast: when your armor breaks, you are immune to health damage for ##2 » 3## seconds. This can not occur more often than once every ##15## seconds." .. FOOT,
	menu_deck3_7_short = "Your armor recovers ##20%## faster. Field Repair: every ##5 » 4## seconds your damaged plate is restored. Hold Fast: when your armor breaks, you are immune to health damage for ##2 » 3## seconds, once every ##15## seconds.",
	menu_deck3_9_desc = "Your armor is increased by an additional ##5%##.\n\nLiquid Armor: your armor is now divided into ##4## plates, and a single hit can remove at most ##50%## of a plate.\n\nYou and your crew's armor recovers ##10%## faster.\n\nNote: Crew perks do not stack." .. COMPLETION,
	menu_deck3_9_short = "##5%## more armor. Liquid Armor: your armor is ##4## plates, and a hit takes at most ##50%## of a plate. You and your crew's armor recovers ##10%## faster.",
	-- (7.20 rework standard) Rogue v1: Blindside, Momentum / Quickdraw, Cutpurse, Riposte, Afterimage
	menu_deck4_1_desc = "Your chance to dodge is increased by ##15% » 20%##.\n\nBlindside: you deal ##25% » 35%## more damage to enemies that are not facing you." .. FOOT,
	menu_deck4_1_short = "Your chance to dodge is increased by ##15% » 20%##. Blindside: ##25% » 35%## more damage to enemies not facing you.",
	menu_deck4_3_desc = "You are ##40%## less likely to be targeted by enemies.\n\nMomentum: every attack you dodge grants you an additional ##5% » 7.5%## chance to dodge for ##6## seconds, stacking up to ##4## times. Dodging again refreshes the duration.\n\nQuickdraw: after you dodge an attack, your reload and weapon swap speeds are increased by ##30%## for ##4## seconds." .. FOOT,
	menu_deck4_3_short = "##40%## less likely to be targeted. Momentum: each dodge gives ##5% » 7.5%## more dodge chance for ##6## seconds, up to ##4## stacks. Quickdraw: ##30%## faster reload and swap for ##4## seconds after a dodge.",
	menu_deck4_5_desc = "Your chance to dodge is increased by an additional ##15%##.\n\nBlindside now makes you deal ##35% » 45%## more damage to enemies that are not facing you.\n\nCutpurse: killing an enemy that is not facing you heals ##3% » 4%## of your health and puts ##3## rounds back into your magazine. This can not occur more often than once every ##0.5## seconds." .. FOOT,
	menu_deck4_5_short = "##15%## more dodge chance. Blindside goes up to ##35% » 45%##. Cutpurse: kills on enemies not facing you heal ##3% » 4%## of your health and put ##3## rounds into your magazine.",
	menu_deck4_7_desc = "Your chance to dodge is increased by an additional ##15%##.\n\nRiposte: after you dodge an attack, every shot you fire within ##2 » 3## seconds is a critical hit." .. FOOT,
	menu_deck4_7_short = "##15%## more dodge chance. Riposte: shots fired within ##2 » 3## seconds of a dodge are critical hits.",
	menu_deck4_9_desc = "Afterimage: dodging ##3## attacks within ##3## seconds makes you invulnerable for ##1.5 » 2## seconds. This can not occur more often than once every ##15## seconds.\n\nYour weapon swapping speed is increased by ##33%##.\n\nYour movement speed is increased by ##10%## and stamina is increased by ##25%##.\n\nYour total chance to dodge can not exceed ##70%##, or ##80%## on Death Sentence." .. FOOT .. COMPLETION,
	menu_deck4_9_short = "Afterimage: dodging ##3## attacks within ##3## seconds makes you invulnerable for ##1.5 » 2## seconds, once every ##15## seconds. Faster weapon swapping, movement speed and stamina.",
	-- Sociopath
	menu_deck9_1_desc = "Frenzy: every melee kill within ##3## seconds of your last melee kill adds ##1## Frenzy stack, up to ##5 » 6##. Each stack makes you take ##3%## less damage. After ##3## seconds without a melee kill, you lose ##1## stack every second. A gun kill takes all your stacks away.\n\nTension: melee kills restore ##20## armor, the same whatever armor you wear, no more than once every ##1## second." .. FOOT,
	menu_deck9_1_short = "Frenzy: chained melee kills stack up to ##5 » 6## times, each ##3%## less damage taken; a gun kill ends it. Tension: melee kills restore ##20## armor, once a second.",
	menu_deck9_3_desc = "You take ##15%## less damage. You gain ##10%## more armor.\n\nHolding your melee weapon builds up damage resistance by ##10%## every second, up to ##15%##. After you stop holding it, this bonus is kept for ##2## seconds and then fades.\n\nThick Skin: any single hit that would take more than ##20%## of your health deals ##40% » 50%## less damage." .. FOOT,
	menu_deck9_3_short = "##15%## less damage and ##10%## more armor. Holding melee builds up to ##15%## damage resistance. Thick Skin: big hits deal ##40% » 50%## less damage.",
	menu_deck9_5_desc = "Your damage reduction from this perk deck is increased to ##25%##.\n\nClean Hit: killing an enemy with a melee weapon adds ##2## Frenzy stacks instead of ##1## and heals you for ##10% » 15%## of your health, no more than once every ##1## second.\n\nCombo: every melee kill adds ##1## Combo, up to ##10##, and every enemy a cleave kills counts. Each Combo makes your melee weapon charge and swing ##10%## faster, up to ##50%##, and makes you take ##2%## less damage, up to ##20%##. Firing a gun, a gun kill or going ##5## seconds without a melee kill ends the Combo." .. FOOT,
	menu_deck9_5_short = "Damage reduction goes up to ##25%##. Clean Hit: melee kills heal ##10% » 15%##, once a second. Combo: each melee kill in a row makes your melee up to ##50%## faster and you take up to ##20%## less damage.",
	menu_deck9_7_desc = "You gain an additional ##10%## more armor.\n\nTension now restores ##30## armor on melee kills within ##18m##.\n\nHardened: every ##10## seconds you spend fighting with an enemy within ##18m##, you take ##5%## less damage, up to ##15%##. It resets after ##10## seconds without an enemy nearby.",
	menu_deck9_7_short = "##10%## more armor. Tension restores ##30## armor on melee kills within ##18m##. Hardened: up to ##15%## less damage the longer you fight.",
	menu_deck9_9_desc = "Your damage reduction from this perk deck is increased to ##30%##.\n\nPanic: killing an enemy within ##18m## of you has a ##75%## chance to spread panic among non-special enemies within ##25m##, no more than once every ##1## second.\n\nDread: you deal ##25% » 35%## more damage to panicking enemies, and killing one with your melee weapon adds ##1## extra Frenzy stack.\n\nMassacre: at ##8 » 6## Combo, every melee hit is a critical hit until the Combo ends." .. FOOT .. COMPLETION,
	menu_deck9_9_short = "Damage reduction goes up to ##30%##. Kills nearby can spread panic. Dread: ##25% » 35%## more damage to panicking enemies. Massacre: at ##8 » 6## Combo, melee hits are critical."
}
for id, text in pairs(B.rework_text) do B.full_text[id] = text end

local function short_map()
	if B._short then return B._short end
	local specs = tweak_data and tweak_data.skilltree and tweak_data.skilltree.specializations
	if not specs then return {} end
	local map = {}
	for _, deck in pairs(specs) do
		if type(deck) == "table" then
			for _, card in ipairs(deck) do
				if type(card) == "table" and card.desc_id and card.short_id and card.short_id ~= card.desc_id
					and (B.desc_lines[card.desc_id] or B.always_lines[card.desc_id]) then
					map[card.short_id] = card.desc_id
				end
			end
		end
	end
	B._short = map
	return map
end

-- (7.19, Geo: "the completion bonus should always be last") the Deck Completion Bonus paragraph moves to the end of
-- any text that has something after it (our "» Scales with difficulty" footnote, Gilza's own notes)
function B.completion_last(text)
	if type(text) ~= "string" then return text end
	local a = string.find(text, "\n\nDeck Completion Bonus", 1, true)
	if not a then return text end
	local b = string.find(text, "\n\n", a + 2, true)
	if not b then return text end
	return string.sub(text, 1, a - 1) .. string.sub(text, b) .. string.sub(text, a, b - 1)
end

local function decorate(id, text)
	if type(text) ~= "string" or type(id) ~= "string" then return text end
	if id == "bm_menu_armor_pickup_desc" and B.AMMO_PICKUP_MUL then
		return (string.gsub(text, "([%d%.]+)%%", function(n)
			local v = tonumber(n)
			return v and (math.floor(v * B.AMMO_PICKUP_MUL + 0.5) .. "%") or (n .. "%")
		end, 1))
	end
	if B.name_text and B.name_text[id] then
		return B.name_text[id]
	end
	if B.full_text[id] then
		text = B.full_text[id]
	end
	local reps = B.replacements[id]
	if reps then
		for _, r in ipairs(reps) do
			local s, e = string.find(text, r[1], 1, true)
			if s then
				text = string.sub(text, 1, s - 1) .. r[2] .. string.sub(text, e + 1)
			end
		end
	end
	local key = (B.desc_lines[id] or B.always_lines[id]) and id or short_map()[id]
	if not key then return text end
	local extra = ""
	local always = B.always_lines[key]
	if always and not string.find(text, always, 1, true) then
		extra = extra .. always
	end
	local line = B.desc_lines[key]
	if line and not string.find(text, line, 1, true) then
		extra = extra .. DS .. line
	end
	if extra == "" then return text end
	local cut = string.find(text, "\n\nDeck Completion Bonus", 1, true)
	if cut then
		return string.sub(text, 1, cut - 1) .. extra .. string.sub(text, cut)
	end
	return text .. extra
end

function B.decorate(id, text)
	return B.completion_last(decorate(id, text))
end

function B.wrap_text()
	if LocalizationManager.text == B.text_wrapper then return end
	local inner = LocalizationManager.text
	B.text_wrapper = function(self, id, ...)
		return B.decorate(id, inner(self, id, ...))
	end
	LocalizationManager.text = B.text_wrapper
end

B.wrap_text()
Hooks:Add("MenuUpdate", "GilzaDSBuffs_keep_text_hook", function() pcall(B.wrap_text) end)
