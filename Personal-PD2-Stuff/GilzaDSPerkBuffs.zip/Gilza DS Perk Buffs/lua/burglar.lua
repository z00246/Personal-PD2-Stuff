GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

-- difficulty scaling (shared with buffs.lua): t = 0 up to Overkill, 1/3 Mayhem, 2/3 Death Wish, 1 Death Sentence
if not B.diff_t then
	B.DIFF_T = { easy_wish = 1 / 3, overkill_290 = 2 / 3, sm_wish = 1 }
	function B.diff_t()
		local gs = Global and Global.game_settings
		return gs and B.DIFF_T[gs.difficulty] or 0
	end
	function B.sc(base, ds) return base + (ds - base) * B.diff_t() end
	function B.sci(base, ds) return math.floor(base + (ds - base) * B.diff_t() + 0.5) end
end

-- Burglar (7.00 rework, Geo 2026-10-24: stealth first; no armor, survives in loud like a ghost)
--  card 1 Ghost (loud: enemies past 15 m / 8 m crouched can't see or target you; unsuppressed shots give you away)
--         Shadow (stealth: slower detection, suspicion fades faster while nobody sees you); no armor
--  card 3 Guard Sense (crouch: nearby guards / cameras, or Snipers / Cloakers / Tasers in loud, outlined)
--         Unseen Mend (health back while no enemy can see you)
--  card 5 Silent Takedown (unaware guards killed by melee don't set off pagers, 2 per heist); melee and suppressed
--         shots don't make enemies notice you; more dodge; concealment per silenced weapon
--  card 7 Second Chance (stealth: suspicion drops to half before you're spotted, once a minute)
--         Slip Away (loud: losing health hides you from enemies past 2 m for a few seconds)
--  card 9 Fade Out (a hit that would down you leaves you at 1 health and hidden, regenerating)
--         Wraith (dodging hides you from enemies past 5 m for 2 s); suppressed weapons hit harder
-- *_ds values are the Death Sentence end of the difficulty scale (B.sc).
B.BURGLAR = {
	deck = 7,
	ghost = 1500, ghost_ds = 1200,              -- card 1 Ghost range (cm)
	ghost_crouch = 800, ghost_crouch_ds = 600,
	exposed_time = 2,                           -- an unsuppressed shot gives you away
	sight_range = 3000,                         -- line-of-sight checks for Unseen Mend
	detect = 0.75, detect_crouch = 0.5,         -- card 1 Shadow: detection speed
	stealth_fade = 0.125,                       -- extra suspicion drained per second while nobody sees you (vanilla 0.125: 2x)
	sense_range = 1500, sense_range_loud = 2000, -- card 3 Guard Sense
	mend = 0.015, mend_ds = 0.02,               -- card 3 Unseen Mend: share of max health per second
	takedowns = 2,                              -- card 5 Silent Takedown, per heist
	dodge_5 = 0.05, dodge_5_ds = 0.10,          -- card 5: on top of the game's +5% (so +10%, Death Sentence +15%)
	silencer_conceal = 4,                       -- card 5: concealment per silenced weapon
	second_at = 0.75, second_to = 0.5, second_cd = 60,   -- card 7 Second Chance
	slip_range = 200, slip_time = 3, slip_time_ds = 4, slip_cd = 15,   -- card 7 Slip Away
	fade_range = 200, fade_time = 4, fade_heal = 0.25,   -- card 9 Fade Out
	fade_cd = 90, fade_cd_ds = 60, fade_invuln = 1,
	wraith_range = 500, wraith_time = 2, wraith_cd = 6,   -- card 9 Wraith
	silenced_dmg = 0.15, silenced_dmg_ds = 0.25,          -- card 9
	close_range = 500,                          -- targeting.lua: enemies this close never ignore a Burglar by chance
	-- (7.24) Clover's signature (card 9, only as Clover): Smash and Grab - while Ghost hides you, bags slow you down
	-- half as much; in stealth you bag loot 15% faster
	sig_carry = 0.5, sig_bag = 0.85
}
B.NET_ID = B.NET_ID or "GilzaDSBuffs"
local C = B.BURGLAR

-- a line in the BLT log the first times a feature does something (buffs.lua)
local function live(key, ...) if B.live then B.live("burglar " .. key, ...) end end

-- the lobby's peers; an empty list outside a real network session (menus)
local function session_peers()
	local session = managers.network and managers.network:session()
	local peers = type(session) == "table" and type(session.peers) == "function" and session:peers()
	return type(peers) == "table" and peers or {}
end

function B.burglar_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == C.deck) then
		return 0
	end
	return st:get_specialization_value(C.deck, "tiers", "current_tier") or 0
end

local function peer_tier(peer)
	if not peer then return 0 end
	local session = managers.network and managers.network:session()
	if session and peer == session:local_peer() then
		return B.burglar_tier()
	end
	local skills = peer.unpacked_skills and peer:unpacked_skills()
	local spec = skills and skills.specializations
	if spec and tonumber(spec[1]) == C.deck then
		return tonumber(spec[2]) or 0
	end
	return 0
end
B.burglar_peer_tier = peer_tier

-- Burglar card of a player unit (local or husk), 0 if not a Burglar
function B.burglar_unit_tier(unit)
	if not alive(unit) or not unit:base() then return 0 end
	if unit:base().is_local_player then return B.burglar_tier() end
	local session = managers.network and managers.network:session()
	local peer = session and session:peer_by_unit(unit)
	return peer and peer_tier(peer) or 0
end

-- is this player unit (local or husk) on the Burglar deck? (used by PD:TH Police Tactics' snipers too)
function B.is_burglar_unit(unit)
	return B.burglar_unit_tier(unit) >= 1
end

local function peer_by_id(id)
	local session = managers.network and managers.network:session()
	return session and id and session:peer(id)
end

local function weapons_hot()
	local state = managers.groupai and managers.groupai:state()
	return state and state:enemy_weapons_hot() and true or false
end

local function whisper()
	local state = managers.groupai and managers.groupai:state()
	return state and state:whisper_mode() and true or false
end

local function game_t()
	return TimerManager:game():time()
end

local function play_perk_sound()
	local unit = managers.player and managers.player:player_unit()
	if alive(unit) and unit:sound() then unit:sound():play("perkdeck_activate", nil, false) end
end

-- host side: Ghost ranges (unit key -> { r = cm, t = game time }), Silent Takedowns used (peer id -> n),
-- Second Chance cooldowns (unit key -> game time)
B.burg_ghost = B.burg_ghost or {}
B.burg_takedowns = B.burg_takedowns or {}
B.burg_second_cd = B.burg_second_cd or {}

-- host: how far away a Burglar unit stops being seen (0 = seen normally). Read by targeting.lua.
function B.burglar_ghost_of(unit)
	local g = alive(unit) and B.burg_ghost[unit:key()]
	if not g then return 0 end
	if game_t() - g.t > 6 then
		B.burg_ghost[unit:key()] = nil
		return 0
	end
	return g.r or 0
end

-- local: your own Ghost range right now (0 = seen normally: stealth, exposed, not a Burglar)
function B.burglar_ghost_range()
	if B.burglar_tier() < 1 or not weapons_hot() then return 0 end
	local now = Application:time()
	if now < (B.burg_exposed_until or 0) then return 0 end
	local unit = managers.player and managers.player:player_unit()
	if not alive(unit) then return 0 end
	local mov = unit:movement()
	local crouch = mov and mov.crouching and mov:crouching()
	local r = crouch and B.sc(C.ghost_crouch, C.ghost_crouch_ds) or B.sc(C.ghost, C.ghost_ds)
	if now < (B.burg_slip_until or 0) or now < (B.burg_fade_until or 0) then r = math.min(r, C.slip_range) end
	if now < (B.burg_wraith_until or 0) then r = math.min(r, C.wraith_range) end
	return math.floor(r + 0.5)
end

-- local: Slip Away, Fade Out or Wraith running (screen haze in burglar_fx.lua)
function B.burglar_vanished()
	if B.burglar_tier() < 1 then return false end
	local now = Application:time()
	if now < (B.burg_exposed_until or 0) then return false end
	return now < (B.burg_slip_until or 0) or now < (B.burg_fade_until or 0) or now < (B.burg_wraith_until or 0)
end

-- the ability slot (Geo HUD) / buff (PocoHud): state, time left, total
function B.burglar_slot()
	local now = Application:time()
	if now < (B.burg_fade_until or 0) then return "active", B.burg_fade_until - now, C.fade_time end
	if now < (B.burg_slip_until or 0) then return "active", B.burg_slip_until - now, B.burg_slip_total or C.slip_time end
	if now < (B.burg_wraith_until or 0) then return "active", B.burg_wraith_until - now, C.wraith_time end
	if weapons_hot() then
		if now < (B.burg_exposed_until or 0) then return "cooldown", B.burg_exposed_until - now, C.exposed_time end
		return "active"
	end
	if B.burglar_tier() >= 7 and now < (B.burg_second_ready or 0) then
		return "cooldown", B.burg_second_ready - now, C.second_cd
	end
	return "ready"
end

if script == "lib/managers/playermanager" then
	------------------------------------------------------------------ Ghost: tell the host your range
	local function sync_ghost(now)
		local r = B.burglar_ghost_range()
		if r == B._burg_sent_r and (r == 0 or now < (B._burg_sent_t or 0)) then return end
		B._burg_sent_r, B._burg_sent_t = r, now + 2
		if r > 0 then live("ghost", "enemies further than %.1f m can't see you", r / 100) end
		local unit = managers.player:player_unit()
		if Network:is_server() then
			if alive(unit) then
				B.burg_ghost[unit:key()] = r > 0 and { r = r, t = game_t() } or nil
			end
		elseif LuaNetworking and managers.network and managers.network:session() then
			pcall(LuaNetworking.SendToPeer, LuaNetworking, 1, B.NET_ID, "bghost:" .. r)
		end
	end

	------------------------------------------------------------------ card 3 Unseen Mend
	local function is_cloaker(unit)
		local base = unit:base()
		return base and base.has_tag and base:has_tag("spooc") or false
	end

	local function seen_by_enemy(unit)
		local r = B.burglar_ghost_range()
		local mask = managers.slot:get_mask("AI_visibility")
		local head = unit:movement():m_head_pos()
		for _, data in pairs(managers.enemy:all_enemies() or {}) do
			local e = data.unit
			local edmg = alive(e) and e:character_damage()
			if edmg and not edmg:dead() then
				local brain = e:brain()
				if not (brain and brain.is_hostage and brain:is_hostage()) then
					local eh = e:movement() and e:movement():m_head_pos()
					local lim = C.sight_range
					if r > 0 and not is_cloaker(e) then lim = math.min(r, lim) end
					if eh and mvector3.distance_sq(eh, head) < lim * lim then
						if not World:raycast("ray", eh, head, "slot_mask", mask, "ray_type", "ai_vision", "report") then
							return true
						end
					end
				end
			end
		end
		return false
	end

	------------------------------------------------------------------ card 3 Guard Sense
	local SENSE_COLOR = Vector3 and Vector3(0.55, 0.8, 1) or nil
	local function sense_types()
		local types = ContourExt and ContourExt._types
		if not types then return false end
		if not types.gdsb_sense then
			types.gdsb_sense = { priority = 7, material_swap_required = true, color = SENSE_COLOR }
			types.gdsb_sense_unit = { priority = 7, color = SENSE_COLOR }
		end
		return true
	end

	B._sense = B._sense or {}
	local function sense_update(unit)
		local want = {}
		local tier = B.burglar_tier()
		local mov = alive(unit) and unit:movement()
		if tier >= 3 and mov and mov.crouching and mov:crouching() and sense_types() then
			local pos = unit:position()
			local stealth = whisper()
			local range = stealth and C.sense_range or C.sense_range_loud
			local r2 = range * range
			for _, data in pairs(managers.enemy:all_enemies() or {}) do
				local e = data.unit
				local edmg = alive(e) and e:character_damage()
				if edmg and not edmg:dead() and mvector3.distance_sq(e:position(), pos) <= r2 then
					local ok = stealth
					if not stealth then
						local base = e:base()
						ok = base and base.has_tag and (base:has_tag("sniper") or base:has_tag("spooc") or base:has_tag("taser")) or false
					end
					if ok then want[e:key()] = { unit = e, kind = "gdsb_sense" } end
				end
			end
			if stealth then
				for _, cam in ipairs(SecurityCamera and SecurityCamera.cameras or {}) do
					if alive(cam) and mvector3.distance_sq(cam:position(), pos) <= r2 then
						want[cam:key()] = { unit = cam, kind = "gdsb_sense_unit" }
					end
				end
			end
		end
		for key, e in pairs(B._sense) do
			if not want[key] then
				local ce = alive(e.unit) and e.unit:contour()
				if ce then pcall(ce.remove, ce, e.kind, false) end
				B._sense[key] = nil
			end
		end
		for key, e in pairs(want) do
			if not B._sense[key] then
				local ce = e.unit:contour()
				local ok, err = false, "no contour extension"
				if ce then ok, err = pcall(ce.add, ce, e.kind, false) end
				if ok then
					B._sense[key] = e
					live("guard sense", "outlined %s", e.kind == "gdsb_sense_unit" and "a camera" or "an enemy")
				else
					live("guard sense failed", "couldn't outline: %s", tostring(err))
				end
			end
		end
	end

	------------------------------------------------------------------ host: Shadow, suspicion fade, Second Chance
	local function set_base_mul(unit, want)
		local base = unit:base()
		if not (base and base.set_suspicion_multiplier and base.set_detection_multiplier) then return end
		if base._gdsb_burg_mul == want then return end
		base._gdsb_burg_mul = want
		base:set_suspicion_multiplier("gdsb_burglar", want)
		base:set_detection_multiplier("gdsb_burglar", want)
		if want < 1 then
			-- what the game made of it (its own detection / suspicion settings on the player)
			local ds, ss = base._detection_settings, base._suspicion_settings
			live("shadow", "detection x%.2f set; the game's detection delay x%s, suspicion buildup x%s", want,
				tostring(type(ds) == "table" and ds.delay_mul), tostring(type(ss) == "table" and ss.buildup_mul))
		end
	end

	-- every Burglar in the lobby: { unit, key, tier, peer_id, crouched }
	local function burglars()
		local list = {}
		local me = managers.player:player_unit()
		if alive(me) then
			local tier = B.burglar_tier()
			local mov = me:movement()
			list[#list + 1] = { unit = me, key = me:key(), tier = tier, local_player = true,
				crouched = tier >= 1 and mov and mov:crouching() or false }
		end
		for _, peer in pairs(session_peers()) do
			local u = peer:unit()
			if alive(u) then
				local mov = u:movement()
				list[#list + 1] = { unit = u, key = u:key(), tier = peer_tier(peer), peer_id = peer:id(),
					crouched = mov and (mov._pose_code == 2 or (u:anim_data() and u:anim_data().crouch)) or false }
			end
		end
		return list
	end

	local function update_host(step)
		if not Network:is_server() then return end
		local stealth = whisper()
		local list = burglars()
		for _, bg in ipairs(list) do
			local want = 1
			if stealth and bg.tier >= 1 then want = bg.crouched and C.detect_crouch or C.detect end
			set_base_mul(bg.unit, want)
		end
		if stealth then
			-- Shadow: suspicion of a Burglar fades twice as fast while nobody can see them
			for _, bg in ipairs(list) do
				if bg.tier >= 1 then
					local atts, seen = {}, false
					local function gather(units)
						for _, u_data in pairs(units or {}) do
							local brain = alive(u_data.unit) and u_data.unit:brain()
							local ld = brain and brain._logic_data
							local att = ld and ld.detected_attention_objects and ld.detected_attention_objects[bg.key]
							if att then
								if att.identified then
									seen = true
								elseif att.notice_progress then
									if att._gdsb_np and att.notice_progress > att._gdsb_np then seen = true end
									atts[#atts + 1] = att
								end
							end
						end
					end
					gather(managers.enemy:all_enemies())
					gather(managers.enemy:all_civilians())
					for _, att in ipairs(atts) do
						local np = att.notice_progress
						if not seen and att._gdsb_np and np < att._gdsb_np then
							np = math.max(0.001, np - C.stealth_fade * step)
							att.notice_progress = np
							live("shadow fade", "suspicion fading faster while nobody sees you")
						end
						att._gdsb_np = np
					end
				end
			end
		end
		local now = game_t()
		for key, g in pairs(B.burg_ghost) do
			if now - g.t > 6 then B.burg_ghost[key] = nil end
		end
	end

	local function notify_second(bg)
		if bg.local_player then
			B.burg_second_ready = Application:time() + C.second_cd
			play_perk_sound()
		elseif bg.peer_id and LuaNetworking then
			pcall(LuaNetworking.SendToPeer, LuaNetworking, bg.peer_id, B.NET_ID, "bsc:" .. C.second_cd)
		end
	end

	local function second_chance()
		if not (Network:is_server() and whisper()) then return end
		local now = game_t()
		for _, bg in ipairs(burglars()) do
			if bg.tier >= 7 and now >= (B.burg_second_cd[bg.key] or 0) then
				local hit = false
				local function scan(units)
					for _, u_data in pairs(units or {}) do
						local brain = alive(u_data.unit) and u_data.unit:brain()
						local ld = brain and brain._logic_data
						local att = ld and ld.detected_attention_objects and ld.detected_attention_objects[bg.key]
						local np = att and not att.identified and att.notice_progress
						if np and np >= C.second_at then
							att.notice_progress = C.second_to
							att._gdsb_np = C.second_to
							hit = true
						end
					end
				end
				scan(managers.enemy:all_enemies())
				scan(managers.enemy:all_civilians())
				if hit then
					B.burg_second_cd[bg.key] = now + C.second_cd
					notify_second(bg)
					live("second chance", "suspicion on %s knocked back to %d%%", bg.local_player and "you" or ("player " .. tostring(bg.peer_id)), C.second_to * 100)
				end
			end
		end
	end

	------------------------------------------------------------------ the loop
	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_burglar_update", function(t, dt)
		local now = Application:time()
		local last = B._burg_last or now
		B._burg_last = now
		local step = math.min(math.max(now - last, 0), 0.5)
		local unit = managers.player and managers.player:player_unit()
		local tier = B.burglar_tier()
		local ok, err = pcall(function()
			if tier >= 1 or B._burg_sent_r ~= 0 then sync_ghost(now) end
			local dmg = alive(unit) and unit:character_damage()
			local can_heal = dmg and not dmg:dead() and not dmg:need_revive()
			-- card 9 Fade Out: 25% of your health back over its 4 seconds
			if can_heal and (B.burg_fade_heal or 0) > 0 and now < (B.burg_fade_until or 0) + 0.25 then
				local amount = math.min(step * C.fade_heal / C.fade_time, B.burg_fade_heal)
				B.burg_fade_heal = B.burg_fade_heal - amount
				B._burg_fade_acc = (B._burg_fade_acc or 0) + amount
				if B._burg_fade_acc >= 0.005 or B.burg_fade_heal <= 0 then
					dmg:restore_health(B._burg_fade_acc, false)
					B._burg_fade_acc = 0
					live("fade out heal", "healing back during Fade Out")
				end
			elseif now >= (B.burg_fade_until or 0) + 0.25 then
				B.burg_fade_heal = 0
			end
			-- card 3 Unseen Mend and Guard Sense (a few checks a second)
			if now >= (B._burg_look_next or 0) then
				B._burg_look_next = now + 0.25
				B._burg_unseen = tier >= 3 and can_heal and not seen_by_enemy(unit) or false
				sense_update(unit)
			end
			if B._burg_unseen and can_heal then
				B._burg_mend = (B._burg_mend or 0) + step * B.sc(C.mend, C.mend_ds)
				if B._burg_mend >= 0.005 then
					dmg:restore_health(B._burg_mend, false)
					B._burg_mend = 0
					live("unseen mend", "healing %.1f%% a second while no enemy sees you", B.sc(C.mend, C.mend_ds) * 100)
				end
			end
		end)
		if not ok and not B._burg_err then
			B._burg_err = true
			log("[Gilza DS Perk Buffs] Burglar update error: " .. tostring(err))
		end
		local ok2, err2 = pcall(second_chance)
		if not ok2 and not B._burg_err2 then
			B._burg_err2 = true
			log("[Gilza DS Perk Buffs] Burglar Second Chance error: " .. tostring(err2))
		end
		if now >= (B._burg_host_next or 0) then
			B._burg_host_next = now + 0.2
			local ok3, err3 = pcall(update_host, 0.2)
			if not ok3 and not B._burg_err3 then
				B._burg_err3 = true
				log("[Gilza DS Perk Buffs] Burglar host update error: " .. tostring(err3))
			end
		end
	end)

	------------------------------------------------------------------ card 5: more dodge
	local orig_dodge = PlayerManager.skill_dodge_chance
	function PlayerManager:skill_dodge_chance(...)
		local chance = orig_dodge(self, ...)
		if type(chance) ~= "number" then return chance end
		local ok, tier = pcall(B.burglar_tier)
		if ok and tier >= 5 then
			chance = chance + C.dodge_5 + B.sc(0, C.dodge_5_ds - C.dodge_5)
			live("dodge", "+%d%% dodge from card 5 (dodge chance now %d%%)", (C.dodge_5 + B.sc(0, C.dodge_5_ds - C.dodge_5)) * 100, chance * 100)
		end
		return chance
	end

	------------------------------------------------------------------ events
	-- an unsuppressed shot gives you away for a moment
	function B.burglar_on_fire(silenced)
		if silenced or B.burglar_tier() < 1 then return end
		B.burg_exposed_until = Application:time() + C.exposed_time
		if weapons_hot() then live("exposed", "an unsuppressed shot gave you away for %ds", C.exposed_time) end
	end

	-- card 7 Slip Away: losing health in loud
	function B.burglar_on_health_loss()
		if B.burglar_tier() < 7 or not weapons_hot() then return end
		local now = Application:time()
		if now < (B.burg_slip_ready or 0) then return end
		B.burg_slip_ready = now + C.slip_cd
		B.burg_slip_total = B.sc(C.slip_time, C.slip_time_ds)
		B.burg_slip_until = now + B.burg_slip_total
		play_perk_sound()
		live("slip away", "losing health hid you past %d m for %.1f s", C.slip_range / 100, B.burg_slip_total)
	end

	-- card 9 Wraith: dodging in loud
	function B.burglar_on_dodge()
		if B.burglar_tier() < 1 then return end
		live("dodged", "the game reported a dodge")
		if B.burglar_tier() < 9 or not weapons_hot() then return end
		local now = Application:time()
		if now < (B.burg_wraith_ready or 0) then return end
		B.burg_wraith_ready = now + C.wraith_cd
		B.burg_wraith_until = now + C.wraith_time
		live("wraith", "a dodge hid you past %d m for %ds", C.wraith_range / 100, C.wraith_time)
	end

	Hooks:PostHook(PlayerManager, "init", "GilzaDSBuffs_burglar_dodge", function(self)
		self:register_message(Message.OnPlayerDodge, "GilzaDSBuffs_burglar_dodge", function()
			pcall(B.burglar_on_dodge)
		end)
	end)

	------------------------------------------------------------------ network
	if LuaNetworking and LuaNetworking.AddReceiveHook then
		LuaNetworking:AddReceiveHook(B.NET_ID, "GilzaDSBuffs_burglar_net", function(data, sender) pcall(function()
			if type(data) ~= "string" then return end
			local kind, value = string.match(data, "^(b%a+):([%d%.]+)$")
			if not kind then return end
			value = tonumber(value) or 0
			if kind == "bsc" then
				-- the host used your Second Chance
				B.burg_second_ready = Application:time() + math.min(value, C.second_cd)
				play_perk_sound()
				live("second chance heard", "the host used your Second Chance")
				return
			elseif kind == "btd" then
				-- the host used one of your Silent Takedowns
				B.burg_takedowns_left = value
				live("takedown heard", "the host used a Silent Takedown, %d left", value)
				return
			end
			if kind ~= "bghost" or not Network:is_server() then return end
			local peer = peer_by_id(tonumber(sender))
			local unit = peer and peer:unit()
			if not alive(unit) or peer_tier(peer) < 1 then return end
			B.burg_ghost[unit:key()] = value > 0 and { r = math.min(value, C.ghost), t = game_t() } or nil
			if value > 0 then live("ghost heard", "player %d: enemies further than %.1f m can't see them", peer:id(), math.min(value, C.ghost) / 100) end
		end) end)
	end

	-- host: use one of this Burglar's Silent Takedowns (2 per heist)
	function B.burglar_use_takedown(att)
		local session = managers.network and managers.network:session()
		if not (session and alive(att)) then return false end
		local peer = att:base() and att:base().is_local_player and session:local_peer() or session:peer_by_unit(att)
		if not peer or peer_tier(peer) < 5 then return false end
		local id = peer:id()
		local used = B.burg_takedowns[id] or 0
		if used >= C.takedowns then return false end
		B.burg_takedowns[id] = used + 1
		if peer == session:local_peer() then
			B.burg_takedowns_left = C.takedowns - used - 1
			play_perk_sound()
		elseif LuaNetworking then
			pcall(LuaNetworking.SendToPeer, LuaNetworking, id, B.NET_ID, "btd:" .. (C.takedowns - used - 1))
		end
		live("silent takedown", "a guard's pager was skipped (player %d, %d left)", id, C.takedowns - used - 1)
		return true
	end

	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_burglar_reset", function()
		local session = managers.network and managers.network:session()
		if B._burg_session ~= session then
			B._burg_session = session
			B.burg_ghost, B.burg_takedowns, B.burg_second_cd = {}, {}, {}
			B.burg_exposed_until, B.burg_slip_until, B.burg_slip_ready = nil, nil, nil
			B.burg_fade_until, B.burg_fade_ready, B.burg_fade_heal = nil, nil, 0
			B.burg_wraith_until, B.burg_wraith_ready, B.burg_second_ready = nil, nil, nil
			B.burg_takedowns_left, B._burg_sent_r, B._burg_unseen = nil, nil, false
			B._sense = {}
		end
	end)

elseif script == "lib/units/beings/player/playerdamage" then
	-- Burglar wears no armor at all
	local orig_max_armor = PlayerDamage._max_armor
	function PlayerDamage:_max_armor(...)
		-- the real deck only (Copycat's Mimicry copies cards 1 and 3 but keeps its armor)
		local st = managers.skilltree
		if st and st:get_specialization_value("current_specialization") == C.deck then
			live("no armor", "max armor is 0")
			return 0
		end
		return orig_max_armor(self, ...)
	end

	-- card 7 Slip Away: when you lose health
	Hooks:PreHook(PlayerDamage, "_calc_health_damage", "GilzaDSBuffs_burglar_hp_pre", function(self)
		B._burg_pre_hp = self:get_real_health()
	end)
	Hooks:PostHook(PlayerDamage, "_calc_health_damage", "GilzaDSBuffs_burglar_hp_post", function(self)
		local before = B._burg_pre_hp
		B._burg_pre_hp = nil
		if before and self:get_real_health() < before and B.burglar_on_health_loss then
			pcall(B.burglar_on_health_loss)
		end
	end)

	-- card 9 Fade Out: a hit that would down you leaves you at 1 health instead
	local orig_bleed = PlayerDamage._check_bleed_out
	function PlayerDamage:_check_bleed_out(...)
		local ok, saved = pcall(function()
			if self:get_real_health() > 0 or self._check_berserker_done or self._bleed_out then return false end
			if B.burglar_tier() < 9 then return false end
			local now = Application:time()
			if now < (B.burg_fade_ready or 0) then return false end
			if self._unit:movement():zipline_unit() then return false end
			B.burg_fade_ready = now + B.sc(C.fade_cd, C.fade_cd_ds)
			B.burg_fade_until = now + C.fade_time
			B.burg_fade_heal = C.fade_heal
			self:change_health(0.1)
			if self.Gilza_add_damage_invuln_timer then
				self:Gilza_add_damage_invuln_timer(C.fade_invuln)
			end
			if self._unit:sound() then
				self._unit:sound():play("perkdeck_activate", nil, false)
			end
			live("fade out", "a hit that would have downed you left you at 1 health, hidden for %ds", C.fade_time)
			return true
		end)
		if ok and saved then return end
		if not ok and not B._burg_fade_err then
			B._burg_fade_err = true
			log("[Gilza DS Perk Buffs] Burglar Fade Out error: " .. tostring(saved))
		end
		return orig_bleed(self, ...)
	end

elseif script == "lib/units/enemies/cop/copdamage" then
	-- card 9: suppressed weapons hit harder
	Hooks:PreHook(CopDamage, "damage_bullet", "GilzaDSBuffs_burglar_bullet", function(self, attack_data)
		pcall(function()
			if not (attack_data and type(attack_data.damage) == "number") then return end
			local player = managers.player and managers.player:player_unit()
			if not (alive(player) and attack_data.attacker_unit == player) then return end
			if B.burglar_tier() < 9 then return end
			local wpn = attack_data.weapon_unit
			local base = alive(wpn) and wpn:base()
			if base and base.got_silencer and base:got_silencer() then
				attack_data.damage = attack_data.damage * (1 + B.sc(C.silenced_dmg, C.silenced_dmg_ds))
				live("silenced damage", "suppressed gun damage x%.2f", 1 + B.sc(C.silenced_dmg, C.silenced_dmg_ds))
			end
		end)
	end)

	-- card 5 Silent Takedown (host): remember a melee hit on an unaware guard with a pager; copbrain.lua's
	-- begin_alarm_pager skips the pager if that hit killed him
	Hooks:PreHook(CopDamage, "damage_melee", "GilzaDSBuffs_burglar_takedown", function(self, attack_data)
		self._gdsb_td = nil
		pcall(function()
			if self._dead or not Network:is_server() or not whisper() then return end
			local att = attack_data and attack_data.attacker_unit
			if B.burglar_unit_tier(att) < 5 then return end
			local ud = self._unit:unit_data()
			if not (ud and ud.has_alarm_pager) then return end
			local brain = self._unit:brain()
			local ld = brain and brain._logic_data
			if not ld or ld.cool == false then return end
			local det = ld.detected_attention_objects and ld.detected_attention_objects[att:key()]
			if det and det.identified then return end
			self._gdsb_td = att
			live("takedown mark", "melee hit on an unaware guard who has a pager")
		end)
	end)
	Hooks:PostHook(CopDamage, "damage_melee", "GilzaDSBuffs_burglar_takedown_post", function(self)
		if not self._dead then self._gdsb_td = nil end
	end)

elseif script == "lib/units/enemies/cop/copbrain" then
	local orig_pager = CopBrain.begin_alarm_pager
	if orig_pager then
		function CopBrain:begin_alarm_pager(reset, ...)
			if not reset and not self._alarm_pager_has_run then
				local ok, skip = pcall(function()
					local dmg = self._unit:character_damage()
					local att = dmg and dmg._gdsb_td
					if not (att and dmg._dead) then return false end
					dmg._gdsb_td = nil
					return B.burglar_use_takedown and B.burglar_use_takedown(att) or false
				end)
				if ok and skip then
					self._alarm_pager_has_run = true
					return
				end
				if not ok and not B._burg_pager_err then
					B._burg_pager_err = true
					log("[Gilza DS Perk Buffs] Burglar Silent Takedown error: " .. tostring(skip))
				end
				local dmg = self._unit and self._unit:character_damage()
				if dmg and dmg._dead then live("pager", "a dead guard's pager went off normally") end
			end
			return orig_pager(self, reset, ...)
		end
	end

elseif script == "lib/units/weapons/newraycastweaponbase" then
	-- an unsuppressed shot gives you away for a moment
	Hooks:PostHook(NewRaycastWeaponBase, "fire", "GilzaDSBuffs_burglar_fire", function(self)
		pcall(function()
			local user = self._setup and self._setup.user_unit
			if not (alive(user) and user == managers.player:player_unit() and B.burglar_on_fire) then return end
			B.burglar_on_fire(self.got_silencer and self:got_silencer() or false)
		end)
	end)

elseif script == "lib/units/beings/player/states/playercarry" then
	-- (7.24) Clover's Smash and Grab: while Ghost hides you (loud), a bag takes away half as much speed
	local orig_walk = PlayerCarry._get_max_walk_speed
	function PlayerCarry:_get_max_walk_speed(...)
		local v = orig_walk(self, ...)
		if type(v) ~= "number" then return v end
		local ok, base = pcall(function(...)
			if not (B.sig_active and B.sig_active(C.deck)) or B.burglar_ghost_range() <= 0 then return nil end
			return PlayerCarry.super._get_max_walk_speed(self, ...)
		end, ...)
		if ok and type(base) == "number" and base > v then
			v = v + (base - v) * (1 - C.sig_carry)
			if B.sig_live then B.sig_live("smash and grab", "Ghost hides you: the bag slows you half as much") end
		end
		return v
	end

elseif script == "lib/units/interactions/interactionext" then
	-- (7.24) Clover's Smash and Grab: in stealth, bagging loot (the interactions a carried bag blocks) is 15% faster
	local orig_timer = BaseInteractionExt._get_timer
	function BaseInteractionExt:_get_timer(...)
		local t = orig_timer(self, ...)
		if type(t) ~= "number" then return t end
		local ok, on = pcall(function()
			local td = self._tweak_data
			return td and td.blocked_hint == "carry_block" and whisper() and B.sig_active and B.sig_active(C.deck)
		end)
		if ok and on then
			t = t * C.sig_bag
			if B.sig_live then B.sig_live("smash and grab bag", "bagging loot %d%% faster", math.floor((1 - C.sig_bag) * 100 + 0.5)) end
		end
		return t
	end

elseif script == "lib/managers/blackmarketmanager" then
	-- card 5: concealment for each silenced weapon
	local orig_conceal = BlackMarketManager.get_silencer_concealment_modifiers
	if orig_conceal then
		function BlackMarketManager:get_silencer_concealment_modifiers(weapon, ...)
			local v = orig_conceal(self, weapon, ...)
			if type(v) ~= "number" then return v end
			local ok, add = pcall(function()
				if type(weapon) ~= "table" or B.burglar_tier() < 5 then return 0 end
				if not (weapon.factory_id and weapon.blueprint and managers.weapon_factory) then return 0 end
				return managers.weapon_factory:has_perk("silencer", weapon.factory_id, weapon.blueprint) and C.silencer_conceal or 0
			end)
			if ok and add > 0 then live("concealment", "+%d concealment on a silenced weapon", add) end
			return v + (ok and add or 0)
		end
	end

elseif script == "lib/tweak_data/skilltreetweakdata" then
	-- the rework's own dodge (card 5), concealment (card 5) and targeting take over from these
	local REMOVE = {
		[5] = { player_level_2_dodge_addend_1 = true, player_level_2_dodge_addend_2 = true,
			player_silencer_concealment_increase_2 = true, player_stand_still_crouch_camouflage_bonus_2 = true },
		[7] = { player_stand_still_crouch_camouflage_bonus_3 = true },
		[9] = { player_armor_regen_timer_stand_still_multiplier = true }
	}
	Hooks:PostHook(SkillTreeTweakData, "init", "GilzaDSBuffs_burglar_cards", function(self)
		local deck = self.specializations and self.specializations[C.deck]
		if not deck then return end
		for card, names in pairs(REMOVE) do
			local ups = deck[card] and deck[card].upgrades
			if ups then
				for i = #ups, 1, -1 do
					if names[ups[i]] then table.remove(ups, i) end
				end
			end
		end
	end)
end
