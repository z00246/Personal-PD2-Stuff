PDTHTactics = PDTHTactics or {}
local T = PDTHTactics
T.name = "[PD:TH Tactics]"
T.color = Color(1, 1, 0.8, 0.28)

function T.active()
	if not (Network and Network:is_server()) then
		return false
	end
	local level = Global.level_data and Global.level_data.level_id
	if level and string.sub(level, 1, 4) == "skm_" then
		return false
	end
	if managers.crime_spree and managers.crime_spree:is_active() then
		return false
	end
	return true
end

function T.has(t, v)
	for _, x in ipairs(t or {}) do
		if x == v then
			return true
		end
	end
end

function T.with(t, add, remove)
	local o = {}
	for _, x in ipairs(t or {}) do
		if not (remove and remove[x]) then
			table.insert(o, x)
		end
	end
	for _, x in ipairs(add or {}) do
		if not T.has(o, x) then
			table.insert(o, x)
		end
	end
	return o
end

function T.has_tag(unit, tag)
	local base = alive(unit) and unit:base()
	return base and base.has_tag and base:has_tag(tag) or false
end

T.tweaks = T.tweaks or {}
function T.set(tbl, key, value)
	table.insert(T.tweaks, { tbl = tbl, key = key, orig = tbl[key], on = value })
	tbl[key] = value
end

function T.set_client(tbl, key, value)
	T.set(tbl, key, value)
	T.tweaks[#T.tweaks].client = true
end

function T.apply(on)
	local client = T.client_on()
	for _, r in ipairs(T.tweaks) do
		r.tbl[r.key] = (on or (client and r.client)) and r.on or r.orig
	end
	T.applied = on
	-- (1.91, Geo: no engine calls wrapped in pcalls) the tweak callbacks (dodge.lua, ds.lua) run directly
	for _, f in ipairs(T.on_apply or {}) do
		f(on)
	end
end

T.on_apply = T.on_apply or {}

T.NET_ID = "PDTHTactics"
T.modded_peers = T.modded_peers or {}

function T.client_on()
	local session = managers.network and managers.network:session()
	return session ~= nil and T.remote_host_session == session and not (Network and Network:is_server())
end

function T.unit_has_mod(unit)
	local net = alive(unit) and unit.network and unit:network()
	local peer = net and net.peer and net:peer()
	local id = peer and peer:id()
	return id and T.modded_peers[id] or false
end

T.DIFF = { easy = 1, normal = 2, hard = 3, overkill = 4, overkill_145 = 5, easy_wish = 6, overkill_290 = 7, sm_wish = 8 }
function T.diff_index()
	return Global.game_settings and T.DIFF[Global.game_settings.difficulty] or 4
end
function T.is_ds()
	return T.diff_index() == 8
end

function T.diff_k()
	return math.clamp((T.diff_index() - 2) / 6, 0, 1)
end

local MIN_SFX = 0.2
T.fade = T.fade or { level = 1, target = 1, rate = 1 }

local function set_sfx(mul)
	local tm = tweak_data and tweak_data.menu
	local um = managers and managers.user
	if not (tm and um and SoundDevice and type(tm.MAX_SFX_VOLUME) == "number" and type(tm.MIN_SFX_VOLUME) == "number") then return end
	local v = tonumber(um:get_setting("sfx_volume")) or tm.MAX_SFX_VOLUME
	local pct = (v - tm.MIN_SFX_VOLUME) / (tm.MAX_SFX_VOLUME - tm.MIN_SFX_VOLUME)
	SoundDevice:set_rtpc("option_sfx_volume", pct * 100 * mul)
end

function T.sniper_focus(duration)
	T.fade.target = MIN_SFX
	T.fade.rate = (1 - MIN_SFX) / math.max(duration or 2.5, 0.3)
end

function T.sniper_unfocus()
	T.fade.target = 1
	T.fade.rate = 1.6
end

Hooks:Add("GameSetupUpdate", "PDTHTactics_sfx_fade", function(t, dt)
	local f = T.fade
	if f.level == f.target then return end
	local step = f.rate * (dt or 0)
	if f.level > f.target then
		f.level = math.max(f.target, f.level - step)
	else
		f.level = math.min(f.target, f.level + step)
	end
	set_sfx(f.level)
end)

Hooks:Add("MenuUpdate", "PDTHTactics_sfx_restore", function()
	if T.fade.level ~= 1 or T.fade.target ~= 1 then
		T.fade.level, T.fade.target = 1, 1
		set_sfx(1)
	end
end)

T.HRT_TEXT = "HOSTAGE RESCUE TEAM PUSH"

function T.set_hrt_banner(on)
	T.hrt_banner = on or nil
	local corner = managers.hud and managers.hud._hud_assault_corner
	local panel = corner and corner._assault_panel
	local title = panel and alive(panel) and panel:child("title")
	if not (title and corner.resize) then return end
	local text = on and T.HRT_TEXT or nil
	if not text then
		-- back to the difficulty's name (the banner's own text)
		local id = tweak_data and tweak_data.difficulty_name_id
		if not (id and managers.localization) then return end
		text = managers.localization:to_upper_text(id)
	end
	title:set_text(text)
	corner:resize()
end

-- installed PD:TH Factions version (read once from its mod.txt), or nil when it isn't installed
function T.factions_pack_version()
	if T._fac_pack_version == nil then
		T._fac_pack_version = false
		local f = io.open("mods/PDTH Factions/mod.txt", "r")
		if f then
			local text = f:read("*all")
			f:close()
			T._fac_pack_version = text and string.match(text, '"version"%s*:%s*"([^"]+)"') or false
		end
	end
	return T._fac_pack_version or nil
end
