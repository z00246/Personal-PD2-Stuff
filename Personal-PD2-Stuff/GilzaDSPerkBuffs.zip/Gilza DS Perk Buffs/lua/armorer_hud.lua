GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs

local function shield_bitmap(tm)
	if not tm then return end
	if tm._radial_shield and alive(tm._radial_shield) then
		return tm._radial_shield
	end
	local pp = tm._player_panel
	local rp = pp and alive(pp) and pp:child("radial_health_panel")
	local sh = rp and rp:child("radial_shield")
	return sh and alive(sh) and sh or nil
end

local function plates_for_tier(tier)
	if not tier or tier < 1 then return 0 end
	local best, n = 0, 0
	for card, v in pairs(B.ARMORER.plates) do
		if tier >= card and card > best then best, n = card, v end
	end
	return n
end

-- Armorer tier of whoever owns this HUD panel (you, or a teammate via their synced perk deck)
local function panel_tier(index, tm)
	if index == HUDManager.PLAYER_PANEL then
		return B.armorer_tier and B.armorer_tier() or 0
	end
	if tm._ai then return 0 end
	local peer_id = tm._peer_id or (tm.peer_id and tm:peer_id())
	local session = managers.network and managers.network:session()
	local peer = session and peer_id and session:peer(peer_id)
	if not peer or peer == session:local_peer() then return 0 end
	local skills = peer.unpacked_skills and peer:unpacked_skills()
	local spec = skills and skills.specializations
	if spec and tonumber(spec[1]) == B.ARMORER.deck then
		return tonumber(spec[2]) or 0
	end
	return 0
end

local function set_texture(shield, path)
	shield:set_image(path)
	local w, h = shield:texture_width(), shield:texture_height()
	if w and h and w > 0 then
		shield:set_texture_rect(w, 0, -w, h)
	end
end

B._plate_state = B._plate_state or {}

local function update_panel(index, tm)
	local shield = shield_bitmap(tm)
	local st = B._plate_state[index]
	if not shield then
		B._plate_state[index] = nil
		return
	end
	local mui = tm._muiColor and true or false
	local n = plates_for_tier(panel_tier(index, tm))
	local want
	if n >= 2 then
		want = "guis/textures/gilza_plates/seg_" .. (mui and "mui_" or "vanilla_") .. n
	else
		want = mui and "mui_textures/shield" or "guis/textures/pd2/hud_shield"
	end
	if st and st.shield == shield and st.texture == want then return end
	if (not st or st.shield ~= shield) and n < 2 then
		-- fresh panel without plates: leave the original texture alone
		B._plate_state[index] = { shield = shield, texture = want }
		return
	end
	set_texture(shield, want)
	B._plate_state[index] = { shield = shield, texture = want }
end

function B.update_plate_texture()
	local hud = managers.hud
	local panels = hud and hud._teammate_panels
	if not panels then return end
	for index, tm in pairs(panels) do
		local ok, err = pcall(update_panel, index, tm)
		if not ok and not B._plate_panel_err then
			B._plate_panel_err = true
			log("[Gilza DS Perk Buffs] plate texture panel error: " .. tostring(err))
		end
	end
end

Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_plate_texture", function(t)
	if t and B._plate_tex_next and t < B._plate_tex_next then return end
	B._plate_tex_next = (t or 0) + 0.5
	local ok, err = pcall(B.update_plate_texture)
	if not ok and not B._plate_err then
		B._plate_err = true
		log("[Gilza DS Perk Buffs] plate texture error: " .. tostring(err))
	end
end)
