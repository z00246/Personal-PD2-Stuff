if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics

local UPGRADE = { average = "athletic" }

local function scale_preset(src, k)
	local p = deep_clone(src)
	p.speed = (p.speed or 1) * (1 + 0.15 * k)
	for name, occ in pairs(p.occasions or {}) do
		occ.chance = math.min(0.95, (occ.chance or 0) * (1 + 0.8 * k) + 0.1 * k)
		if occ.check_timeout then
			occ.check_timeout = { occ.check_timeout[1] * (1 - 0.4 * k), occ.check_timeout[2] * (1 - 0.4 * k) }
		end
		for vname, var in pairs(occ.variations or {}) do
			if vname == "roll" or vname == "dive" or vname == "wheel" then
				var.chance = (var.chance or 1) * (1 + 1.5 * k)
			end
			if var.timeout then
				var.timeout = { var.timeout[1] * (1 - 0.3 * k), var.timeout[2] * (1 - 0.3 * k) }
			end
		end
	end
	if T.is_ds() then
		p.speed = p.speed * 1.2
		for _, occ in pairs(p.occasions or {}) do
			occ.chance = math.min(0.95, (occ.chance or 0) * 1.15)
			if occ.check_timeout then
				occ.check_timeout = { occ.check_timeout[1] * 0.6, occ.check_timeout[2] * 0.6 }
			end
			for _, var in pairs(occ.variations or {}) do
				if var.timeout then
					var.timeout = { var.timeout[1] * 0.75, var.timeout[2] * 0.75 }
				end
			end
		end
	end
	if p.occasions and not p.occasions.preemptive and p.occasions.hit and k > 0 then
		p.occasions.preemptive = deep_clone(p.occasions.hit)
		p.occasions.preemptive.chance = 0.2 + 0.25 * k
		p.occasions.preemptive.check_timeout = { 1, 4 }
	end
	return p
end

T._dodge_orig = T._dodge_orig or {}

table.insert(T.on_apply, function(on)
	local chars = tweak_data and tweak_data.character
	local presets = chars and chars.presets and chars.presets.dodge
	if not presets then return end

	for name, d in pairs(T._dodge_orig) do
		if chars[name] then chars[name].dodge = d end
	end
	T._dodge_orig = {}
	if not on then return end

	local diff = T.diff_index()
	local k = T.is_ds() and 1.35 or T.diff_k()

	local cache = {}
	for name, data in pairs(chars) do
		if type(data) == "table" and type(data.dodge) == "table" and data.dodge.occasions then
			local key
			for pname, pdata in pairs(presets) do
				if pdata == data.dodge then key = pname break end
			end
			if key ~= "heavy" and key ~= "poor" and not T.has(data.tags, "tank") and not T.has(data.tags, "shield") then
				if key and UPGRADE[key] and diff >= 4 and presets[UPGRADE[key]] then
					key = UPGRADE[key]
				end
				local src = key and presets[key] or data.dodge
				local id = key or name
				cache[id] = cache[id] or scale_preset(src, k)
				T._dodge_orig[name] = data.dodge
				data.dodge = cache[id]
			end
		end
	end
end)
