if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics
local script = RequiredScript and RequiredScript:lower() or ""

-- ZEAL Medic (Restoration Mod model) replaces the regular Medic on Death Sentence.
-- Custom units crash players who don't have them, so it is only used while everyone has this mod.
local ZEAL = "units/pd2_dlc_gitgud/characters/ene_zeal_medic/ene_zeal_medic"
local UNIT = Idstring("unit")
local MAT = Idstring("material_config")

local function load_zeal()
	if T._zeal_loaded ~= nil then return T._zeal_loaded end
	T._zeal_loaded = false
	if not (BeardLib and T.is_ds() and DB:has(UNIT, Idstring(ZEAL))) then return false end
	local dyn = managers.dyn_resource
	if not dyn then return false end
	for _, name in ipairs({ ZEAL, ZEAL .. "_husk" }) do
		local ids = Idstring(name)
		if not PackageManager:has(UNIT, ids) then
			dyn:load(UNIT, ids, dyn.DYN_RESOURCES_PACKAGE, nil)
		end
	end
	for _, name in ipairs({ ZEAL, ZEAL .. "_contour" }) do
		local ids = Idstring(name)
		if DB:has(MAT, ids) and not PackageManager:has(MAT, ids) then
			pcall(dyn.load, dyn, MAT, ids, dyn.DYN_RESOURCES_PACKAGE, nil)
		end
	end
	T._zeal_loaded = PackageManager:has(UNIT, Idstring(ZEAL)) and PackageManager:has(UNIT, Idstring(ZEAL .. "_husk"))
	return T._zeal_loaded
end

if script == "lib/units/enemies/cop/copbase" then
	-- outlines: cops swap to a "_contour" material when marked; register the ZEAL Medic's pair
	if CopBase._material_translation_map then
		local normal_id, contour_id = Idstring(ZEAL), Idstring(ZEAL .. "_contour")
		CopBase._material_translation_map[tostring(normal_id:key())] = contour_id
		CopBase._material_translation_map[tostring(contour_id:key())] = normal_id
	end

elseif script == "lib/managers/mission/elementspawnenemydummy" then
	T.zeal_peers = T.zeal_peers or {}

	local function everyone_has_zeal()
		local session = managers.network and managers.network:session()
		for _, peer in pairs(session and session:peers() or {}) do
			if not T.zeal_peers[peer:id()] then return false end
		end
		return true
	end

	-- load once the game is running (host and modded clients), then tell the host we can show it
	Hooks:Add("GameSetupUpdate", "PDTHTactics_zeal_medic_load", function()
		if T._zeal_done then return end
		if T._zeal_loaded == nil then
			local ok, err = pcall(load_zeal)
			if not ok then
				T._zeal_loaded = false
				log(T.name .. " ZEAL Medic load failed: " .. tostring(err))
			end
		end
		if not T._zeal_loaded or (Network and Network:is_server()) then
			T._zeal_done = true
			return
		end
		if T.client_on() and LuaNetworking then
			pcall(LuaNetworking.SendToPeer, LuaNetworking, 1, T.NET_ID, "zeal")
			T._zeal_done = true
		end
	end)

	if LuaNetworking and LuaNetworking.AddReceiveHook then
		LuaNetworking:AddReceiveHook(T.NET_ID, "PDTHTactics_zeal_net", function(data, sender)
			if data == "zeal" and sender and Network and Network:is_server() then
				T.zeal_peers[sender] = true
			end
		end)
	end
	Hooks:Add("BaseNetworkSessionOnPeerRemoved", "PDTHTactics_zeal_peer_removed", function(peer, peer_id)
		T.zeal_peers[peer_id] = nil
	end)

	-- someone joins mid-heist: quietly remove any ZEAL Medics before their game loads them,
	-- so they never get sent a unit they might not have (new spawns stay vanilla until they confirm)
	Hooks:Add("NetworkManagerOnPeerAdded", "PDTHTactics_zeal_joiner", function(peer, peer_id)
		T.zeal_peers[peer_id] = nil
		if not (Network and Network:is_server()) then return end
		pcall(function()
			local key = Idstring(ZEAL):key()
			for _, u_data in pairs(managers.enemy:all_enemies() or {}) do
				local unit = u_data.unit
				if alive(unit) and unit:name():key() == key then
					unit:brain():set_active(false)
					unit:base():set_slot(unit, 0)
				end
			end
			local corpses = managers.enemy._enemy_data and managers.enemy._enemy_data.corpses or {}
			for _, c in pairs(corpses) do
				if alive(c.unit) and c.unit:name():key() == key then
					c.unit:set_slot(0)
				end
			end
		end)
	end)

	local SWAP = {
		[Idstring("units/payday2/characters/ene_medic_m4/ene_medic_m4"):key()] = true,
		[Idstring("units/payday2/characters/ene_medic_r870/ene_medic_r870"):key()] = true
	}
	local zeal_ids = Idstring(ZEAL)

	local function zeal_ok()
		if not (T.active() and T.is_ds() and T._zeal_loaded and everyone_has_zeal()) then return false end
		if T.faction_now and T.faction_now() then return false end
		return true
	end

	-- group spawns (params.name) and mission/scripted spawns (the element's own unit) alike
	local orig_produce = ElementSpawnEnemyDummy.produce
	function ElementSpawnEnemyDummy:produce(params, ...)
		local ok, use = pcall(zeal_ok)
		if ok and use then
			if params and params.name then
				if SWAP[params.name:key()] then params.name = zeal_ids end
			elseif self._enemy_name and SWAP[self._enemy_name:key()] then
				local old = self._enemy_name
				self._enemy_name = zeal_ids
				local res = { pcall(orig_produce, self, params, ...) }
				self._enemy_name = old
				if not res[1] then error(res[2], 0) end
				return unpack(res, 2)
			end
		end
		return orig_produce(self, params, ...)
	end
end
