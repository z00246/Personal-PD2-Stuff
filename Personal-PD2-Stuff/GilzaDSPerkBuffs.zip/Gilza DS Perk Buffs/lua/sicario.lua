GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

B.SICARIO = {
	deck = 18,
	haze = 0.20,
	haze_ds = 0.30,
	vanish_cd = 2
}
local C = B.SICARIO

function B.sic_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == C.deck) then
		return 0
	end
	return st:get_specialization_value(C.deck, "tiers", "current_tier") or 0
end

-- is this unit standing in one of your own smoke screens?
function B.sic_in_my_smoke(unit)
	local pm = managers.player
	if not (pm and alive(unit)) then return false end
	for _, smoke in ipairs(pm._smoke_screen_effects or {}) do
		local ok, mine = pcall(smoke.mine, smoke)
		if ok and mine then
			local ok2, inside = pcall(smoke.is_in_smoke, smoke, unit)
			if ok2 and inside then return true end
		end
	end
	return false
end

if script == "lib/units/enemies/cop/copdamage" then
	local function is_me(attack_data)
		local player = managers.player and managers.player:player_unit()
		return alive(player) and attack_data and attack_data.attacker_unit == player
	end

	local function pre(self, attack_data)
		self._gdsb_sic_alive, self._gdsb_sic_smoke = nil, nil
		if not (is_me(attack_data) and type(attack_data.damage) == "number") then return end
		local tier = B.sic_tier()
		if tier < 5 then return end
		if not B.sic_in_my_smoke(self._unit) then return end
		self._gdsb_sic_alive, self._gdsb_sic_smoke = not self._dead, true
		attack_data.damage = attack_data.damage * (1 + (B.on and C.haze_ds or C.haze))
	end

	local function post(self)
		local was_alive, smoke = self._gdsb_sic_alive, self._gdsb_sic_smoke
		self._gdsb_sic_alive, self._gdsb_sic_smoke = nil, nil
		if was_alive and smoke and self._dead and B.sic_tier() >= 7 then
			managers.player:speed_up_grenade_cooldown(C.vanish_cd)
		end
	end

	for _, fn in ipairs({ "damage_bullet", "damage_melee" }) do
		Hooks:PreHook(CopDamage, fn, "GilzaDSBuffs_sic_pre_" .. fn, function(self, attack_data)
			pcall(pre, self, attack_data)
		end)
		Hooks:PostHook(CopDamage, fn, "GilzaDSBuffs_sic_post_" .. fn, function(self)
			pcall(post, self)
		end)
	end
end
