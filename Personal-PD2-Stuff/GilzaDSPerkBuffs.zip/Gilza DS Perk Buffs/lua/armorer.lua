GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

B.ARMORER = {
	deck = 3,
	plates = { [1] = 2, [5] = 3, [9] = 4 },
	hit_cap = { [1] = 1, [5] = 0.75, [9] = 0.5 },
	plate_regen_tier = 7,
	plate_regen_every = 5,
	shatter_tier = 3,
	shatter_range = 600,
	shatter_panic = 0.6,
	regen_mul = 0.8,
	plate_step = 0.75
}

function B.armorer_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == B.ARMORER.deck) then
		return 0
	end
	return st:get_specialization_value(B.ARMORER.deck, "tiers", "current_tier") or 0
end

function B.armorer_pre_apply()
	local values = tweak_data and tweak_data.upgrades and tweak_data.upgrades.values
	if not values or B._armorer_done_for == values then return end
	B._armorer_done_for = values
	values.player.armor_regen_timer_multiplier_passive = { B.ARMORER.regen_mul }
end

local function by_tier(tbl, tier)
	local best, v = 0, nil
	for card, val in pairs(tbl) do
		if tier >= card and card > best then best, v = card, val end
	end
	return v
end

local function plate_count(tier)
	local best, n = 0, 0
	for card, v in pairs(B.ARMORER.plates) do
		if tier >= card and card > best then best, n = card, v end
	end
	return n
end

local function shatter(player_unit)
	local pos = player_unit:position()
	local enemies = World:find_units_quick("sphere", pos, B.ARMORER.shatter_range, managers.slot:get_mask("enemies"))
	for _, unit in ipairs(enemies or {}) do
		local dmg = unit:character_damage()
		if dmg and dmg.build_suppression then
			dmg:build_suppression("max", B.ARMORER.shatter_panic)
		end
	end
end

if script == "lib/units/beings/player/playerdamage" then
	-- recover armor one plate at a time instead of all at once
	local orig_regen = PlayerDamage._regenerate_armor
	function PlayerDamage:_regenerate_armor(...)
		local tier = B.armorer_tier()
		local plates = tier >= 1 and plate_count(tier) or 0
		if plates >= 2 and not self._dead and not self._bleed_out then
			local armor, max = self:get_real_armor(), self:_max_armor()
			if max > 0 and armor < max - 0.0001 then
				local plate = max / plates
				local top = math.min((math.floor(armor / plate + 0.0001) + 1) * plate, max)
				if top < max - 0.0001 then
					self:set_armor(top)
					self:_send_set_armor()
					if self._unit:sound() then
						self._unit:sound():play("shield_full_indicator")
					end
					self._regenerate_timer = B.ARMORER.plate_step
					self._current_state = self._update_regenerate_timer
					return
				end
			end
		end
		return orig_regen(self, ...)
	end

	Hooks:PreHook(PlayerDamage, "_calc_armor_damage", "GilzaDSBuffs_armorer_plates", function(self, attack_data)
		if not attack_data or attack_data.armor_piercing or type(attack_data.damage) ~= "number" then return end
		local tier = B.armorer_tier()
		if tier < 1 then return end
		local armor = self:get_real_armor()
		if armor <= 0 then return end
		local plates = plate_count(tier)
		if plates < 2 then return end
		local plate = self:_max_armor() / plates
		local in_plate = armor - plate * (math.ceil(armor / plate - 0.0001) - 1)
		local cap = math.min(in_plate, plate * (by_tier(B.ARMORER.hit_cap, tier) or 1))
		if attack_data.damage >= cap then
			attack_data.damage = cap
			if cap >= in_plate - 0.0001 and tier >= B.ARMORER.shatter_tier then
				pcall(shatter, self._unit)
			end
		end
	end)
end

if script == "lib/managers/playermanager" then
	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_armorer_plate_regen", function()
		local tier = B.armorer_tier()
		if tier < B.ARMORER.plate_regen_tier then return end
		local now = Application:time()
		if now < (B._plate_regen_t or 0) then return end
		B._plate_regen_t = now + B.ARMORER.plate_regen_every
		local unit = managers.player:player_unit()
		local dmg = alive(unit) and unit:character_damage()
		if not dmg or dmg:dead() or dmg:need_revive() then return end
		local armor, max = dmg:get_real_armor(), dmg:_max_armor()
		if armor <= 0 or armor >= max then return end
		local plate = max / plate_count(tier)
		local top = math.min(math.ceil(armor / plate - 0.0001) * plate, max)
		if top > armor then
			dmg:restore_armor(top - armor)
		end
	end)
end
