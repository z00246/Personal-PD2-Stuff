-- Gilza DS Perk Buffs 7.25: the HLM2 combo counter ("Kill Combo Counter" / HLM2 Combo Counter Improved - its own mod,
-- left as it is) shows Sociopath's Combo (Geo 2026-10-26: "Sociopath's Combo", then "heavy is sick as hell, start adding
-- it in with this"):
--   * it counts our Combo (card 5: melee kills chained within 5 s), not every kill; hidden on other decks / below card 5
--   * it pops in at 2, slams + flickers on every melee kill from the 3rd (its own kill animation / flash options; they
--     count as on until you turn them off), slides out when the Combo ends; cyan at Massacre (card 9)
--   * it only animates when something changes: its own update started a new slide-out animation every frame while it was
--     hidden and its kill hook wrote three log lines per kill - both are gone (OnKillshot does nothing now)
--   * GilzaDSBuffs.hlm2 is the state other HUDs read (Geo HUD draws its bar, Jacket, colours and music from it);
--     hlm2.hide_req = true makes the counter fade out (Geo HUD sets it while TAB is held)
-- Without the counter mod nothing is drawn here, but hlm2 is still kept up to date.
-- No pcall anywhere (Geo: no engine calls wrapped in pcalls): every call is checked before it's made instead.
GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
if B._hlm2_loaded then return end
B._hlm2_loaded = true

B.hlm2 = B.hlm2 or {}
local S = B.hlm2
S.kills = S.kills or 0
local PINK = Color(226 / 255, 8 / 255, 124 / 255)    -- the counter's own colour (e2087c)
local CYAN = Color(40 / 255, 226 / 255, 240 / 255)   -- Massacre
B.HLM2 = { pink = PINK, cyan = CYAN }

local function window()
	return B.SOCIO and B.SOCIO.combo_window or 5
end

local function in_heist()
	local U = rawget(_G, "Utils")
	if not (U and U.IsInHeist and rawget(_G, "game_state_machine")) then return false end
	return U:IsInHeist() and true or false
end

-- every frame: the Combo as the counter (and Geo HUD) show it
--   combo / shown (2+, card 5, in a heist) / massacre / left (s) / frac (0-1 of the window) / kills (+1 per melee
--   kill that counted, every kill of a cleave too: sociopath.lua's B.combo_kills) / kill_t (Application:time of the last)
function B.hlm2_tick()
	local tier = B.socio_tier and B.socio_tier() or 0
	local combo = tier >= 5 and (B.combo or 0) or 0
	local now = Application:time()
	local lt = tier >= 5 and B.combo_last_t or nil
	local ck = B.combo_kills or 0
	if S.seen_kills == nil then S.seen_kills = ck end
	if ck ~= S.seen_kills then
		if tier >= 5 then
			S.kills = (S.kills or 0) + math.max(1, ck - S.seen_kills)
			S.kill_t = now
		end
		S.seen_kills = ck
	end
	S.combo = combo
	S.shown = combo >= 2 and in_heist()
	S.massacre = S.shown and B.socio_massacre and B.socio_massacre() or false
	S.window = window()
	S.left = lt and math.max(0, S.window - (now - lt)) or 0
	S.frac = S.window > 0 and S.left / S.window or 0
end

if Hooks then
	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_hlm2", function()
		B.hlm2_tick()
	end)
end

------------------------------------------------------------------------------------------------
-- the counter itself (HUDComboCounter, made by the counter mod in its hudmanagerpd2 hook)
------------------------------------------------------------------------------------------------
local function opt(id, default)
	local H = rawget(_G, "HMHCC")
	local v = H and H.GetOption and H:GetOption(id)
	if v == nil then return default end
	return v
end

local function lit(c, k)   -- the counter's flash: its colour times 2 x |sin|, clipped (black <-> bright)
	return Color(math.min(1, c.r * k), math.min(1, c.g * k), math.min(1, c.b * k))
end

function B.hlm2_counter_update(self, t, dt)
	local p = self._combo_panel
	if not (p and alive(p)) then return end
	local txt, sh, bg = p:child("Combo_text"), p:child("Combo_text_bg"), p:child("Combo_bg")
	if not (txt and sh and bg) then return end
	S.panel, S.band, S.text = p, bg, txt
	dt = dt or 0
	local g = self._gdsb
	if not g then
		g = { shown = false, closing = false, x = -150, combo = -1, kills = S.kills or 0, alpha = 1 }
		self._gdsb = g
		p:set_visible(false)
	end
	local want = S.shown and true or false
	-- open: slide in from the left (the counter's own: -150 -> 50 in 10 / open speed s); close: back out the same way
	if want and (not g.shown or g.closing) then
		if not g.shown then
			g.x = -150
			p:set_top(opt("panel_position", 40))
			p:set_visible(true)
		end
		g.shown, g.closing = true, false
	elseif not want and g.shown and not g.closing then
		g.closing = true
	end
	if g.closing then
		g.x = g.x - 20 * opt("close_speed", 75) * dt
		if g.x <= -150 then
			g.x, g.shown, g.closing = -150, false, false
			g.pop, g.flash = nil, nil
			p:set_visible(false)
		end
	elseif g.shown and g.x < 50 then
		g.x = math.min(50, g.x + 20 * opt("open_speed", 50) * dt)
	end
	if not g.shown then
		g.kills = S.kills or 0
		S.text_x, S.open = g.x, false
		return
	end
	-- the number (and the band's width) only when it changes
	local c = S.combo or 0
	if want and c ~= g.combo and c > 0 then
		local s = tostring(c) .. "x"
		txt:set_text(s); sh:set_text(s)
		bg:set_w(c > 99 and 310 or (c > 9 and 240 or 200))
		g.combo = c
	end
	-- a melee kill (every one of a cleave): slam + flicker, from the 3rd on like the counter's own
	if (S.kills or 0) ~= g.kills then
		g.kills = S.kills or 0
		if want and c >= 3 then
			if opt("kill_anim", true) then g.pop = 0 end
			if opt("kill_flash", true) then g.flash = 0 end
		end
	end
	if g.pop then
		g.pop = g.pop + dt
		local k = math.min(1, g.pop / 0.4)
		local size = 96 + 125 * (1 - math.sin(k * 90))
		txt:set_font_size(size); sh:set_font_size(size)
		if k >= 1 then g.pop = nil end
	end
	local base = S.massacre and CYAN or PINK
	if g.flash then
		g.flash = g.flash + dt
		if g.flash >= 0.4 then
			g.flash, g.col = nil, nil
		else
			txt:set_color(lit(base, 2 * math.abs(math.sin((0.4 - g.flash) * 180 * 16))))
		end
	end
	if not g.flash and g.col ~= base then
		txt:set_color(base); g.col = base
	end
	txt:set_x(g.x); sh:set_x(g.x + 2)
	-- other HUDs can ask it to step aside for a moment (Geo HUD: while TAB is held)
	local target = S.hide_req and 0 or 1
	if g.alpha ~= target then
		local step = dt / 0.15
		g.alpha = target > g.alpha and math.min(target, g.alpha + step) or math.max(target, g.alpha - step)
		p:set_alpha(g.alpha)
	end
	S.text_x, S.open, S.alpha = g.x, not g.closing, g.alpha
end

function B.hlm2_patch()
	local HC = rawget(_G, "HUDComboCounter")
	if type(HC) ~= "table" then return false end
	if HC._gdsb_hlm2 then return true end
	HC._gdsb_hlm2 = true
	-- counting comes from Sociopath's Combo now (and no log lines on every kill)
	HC.OnKillshot = function() end
	HC.update = B.hlm2_counter_update
	log("[Gilza DS Perk Buffs] HLM2 combo counter: showing Sociopath's Combo")
	return true
end

-- the counter mod may load before or after us: patch it as soon as its class exists
if not B.hlm2_patch() and Hooks then
	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_hlm2_patch", function()
		if not B._hlm2_patched and B.hlm2_patch() then B._hlm2_patched = true end
	end)
end
