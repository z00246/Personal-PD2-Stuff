GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

B.MUSCLE = {
	deck = 2,
	stack_per_health = 0.1,
	max_stacks = 10,
	max_stacks_ds = 12,
	damage_per_stack = { [1] = 0.03, [7] = 0.05 },
	resist_at = 5,
	resist = 0.15,
	kill_heal_at = 5,
	kill_heal = 0.03,
	decay_after = 4,
	decay_every = 2,
	unstoppable_time = 4,
	unstoppable_resist = 0.5,
	unstoppable_cooldown = 20
}
B.rage = 0

function B.muscle_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == B.MUSCLE.deck) then
		return 0
	end
	return st:get_specialization_value(B.MUSCLE.deck, "tiers", "current_tier") or 0
end

local function max_stacks()
	return B.on and B.MUSCLE.max_stacks_ds or B.MUSCLE.max_stacks
end

local function per_stack(tier)
	return tier >= 7 and B.MUSCLE.damage_per_stack[7] or B.MUSCLE.damage_per_stack[1]
end

function B.muscle_add_rage(health_lost, max_health)
	if B.muscle_tier() < 1 or max_health <= 0 then return end
	B._rage_carry = (B._rage_carry or 0) + health_lost / max_health
	local gained = math.floor(B._rage_carry / B.MUSCLE.stack_per_health)
	if gained > 0 then
		B._rage_carry = B._rage_carry - gained * B.MUSCLE.stack_per_health
		B.rage = math.min(B.rage + gained, max_stacks())
	end
	local now = Application:time()
	B._rage_hit_t = now
	B._rage_decay_t = now + B.MUSCLE.decay_after
	if B.rage >= max_stacks() and B.muscle_tier() >= 9 and now >= (B._unstoppable_ready or 0) then
		B._unstoppable_until = now + B.MUSCLE.unstoppable_time
		B._unstoppable_ready = now + B.MUSCLE.unstoppable_cooldown
		local unit = managers.player:player_unit()
		if alive(unit) then unit:sound():play("perkdeck_activate", nil, false) end
	end
end

if script == "lib/managers/playermanager" then
	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_muscle_decay", function()
		if (B.rage or 0) <= 0 then return end
		local now = Application:time()
		local unit = managers.player and managers.player:player_unit()
		if not alive(unit) or unit:character_damage():dead() then
			B.rage, B._rage_carry = 0, 0
			return
		end
		if now >= (B._rage_decay_t or 0) then
			B.rage = math.max(B.rage - 1, 0)
			B._rage_decay_t = now + B.MUSCLE.decay_every
		end
	end)

	local orig_resist = PlayerManager.damage_reduction_skill_multiplier
	function PlayerManager:damage_reduction_skill_multiplier(...)
		local m = orig_resist(self, ...)
		if type(m) ~= "number" then return m end
		local ok, tier = pcall(B.muscle_tier)
		if not ok or tier < 1 then return m end
		if tier >= 3 and B.rage >= B.MUSCLE.resist_at then
			m = m * (1 - B.MUSCLE.resist)
		end
		if Application:time() < (B._unstoppable_until or 0) then
			m = m * (1 - B.MUSCLE.unstoppable_resist)
		end
		return m
	end

	Hooks:PostHook(PlayerManager, "on_killshot", "GilzaDSBuffs_muscle_kill", function(self)
		if B.muscle_tier() < 5 or B.rage < B.MUSCLE.kill_heal_at then return end
		local unit = self:player_unit()
		local dmg = alive(unit) and unit:character_damage()
		if dmg and not dmg:dead() and not dmg:need_revive() then
			dmg:restore_health(B.MUSCLE.kill_heal, false)
		end
	end)

elseif script == "lib/units/beings/player/playerdamage" then
	local orig_health = PlayerDamage._calc_health_damage
	function PlayerDamage:_calc_health_damage(attack_data, ...)
		local lost = orig_health(self, attack_data, ...)
		if type(lost) == "number" and lost > 0 then
			pcall(B.muscle_add_rage, lost, self:_max_health())
		end
		return lost
	end

elseif script == "lib/units/enemies/cop/copdamage" then
	local function rage_bonus(attack_data)
		if not attack_data or type(attack_data.damage) ~= "number" or (B.rage or 0) <= 0 then return end
		local player = managers.player and managers.player:player_unit()
		if not (alive(player) and attack_data.attacker_unit == player) then return end
		local tier = B.muscle_tier()
		if tier < 1 then return end
		attack_data.damage = attack_data.damage * (1 + B.rage * per_stack(tier))
	end
	for _, fn in ipairs({ "damage_bullet", "damage_melee" }) do
		Hooks:PreHook(CopDamage, fn, "GilzaDSBuffs_muscle_" .. fn, function(self, attack_data)
			pcall(rage_bonus, attack_data)
		end)
	end
end
