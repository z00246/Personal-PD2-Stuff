GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

B.MANIAC = {
	deck = 14,
	habit_stacks = 300,
	habit_speed = 1.1,
	binge = 30,
	binge_ds = 45,
	rush_speed = 1.1,
	comedown = 0.3,
	comedown_ds = 0.4,
	comedown_time = 3,
	-- (7.24) Jimmy's signature (card 9, only as Jimmy): Bender - reaching 600 Hysteria (the most there is) starts an
	-- 8 s Bender: your stacks can't drop and kills heal 2%; once every 60 s
	bender_time = 8, bender_every = 60, bender_heal = 0.02
}
local C = B.MANIAC

-- (7.24) Jimmy's Bender running?
function B.maniac_bender()
	return Application:time() < (B.maniac_bender_until or 0)
end

function B.maniac_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == C.deck) then
		return 0
	end
	return st:get_specialization_value(C.deck, "tiers", "current_tier") or 0
end

local function local_id()
	local session = managers.network and managers.network:session()
	local peer = session and session:local_peer()
	return peer and peer:id()
end

function B.maniac_stacks()
	local pm = managers.player
	local id = local_id()
	if not (pm and id and pm.get_synced_cocaine_stacks) then return 0 end
	local s = pm:get_synced_cocaine_stacks(id)
	return s and s.amount or 0
end

local function max_stacks()
	return tweak_data and tweak_data.upgrades and tweak_data.upgrades.max_total_cocaine_stacks or 600
end

function B.maniac_habit()
	return B.maniac_tier() >= 3 and B.maniac_stacks() >= C.habit_stacks
end

function B.maniac_rush()
	return B.maniac_tier() >= 7 and B.maniac_stacks() >= max_stacks()
end

function B.maniac_comedown()
	if Application:time() >= (B.maniac_cd_until or 0) then return 0 end
	return B.maniac_cd_dr or 0
end

if script == "lib/managers/playermanager" then
	local function set_stacks(pm, amount)
		if not pm.update_synced_cocaine_stacks_to_peers then return end
		amount = math.clamp(math.floor(amount), 0, max_stacks())
		pm:update_synced_cocaine_stacks_to_peers(amount, pm:upgrade_value("player", "sync_cocaine_upgrade_level", 1), pm:upgrade_level("player", "cocaine_stack_absorption_multiplier", 0))
	end

	-- Comedown: stacks lost to decay turn into brief damage reduction
	local function after_update(pm, before, decay_t)
		if B.maniac_tier() < 9 then return end
		-- (7.24) Jimmy's Bender: starts at the most Hysteria there is
		local now = Application:time()
		if not B.maniac_bender() and now >= (B.maniac_bender_ready or 0) and B.sig_active and B.sig_active(C.deck)
			and B.maniac_stacks() >= max_stacks() then
			B.maniac_bender_until = now + C.bender_time
			B.maniac_bender_ready = now + C.bender_every
			local unit = pm:player_unit()
			if alive(unit) and unit:sound() then unit:sound():play("perkdeck_activate", nil, false) end
			B.sig_live("bender", "%d Hysteria: Bender for %d seconds", max_stacks(), C.bender_time)
		end
		if decay_t == pm._damage_dealt_to_cops_decay_t then return end
		local lost = before - B.maniac_stacks()
		if lost <= 0 then return end
		local max = B.on and C.comedown_ds or C.comedown
		B.maniac_cd_dr = math.min(lost / max_stacks(), 1) * max
		B.maniac_cd_until = Application:time() + C.comedown_time
	end
	local orig_update = PlayerManager._update_damage_dealt
	function PlayerManager:_update_damage_dealt(t, dt, ...)
		-- (7.24) Jimmy's Bender: the decay timer keeps getting pushed back, so the stacks can't drop
		if type(t) == "number" and B.maniac_bender() then
			self._damage_dealt_to_cops_decay_t = t + ((tweak_data.upgrades and tweak_data.upgrades.cocaine_stacks_decay_t) or 5)
		end
		local before = B.maniac_stacks()
		local decay_t = self._damage_dealt_to_cops_decay_t
		local r = orig_update(self, t, dt, ...)
		after_update(self, before, decay_t)
		return r
	end

	-- (7.24) Jimmy's Bender: kills heal
	Hooks:PostHook(PlayerManager, "on_killshot", "GilzaDSBuffs_maniac_bender", function(self)
		if not B.maniac_bender() then return end
		local unit = self:player_unit()
		local dmg = alive(unit) and unit:character_damage()
		if dmg and not dmg:need_revive() and not dmg:dead() then
			dmg:restore_health(C.bender_heal)
			B.sig_live("bender heal", "a kill during Bender healed %d%%", C.bender_heal * 100)
		end
	end)

	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_maniac_reset", function()
		local session = managers.network and managers.network:session()
		if B._maniac_session ~= session then
			B._maniac_session = session
			B.maniac_bender_until, B.maniac_bender_ready = nil, nil
		end
	end)

	-- Binge: kills add stacks instantly
	Hooks:PostHook(PlayerManager, "on_killshot", "GilzaDSBuffs_maniac_binge", function(self)
		if B.maniac_tier() < 5 or not self:has_category_upgrade("player", "cocaine_stacking") then return end
		set_stacks(self, B.maniac_stacks() + (B.on and C.binge_ds or C.binge))
	end)

	local orig_resist = PlayerManager.damage_reduction_skill_multiplier
	function PlayerManager:damage_reduction_skill_multiplier(...)
		local m = orig_resist(self, ...)
		if type(m) ~= "number" then return m end
		local cd = B.maniac_comedown()
		if cd > 0 then m = m * (1 - cd) end
		return m
	end

	local orig_speed = PlayerManager.movement_speed_multiplier
	function PlayerManager:movement_speed_multiplier(...)
		local m = orig_speed(self, ...)
		if type(m) == "number" and B.maniac_rush() then
			return m * C.rush_speed
		end
		return m
	end

elseif script == "lib/units/beings/player/playermovement" then
	-- Rush: no stamina drain at max stacks
	local orig_sub = PlayerMovement.subtract_stamina
	function PlayerMovement:subtract_stamina(value, ...)
		if B.maniac_rush() then return end
		return orig_sub(self, value, ...)
	end

elseif script == "lib/units/weapons/newraycastweaponbase" then
	local orig_reload = NewRaycastWeaponBase.reload_speed_multiplier
	function NewRaycastWeaponBase:reload_speed_multiplier(...)
		local m = orig_reload(self, ...)
		if type(m) == "number" and B.maniac_habit() then
			return m * C.habit_speed
		end
		return m
	end

elseif script == "lib/units/beings/player/states/playerstandard" then
	local orig_swap = PlayerStandard._get_swap_speed_multiplier
	function PlayerStandard:_get_swap_speed_multiplier(...)
		local m = orig_swap(self, ...)
		if type(m) == "number" and B.maniac_habit() then
			return m * C.habit_speed
		end
		return m
	end
end
