GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

B.BIKER = {
	deck = 16,
	road_rage = 0.04,
	road_rage_ds = 0.05,
	chopper = 0.03,
	colors_slots = 3,
	colors = 0.10,
	colors_ds = 0.15,
	burnout = 0.25,
	burnout_time = 3,
	burnout_cd = 10
}
local C = B.BIKER

function B.biker_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == C.deck) then
		return 0
	end
	return st:get_specialization_value(C.deck, "tiers", "current_tier") or 0
end

function B.biker_max_slots()
	return tweak_data and tweak_data.upgrades and tweak_data.upgrades.wild_max_triggers_per_time or 4
end

-- Momentum: kills by you or your crew in the last 4 seconds, up to 4.
-- Tracked separately from the Regeneration slots, which only fill when a stack actually heals.
B.biker_kills = B.biker_kills or {}
function B.biker_slots()
	local now, n = Application:time(), 0
	for i = #B.biker_kills, 1, -1 do
		if B.biker_kills[i] <= now then
			table.remove(B.biker_kills, i)
		else
			n = n + 1
		end
	end
	return math.min(n, B.biker_max_slots())
end

local function add_kill()
	local window = tweak_data and tweak_data.upgrades and tweak_data.upgrades.wild_trigger_time or 4
	B.biker_slots()
	table.insert(B.biker_kills, Application:time() + window)
	while #B.biker_kills > B.biker_max_slots() do
		table.remove(B.biker_kills, 1)
	end
end

function B.biker_burnout()
	return Application:time() < (B.biker_burnout_until or 0)
end

if script == "lib/managers/playermanager" then
	-- every kill feeds Momentum; Burnout: reaching max Momentum gives a damage burst
	local function on_wild_kill(pm, before)
		if B.biker_tier() < 1 then return end
		add_kill()
		if B.biker_tier() < 9 then return end
		local now = Application:time()
		local reached = before < B.biker_max_slots() and B.biker_slots() >= B.biker_max_slots()
		if reached and now >= (B.biker_burnout_ready or 0) then
			B.biker_burnout_until = now + C.burnout_time
			B.biker_burnout_ready = now + C.burnout_cd
		end
	end
	local orig_wild = PlayerManager.chk_wild_kill_counter
	function PlayerManager:chk_wild_kill_counter(...)
		local before = B.biker_slots()
		local r = orig_wild(self, ...)
		on_wild_kill(self, before)
		return r
	end

	-- Colors: less damage at 3+ Momentum
	local orig_resist = PlayerManager.damage_reduction_skill_multiplier
	function PlayerManager:damage_reduction_skill_multiplier(...)
		local m = orig_resist(self, ...)
		if type(m) ~= "number" then return m end
		if B.biker_tier() >= 7 and B.biker_slots() >= C.colors_slots then
			m = m * (1 - (B.on and C.colors_ds or C.colors))
		end
		return m
	end

	-- Chopper: faster per Momentum
	local orig_speed = PlayerManager.movement_speed_multiplier
	function PlayerManager:movement_speed_multiplier(...)
		local m = orig_speed(self, ...)
		if type(m) == "number" then
			local tier = B.biker_tier()
			if tier >= 5 then
				m = m * (1 + C.chopper * B.biker_slots())
			end
		end
		return m
	end

elseif script == "lib/units/enemies/cop/copdamage" then
	-- Road Rage (+damage per Momentum) and Burnout
	local function bonus(self, attack_data)
		if not attack_data or type(attack_data.damage) ~= "number" then return end
		local player = managers.player and managers.player:player_unit()
		if not (alive(player) and attack_data.attacker_unit == player) then return end
		local tier = B.biker_tier()
		if tier < 3 then return end
		local mul = 1 + B.biker_slots() * (B.on and C.road_rage_ds or C.road_rage)
		if tier >= 9 and B.biker_burnout() then mul = mul + C.burnout end
		if mul ~= 1 then attack_data.damage = attack_data.damage * mul end
	end
	for _, fn in ipairs({ "damage_bullet", "damage_melee" }) do
		Hooks:PreHook(CopDamage, fn, "GilzaDSBuffs_biker_" .. fn, function(self, attack_data)
			bonus(self, attack_data)
		end)
	end
end
