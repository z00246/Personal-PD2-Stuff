GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

B.EXPRES = {
	deck = 13,
	trail = 0.02,
	trail_ds = 0.03,
	trail_max = 5,
	trail_time = 10,
	service = 0.10,
	service_ds = 0.15,
	body_double = 0.25,
	body_double_time = 2,
	second_term_range = 1800,
	-- (7.24) Bodhi's signature (card 9, only as Bodhi): Thrill Seeker - while your armor is broken you move 25% faster,
	-- sprinting costs no stamina, and kills still store health, twice as much
	thrill_speed = 1.25, thrill_store = 2
}
local C = B.EXPRES

-- (7.24) Bodhi's Thrill Seeker: on while the armor is broken (and you're up)
function B.expres_thrill()
	if not (B.sig_active and B.sig_active(C.deck)) then return false end
	local unit = managers.player and managers.player:player_unit()
	local dmg = alive(unit) and unit:character_damage()
	if not dmg or dmg:need_revive() or dmg._dead then return false end
	return dmg:get_real_armor() <= 0
end

function B.expres_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == C.deck) then
		return 0
	end
	return st:get_specialization_value(C.deck, "tiers", "current_tier") or 0
end

local function player_dmg()
	local unit = managers.player and managers.player:player_unit()
	return alive(unit) and unit:character_damage() or nil
end

function B.expres_stored()
	local dmg = player_dmg()
	if not (dmg and dmg._armor_stored_health and dmg.max_armor_stored_health) then return 0, 0 end
	return dmg._armor_stored_health, dmg:max_armor_stored_health()
end

function B.expres_trail_stacks()
	if Application:time() >= (B.expres_trail_until or 0) then return 0 end
	return B.expres_trail or 0
end

if script == "lib/managers/playermanager" then
	-- Secret Service: less damage while you have stored health
	local orig_resist = PlayerManager.damage_reduction_skill_multiplier
	function PlayerManager:damage_reduction_skill_multiplier(...)
		local m = orig_resist(self, ...)
		if type(m) ~= "number" then return m end
		local ok, tier = pcall(B.expres_tier)
		if ok and tier >= 5 and B.expres_stored() > 0 then
			m = m * (1 - (B.on and C.service_ds or C.service))
		end
		if ok and tier >= 7 and Application:time() < (B.expres_bd_until or 0) then
			m = m * (1 - C.body_double)
		end
		return m
	end

	-- Campaign Trail: your kills while stored health is full stack damage
	Hooks:PostHook(PlayerManager, "on_killshot", "GilzaDSBuffs_expres_trail", function(self)
		pcall(function()
			if B.expres_tier() < 3 then return end
			local stored, max = B.expres_stored()
			if max <= 0 or stored < max - 0.001 then return end
			B.expres_trail = math.min(B.expres_trail_stacks() + 1, C.trail_max)
			B.expres_trail_until = Application:time() + C.trail_time
		end)
	end)

	-- (7.24) Bodhi's Thrill Seeker: faster while the armor is broken
	local orig_speed = PlayerManager.movement_speed_multiplier
	function PlayerManager:movement_speed_multiplier(...)
		local m = orig_speed(self, ...)
		if type(m) == "number" then
			local ok, on = pcall(B.expres_thrill)
			if ok and on then
				B.sig_live("thrill speed", "armor broken: moving x%.2f", C.thrill_speed)
				return m * C.thrill_speed
			end
		end
		return m
	end

	-- (7.24) Bodhi's Thrill Seeker: kills store health with the armor broken (the game only stores it while you have
	-- armor, so nothing is counted twice), twice the usual amount
	Hooks:PostHook(PlayerManager, "chk_store_armor_health_kill_counter", "GilzaDSBuffs_expres_thrill_store", function(self, killed_unit)
		pcall(function()
			if not (alive(killed_unit) and B.expres_thrill()) then return end
			if CopDamage.is_civilian(killed_unit:base()._tweak_table) then return end
			if not self:has_category_upgrade("player", "armor_health_store_amount") then return end
			local dmg = self:player_unit():character_damage()
			if dmg._check_berserker_done then return end
			local amount = self:upgrade_value("player", "armor_health_store_amount", 0) * C.thrill_store
			if amount > 0 then
				dmg:add_armor_stored_health(amount)
				B.sig_live("thrill store", "a kill with the armor broken stored %.1f health", amount * 10)
			end
		end)
	end)

elseif script == "lib/units/beings/player/playerdamage" then
	-- Second Term: stored health that doesn't fit is shared with your crew as healing
	local orig_add = PlayerDamage.add_armor_stored_health
	function PlayerDamage:add_armor_stored_health(amount, ...)
		local before = self._armor_stored_health or 0
		local result = orig_add(self, amount, ...)
		pcall(function()
			if B.expres_tier() < 9 or type(amount) ~= "number" then return end
			local max = self:max_armor_stored_health()
			local leftover = before + amount - max
			if leftover > 0 and B.team_heal then
				B.team_heal(math.min(leftover, amount), C.second_term_range, false)
			end
		end)
		return result
	end

	-- Body Double: stored health soaking a hit gives brief damage reduction.
	-- Also handles partial soaks correctly (Gilza's version let the full hit through once stored health ran out).
	local orig_calc = PlayerDamage._calc_health_damage
	function PlayerDamage:_calc_health_damage(attack_data, ...)
		local tier = B.expres_tier()
		local soaked = false
		if tier >= 7 and attack_data and type(attack_data.damage) == "number" and attack_data.damage > 0
			and (self._armor_stored_health or 0) > 0 and not (self:get_real_armor() > 0)
			and managers.player:has_category_upgrade("player", "armor_health_store_shield") then
			soaked = true
			local stored = self._armor_stored_health
			if stored < attack_data.damage then
				attack_data.damage = attack_data.damage - stored
				self._armor_stored_health = 0
				self:update_armor_stored_health()
				if managers.player.Gilza_new_expres_armor_regen_bonus_timer_on_kill_reset then
					managers.player:Gilza_new_expres_armor_regen_bonus_timer_on_kill_reset()
				end
			end
		end
		local result = orig_calc(self, attack_data, ...)
		if soaked then
			B.expres_bd_until = Application:time() + C.body_double_time
		end
		return result
	end

elseif script == "lib/units/beings/player/playermovement" then
	-- (7.24) Bodhi's Thrill Seeker: sprinting costs no stamina while the armor is broken
	local orig_sub = PlayerMovement.subtract_stamina
	if orig_sub then
		function PlayerMovement:subtract_stamina(value, ...)
			local ok, on = pcall(B.expres_thrill)
			if ok and on and self._is_running then
				B.sig_live("thrill stamina", "armor broken: sprinting costs no stamina")
				return
			end
			return orig_sub(self, value, ...)
		end
	end

elseif script == "lib/units/enemies/cop/copdamage" then
	local function trail(self, attack_data)
		if not attack_data or type(attack_data.damage) ~= "number" then return end
		local player = managers.player and managers.player:player_unit()
		if not (alive(player) and attack_data.attacker_unit == player) then return end
		local n = B.expres_trail_stacks()
		if n > 0 and B.expres_tier() >= 3 then
			attack_data.damage = attack_data.damage * (1 + n * (B.on and C.trail_ds or C.trail))
		end
	end
	for _, fn in ipairs({ "damage_bullet", "damage_melee" }) do
		Hooks:PreHook(CopDamage, fn, "GilzaDSBuffs_expres_" .. fn, function(self, attack_data)
			pcall(trail, self, attack_data)
		end)
	end

elseif script == "lib/tweak_data/skilltreetweakdata" then
	-- Secret Service replaces the static dodge
	Hooks:PostHook(SkillTreeTweakData, "init", "GilzaDSBuffs_expres_cards", function(self)
		local deck = self.specializations and self.specializations[C.deck]
		for _, card in pairs(deck or {}) do
			local ups = type(card) == "table" and card.upgrades
			if ups then
				for i = #ups, 1, -1 do
					if ups[i] == "player_static_dodge_chance" then table.remove(ups, i) end
				end
			end
		end
	end)
end
