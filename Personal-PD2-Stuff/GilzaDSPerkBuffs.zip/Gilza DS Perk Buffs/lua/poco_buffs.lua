GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs

local function card_icon(deck, card)
	local spec = tweak_data.skilltree.specializations[deck]
	local data = spec and spec[card]
	if not (data and data.icon_xy) then return end
	local folder = data.texture_bundle_folder
	local path = folder and ("guis/dlcs/" .. folder .. "/textures/pd2/specialization/icons_atlas") or "guis/textures/pd2/specialization/icons_atlas"
	return path, { data.icon_xy[1] * 64, data.icon_xy[2] * 64, 64, 64 }
end

local function poco_now()
	return managers.player:player_timer():time()
end


-- Combined "less likely to be targeted" multiplier for the local player.
-- Mirrors how enemies weigh targets (PlayerMovement attention settings + CopLogicIdle stand-still/crouch bonus).
function B.targeted_mul()
	local pm = managers.player
	local unit = pm and pm:player_unit()
	if not alive(unit) then return end
	local mul, best, src = 1, 0, nil
	local function take(v, deck, card)
		if type(v) ~= "number" or v == 1 then return end
		mul = mul * v
		local strength = math.abs(1 - v)
		if strength > best then
			best, src = strength, { deck, card }
		end
	end
	local server = Network:is_server()
	local host_mod = server or (B.host_has_mod and managers.network and B.host_has_mod == managers.network:session())
	local brawler = pm:has_category_upgrade("player", "damage_resist_brawler") and pm:has_category_upgrade("player", "uncover_multiplier")
	if not brawler then
		if pm:has_category_upgrade("player", "camouflage_bonus") then
			take(pm:upgrade_value("player", "camouflage_bonus", 1), "optic_illusions")
		end
		if pm:has_category_upgrade("player", "camouflage_multiplier") then
			local v = pm:upgrade_value("player", "camouflage_multiplier", 1)
			if not host_mod then v = 0.85 end
			take(v, 4, 3)
		end
	end
	if pm:has_category_upgrade("player", "uncover_multiplier") then
		local v = pm:upgrade_value("player", "uncover_multiplier", 1)
		-- Muscle card 3 Taunt: 50% instead of the game's 15%
		if B.muscle_tier and B.MUSCLE and B.muscle_tier() >= 3 then v = B.MUSCLE.taunt end
		take(v, 2, 3)
	end
	local state = unit:movement():current_state()
	if state and not state._moving and state.ducking and state:ducking() and pm:has_category_upgrade("player", "stand_still_crouch_camouflage_bonus") then
		take(pm:upgrade_value("player", "stand_still_crouch_camouflage_bonus", 1), 7, 3)
	end
	if not src then return 1 end
	return mul, src[1], src[2]
end

local active = {}

local function skill_icon(skill_id)
	local data = tweak_data.skilltree.skills and tweak_data.skilltree.skills[skill_id]
	if not (data and data.icon_xy) then return end
	return "guis/textures/pd2/skilltree_2/icons_atlas_2", { data.icon_xy[1] * 80, data.icon_xy[2] * 80, 80, 80 }
end

local function show(key, deck, card, good, text, until_t, ratio)
	local poco = rawget(_G, "PocoHud3")
	if not (poco and poco.Buff3 and poco.buffs) then return end
	local icon, rect
	if type(deck) == "string" then
		icon, rect = skill_icon(deck)
	else
		icon, rect = card_icon(deck, card)
	end
	local data = { key = key, good = good, icon = icon, iconRect = rect, text = text or "" }
	if ratio then
		-- as a table, the text is shown as it is: PocoHud doesn't add how full the ring is as a percentage
		-- (Combo 6 of 10 showed "CRIT x6 60%", which read like a 60% crit chance)
		data.text = { { (text and text ~= "") and text or " " } }
		data.st, data.et = math.clamp(ratio, 0, 1), 1
	else
		local remaining = until_t - Application:time()
		if remaining <= 0 then return end
		local now = poco_now()
		data.st, data.et = now, now + remaining
		local existing = poco.buffs[key]
		if existing and existing.data and existing.data.et and math.abs(existing.data.et - data.et) < 0.15 then
			active[key] = true
			return
		end
	end
	poco:Buff3(data)
	active[key] = true
end

local function hide(key)
	if not active[key] then return end
	active[key] = nil
	local poco = rawget(_G, "PocoHud3")
	if poco and poco.RemoveBuff then poco:RemoveBuff(key) end
end

local function timed(key, deck, card, good, until_t, text)
	if until_t and until_t > Application:time() then
		show(key, deck, card, good, text, until_t)
	else
		hide(key)
	end
end

function B.update_poco()
	local now = Application:time()

	if B.rogue_tier and B.rogue_tier() >= 3 and now < (B.rogue_stack_until or 0) and (B.rogue_stacks or 0) > 0 then
		show("gdb_rogue_stacks", 4, 3, true, "x" .. B.rogue_stacks, B.rogue_stack_until)
	else
		hide("gdb_rogue_stacks")
	end
	timed("gdb_rogue_riposte", 4, 7, true, B.rogue_riposte_until)
	-- (7.20) Rogue's Afterimage; Armorer's Reactive Plates and Hold Fast; Crew Chief's Squad
	timed("gdb_rogue_afterimage", 4, 9, true, B.rogue_ghost_until)
	if B.armorer_tier and B.armorer_tier() >= 1 then
		timed("gdb_armorer_reactive", 3, 1, true, B.armorer_reactive_until)
		timed("gdb_armorer_holdfast", 3, 7, true, B.armorer_holdfast_until)
	else
		hide("gdb_armorer_reactive"); hide("gdb_armorer_holdfast")
	end
	local squad = B.cc_squad and B.cc_squad() or 0
	if squad > 0 then
		show("gdb_cc_squad", 1, 1, true, "x" .. squad, nil, squad / ((B.CC and B.CC.max_allies) or 3))
	else
		hide("gdb_cc_squad")
	end

	if B.muscle_tier and B.muscle_tier() >= 1 and (B.rage or 0) > 0 then
		local max = B.muscle_max_stacks and B.muscle_max_stacks() or B.MUSCLE.max_stacks
		show("gdb_muscle_rage", 2, 1, true, "x" .. B.rage, nil, B.rage / math.max(max, 1))
	else
		hide("gdb_muscle_rage")
	end
	timed("gdb_muscle_unstoppable", 2, 9, true, B._unstoppable_until)
	-- a teammate's Bodyguard / Unstoppable on you
	local guard, unstop = 0, false
	pcall(function()
		local me = managers.player:player_unit()
		if alive(me) and B.muscle_cover then guard, unstop = B.muscle_cover(me:position(), me) end
	end)
	if (guard or 0) > 0 or unstop then
		local pct = math.floor((1 - (1 - (guard or 0)) * (unstop and (1 - B.MUSCLE.crew_resist) or 1)) * 100 + 0.5)
		show("gdb_muscle_guard", 2, unstop and 9 or 3, true, "-" .. pct .. "%", nil, 1)
	else
		hide("gdb_muscle_guard")
	end

	timed("gdb_crook_counter", 6, 7, true, B.crook_counter_until)
	timed("gdb_crook_slip", 6, 9, true, B.crook_slip_until)

	timed("gdb_cc_rally", 1, 5, true, B.cc_rally_until)

	-- Hitman (7.18): your Contract's time left, Hit List Streaks, Untouchable; (7.19) the second Contract's time left
	-- with card 3's dual-pistol icon (Twin Contracts)
	local hm = B.hitman_tier and B.hitman_tier() or 0
	if hm >= 1 then
		timed("gdb_hitman_contract", 5, 1, true, B.hitman_contract and B.hitman_contract() and B.hm_contract and B.hm_contract.until_t or nil)
		timed("gdb_hitman_twin", 5, 3, true, B.hitman_twin and B.hitman_twin() and B.hm_twin and B.hm_twin.until_t or nil)
		if hm >= 5 and (B.hm_streak or 0) > 0 and (B.hm_streak_until or 0) > now then
			show("gdb_hitman_streak", 5, 5, true, "x" .. B.hm_streak, B.hm_streak_until)
		else
			hide("gdb_hitman_streak")
		end
		timed("gdb_hitman_untouch", 5, 7, true, B.hm_untouch_until)
	else
		hide("gdb_hitman_contract"); hide("gdb_hitman_twin"); hide("gdb_hitman_streak"); hide("gdb_hitman_untouch")
	end

	local crit = B.gambler_crit or 0
	if crit ~= 0 then
		local c = B.crit_values and B.crit_values() or { cap = 0.3 }
		-- (7.21: rounded the same way both sides; -30% used to show as -31%)
		show("gdb_gambler_crit", 10, 1, crit > 0, string.format("%+d%%", math.floor(crit * 100 + 0.5)), nil, math.abs(crit) / c.cap)
	else
		hide("gdb_gambler_crit")
	end
	-- (7.21) Gambler: the time until your next roll
	timed("gdb_gambler_roll", 10, 1, false, B.gambler_next_roll)

	-- Burglar: Ghost (loud, unless you just fired an unsuppressed gun), Slip Away / Fade Out / Wraith while they hide you
	-- (Geo HUD shows these in its ability slot instead)
	if B.burglar_tier and B.burglar_tier() >= 1 and B.burglar_slot and not rawget(_G, "GeoHUD") then
		local st, left, total = B.burglar_slot()
		local fading = now < (B.burg_fade_until or 0)
		local slipping = now < (B.burg_slip_until or 0)
		local wraith = now < (B.burg_wraith_until or 0)
		if st == "active" and not (fading or slipping or wraith) then
			show("gdb_burg_ghost", 7, 1, true, "", nil, 1)
		else
			hide("gdb_burg_ghost")
		end
		timed("gdb_burg_exposed", 7, 1, false, st == "cooldown" and (B.burg_exposed_until or 0) > now and B.burg_exposed_until or nil)
		timed("gdb_burg_fade", 7, 9, true, fading and B.burg_fade_until or nil)
		timed("gdb_burg_slip", 7, 7, true, slipping and B.burg_slip_until or nil)
		timed("gdb_burg_wraith", 7, 9, true, wraith and B.burg_wraith_until or nil)
		timed("gdb_burg_second", 7, 7, false, B.burglar_tier() >= 7 and B.burg_second_ready or nil)
	else
		for _, k in ipairs({ "gdb_burg_ghost", "gdb_burg_exposed", "gdb_burg_fade", "gdb_burg_slip", "gdb_burg_wraith", "gdb_burg_second" }) do hide(k) end
	end

	local tmul, tdeck, tcard = B.targeted_mul()
	if tmul and math.abs(tmul - 1) > 0.001 then
		local pct = math.floor((1 - tmul) * 100 + 0.5)
		local text = pct > 0 and ("-" .. pct .. "%") or ("+" .. (-pct) .. "%")
		local key_text = text .. tostring(tdeck) .. tostring(tcard)
		if B._targeted_last ~= key_text then
			hide("gdb_targeted")
			B._targeted_last = key_text
		end
		show("gdb_targeted", tdeck, tcard, tmul < 1, text, nil, 1)
	else
		B._targeted_last = nil
		hide("gdb_targeted")
	end

	if B.infil_tier and B.infil_tier() >= 3 and (B.infil_close or 0) > 0 then
		local max = B.infil_close_max and B.infil_close_max(B.infil_tier()) or 0
		show("gdb_infil_close", 8, 3, true, "-" .. math.floor(B.infil_close * 100 + 0.5) .. "%", nil, max > 0 and B.infil_close / max or 1)
	else
		hide("gdb_infil_close")
	end
	local ex = B.infil_last_exposed
	timed("gdb_infil_exposed", 8, 5, true, alive(ex) and B.infil_exposed and B.infil_exposed[ex:key()] or nil)
	timed("gdb_infil_melt", 8, 7, true, B.infil_melt_until)

	local gstacks = B.grinder_tier and B.grinder_tier() >= 1 and B.grinder_stacks() or 0
	if gstacks > 0 then
		local cap = B.grinder_cap()
		local n = math.min(gstacks, cap)
		local text = "x" .. n
		-- (7.22: 5% a stack while Engorged)
		local per = B.grinder_bloodlust_per and B.grinder_bloodlust_per() or B.GRINDER.bloodlust
		if B.grinder_tier() >= 3 then text = text .. " +" .. math.floor(n * per * 100 + 0.5) .. "%" end
		show("gdb_grinder_stacks", 11, 1, true, text, nil, n / cap)
	else
		hide("gdb_grinder_stacks")
	end
	-- (7.22) Grinder's Overheal: "+N" with a ring for how full it is (Geo HUD draws it on the health bar instead)
	local over = B.grinder_overheal or 0
	if over > 0 and not rawget(_G, "GeoHUD") then
		local unit = managers.player:player_unit()
		local dmg = alive(unit) and unit:character_damage()
		local cap = dmg and B.grinder_eff_max and B.grinder_eff_max(dmg) * B.grinder_overheal_frac() or 0
		show("gdb_grinder_overheal", 11, 5, true, "+" .. math.floor(over * 10 + 0.5), nil, cap > 0 and over / cap or 1)
	else
		hide("gdb_grinder_overheal")
	end

	local bl = B.yakuza_bloodied and B.yakuza_bloodied() or 0
	if bl > 0 then
		-- (7.23: 25% » 35% with the difficulty)
		local max = B.yakuza_bloodied_max and B.yakuza_bloodied_max() or B.YAKUZA.bloodied
		show("gdb_yakuza_bloodied", 12, 3, true, "+" .. math.floor(bl * 100 + 0.5) .. "%", nil, bl / max)
	else
		hide("gdb_yakuza_bloodied")
	end
	-- (7.23) Oni: the 6 s after Last Stand, next to the Last Stand cooldown
	timed("gdb_yakuza_oni", 12, 5, true, B.yakuza_oni and B.yakuza_oni() and B.yakuza_oni_until or nil, "Oni")
	if B.yakuza_tier and B.yakuza_tier() >= 5 then
		if Application:time() < (B.yakuza_ls_ready or 0) then
			show("gdb_yakuza_laststand", 12, 5, false, "", B.yakuza_ls_ready)
		else
			show("gdb_yakuza_laststand", 12, 5, true, "", nil, 1)
		end
	else
		hide("gdb_yakuza_laststand")
	end

	local trail = B.expres_trail_stacks and B.expres_trail_stacks() or 0
	if trail > 0 and B.expres_tier() >= 3 then
		show("gdb_expres_trail", 13, 3, true, "x" .. trail, B.expres_trail_until)
	else
		hide("gdb_expres_trail")
	end
	timed("gdb_expres_bd", 13, 7, true, B.expres_bd_until)
	if B.expres_tier and B.expres_tier() >= 5 and B.expres_stored() > 0 then
		show("gdb_expres_service", 13, 5, true, "", nil, 1)
	else
		hide("gdb_expres_service")
	end

	if B.maniac_tier and B.maniac_tier() >= 1 then
		local n = B.maniac_stacks()
		if n > 0 then
			local text = tostring(n)
			if B.maniac_rush() then text = text .. " RUSH" elseif B.maniac_habit() then text = text .. " HABIT" end
			show("gdb_maniac_stacks", 14, 1, true, text, nil, n / 600)
		else
			hide("gdb_maniac_stacks")
		end
	else
		hide("gdb_maniac_stacks")
	end
	timed("gdb_maniac_comedown", 14, 9, true, (B.maniac_comedown and B.maniac_comedown() > 0) and B.maniac_cd_until or nil)

	if B.anar_tier and B.anar_tier() >= 1 then
		if B.anar_riot() then show("gdb_anar_riot", 15, 3, true, "", nil, 1) else hide("gdb_anar_riot") end
		timed("gdb_anar_bloc", 15, 7, true, B.anar_bloc() and B.anar_bloc_until or nil)
		local cd = B.anar_invuln_cd()
		timed("gdb_anar_cd", 15, 1, false, cd > 0 and (Application:time() + cd) or nil)
	else
		hide("gdb_anar_riot"); hide("gdb_anar_bloc"); hide("gdb_anar_cd")
	end

	if B.biker_tier and B.biker_tier() >= 3 then
		local n = B.biker_slots()
		if n > 0 then
			show("gdb_biker_momentum", 16, 3, true, n .. "/" .. B.biker_max_slots() .. " +" .. math.floor(n * (B.on and B.BIKER.road_rage_ds or B.BIKER.road_rage) * 100 + 0.5) .. "%", nil, n / B.biker_max_slots())
		else
			hide("gdb_biker_momentum")
		end
		if B.biker_tier() >= 7 and n >= B.BIKER.colors_slots then show("gdb_biker_colors", 16, 7, true, "", nil, 1) else hide("gdb_biker_colors") end
		timed("gdb_biker_burnout", 16, 9, true, B.biker_burnout() and B.biker_burnout_until or nil)
	else
		hide("gdb_biker_momentum"); hide("gdb_biker_colors"); hide("gdb_biker_burnout")
	end

	if B.kp_tier and B.kp_tier() >= 3 and B.kp_active() then
		show("gdb_kp_injector", 17, 3, true, "", B.kp_injector_until())
	else
		hide("gdb_kp_injector")
	end
	timed("gdb_kp_withdrawal", 17, 9, true, B.kp_withdrawal and B.kp_withdrawal() and B.kp_withdrawal_until or nil)

	if B.sic_tier and B.sic_tier() >= 5 and B.sic_in_my_smoke(managers.player:player_unit()) then
		show("gdb_sic_haze", 18, 5, true, "", nil, 1)
	else
		hide("gdb_sic_haze")
	end

	local grit = B.stoic_grit and B.stoic_grit() or 0
	if grit > 0.005 then
		local max = B.on and B.STOIC.grit_ds or B.STOIC.grit
		show("gdb_stoic_grit", 19, 3, true, "+" .. math.floor(grit * 100 + 0.5) .. "%", nil, grit / max)
	else
		hide("gdb_stoic_grit")
	end
	timed("gdb_stoic_composure", 19, 5, true, B.stoic_composure and B.stoic_composure() and B.stoic_composure_until or nil)

	if B.tt_tier and B.tt_tier() >= 1 and B.tt_linked() then
		show("gdb_tt_link", 20, 1, true, "", nil, 1)
	else
		hide("gdb_tt_link")
	end
	timed("gdb_tt_lifeline", 20, 5, true, B.tt_lifeline and B.tt_lifeline() and B.tt_lifeline_until or nil)

	if (B.socio_hold or 0) > 0 then
		show("gdb_socio_hold", 9, 3, true, math.floor(B.socio_hold * 100 + 0.5) .. "%", nil, B.socio_hold / B.SOCIO.hold_max)
	else
		hide("gdb_socio_hold")
	end
	local socio = B.socio_tier and B.socio_tier() or 0
	if socio >= 1 and (B.frenzy or 0) > 0 then
		local max = B.socio_frenzy_max and B.socio_frenzy_max() or 5
		show("gdb_socio_frenzy", 9, 1, true, "x" .. B.frenzy, nil, B.frenzy / math.max(max, 1))
	else
		hide("gdb_socio_frenzy")
	end
	if socio >= 5 and (B.combo or 0) > 0 then
		local massacre = B.socio_massacre and B.socio_massacre()
		show("gdb_socio_combo", 9, massacre and 9 or 5, true, (massacre and "CRIT " or "") .. "x" .. B.combo, nil, B.combo / B.SOCIO.combo_max)
	else
		hide("gdb_socio_combo")
	end
	if socio >= 7 and (B.hard_level or 0) > 0 then
		show("gdb_socio_hardened", 9, 7, true, "-" .. math.floor(B.hard_level * B.SOCIO.hard_step * 100 + 0.5) .. "%", nil, B.hard_level / B.SOCIO.hard_levels)
	else
		hide("gdb_socio_hardened")
	end
end

Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_poco", function(t)
	if t and B._poco_next and t < B._poco_next then return end
	B._poco_next = (t or 0) + 0.2
	local ok, err = pcall(B.update_poco)
	if not ok and not B._poco_err then
		B._poco_err = true
		log("[Gilza DS Perk Buffs] PocoHud buffs error: " .. tostring(err))
	end
end)
