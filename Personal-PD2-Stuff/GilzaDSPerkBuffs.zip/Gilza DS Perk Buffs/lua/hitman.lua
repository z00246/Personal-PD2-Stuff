GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

-- difficulty scaling (shared with buffs.lua): t = 0 up to Overkill, 1/3 Mayhem, 2/3 Death Wish, 1 Death Sentence
if not B.diff_t then
	B.DIFF_T = { easy_wish = 1 / 3, overkill_290 = 2 / 3, sm_wish = 1 }
	function B.diff_t()
		local gs = Global and Global.game_settings
		return gs and B.DIFF_T[gs.difficulty] or 0
	end
	function B.sc(base, ds) return base + (ds - base) * B.diff_t() end
	function B.sci(base, ds) return math.floor(base + (ds - base) * B.diff_t() + 0.5) end
end

-- a line in the BLT log the first times a feature does something (buffs.lua)
local function live(key, ...) if B.live then B.live("hitman " .. key, ...) end end

-- Hitman (7.18 rework v2, Geo 2026-10-25: "is there a way to make the contract a bit more buffed then?" - "I meant he
-- should get buffed himself, the enemy" - "also make sure his contour is the same as whatever the player color is";
-- the money effect: "what about the money one"; approved with "yeah this is all fine"). Replaces Gilza's Hitman cards
-- (Master of Arms, the akimbo card, Rhythm of Death, Bounty Hunter) and the 6.x armor-overflow card.
--  card 1 Contract: the nearest enemy you can see within 30 m becomes your Contract, outlined in your player colour for
--   you only (specials first, never Bulldozers or Captain Winters). A new one after 20 s, or when someone else kills him.
--   He takes 20% » 30% less damage from you and deals 20% » 30% more to you. Killing him (any weapon) restores
--   25% » 35% of your armor and marks the next one at once. +5% armor (Gilza's player_tier_armor_multiplier_1).
--   Bills drift off his chest while he is your Contract and burst out when you kill him (our own effects, local).
--  card 3 Clean Kill: headshot kills restore 10% armor, at most every 0.5 s; your headshots ignore the toughness.
--  card 5 Hit List: each Contract kill = 1 Streak (max 5): +5% damage and 5% faster armor recovery per Streak; all
--   lost after 15 » 20 s without a Contract kill.
--  card 7 Untouchable: a Contract kill makes you unable to take damage for 1.5 » 2 s, at most every 15 s.
--  card 9 Tooth and Claw: armor recovers 1.5 s after breaking (the game's), a Contract kill while your armor is broken
--   brings it back at once; completion bonus.
-- 7.19 rework v3 (Geo 2026-10-25: "shouldnt hitman have some more dual wielding stuff since one of his perks have an
-- image of that or a perk icon?" - "something else with dual wielding, think of something" - "should give card 5
-- somethign too" - "unless you make it where if I wear a certain armor I get better stats" - "I believe it should be %
-- based and I dont think you should give two piece armor since its basically useless" - "maybe some adequate dodge for
-- suit" - "yea this is fine"): dual wielding on cards 3, 5 and 9 (the two cards with the dual-pistol icons and card 5),
-- light armor on card 7.
--  card 3 Twin Contracts: while you hold a dual-wielded weapon you have 2 Contracts at once: the second is picked the
--   same way, is just as tough and pays out the same. With the dual-wielded weapon put away no new second one is
--   picked (the one you have stays until it dies or runs out, and moves up when the first one is gone).
--  card 5 Hot Streak: a dual-wielded weapon in your hands fires 5% faster per Streak.
--  card 7 Tailored: in the Lightweight Ballistic Vest +40% » 80% armor, and the armor this deck gives back is doubled
--   (a Contract kill 50% » 70%, Clean Kill 20%, 10% faster armor recovery per Streak). Black Tie: in the Two-piece
--   Suit +20% » 30% dodge.
--  card 9 Gun Kata: dual-wielded weapons reload 20% » 30% faster, and a shot of theirs that hits one of your Contracts
--   goes back into the magazine.
-- 7.24 (Geo 2026-10-26: "we do need to nerf hitman a bit because theres no cooldowns on contracts, also the contract
-- kind of blends in with the outlines of jokers" - picked 5 seconds and purple): after you kill a Contract the next one
-- is marked 5 s later (each Contract you kill starts its own 5 s, so with Twin Contracts each one waits); one that runs
-- out or someone else kills is still replaced at once. The outline is purple for everyone instead of your player colour.
-- (7.36: John Wick's Baba Yaga signature is gone with the other signatures - Geo: "remove the signatures")
-- *_ds values are the Death Sentence end of the difficulty scale (B.sc).
B.HITMAN = {
	deck = 5,
	range = 3000,              -- the Contract is picked within 30 m...
	cone = 0.35,               -- ...in front of you (cosine of the angle off your view, ~70 degrees)
	checks = 12,               -- line-of-sight checks per look, nearest first
	scan_every = 0.25,
	expire = 20,               -- a new Contract after 20 s
	skip = 10,                 -- an expired Contract isn't picked again for 10 s
	cooldown = 5,              -- (7.24) the next Contract comes this long after you kill one
	outline = { 165 / 255, 80 / 255, 1 },   -- (7.24) purple
	tough = 0.20, tough_ds = 0.30,     -- he takes this much less damage from you
	hits = 0.20, hits_ds = 0.30,       -- he deals this much more damage to you
	refill = 0.25, refill_ds = 0.35,   -- share of max armor a Contract kill restores
	clean = 0.10, clean_every = 0.5,   -- card 3 Clean Kill
	streak_max = 5, streak_dmg = 0.05, streak_regen = 0.05,
	streak_time = 15, streak_time_ds = 20,
	untouch = 1.5, untouch_ds = 2, untouch_every = 15,
	puff_every = 0.45,         -- a puff of 4 bills off his chest this often (~9 bills a second)
	rof = 0.05,                                     -- card 5 Hot Streak: fire rate per Streak, dual-wielded
	vest = "level_2", vest_armor = 0.40, vest_armor_ds = 0.80, vest_give = 2,   -- card 7 Tailored
	suit = "level_1", suit_dodge = 0.20, suit_dodge_ds = 0.30,                  -- card 7 Black Tie
	kata_reload = 0.20, kata_reload_ds = 0.30       -- card 9 Gun Kata
}
local C = B.HITMAN
B.hm_skip = B.hm_skip or {}
B.hm_streak = B.hm_streak or 0
B.hm_cool = B.hm_cool or {}   -- (7.24) when each killed Contract's 5 s wait ends

-- (7.24) the waits still running (drops the finished ones)
function B.hitman_cooling(now)
	now = now or Application:time()
	for i = #B.hm_cool, 1, -1 do
		if B.hm_cool[i] <= now then table.remove(B.hm_cool, i) end
	end
	return #B.hm_cool
end

-- (7.24) when the next Contract can come, while you have fewer than you could (nil otherwise)
function B.hitman_next_contract()
	if B.hitman_cooling() == 0 or B.hm_contract then return nil end
	local first
	for _, t in ipairs(B.hm_cool) do
		if not first or t < first then first = t end
	end
	return first
end

-- your Contracts: the deck's own (B.hm_contract) and, from card 3 while you hold a dual-wielded weapon, a second one
-- (B.hm_twin); each { unit, key, until_t, puff_t }
B.HM_SLOTS = { "hm_contract", "hm_twin" }

function B.hitman_tier()
	local st = managers.skilltree
	if not (st and st:get_specialization_value("current_specialization") == C.deck) then
		return 0
	end
	return st:get_specialization_value(C.deck, "tiers", "current_tier") or 0
end

-- the Contract unit while there is one
function B.hitman_contract()
	local c = B.hm_contract
	return c and alive(c.unit) and c.unit or nil
end

-- the second Contract (card 3 Twin Contracts) while there is one
function B.hitman_twin()
	local c = B.hm_twin
	return c and alive(c.unit) and c.unit or nil
end

-- which of your Contracts this unit is ("hm_contract" / "hm_twin"), or nil
function B.hitman_slot(unit)
	if unit == nil then return nil end
	for _, slot in ipairs(B.HM_SLOTS) do
		local c = B[slot]
		if c and c.unit == unit then return slot end
	end
	return nil
end

-- a dual-wielded weapon: the game's akimbo weapons (AkimboWeaponBase and everything built on it, both guns)
function B.hitman_akimbo(base)
	if type(base) ~= "table" then return false end
	if base.AKIMBO then return true end
	return base.is_category and base:is_category("akimbo") and true or false
end

-- the weapon in your hands is dual-wielded
function B.hitman_holding_akimbo()
	local pm = managers.player
	local player = pm and pm:player_unit()
	if not alive(player) then return false end
	local inv = player:inventory()
	local w = inv and inv:equipped_unit()
	return alive(w) and B.hitman_akimbo(w:base()) or false
end

-- the armor you wear (the game's own check: an unused armor kit is the suit), or the one the inventory asks about
function B.hitman_armor(override_armor)
	return override_armor or (managers.blackmarket and managers.blackmarket:equipped_armor(true, true))
end

-- card 7 Tailored: in the Lightweight Ballistic Vest the armor this deck gives back is doubled
function B.hitman_give()
	if B.hitman_tier() >= 7 and B.hitman_armor() == C.vest then return C.vest_give end
	return 1
end

local function is_head(cop_damage, attack_data)
	local body = attack_data and attack_data.col_ray and attack_data.col_ray.body
	return (cop_damage._head_body_name and cop_damage._ids_head_body_name and body and alive(body)
		and body:name() == cop_damage._ids_head_body_name) and true or false
end

if script == "lib/managers/playermanager" then
	------------------------------------------------------------------ the outline: purple (7.24), you only
	local function contract_color()
		return Vector3(C.outline[1], C.outline[2], C.outline[3])
	end

	local function contract_type()
		local types = ContourExt and ContourExt._types
		if not types then return nil end
		if not types.gdsb_contract then
			-- priority 2: shown over marks (4-5), under a Medic's heal flash (1); swaps to the contour material like
			-- the game's own enemy marks; unique: adding it twice doesn't stack
			types.gdsb_contract = { priority = 2, material_swap_required = true, unique = true, color = contract_color() }
		end
		return "gdsb_contract"
	end

	------------------------------------------------------------------ the money (our own effects, local)
	local IDS_EFFECT, IDS_TEXTURE = Idstring("effect"), Idstring("texture")
	local FX_PUFF = Idstring("effects/gilza/contract_money")
	local FX_PAYOUT = Idstring("effects/gilza/contract_payout")
	local BILL = Idstring("effects/textures/dollar_bill_effect_edf")
	local IDS_SPINE = Idstring("Spine2")

	-- a file the game has, or one BeardLib added from add.xml (our two effects)
	local function in_db(ext, path)
		if DB:has(ext, path) then return true end
		local fm = rawget(_G, "BeardLib") and BeardLib.Managers and BeardLib.Managers.File
		return fm and fm.Has and fm:Has(ext, path) and true or false
	end

	-- loads the bill texture and both effects once (synchronously: a nil callback), only what the database has; if
	-- anything is missing the money just doesn't show (a live line says why)
	local function load_fx()
		local dr = managers.dyn_resource
		local pkg = dr and dr.DYN_RESOURCES_PACKAGE
		if not (dr and dr.load and pkg) then return false, "no dynamic resource manager" end
		for _, r in ipairs({ { IDS_TEXTURE, BILL }, { IDS_EFFECT, FX_PUFF }, { IDS_EFFECT, FX_PAYOUT } }) do
			if not PackageManager:has(r[1], r[2]) then
				if not in_db(r[1], r[2]) then return false, "not in the database: " .. tostring(r[2]) end
				dr:load(r[1], r[2], pkg, nil)
				-- never spawn an effect the game doesn't have loaded
				if not PackageManager:has(r[1], r[2]) then return false, "didn't load: " .. tostring(r[2]) end
			end
		end
		return true
	end
	local function fx_ready()
		if B._hm_fx ~= nil then return B._hm_fx end
		B._hm_fx = false
		local ok, err = load_fx()
		B._hm_fx = ok
		if ok then live("money", "the money effects are loaded") else live("money failed", "no money effects: %s", tostring(err)) end
		return ok
	end

	local function chest(unit)
		local obj = unit:get_object(IDS_SPINE)
		if obj then return obj:position() end
		local mov = unit:movement()
		return mov and mov.m_com and mov:m_com() or unit:position()
	end

	local function spawn(fx, unit)
		if not (alive(unit) and fx_ready()) then return false end
		World:effect_manager():spawn({ effect = fx, position = chest(unit), normal = math.UP })
		return true
	end

	------------------------------------------------------------------ card 1: picking the Contract
	local function usable(u, now)
		if not alive(u) then return false end
		local dmg = u:character_damage()
		if not dmg or dmg._dead or (dmg.dead and dmg:dead()) then return false end
		local brain = u.brain and u:brain()
		if brain and ((brain.is_hostage and brain:is_hostage()) or (brain.converted and brain:converted())) then return false end
		return true
	end

	local function excluded(u)
		local base = u:base()
		local tt = base and base._tweak_table or ""
		if tt == "phalanx_vip" or tt:sub(1, 4) == "tank" then return true end
		return base and base.has_tag and (base:has_tag("tank") or base:has_tag("captain")) or false
	end

	local function is_special(u)
		local base = u:base()
		if base and base.has_tag and base:has_tag("special") then return true end
		local ct = base and tweak_data.character and tweak_data.character[base._tweak_table]
		return ct and ct.priority_shout ~= nil or false
	end

	-- not_unit: your other Contract (the second one is never the first one)
	local tmp = Vector3()
	local function pick(now, player, not_unit)
		if not (managers.slot and managers.enemy) then return nil end
		local cam = player.camera and player:camera()
		local pmov = player:movement()
		local from = cam and cam:position() or (pmov and pmov:m_head_pos())
		if not from then return nil end
		local fwd = cam and cam:forward()
		local mask = managers.slot:get_mask("enemies")
		local list = {}
		for _, data in pairs(managers.enemy:all_enemies() or {}) do
			local u = data.unit
			if u ~= not_unit and usable(u, now) and u:in_slot(mask) and not excluded(u) and (B.hm_skip[u:key()] or 0) <= now then
				local mov = u:movement()
				local head = mov and mov:m_head_pos() or u:position()
				local d = mvector3.distance(from, head)
				if d <= C.range then
					local ahead = true
					if fwd and d > 1 then
						mvector3.set(tmp, head)
						mvector3.subtract(tmp, from)
						mvector3.normalize(tmp)
						ahead = mvector3.dot(tmp, fwd) >= C.cone
					end
					if ahead then list[#list + 1] = { u = u, d = d, special = is_special(u) } end
				end
			end
		end
		if #list == 0 then return nil end
		table.sort(list, function(a, b)
			if a.special ~= b.special then return a.special end
			return a.d < b.d
		end)
		local vis = managers.slot:get_mask("AI_visibility")
		for i = 1, math.min(#list, C.checks) do
			local u = list[i].u
			local mov = u:movement()
			local head = mov and mov:m_head_pos()
			local seen = head and not World:raycast("ray", from, head, "slot_mask", vis, "ray_type", "ai_vision", "report")
			if head and not seen and mov.m_com then
				seen = not World:raycast("ray", from, mov:m_com(), "slot_mask", vis, "ray_type", "ai_vision", "report")
			end
			if seen then return u, list[i].d, list[i].special end
		end
		return nil
	end

	local function clear_contract(slot)
		local c = B[slot]
		B[slot] = nil
		-- the outline stays on a unit that is still your other Contract (never the case, but never strip it)
		if c and alive(c.unit) and not B.hitman_slot(c.unit) then
			local ce = c.unit.contour and c.unit:contour()
			local types = ContourExt and ContourExt._types
			if ce and ce.remove and types and types.gdsb_contract then ce:remove("gdsb_contract", false) end
		end
	end

	local function clear_all()
		for _, slot in ipairs(B.HM_SLOTS) do clear_contract(slot) end
	end
	B.hitman_clear_contract = clear_all

	local function set_contract(slot, u, now, d, special)
		clear_contract(slot)
		B[slot] = { unit = u, key = u:key(), until_t = now + C.expire, puff_t = now }
		local ce = u.contour and u:contour()
		local ty = contract_type()
		local ok, err = false, "no contour extension"
		if ce and ce.add and ty then
			ce:add(ty, false, nil, contract_color())
			ok = true
		end
		local base = u:base()
		live(slot == "hm_twin" and "twin" or "contract", "marked a %s%s %.1f m away", special and "special " or "",
			tostring(base and base._tweak_table), (d or 0) / 100)
		if not ok then live("outline failed", "couldn't outline the Contract: %s", tostring(err)) end
	end

	local function reset()
		clear_all()
		B.hm_skip = {}
		B.hm_cool = {}
		B.hm_streak, B.hm_streak_until = 0, nil
		B.hm_untouch_until, B.hm_untouch_ready = nil, nil
		B._hm_clean_next, B._hm_scan_t = nil, nil
		B._hm_fx = nil
		B._hm_shot = nil
	end

	local function update()
		local session = managers.network and managers.network:session()
		if B._hm_session ~= session then
			B._hm_session = session
			reset()
		end
		local now = Application:time()
		local tier = B.hitman_tier()
		local player = managers.player and managers.player:player_unit()
		if tier < 1 or not alive(player) then
			if B.hm_contract or B.hm_twin then clear_all() end
			return
		end
		-- card 5: the Streaks run out
		if (B.hm_streak or 0) > 0 and now >= (B.hm_streak_until or 0) then
			live("streak lost", "%d Streaks ran out", B.hm_streak)
			B.hm_streak, B.hm_streak_until = 0, nil
		end
		-- each Contract: gone, run out, or another puff of bills
		for _, slot in ipairs(B.HM_SLOTS) do
			local c = B[slot]
			if c then
				local u = c.unit
				if not usable(u, now) then
					-- dead without our kill (someone else), cuffed, converted or gone: the next one at once
					if alive(u) and u:character_damage() and (u:character_damage()._dead or u:character_damage():dead()) then
						live("lost", "someone else killed your Contract")
					end
					clear_contract(slot)
					B._hm_scan_t = nil
				elseif now >= c.until_t then
					B.hm_skip[c.key] = now + C.skip
					live("expired", "the Contract lived %d seconds, picking another", C.expire)
					clear_contract(slot)
					B._hm_scan_t = nil
				elseif now >= c.puff_t then
					c.puff_t = now + C.puff_every
					if spawn(FX_PUFF, u) then live("money puff", "bills off the Contract's chest") end
				end
			end
		end
		-- the second one moves up when the first one is gone
		if not B.hm_contract and B.hm_twin then
			B.hm_contract, B.hm_twin = B.hm_twin, nil
		end
		-- card 3 Twin Contracts: a second one only while you hold a dual-wielded weapon
		local twin = tier >= 3 and B.hitman_holding_akimbo()
		if B.hm_contract and (B.hm_twin or not twin) then return end
		-- (7.24) each Contract you killed keeps its place empty for 5 s
		local free = (twin and 2 or 1) - (B.hm_contract and 1 or 0) - (B.hm_twin and 1 or 0) - B.hitman_cooling(now)
		if free <= 0 then return end
		if now < (B._hm_scan_t or 0) then return end
		B._hm_scan_t = now + C.scan_every
		if not B.hm_contract then
			local u, d, special = pick(now, player, nil)
			if u then
				set_contract("hm_contract", u, now, d, special)
				free = free - 1
			end
		end
		if free > 0 and twin and B.hm_contract and not B.hm_twin then
			local u, d, special = pick(now, player, B.hm_contract.unit)
			if u then set_contract("hm_twin", u, now, d, special) end
		end
	end

	Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_hitman_update", function()
		update()
	end)

	------------------------------------------------------------------ kills: Contract, Clean Kill, Hit List, Untouchable, Tooth and Claw
	local function on_kill(pm, killed, variant, headshot)
		local tier = B.hitman_tier()
		if tier < 1 or not alive(killed) then return end
		local base = killed:base()
		if base and CopDamage.is_civilian and CopDamage.is_civilian(base._tweak_table) then return end
		local player = pm:player_unit()
		local dmg = alive(player) and player:character_damage()
		if not dmg or dmg._dead or (dmg.dead and dmg:dead()) then return end
		local now = Application:time()
		-- card 7 Tailored: twice the armor back in the Lightweight Ballistic Vest
		local give = B.hitman_give()
		-- card 3 Clean Kill: a headshot kill with any weapon (melee headshots too)
		if tier >= 3 and (headshot or (variant == "melee" and B._hm_melee_head == killed)) and now >= (B._hm_clean_next or 0) then
			B._hm_clean_next = now + C.clean_every
			dmg:restore_armor(dmg:_max_armor() * C.clean * give)
			live("clean kill", "a %s headshot kill restored %d%% armor", tostring(variant), math.floor(C.clean * give * 100 + 0.5))
		end
		local slot = B.hitman_slot(killed)
		if not slot then return end
		-- a Contract (either one): the payout, then the next one 5 s later (7.24)
		if spawn(FX_PAYOUT, killed) then live("payout", "bills burst out of the Contract") end
		clear_contract(slot)
		B._hm_scan_t = nil
		table.insert(B.hm_cool, now + C.cooldown)
		live("contract cooldown", "the next Contract in %d seconds", C.cooldown)
		if slot == "hm_twin" then live("twin kill", "you killed your second Contract") end
		local broken = dmg:get_real_armor() <= 0
		if tier >= 9 and broken and not (dmg._bleed_out or dmg._check_berserker_done) then
			-- card 9 Tooth and Claw: broken armor comes back at once (7.25: the game's own refill, PlayerDamage's
			-- _regenerate_armor - 7.19-7.24 called regenerate_armor, which doesn't exist, so the pcall swallowed the
			-- error and the armor never came back)
			if dmg._regenerate_armor then
				dmg:_regenerate_armor()
			else
				dmg:restore_armor(dmg:_max_armor())
			end
			live("tooth and claw", "a Contract kill brought the broken armor back")
		else
			local share = B.sc(C.refill, C.refill_ds) * give
			dmg:restore_armor(dmg:_max_armor() * share)
			live("contract kill", "a %s kill restored %.1f%% armor", tostring(variant), share * 100)
		end
		if give > 1 then live("tailored", "the Lightweight Ballistic Vest doubled the armor back") end
		-- card 5 Hit List
		if tier >= 5 then
			B.hm_streak = math.min((B.hm_streak or 0) + 1, C.streak_max)
			B.hm_streak_until = now + B.sc(C.streak_time, C.streak_time_ds)
			live("streak", "%d Streaks (+%d%% damage)", B.hm_streak, math.floor(B.hm_streak * C.streak_dmg * 100 + 0.5))
		end
		-- card 7 Untouchable
		if tier >= 7 and now >= (B.hm_untouch_ready or 0) then
			local dur = B.sc(C.untouch, C.untouch_ds)
			dmg._can_take_dmg_timer = math.max(dmg._can_take_dmg_timer or 0, dur)
			B.hm_untouch_until = now + dur
			B.hm_untouch_ready = now + C.untouch_every
			live("untouchable", "no damage for %.2f seconds", dur)
		end
	end

	Hooks:PostHook(PlayerManager, "on_killshot", "GilzaDSBuffs_hitman_kill", function(self, killed_unit, variant, headshot)
		on_kill(self, killed_unit, variant, headshot)
	end)

	------------------------------------------------------------------ card 5: faster armor recovery per Streak
	local orig_regen = PlayerManager.body_armor_regen_multiplier
	if orig_regen then
		function PlayerManager:body_armor_regen_multiplier(...)
			local m = orig_regen(self, ...)
			local n = B.hm_streak or 0
			if n > 0 and type(m) == "number" then
				-- card 7 Tailored: 10% a Streak in the Lightweight Ballistic Vest
				local per = B.hitman_tier() >= 5 and C.streak_regen * B.hitman_give() or 0
				if per > 0 then
					m = m * (1 - per * n)
					live("streak recovery", "armor recovery timer x%.2f with %d Streaks", 1 - per * n, n)
				end
			end
			return m
		end
	end

	------------------------------------------------------------------ card 7: Tailored armor, Black Tie dodge
	-- added to the game's armor multiplier like the other armor skills (card 1's 5% is one of them); the inventory
	-- asks about other armors with override_armor
	local orig_armor_mul = PlayerManager.body_armor_skill_multiplier
	if orig_armor_mul then
		function PlayerManager:body_armor_skill_multiplier(override_armor, ...)
			local m = orig_armor_mul(self, override_armor, ...)
			if type(m) ~= "number" then return m end
			local more = 0
			if B.hitman_tier() >= 7 and B.hitman_armor(override_armor) == C.vest then
				more = B.sc(C.vest_armor, C.vest_armor_ds)
			end
			if more > 0 then
				m = m + more
				live("tailored armor", "+%.1f%% armor in the Lightweight Ballistic Vest", more * 100)
			end
			return m
		end
	end

	-- (dodgecap.lua wraps this later and still caps the total)
	local orig_dodge = PlayerManager.skill_dodge_chance
	if orig_dodge then
		function PlayerManager:skill_dodge_chance(running, crouching, on_zipline, override_armor, ...)
			local chance = orig_dodge(self, running, crouching, on_zipline, override_armor, ...)
			if type(chance) ~= "number" then return chance end
			local more = 0
			if B.hitman_tier() >= 7 and B.hitman_armor(override_armor) == C.suit then
				more = B.sc(C.suit_dodge, C.suit_dodge_ds)
			end
			if more > 0 then
				chance = chance + more
				live("black tie", "+%.1f%% dodge in the Two-piece Suit", more * 100)
			end
			return chance
		end
	end

	------------------------------------------------------------------ Copycat: unchanged
	-- Gilza's Hitman card 3 is gone from the deck now, but Copycat's Hitman mimic still carries its akimbo armor
	-- recovery upgrade; 6.x-7.17 kept it switched off, and so does this, so Copycat plays as before.
	local orig_temp_value = PlayerManager.temporary_upgrade_value
	function PlayerManager:temporary_upgrade_value(category, upgrade, default, ...)
		if upgrade == "akimbo_pistol_armor_regen_timer_multiplier" then
			return default
		end
		return orig_temp_value(self, category, upgrade, default, ...)
	end

	local orig_activate = PlayerManager.activate_temporary_upgrade
	function PlayerManager:activate_temporary_upgrade(category, upgrade, ...)
		if upgrade == "akimbo_pistol_armor_regen_timer_multiplier" then
			return
		end
		return orig_activate(self, category, upgrade, ...)
	end

elseif script == "lib/units/enemies/cop/copdamage" then
	-- card 1: your Contracts take less damage from you (card 3: not your headshots); card 5: +5% damage per Streak;
	-- card 9: marks a shot of a dual-wielded weapon that hit one of your Contracts (Gun Kata)
	local function my_hit(self, attack_data, fn)
		if not attack_data or type(attack_data.damage) ~= "number" then return end
		local player = managers.player and managers.player:player_unit()
		if not (alive(player) and attack_data.attacker_unit == player) then return end
		local tier = B.hitman_tier()
		if tier < 1 then return end
		local melee = fn == "damage_melee"
		local mul = 1
		if B.hitman_slot(self._unit) then
			local shot = B._hm_shot
			if shot and not self._dead then shot.hit = true end
			local head = (fn == "damage_bullet" or melee) and is_head(self, attack_data)
			if melee and head then B._hm_melee_head = self._unit end
			if head and tier >= 3 then
				live("headshot through", "a %s headshot went through the Contract's toughness", fn)
			else
				local tough = B.sc(C.tough, C.tough_ds)
				mul = mul * (1 - tough)
				live("tough", "the Contract took %.1f%% less from a %s hit", tough * 100, fn)
			end
		elseif melee and is_head(self, attack_data) then
			B._hm_melee_head = self._unit
		end
		local n = B.hm_streak or 0
		if tier >= 5 and n > 0 then
			mul = mul * (1 + C.streak_dmg * n)
			live("streak damage", "+%d%% damage with %d Streaks", math.floor(C.streak_dmg * n * 100 + 0.5), n)
		end
		if mul ~= 1 then attack_data.damage = attack_data.damage * mul end
	end

	for _, fn in ipairs({ "damage_bullet", "damage_melee", "damage_fire", "damage_dot", "damage_explosion" }) do
		if CopDamage[fn] then
			Hooks:PreHook(CopDamage, fn, "GilzaDSBuffs_hitman_" .. fn, function(self, attack_data)
				if fn == "damage_melee" then B._hm_melee_head = nil end
				my_hit(self, attack_data, fn)
			end)
		end
	end
	-- the melee headshot flag only lives through the hit (the kill callback runs inside it)
	Hooks:PostHook(CopDamage, "damage_melee", "GilzaDSBuffs_hitman_damage_melee_post", function()
		B._hm_melee_head = nil
	end)

elseif script == "lib/units/beings/player/playerdamage" then
	-- card 1: your Contracts hit you harder (melee goes through damage_bullet)
	for _, fn in ipairs({ "damage_bullet", "damage_explosion", "damage_fire" }) do
		if PlayerDamage[fn] then
			Hooks:PreHook(PlayerDamage, fn, "GilzaDSBuffs_hitman_hurt_" .. fn, function(self, attack_data)
				if not (attack_data and type(attack_data.damage) == "number") then return end
				local u = attack_data.attacker_unit
				if u == nil or not B.hitman_slot(u) or not alive(u) then return end
				if B.hitman_tier() < 1 then return end
				local more = B.sc(C.hits, C.hits_ds)
				attack_data.damage = attack_data.damage * (1 + more)
				live("contract hits harder", "%.1f%% more damage from your Contract (%s)", more * 100, fn)
			end)
		end
	end

elseif script == "lib/units/weapons/newraycastweaponbase" then
	-- your own weapon (not a teammate's or an NPC's)
	local function mine(base)
		local user = base._setup and base._setup.user_unit
		return alive(user) and managers.player and user == managers.player:player_unit() or false
	end

	-- card 5 Hot Streak: a dual-wielded weapon in your hands fires 5% faster per Streak (read every shot)
	local orig_rof = NewRaycastWeaponBase.fire_rate_multiplier
	if orig_rof then
		function NewRaycastWeaponBase:fire_rate_multiplier(...)
			local m = orig_rof(self, ...)
			local n = B.hm_streak or 0
			if n <= 0 or type(m) ~= "number" then return m end
			if B.hitman_akimbo(self) and mine(self) and B.hitman_tier() >= 5 then
				m = m * (1 + C.rof * n)
				live("hot streak", "dual-wielded fire rate x%.2f with %d Streaks", 1 + C.rof * n, n)
			end
			return m
		end
	end

	-- card 9 Gun Kata: dual-wielded weapons reload faster (the game caches the multiplier for a reload: count it once)
	local orig_reload = NewRaycastWeaponBase.reload_speed_multiplier
	if orig_reload then
		function NewRaycastWeaponBase:reload_speed_multiplier(...)
			local m = orig_reload(self, ...)
			if self._current_reload_speed_multiplier or type(m) ~= "number" then return m end   -- cached: already counted
			if B.hitman_akimbo(self) and mine(self) and B.hitman_tier() >= 9 then
				local more = B.sc(C.kata_reload, C.kata_reload_ds)
				m = m * (1 + more)
				live("gun kata reload", "dual-wielded reload x%.2f", 1 + more)
			end
			return m
		end
	end

	-- card 9 Gun Kata: a shot of a dual-wielded weapon (either gun) that hits one of your Contracts goes back into the
	-- magazine. The shot is noted before it fires; the Contract's damage hook (copdamage) marks it when it hits; one
	-- round back per shot however many pellets or Contracts it hit, and only when the shot used a round.
	-- the ammo calls a refund needs (every weapon's ammo base has them; checked anyway)
	local function ammo_ok(base)
		return base and base.get_ammo_remaining_in_clip and base.get_ammo_total and base.set_ammo_remaining_in_clip
			and base.get_ammo_max_per_clip and base.set_ammo_total and base.get_ammo_max and true or false
	end

	local function kata_shot(wb)
		if not (B.hitman_akimbo(wb) and mine(wb) and B.hitman_tier() >= 9) then return nil end
		local base = wb.ammo_base and wb:ammo_base()
		if not ammo_ok(base) then return nil end
		return { base = base, clip = base:get_ammo_remaining_in_clip(), total = base:get_ammo_total() }
	end

	local function kata_refund(shot)
		local base = shot.base
		local clip, total = base:get_ammo_remaining_in_clip(), base:get_ammo_total()
		if clip >= shot.clip then return end   -- the shot cost no round (Bulletstorm, Swan Song, a free shot)
		base:set_ammo_remaining_in_clip(math.min(clip + 1, base:get_ammo_max_per_clip()))
		if total < shot.total then base:set_ammo_total(math.min(total + 1, base:get_ammo_max())) end
		if managers.hud and base.selection_index and base.ammo_info then
			managers.hud:set_ammo_amount(base:selection_index(), base:ammo_info())
		end
		live("gun kata", "a shot that hit your Contract went back into the magazine (%d left)", base:get_ammo_remaining_in_clip())
	end

	Hooks:PreHook(NewRaycastWeaponBase, "fire", "GilzaDSBuffs_hitman_kata_pre", function(self)
		B._hm_shot = nil
		if not (B.hm_contract or B.hm_twin) then return end
		B._hm_shot = kata_shot(self)
	end)

	Hooks:PostHook(NewRaycastWeaponBase, "fire", "GilzaDSBuffs_hitman_kata", function(self)
		local shot = B._hm_shot
		B._hm_shot = nil
		if not (shot and shot.hit and ammo_ok(shot.base)) then return end
		kata_refund(shot)
	end)

elseif script == "lib/tweak_data/skilltreetweakdata" then
	-- the reworked cards replace Gilza's: card 1 keeps the 5% armor, card 9 keeps the 1.5 s armor recovery after a
	-- break and the completion bonus; cards 3, 5 and 7 are ours alone
	local REMOVE = {
		[1] = { temporary_badass_hitman_kill_armor_regen = true },
		[3] = { akimbo_recoil_index_addend_4 = true, akimbo_extra_ammo_multiplier_2 = true,
			temporary_akimbo_pistol_armor_regen_timer_multiplier = true },
		[5] = { temporary_death_dance_combo_invulnerability = true },
		[7] = { temporary_player_bounty_hunter = true }
	}
	Hooks:PostHook(SkillTreeTweakData, "init", "GilzaDSBuffs_hitman_cards", function(self)
		local deck = self.specializations and self.specializations[C.deck]
		for card, names in pairs(REMOVE) do
			local ups = deck and deck[card] and deck[card].upgrades
			if ups then
				for i = #ups, 1, -1 do
					if names[ups[i]] then table.remove(ups, i) end
				end
			end
		end
	end)
end
