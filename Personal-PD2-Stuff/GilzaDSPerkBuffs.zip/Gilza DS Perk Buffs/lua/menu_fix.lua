GilzaDSBuffs = GilzaDSBuffs or {}

-- Gilza moves the armor "Ammo and throwables pick up rate" line onto the stats area, where it can
-- overlap the red "perk deck is disabled while wearing this armor" warning (Grinder, Anarchist, ...).
-- Push the pick-up line below any other info text it would overlap.
local function fix(self)
	local texts = self._info_texts
	local info = texts and texts[2]
	if not (info and alive(info) and info:visible() and info:text() ~= "") then return end
	if not string.find(info:text(), "%%", 1, false) then return end
	local top, bottom = info:world_top(), info:world_bottom()
	local push
	for i, t in pairs(texts) do
		if i ~= 2 and alive(t) and t:visible() and t:text() ~= "" then
			local _, _, _, th = t:text_rect()
			local t_top, t_bottom = t:world_top(), t:world_top() + (th or t:h())
			if t_top < bottom and t_bottom > top then
				push = math.max(push or 0, t_bottom + 4)
			end
		end
	end
	if not push then return end
	info:set_world_y(push)
	local panel = self._info_texts_panel
	if panel and alive(panel) then
		local max_h = panel:h() - info:top()
		local _, _, _, th = info:text_rect()
		if max_h > 0 and th and th > max_h then
			info:set_font_size(info:font_size() * max_h / th)
			_, _, _, th = info:text_rect()
			info:set_h(th)
		end
	end
end

Hooks:PostHook(BlackMarketGui, "update_info_text", "GilzaDSBuffs_info_text_overlap", function(self)
	pcall(fix, self)
end)
