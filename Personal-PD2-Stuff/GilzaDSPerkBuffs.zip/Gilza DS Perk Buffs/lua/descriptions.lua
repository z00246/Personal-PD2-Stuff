GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs

local DS = "\n\nWhile playing on Death Sentence difficulty, "
local DODGE = "your chance to dodge from this perk card is increased by an additional ##5%##."
local VEST_DODGE = "your chance to dodge for ballistic vests from this perk card is increased by an additional ##5%##."

B.desc_lines = {
	menu_deck2_1_desc = "Rage can stack up to ##12## times instead.",
	menu_deck4_3_desc = "every attack you dodge grants you an additional ##7.5%## chance to dodge instead, up to ##30%##.",
	menu_deck1_3_desc = "the damage reduction while you are within ##18m## of an enemy is increased to ##12%##.",
	menu_deck4_1_desc = "your chance to dodge from this perk deck is increased by an additional ##5%##.",
	menu_deck1_9_desc = "the damage reduction for having one or more hostages is increased to ##12%##.",
	menu_deck3_7_desc = "you will be immune to health damage for ##3## seconds when your armor gets depleted, instead of ##2##.",
	menu_deck5_1_desc = "kills with pistols, SMGs and akimbo weapons regenerate ##50## points of armor instead, and melee and throwable kills regenerate no less than ##50## points of armor.",
	menu_deck5_3_desc = "the additional armor regenerated is ##30## points instead, or ##50## while wearing the Two-piece Suit or the Lightweight Ballistic Vest, and you can keep up to ##100## extra armor.",
	menu_deck6_1_desc = VEST_DODGE,
	menu_deck6_3_desc = VEST_DODGE,
	menu_deck6_5_desc = VEST_DODGE,
	menu_deck6_7_desc = VEST_DODGE,
	menu_deck7_1_desc = "your chance to dodge from this perk card is increased by an additional ##5%##, and being Hidden increases your chance to dodge by ##15%## instead.",
	menu_deck7_3_desc = "you deal ##60%## more damage to enemies that are not targeting you instead.",
	menu_deck7_5_desc = DODGE,
	menu_deck7_7_desc = "your chance to dodge from this perk card is increased by an additional ##5%##, and enemies lose track of you for ##3## seconds instead.",
	menu_deck7_9_desc = "your next shot after being Hidden deals ##75%## more damage instead.",
	menu_sociopathinfil_1_desc = "the damage reduction while you are surrounded is increased to ##15%##.",
	menu_deck8_3_desc = "this damage reduction goes up to ##15%## instead.",
	menu_deck8_5_desc = "this damage reduction goes up to ##25%## instead, and Exposed enemies take ##40%## more damage for ##7## seconds instead.",
	menu_deck8_7_desc = "this damage reduction goes up to ##35%## instead, and Melt Away reduces damage taken by ##35%## instead.",
	menu_deck9_3_desc = "the armor you regenerate on kill is increased by ##50%##.",
	menu_deck9_5_desc = "killing an enemy with a melee weapon regenerates ##15%## health instead, and the additional damage reduction is increased to ##12%##.",
	menu_deck9_7_desc = "the armor regenerated on kills within ##18m## of you is increased to ##45##.",
	menu_deck10_1_desc = "you will be healed for a random amount from ##28## to ##42## health points instead, and you will lose a random amount from ##56## to ##84## health points instead. Jackpots still triple these amounts.\nCritical hit chance you gain or lose is from ##3%## to ##9%## instead, a jackpot is ##30%##, and it can go from ##-45%## up to ##45%##.",
	menu_deck10_7_desc = "health you gain on a successful roll is increased by ##28## instead, but health you lose on a failure roll is also increased by ##56##.",
	menu_deck10_9_desc = "on a successful roll you gain a random amount of dodge chance from ##4%## to ##16%##, a jackpot gives ##56%##. On a failure roll you lose a random amount from ##8%## to ##32%##, a failure jackpot takes away ##56%##. Maximum dodge chance you can get from this perk card is increased to ##60%##.",
	menu_deck11_1_desc = "the health you regenerate from each stack is increased by ##50%##.",
	menu_deck12_1_desc = "the maximum armor recovery bonus is ##25%## instead.",
	menu_deck12_5_desc = "the maximum armor recovery bonus while at low health is increased by an additional ##25%## instead.",
	menu_deck12_7_desc = "the maximum armor recovery bonus while at low health is increased by an additional ##25%## instead.",
	menu_deck13_1_desc = "you get ##6## stored health for each enemy you or your crew kills instead.",
	menu_deck13_3_desc = "the amount of stored health gained on kill is increased by ##6## instead.",
	menu_deck13_7_desc = "the amount of stored health gained on kill is increased by ##6## instead.",
	menu_deck14_1_desc = "you can convert up to ##150## damage into Hysteria Stacks every ##1.5## second(s) instead.",
	menu_deck15_1_desc = "the armor you regenerate is increased by ##30%##, and you will be immune to health damage for ##3## seconds when your armor gets depleted instead.",
	menu_deck16_1_desc = "each Stack of Regeneration instantly restores ##7.5## health and ##7.5## armor instead.",
	menu_deck17_1_desc = "activating the injector will heal you with ##75%## of all damage taken for ##8## seconds instead.",
	menu_deck18_3_desc = "you gain ##22.5%## dodge chance every time you are damaged instead.",
	menu_deck18_5_desc = DODGE,
	menu_deck19_1_desc = "damage taken is reduced by ##80%## instead, and the ##80%## reduced damage will be applied over-time.",
	menu_deck20_1_desc = "each enemy you or the tagged unit kills will heal you for ##22.5## health and the tagged unit for ##11.25## health instead.",
	menu_deck21_5_desc = "killing an enemy while the feedback effect is active will regenerate ##45## health instead, and " .. DODGE,
	menu_deck21_7_desc = "you will gain ##20## dodge instead.",
	menu_deck21_9_desc = "the health regenerated on kill while the feedback effect is active is increased by ##50%##, and " .. DODGE,
	menu_deck22_1_desc = "activating the Leech Ampule restores ##45%## health instead.",
	menu_deck23_1_desc = "perk cards you copy from other perk decks also get their Death Sentence bonuses.",
	menu_deck_brawler1_desc = "while using melee weapons your armor gains ##7.5%## bullet damage resistance instead.",
	menu_deck_brawler3_desc = "while using melee weapons your armor gains ##7.5%## more bullet damage resistance instead.",
	menu_deck_brawler5_desc = "while using melee weapons your armor gains ##15%## more bullet damage resistance instead.",
	menu_deck_SJ_5_desc = "securing a kill adds ##6## to ##25## stacks of adrenaline instead.",
	menu_deck_SJ_7_desc = "you gain ##22.5## points of armor when you dodge instead, or ##67.5## if you have no armor remaining.",
	menu_deck_Gilza_guardian_1_desc = "you regenerate ##15## points of health every ##2## seconds while inside of your defensive area instead, and teammates inside of it take ##20%## less damage instead of ##15%##.",
	menu_deck_Gilza_guardian_3_desc = "you regenerate ##30## points of health every ##2## seconds while inside of your defensive area instead.",
	menu_deck_Gilza_guardian_5_desc = "you regenerate ##45## points of health every ##2## seconds while inside of your defensive area instead."
}

B.full_text = {
	menu_deck8_3_desc = "The closer the nearest enemy is, the less damage you take: up to ##12%## within ##5m##, fading to ##40%## of that at ##18m##.",
	menu_deck8_3_short = "You take up to ##12%## less damage the closer the nearest enemy is, at full strength within ##5m##.",
	menu_deck8_5_desc = "Your Closing In damage reduction goes up to ##20%##.\n\nHitting an enemy with a melee weapon leaves it Exposed for ##5## seconds. You deal ##30%## more damage to Exposed enemies with your guns.",
	menu_deck8_5_short = "Closing In goes up to ##20%##. Melee hits Expose enemies for ##5## seconds, making your guns deal ##30%## more damage to them.",
	menu_deck8_7_desc = "Your Closing In damage reduction goes up to ##28%##.\n\nKilling an enemy with a melee weapon grants Melt Away: ##20%## faster movement and ##25%## less damage taken for ##3## seconds. Enemies within ##10m## of the kill also lose track of you for ##2## seconds.",
	menu_deck8_7_short = "Closing In goes up to ##28%##. Melee kills give ##20%## speed and ##25%## less damage for ##3## seconds, and nearby enemies lose track of you for ##2## seconds.",
	menu_deck8_9_desc = "Every melee hit restores ##4%## of your health, up to ##20%## every ##10## seconds.\n\nKilling an Exposed enemy restores ##10%## of your armor.\n\nDeck Completion Bonus: Your chance of getting a higher quality item during a Payday is increased by ##10%##.",
	menu_deck8_9_short = "Melee hits restore ##4%## health, up to ##20%## every ##10## seconds. Killing an Exposed enemy restores ##10%## armor.",
	menu_deck7_3_desc = "Standing still and crouching decreases your chances to be targeted by ##10%##.\n\nYou deal ##40%## more damage to enemies that are not targeting you.\n\nEnemies and cameras you mark stay marked ##50%## longer.\n\nYou bag corpses ##25%## faster.",
	menu_deck7_3_short = "Standing still and crouching makes you ##10%## less likely to be targeted. You deal ##40%## more damage to enemies not targeting you. Your marks last ##50%## longer. You bag corpses ##25%## faster.",
	menu_deck7_5_desc = "Your chance to dodge is increased by an additional ##5%##, or ##15%## while using the Lightweight Ballistic Vest.\n\nYour chance to be targeted while standing still and crouching is decreased by an additional ##5%##.\n\nKills with silenced weapons make you Hidden for ##3## seconds, even while moving, and enemies prefer other targets during that time.\n\nYou gain ##2## concealment for each silenced weapon you equip.\n\nYour ECM jammers and their feedback last ##25%## longer.\n\nYou pick locks ##25%## faster.",
	menu_deck7_5_short = "##5%## more dodge chance, ##15%## with the Lightweight Ballistic Vest. Silenced kills make you Hidden for ##3## seconds. ##2## concealment per silenced weapon. ECMs last ##25%## longer. You pick locks ##25%## faster.",
	menu_deck7_7_desc = "Your chance to dodge is increased by an additional ##5%##.\n\nYour chance to be targeted while standing still and crouching is decreased by an additional ##5%##.\n\nWhen your armor breaks, enemies lose track of you for ##2## seconds. This can not occur more often than once every ##20## seconds.\n\nYou answer pagers ##25%## faster.",
	menu_deck7_7_short = "##5%## more dodge chance. When your armor breaks, enemies lose track of you for ##2## seconds, once every ##20## seconds. You answer pagers ##25%## faster.",
	menu_deck7_9_desc = "Standing still increases your armor recovery rate by ##20%##.\n\nYou gain ##10%## crouching movement speed.\n\nAfter being Hidden for ##2## seconds, your next shot deals ##50%## more damage and pierces enemy body armor.\n\nDeck Completion Bonus: Your chance of getting a higher quality item during a Payday is increased by ##10%##.",
	menu_deck7_9_short = "Standing still increases armor recovery by ##20%##. ##10%## faster crouch movement. After ##2## seconds of being Hidden, your next shot deals ##50%## more damage and pierces body armor.",
	menu_deck2_9_desc = "You gain an additional ##60%## more health.\n\nYou regenerate ##3%## of your health every ##5## seconds.\n\nReaching maximum Rage makes you take ##50%## less damage for ##4## seconds. This can not occur more often than once every ##20## seconds.\n\nWhile playing on Death Sentence difficulty, your passive health regeneration is increased to ##6.5%## every ##5## seconds.\n\nDeck Completion Bonus: Your chance of getting a higher quality item during a Payday is increased by ##10%##.",
	menu_deck2_9_short = "You gain an additional ##60%## more health and regenerate ##3%## of your health every ##5## seconds. Reaching maximum Rage makes you take ##50%## less damage for ##4## seconds.",
	menu_deck6_1_desc = "Your chance to dodge is increased by ##15%## for ballistic vests.\n\nWhile wearing a ballistic vest, every attack you dodge restores ##10%## of your armor.",
	menu_deck6_1_short = "Your chance to dodge is increased by ##15%## for ballistic vests. With a ballistic vest, dodging an attack restores ##10%## of your armor.",
	menu_deck6_3_desc = "Your chance to dodge is increased by ##5%## for ballistic vests.\n\nYour armor is increased by ##20%## for ballistic vests.\n\nArmor restored by dodging is increased to ##15%##.",
	menu_deck6_3_short = "Ballistic vests gain ##5%## dodge chance and ##20%## armor. Dodging restores ##15%## of your armor.",
	menu_deck6_5_desc = "Your chance to dodge is increased by ##5%## for ballistic vests.\n\nYour armor is increased by ##20%## for ballistic vests.\n\nArmor restored by dodging is increased to ##20%##.",
	menu_deck6_5_short = "Ballistic vests gain ##5%## more dodge chance and ##20%## more armor. Dodging restores ##20%## of your armor.",
	menu_deck6_7_desc = "Your chance to dodge is increased by ##15%## for ballistic vests.\n\nYour armor is increased by ##25%## for ballistic vests.\n\nAfter you dodge an attack, you deal ##25%## more damage for ##3## seconds.",
	menu_deck6_7_short = "Ballistic vests gain ##15%## more dodge chance and ##25%## more armor. Dodging an attack increases your damage by ##25%## for ##3## seconds.",
	menu_deck6_9_desc = "Your armor recovery rate is increased by ##10%##.\n\nWhen your ballistic vest breaks, your chance to dodge is increased by ##30%## for ##5## seconds. This can not occur more often than once every ##15## seconds.\n\nDeck Completion Bonus: Your chance of getting a higher quality item during a Payday is increased by ##10%##.",
	menu_deck6_9_short = "Your armor recovery rate is increased by ##10%##. When your ballistic vest breaks, your dodge chance is increased by ##30%## for ##5## seconds.",
	menu_deck3_1_desc = "Your armor is increased by ##10%##.\n\nYour armor is divided into ##2## plates. A single hit can break at most one plate. Armor recovers one plate at a time.",
	menu_deck3_1_short = "Your armor is increased by ##10%##. Your armor is divided into ##2## plates, a single hit can break at most one plate, and armor recovers one plate at a time.",
	menu_deck3_3_desc = "Your armor is increased by an additional ##10%##.\n\nWhenever one of your armor plates breaks, enemies within ##6m## of you are suppressed and have a ##60%## chance to panic.",
	menu_deck3_3_short = "Your armor is increased by an additional ##10%##. Breaking an armor plate suppresses enemies within ##6m##, with a ##60%## chance to panic them.",
	menu_deck3_5_desc = "Your armor is increased by an additional ##10%##.\n\nYour armor is now divided into ##3## plates, and a single hit can remove at most ##75%## of a plate.",
	menu_deck3_5_short = "Your armor is increased by an additional ##10%##. Your armor is divided into ##3## plates, and a hit can remove at most ##75%## of a plate.",
	menu_deck3_7_desc = "Your armor recovers ##20%## faster.\n\nEvery ##5## seconds, even while taking damage, your current damaged plate is fully restored as long as your armor is not broken.\n\nWhen your armor breaks, you are immune to health damage for ##2## seconds. This can not occur more often than once every ##15## seconds.",
	menu_deck3_7_short = "Your armor recovers ##20%## faster. Every ##5## seconds your current damaged plate is restored, even in combat. When your armor breaks, you are immune to health damage for ##2## seconds, once every ##15## seconds.",
	menu_deck3_9_desc = "Your armor is increased by an additional ##5%##.\n\nYour armor is now divided into ##4## plates, and a single hit can remove at most ##50%## of a plate.\n\nYou and your crew's armor recovers ##10%## faster.\n\nNote: Crew perks do not stack.\n\nDeck Completion Bonus: Your chance of getting a higher quality item during a Payday is increased by ##10%##.",
	menu_deck3_9_short = "Your armor is increased by an additional ##5%## and divided into ##4## plates, and a hit can remove at most ##50%## of a plate. You and your crew's armor recovers ##10%## faster.",
	menu_deck2_1_desc = "Your health is increased by ##10%##.\n\nLosing health builds Rage: every ##10%## of your maximum health you lose grants ##1## stack, up to ##10##. Each stack increases the damage you deal by ##3%##. After ##4## seconds without losing health, you lose ##1## stack every ##2## seconds.",
	menu_deck2_1_short = "Your health is increased by ##10%##. Every ##10%## health you lose grants ##1## Rage stack, up to ##10##. Each stack increases your damage by ##3%##.",
	menu_deck2_3_desc = "Your health is increased by an additional ##10%##.\n\nYou are more likely to be targeted by enemies.\n\nWhile you have ##5## or more Rage stacks, you take ##15%## less damage.",
	menu_deck2_3_short = "Your health is increased by an additional ##10%##. You are more likely to be targeted. At ##5## or more Rage stacks you take ##15%## less damage.",
	menu_deck2_5_desc = "Your health is increased by an additional ##20%##.\n\nWhile you have ##5## or more Rage stacks, every kill heals you for ##3%## of your health.",
	menu_deck2_5_short = "Your health is increased by an additional ##20%##. At ##5## or more Rage stacks, kills heal you for ##3%## of your health.",
	menu_deck4_1_desc = "Your chance to dodge is increased by ##15%##.\n\nYou deal ##25%## more damage to enemies that are not facing you.",
	menu_deck4_1_short = "Your chance to dodge is increased by ##15%##. You deal ##25%## more damage to enemies that are not facing you.",
	menu_deck4_3_desc = "You are ##40%## less likely to be targeted by enemies.\n\nEvery attack you dodge grants you an additional ##5%## chance to dodge for ##6## seconds, stacking up to ##4## times. Dodging again refreshes the duration.\n\nAfter you dodge an attack, your reload and weapon swap speeds are increased by ##30%## for ##4## seconds.",
	menu_deck4_3_short = "You are ##40%## less likely to be targeted. Each dodge grants ##5%## more dodge chance for ##6## seconds, up to ##4## stacks. Dodging increases your reload and swap speed by ##30%## for ##4## seconds.",
	menu_deck4_5_desc = "Your chance to dodge is increased by an additional ##15%##.\n\nYou deal ##35%## more damage to enemies that are not facing you.",
	menu_deck4_5_short = "Your chance to dodge is increased by an additional ##15%##. Damage against enemies not facing you is increased to ##35%##.",
	menu_deck4_7_desc = "Your chance to dodge is increased by an additional ##15%##.\n\nAfter you dodge an attack, every shot you fire within ##2## seconds is a critical hit.",
	menu_deck4_7_short = "Your chance to dodge is increased by an additional ##15%##. Shots fired within ##2## seconds of a dodge are critical hits.",
	menu_deck4_9_desc = "Dodging ##3## attacks within ##3## seconds makes you invulnerable for ##1.5## seconds. This can not occur more often than once every ##15## seconds.\n\nYour weapon swapping speed is increased by ##33%##.\n\nYour movement speed is increased by ##10%## and stamina is increased by ##25%##.\n\nYour total chance to dodge can not exceed ##70%##, or ##80%## while playing on Death Sentence difficulty.\n\nDeck Completion Bonus: Your chance of getting a higher quality item during a Payday is increased by ##10%##.",
	menu_deck4_9_short = "Dodging ##3## attacks within ##3## seconds makes you invulnerable for ##1.5## seconds, once every ##15## seconds. Faster weapon swapping, movement speed and stamina.",
	menu_deck1_1_desc = "You and your crew take ##8%## less damage. While your health is below ##50%##, this damage reduction is doubled for you.\n\nFor every teammate within ##18m## of you, you take an additional ##5%## less damage, up to ##15%##.\n\nNote: Crew perks do not stack.",
	menu_deck1_1_short = "You and your crew take ##8%## less damage. You take an additional ##5%## less damage for every teammate within ##18m##, up to ##15%##.",
	menu_deck1_3_desc = "You and your crew's stamina is increased by ##50%##.\n\nWhile trying to intimidate a law enforcer or a civilian, marking a special enemy, or using \"Inspire\" skill on your teammates, your shout distance is increased by ##25%##.\n\nWhile you are within ##18m## of an enemy that you can see, you receive a ##8%## damage reduction. This damage reduction lingers for ##5## seconds after you are no longer close to an enemy.\n\nMarked enemies take ##25%## more damage from your whole crew.\n\nNote: Crew perks do not stack.",
	menu_deck1_3_short = "You and your crew's stamina is increased by ##50%##. Your shout distance for intimidating, marking and Inspire is increased by ##25%##. ##8%## damage reduction near enemies. Marked enemies take ##25%## more damage from your whole crew.",
	menu_deck1_5_desc = "You and your crew's health is increased by ##10%##.\n\nYou gain ##10%## health that is only applied to you.\n\nReviving a teammate grants you ##40%## damage reduction for ##6## seconds.\n\nNote: Crew perks do not stack.",
	menu_deck1_5_short = "You and your crew's health is increased by ##10%##. You gain ##10%## more health. Reviving a teammate grants you ##40%## damage reduction for ##6## seconds.",
	menu_deck1_7_desc = "You and your crew's armor is increased by ##5%##.\n\nYou gain ##5%## armor that is only applied to you.\n\nThe damage reduction you get for every teammate within ##18m## is increased to ##7%##, up to ##21%##.\n\nNote: Crew perks do not stack.",
	menu_deck1_7_short = "You and your crew's armor is increased by ##5%##. You gain ##5%## more armor. Damage reduction per nearby teammate is increased to ##7%##, up to ##21%##.",
	menu_deck22_1_desc = "Unlocks and equips the Leech Ampule, which replaces your throwable. Use your throwable key to activate it.\nThe Leech Ampule lasts for ##6## seconds with a ##60## second cooldown. If you go down while it is ready or its cooldown is below ##20## seconds, the cooldown is set to ##20## seconds.\n\nActivating the Leech Ampule restores ##30%## health. While it is active your armor is disabled and your health is divided into segments of ##25%##. Each hit removes one segment, or two if the damage was greater than ##150##, and grants ##1## second of invulnerability. Securing a kill during that second restores ##1## segment. Reviving a teammate while it is active restores ##50%## of your health and all of your armor when it ends.\n\nEvery kill you secure while the Leech Ampule is active heals teammates within ##15m## of you for ##5%## of their health.",
	menu_deck22_1_short = "Unlocks the Leech Ampule: restores ##30%## health, disables armor and splits your health into ##25%## segments. Kills while it is active heal teammates within ##15m## for ##5%##.",
	menu_deck22_3_desc = "Your maximum health is increased by ##20%##.\n\nActivating the Leech Ampule heals teammates within ##15m## of you for ##10%## of their health.\n\nWhile the Leech Ampule is active you can not go into bleedout. Reaching ##0## health puts you in Last Breath, slowing you by ##80%## and only allowing kills during invulnerability to heal you. If the Leech Ampule ends while you are in Last Breath, you go down unless you revived a teammate during it.",
	menu_deck22_3_short = "Your maximum health is increased by ##20%##. Activating the Leech Ampule heals teammates within ##15m## for ##10%##.",
	menu_deck22_5_desc = "The Leech Ampule lasts for ##10## seconds, and killing an enemy reduces its cooldown by ##1## second.\n\nKills while the Leech Ampule is active heal teammates for ##10%## of their health, and the range is increased to ##20m##.\n\nReviving a crew member heals them for ##20%## of their health and you for ##10%## of yours.",
	menu_deck22_5_short = "The Leech Ampule lasts ##10## seconds and kills reduce its cooldown by ##1## second. Kills during it heal teammates for ##10%## within ##20m##.",
	menu_deck22_7_desc = "Your maximum health is increased by ##60%##.\n\nEvery kill you secure while the Leech Ampule is active extends its duration by ##0.5## seconds, up to ##3## seconds per activation.",
	menu_deck22_7_short = "Your maximum health is increased by ##60%##. Kills during the Leech Ampule extend it by ##0.5## seconds, up to ##3## seconds.",
	menu_deck22_9_desc = "You can activate the Leech Ampule while downed, reviving yourself until it ends. Doing so adds ##40## seconds to its cooldown. You stay up after it ends if you use a Doctor Bag or revive a teammate during it.\n\nYour health segments are reduced to ##20%##.\n\nKills while the Leech Ampule is active heal teammates for ##20%## of their health, and activating it heals teammates in range for ##20%## of their health.\n\nDeck Completion Bonus: Your chance of getting a higher quality item during a Payday is increased by ##10%##.",
	menu_deck22_9_short = "You can activate the Leech Ampule while downed. Health segments are reduced to ##20%##. Kills during it and activating it heal teammates for ##20%##."
}

B.replacements = {
	menu_deck9_9_desc = {
		{ "Killing an enemy within ##18m## of you has a ##75%## chance to spread panic among your enemies.",
		  "Killing an enemy within ##18m## of you has a ##75%## chance to spread panic among your enemies within ##25m##.\n\nYour damage reduction from this perk deck is increased to ##35%##." }
	},
	menu_deck5_1_desc = {
		{ "Securing a kill with a melee weapon or a throwable non-explosive weapon regenerates ##20%## of your armor.",
		  "Securing a kill with a melee weapon or a throwable non-explosive weapon regenerates ##20%## of your armor, but no less than ##30## points of armor.\nSecuring a kill with a pistol, SMG or an akimbo weapon regenerates ##30## points of armor. This can not occur more often than once every ##0.5## seconds." }
	},
	menu_deck5_1_short = {
		{ "Securing kills with melee or throwable non-explosive weapons regenerates ##20%## armor.",
		  "Securing kills with melee or throwable non-explosive weapons regenerates ##20%## armor, but no less than ##30##. Kills with pistols, SMG's and akimbo weapons regenerate ##30## armor." }
	},
	menu_deck5_3_desc = {
		{ "Killing an enemy using a pistol, SMG or an akimbo weapon grants you ##25%## faster armor recovery rate for ##10## seconds.",
		  "Killing an enemy using a pistol, SMG or an akimbo weapon regenerates an additional ##20## points of armor, or ##30## while wearing the Two-piece Suit or the Lightweight Ballistic Vest.\nWhile wearing either of these armors, armor regenerated by Hitman perk cards beyond your maximum armor is kept as extra armor, up to ##50## points. Extra armor is lost first when you take damage, and starts to fade after ##5## seconds without regenerating more." }
	},
	menu_deck5_3_short = {
		{ "Kills with pistols, SMG's and akimbo weapons will grant ##25%## faster armor recovery bonus.",
		  "Kills with pistols, SMG's and akimbo weapons regenerate an additional ##20## armor, or ##30## with the Two-piece Suit or Lightweight Ballistic Vest. With these armors, armor over your maximum is kept as up to ##50## extra armor." }
	},
	menu_deck5_5_desc = {
		{ "First kill of the combo must be achieved using either a melee weapon or a throwable non-explosive weapon. Securing kills with melee or throwable non-explosive weapons during the combo, will count as 2 kills instead of 1, except for the very first kill of the combo.",
		  "First kill of the combo must be achieved using a melee weapon, a throwable non-explosive weapon, a pistol, an SMG or an akimbo weapon. Securing kills with any of these weapons during the combo will count as 2 kills instead of 1, except for the very first kill of the combo." }
	},
	menu_deck5_5_short = {
		{ "Combo requires a melee or throwable non-explosive weapon kill to begin.",
		  "Combo requires a melee, throwable non-explosive, pistol, SMG or akimbo weapon kill to begin." }
	},
	menu_deck5_7_desc = {
		{ "First card's armor regeneration is increased to ##40%## per kill, third card's armor recovery bonus is increased to ##50%##,",
		  "First card's armor regeneration is increased to ##40%## per kill, or ##60## points of armor for pistol, SMG and akimbo kills, third card's additional armor regeneration is doubled," }
	}
}

B.always_lines = {
	menu_deck7_1_desc = "\n\nCrouching or standing still for ##1## second makes you Hidden, increasing your chance to dodge by ##10%##.\n\nEnemies detect you ##20%## slower while you crouch.",
	menu_deck2_7_desc = "\n\nEach Rage stack now increases the damage you deal by ##5%##.",
	menu_deck9_3_desc = "\n\nYou take ##15%## less damage.\n\nHolding your melee weapon builds up damage resistance by ##10%## every second, up to ##30%##. After you stop holding it, this bonus is kept for ##2## seconds and then fades.",
	menu_deck9_5_desc = "\n\nYour damage reduction from this perk deck is increased to ##25%##.",
	menu_deck_Gilza_guardian_1_desc = "\n\nYour defensive area also protects your crew. Every ##2## seconds, teammates standing inside of your defensive area regenerate ##50%## of the health it regenerates for you, and take ##15%## less damage for ##2.5## seconds.\nNote: teammates need the Gilza DS Perk Buffs mod to receive this effect. Bots receive it only while you are the host.",
	menu_deck10_1_desc = "\n\nEvery roll also gambles your critical hit chance. On a successful roll you gain a random amount of critical hit chance from ##2%## to ##6%##, a jackpot gives ##20%##. On a failure roll you lose a random amount from ##2%## to ##6%##, a failure jackpot takes away ##20%##. Your critical hit chance from this perk card can go from ##-30%## up to ##30%## and resets when you are taken into custody.\nWhile it is negative, that percentage of your bullet and melee hits will heal the enemy instead of damaging them."
}

local function short_map()
	if B._short then return B._short end
	local specs = tweak_data and tweak_data.skilltree and tweak_data.skilltree.specializations
	if not specs then return {} end
	local map = {}
	for _, deck in pairs(specs) do
		if type(deck) == "table" then
			for _, card in ipairs(deck) do
				if type(card) == "table" and card.desc_id and card.short_id and card.short_id ~= card.desc_id
					and (B.desc_lines[card.desc_id] or B.always_lines[card.desc_id]) then
					map[card.short_id] = card.desc_id
				end
			end
		end
	end
	B._short = map
	return map
end

function B.decorate(id, text)
	if type(text) ~= "string" or type(id) ~= "string" then return text end
	if id == "bm_menu_armor_pickup_desc" and B.AMMO_PICKUP_MUL then
		return (string.gsub(text, "([%d%.]+)%%", function(n)
			local v = tonumber(n)
			return v and (math.floor(v * B.AMMO_PICKUP_MUL + 0.5) .. "%") or (n .. "%")
		end, 1))
	end
	if B.full_text[id] then
		text = B.full_text[id]
	end
	local reps = B.replacements[id]
	if reps then
		for _, r in ipairs(reps) do
			local s, e = string.find(text, r[1], 1, true)
			if s then
				text = string.sub(text, 1, s - 1) .. r[2] .. string.sub(text, e + 1)
			end
		end
	end
	local key = (B.desc_lines[id] or B.always_lines[id]) and id or short_map()[id]
	if not key then return text end
	local extra = ""
	local always = B.always_lines[key]
	if always and not string.find(text, always, 1, true) then
		extra = extra .. always
	end
	local line = B.desc_lines[key]
	if line and not string.find(text, line, 1, true) then
		extra = extra .. DS .. line
	end
	if extra == "" then return text end
	local cut = string.find(text, "\n\nDeck Completion Bonus", 1, true)
	if cut then
		return string.sub(text, 1, cut - 1) .. extra .. string.sub(text, cut)
	end
	return text .. extra
end

function B.wrap_text()
	if LocalizationManager.text == B.text_wrapper then return end
	local inner = LocalizationManager.text
	B.text_wrapper = function(self, id, ...)
		return B.decorate(id, inner(self, id, ...))
	end
	LocalizationManager.text = B.text_wrapper
end

B.wrap_text()
Hooks:Add("MenuUpdate", "GilzaDSBuffs_keep_text_hook", function() pcall(B.wrap_text) end)
