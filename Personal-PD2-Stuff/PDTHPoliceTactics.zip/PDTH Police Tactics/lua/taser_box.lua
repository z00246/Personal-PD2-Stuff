if not PDTHTactics then dofile(ModPath .. "lua/core.lua") end

local T = PDTHTactics
local script = RequiredScript and RequiredScript:lower() or ""

-- Shooting a Tazer's battery box on his back shorts it out: an electric burst tases enemies
-- around him (him included) and his taser stops working for the rest of his life.
T.TBOX = T.TBOX or {
	hit_radius = 18,     -- cm around the box that counts as hitting it
	back_offset = 20,    -- how far behind the spine the box sits
	burst_radius = 400,  -- tase range of the burst
	burst_damage = 1     -- tiny damage, it's about the stun
}
local C = T.TBOX
local ids_spine2 = Idstring("Spine2")
local ids_bag = Idstring("bag")
local ids_unit = Idstring("unit")
local EFFECT = Idstring("effects/payday2/particles/character/taser_hittarget")

local function is_taser(unit)
	local base = alive(unit) and unit:base()
	if not base then return false end
	if base.has_tag and base:has_tag("taser") then return true end
	return base._tweak_table and string.find(base._tweak_table, "taser", 1, true) and true or false
end

local function box_pos(unit)
	local obj = unit:get_object(ids_spine2)
	if not obj then return end
	local fwd = unit:movement() and unit:movement().m_fwd and unit:movement():m_fwd() or unit:rotation():y()
	return obj:position() - fwd * C.back_offset
end

local function hit_box(unit, col_ray)
	if not (col_ray and col_ray.position) then return false end
	if col_ray.body and col_ray.body.name and col_ray.body:name() == ids_bag then return true end
	local pos = box_pos(unit)
	return pos and mvector3.distance(pos, col_ray.position) <= C.hit_radius or false
end

local function spark(pos)
	if not pos then return end
	World:effect_manager():spawn({ effect = EFFECT, position = pos, normal = math.UP })
end
T.taser_box_spark = spark

-- host: short out the box
function T.taser_box_burst(taser, attacker)
	if not (alive(taser) and Network and Network:is_server()) then return end
	local base = taser:base()
	if not base or base._pdth_box_broken then return end
	local dmg = taser:character_damage()
	if not dmg or dmg._dead then return end
	base._pdth_box_broken = true

	-- his taser is done
	local brain = taser:brain()
	local data = brain and brain._logic_data
	if data then
		data.tase_delay_t = math.huge
		local my_data = data.internal_data
		if my_data and my_data.tasing and TaserLogicAttack and TaserLogicAttack._cancel_tase_attempt then
			TaserLogicAttack._cancel_tase_attempt(data, my_data)
		end
	end

	local center = box_pos(taser) or taser:movement():m_com()
	spark(center)
	if LuaNetworking then
		LuaNetworking:SendToPeers(T.NET_ID, string.format("tboxfx:%.1f:%.1f:%.1f", center.x, center.y, center.z))
	end

	-- the burst
	local victims = {}
	for _, u_data in pairs(managers.enemy:all_enemies() or {}) do
		local unit = u_data.unit
		if alive(unit) and unit:movement() and mvector3.distance(unit:movement():m_com(), center) <= C.burst_radius then
			table.insert(victims, unit)
		end
	end
	-- (1.91, Geo: no engine calls wrapped in pcalls) each one is checked before he's tased
	for _, unit in ipairs(victims) do
		local cd = alive(unit) and unit:character_damage()
		if cd and not cd._dead and cd.damage_tase then
			local pos = unit:movement():m_com()
			local dir = pos - center
			mvector3.normalize(dir)
			cd:damage_tase({
				damage = C.burst_damage,
				attacker_unit = alive(attacker) and attacker or nil,
				attack_dir = dir,
				variant = "heavy",
				pos = pos,
				col_ray = { position = pos, ray = dir, body = unit:body("body") }
			})
		end
	end
end

if script == "lib/units/enemies/cop/copdamage" then
	-- the shooter's machine decides whether the box was hit
	Hooks:PreHook(CopDamage, "damage_bullet", "PDTHTactics_taser_box", function(self, attack_data)
		if not (T.active() or T.client_on()) then return end
		if self._dead or not attack_data then return end
		local player = managers.player and managers.player:player_unit()
		if not (alive(player) and attack_data.attacker_unit == player) then return end
		local unit = self._unit
		if not is_taser(unit) or unit:base()._pdth_box_broken then return end
		if not hit_box(unit, attack_data.col_ray) then return end
		if Network:is_server() then
			T.taser_box_burst(unit, player)
		elseif LuaNetworking and unit:id() ~= -1 then
			unit:base()._pdth_box_broken = true
			LuaNetworking:SendToPeer(1, T.NET_ID, "tbox:" .. tostring(unit:id()))
		end
	end)

	if LuaNetworking and LuaNetworking.AddReceiveHook then
		LuaNetworking:AddReceiveHook(T.NET_ID, "PDTHTactics_taser_box_net", function(data, sender)
			if type(data) ~= "string" then return end
			local id = string.match(data, "^tbox:(%-?%d+)$")
			if id and Network:is_server() and T.active() then
				id = tonumber(id)
				for _, u_data in pairs(managers.enemy and managers.enemy:all_enemies() or {}) do
					if alive(u_data.unit) and u_data.unit:id() == id then
						local session = managers.network and managers.network:session()
						local peer = session and session:peer(sender)
						T.taser_box_burst(u_data.unit, peer and peer:unit())
						break
					end
				end
				return
			end
			local x, y, z = string.match(data, "^tboxfx:([%-%d%.]+):([%-%d%.]+):([%-%d%.]+)$")
			x, y, z = tonumber(x), tonumber(y), tonumber(z)
			if x and y and z and sender == 1 and T.client_on() then
				spark(Vector3(x, y, z))
			end
		end)
	end

elseif script == "lib/units/enemies/taser/logics/taserlogicattack" then
	-- keep a shorted-out taser from ever tasing again (logic data can be refreshed)
	Hooks:PreHook(TaserLogicAttack, "_upd_aim", "PDTHTactics_taser_box_lock", function(data)
		local base = data and alive(data.unit) and data.unit:base()
		if base and base._pdth_box_broken then
			data.tase_delay_t = math.huge
		end
	end)
end
