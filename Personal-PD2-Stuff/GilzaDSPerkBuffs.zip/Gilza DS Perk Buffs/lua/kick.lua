GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs

-- (7.26) Geo's Kick mod (KickKeybind, the local edit of Kick (Keybind) by sixthief & rosey589) and this mod:
--  * a kick is a melee hit with name_id "fists" and no charge, so the Sociopath counts kick kills as melee kills, Gilza
--    turns its damage into a share of the enemy's health (a ground kick 25%, a jump kick 35%: KickKeybind.KINDS) and
--    the melee skill multipliers apply; masks.lua reads attack_data.kick for Don Juan's wall kicks and Biker's Stomp
--  * here: a landed kick spends Bloodthirst like a melee hit would, and the melee stats panel gets a Kick row
--    (melee.lua reads B.kick_stats)
local function kick()
	local k = rawget(_G, "KickKeybind")
	return type(k) == "table" and k._ready and k or nil
end

-- a ground kick's and a jump kick's damage in % of a regular enemy's health (nil without the Kick mod)
function B.kick_stats()
	local k = kick()
	local kinds = k and k.KINDS
	if not (kinds and kinds.ground and kinds.jump) then return nil end
	return math.floor(kinds.ground.damage * 10 + 0.5), math.floor(kinds.jump.damage * 10 + 0.5)
end

local function wrap()
	local k = kick()
	if not k or B._kick_wrapped == k or type(k.DamageCharacter) ~= "function" then return end
	B._kick_wrapped = k
	local orig = k.DamageCharacter
	k.DamageCharacter = function(self, target, ext, attack, ...)
		local result = orig(self, target, ext, attack, ...)
		if type(result) == "table" and managers.player and managers.player.reset_melee_dmg_multiplier then
			managers.player:reset_melee_dmg_multiplier()
		end
		if not B._kick_logged then
			B._kick_logged = true
			log("[Gilza DS Perk Buffs] kick: a " .. tostring(attack and attack.kick) .. " kick landed (Bloodthirst spent like a melee hit)")
		end
		return result
	end
end

Hooks:Add("GameSetupUpdate", "GilzaDSBuffs_kick_wrap", function() wrap() end)
Hooks:Add("MenuUpdate", "GilzaDSBuffs_kick_wrap_menu", function() wrap() end)
