GilzaDSBuffs = GilzaDSBuffs or {}

-- Death Sentence: Gilza doubles Bulldozer health but keeps the x6 headshot multiplier,
-- so precise guns needed twice the face shots. Raise it to x10 (body shots stay as tanky).
Hooks:PostHook(CharacterTweakData, "_set_sm_wish", "GilzaDSBuffs_dozer_headshots", function(self)
	for _, name in ipairs({ "tank", "tank_medic", "tank_mini" }) do
		if self[name] and self[name].headshot_dmg_mul then
			self[name].headshot_dmg_mul = 10
		end
	end
end)
