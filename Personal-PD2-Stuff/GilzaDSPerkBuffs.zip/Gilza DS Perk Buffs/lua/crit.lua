GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs

local function backfires(self, attack_data)
	local crit = B.gambler_crit or 0
	if crit >= 0 or not attack_data then return false end
	local attacker = attack_data.attacker_unit
	local player = managers.player and managers.player:player_unit()
	if not (alive(attacker) and attacker == player) then return false end
	if self._dead or self._invulnerable then return false end
	return math.random() < -crit
end

local function heal(self, attack_data)
	if Network:is_server() and self._health and self._HEALTH_INIT then
		local amount = attack_data.damage or 0
		self._health = math.min(self._health + amount, self._HEALTH_INIT)
		self._health_ratio = self._health / self._HEALTH_INIT
	end
end

for _, fn in ipairs({ "damage_bullet", "damage_melee" }) do
	local orig = CopDamage[fn]
	if orig then
		CopDamage[fn] = function(self, attack_data, ...)
			local ok, backfire = pcall(backfires, self, attack_data)
			if ok and backfire then
				pcall(heal, self, attack_data)
				-- (7.21) live line: the Gambler's negative crit chance at work
				if B.live then
					B.live("gambler backfire", "crit %d%%: a hit %s", math.floor((B.gambler_crit or 0) * 100 + 0.5),
						Network:is_server() and "healed the enemy" or "did no damage (not hosting)")
				end
				return
			end
			return orig(self, attack_data, ...)
		end
	end
end
