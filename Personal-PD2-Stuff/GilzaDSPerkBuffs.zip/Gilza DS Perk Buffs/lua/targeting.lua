GilzaDSBuffs = GilzaDSBuffs or {}
local B = GilzaDSBuffs
local script = RequiredScript and RequiredScript:lower() or ""

-- Reworked "less / more likely to be targeted".
-- Each enemy rolls a fixed number against each player once. If the roll is under the player's
-- "less likely" chance, that enemy ignores the player completely (won't aim at or turn to them)
-- until it gets provoked: the player damages it, or gets right in its face.
-- So with 40%, roughly 40% of enemies ignore you, and crouching etc. raises it on the fly.
-- "More likely" values work the other way: that share of enemies prefer you when they can see you.
-- Runs on the host, so it covers the host and every client.
B.TARGETING = {
	close_range = 400,
	provoke_time = 10,
	max_pass = 0.9,
	max_pull = 0.5
}
local T = B.TARGETING

-- a line in the BLT log the first times a feature does something (buffs.lua)
local function live(key, ...) if B.live then B.live(key, ...) end end

-- chance (per target pick) that a Cloaker who can see a Burglar picks the Burglar over everyone else
T.cloaker_burglar_pull = 0.75
function T.has_tag_spooc(data)
	local base = data and alive(data.unit) and data.unit:base()
	return base and base.has_tag and base:has_tag("spooc") or false
end

local STILL_KEY = "stand_still_crouch_camouflage_bonus"

if script == "lib/managers/playermanager" then
	-- while the enemy logic weighs targets, hide the vanilla crouch-still weight so it isn't counted twice
	local orig_uv = PlayerManager.upgrade_value
	function PlayerManager:upgrade_value(category, upgrade, ...)
		if B._tgt_neutral and upgrade == STILL_KEY and category == "player" then
			return 1
		end
		return orig_uv(self, category, upgrade, ...)
	end

elseif script == "lib/units/beings/player/huskplayerbase" then
	local orig_uv = HuskPlayerBase.upgrade_value
	function HuskPlayerBase:upgrade_value(category, upgrade, ...)
		if B._tgt_neutral and upgrade == STILL_KEY and category == "player" then
			return nil
		end
		return orig_uv(self, category, upgrade, ...)
	end

elseif script == "lib/units/enemies/cop/logics/coplogicidle" then
	local function game_t()
		return TimerManager:game():time()
	end

	local function husk_mul(unit)
		local base = unit:base()
		if not (base and base.upgrade_value) then return 1 end
		local function uv(k) return base:upgrade_value("player", k) end
		local mul = 1
		local brawler = uv("damage_resist_brawler") and uv("uncover_multiplier")
		if not brawler then
			local a, b = uv("camouflage_bonus"), uv("camouflage_multiplier")
			if type(a) == "number" then mul = mul * a end
			if type(b) == "number" then mul = mul * b end
		end
		local c = uv("uncover_multiplier")
		-- Muscle card 3 Taunt: 50% instead of the game's 15%
		if type(c) == "number" and B.MUSCLE and B.peer_deck then
			local session = managers.network and managers.network:session()
			local peer = session and session:peer_by_unit(unit)
			local deck, tier = B.peer_deck(peer)
			if deck == B.MUSCLE.deck and tier >= 3 then c = B.MUSCLE.taunt end
		end
		if type(c) == "number" then mul = mul * c end
		local mov = unit:movement()
		if mov and not mov._move_data and mov._pose_code == 2 then
			local d = uv(STILL_KEY)
			if type(d) == "number" then mul = mul * d end
		end
		return mul
	end

	local function unit_mul(att)
		local unit = att.unit
		if not alive(unit) then return 1 end
		local mul
		if att.is_local_player then
			mul = B.targeted_mul and select(1, B.targeted_mul()) or 1
			return mul or 1
		elseif att.is_husk_player then
			mul = husk_mul(unit)
		else
			return 1
		end
		return mul
	end

	B._tgt_rolls = B._tgt_rolls or {}
	local rolls_n = 0

	-- fixed random value per enemy/player pair, so the same enemies keep ignoring you
	local function pair_value(enemy_key, target_key)
		local per = B._tgt_rolls[enemy_key]
		if not per then
			rolls_n = rolls_n + 1
			if rolls_n > 600 then
				B._tgt_rolls, rolls_n = {}, 1
				B._tgt_provoked = {}
			end
			per = {}
			B._tgt_rolls[enemy_key] = per
		end
		local v = per[target_key]
		if not v then
			v = math.random()
			per[target_key] = v
		end
		return v
	end

	local function provoked(enemy_key, target_key)
		local p = B._tgt_provoked and B._tgt_provoked[enemy_key]
		local until_t = p and p[target_key]
		return until_t and game_t() < until_t
	end

	local function is_burglar(att)
		if not (B.burglar_unit_tier and alive(att.unit)) then return false end
		return B.burglar_unit_tier(att.unit) >= 1
	end

	local function too_close(data, att)
		local dis = att.dis
		if not dis and alive(att.unit) and data.m_pos then
			dis = mvector3.distance(data.m_pos, att.unit:position())
		end
		local range = T.close_range
		if B.BURGLAR and B.BURGLAR.close_range and is_burglar(att) then
			range = math.max(range, B.BURGLAR.close_range)
		end
		return dis and dis <= range
	end

	local function dist(data, att)
		if att.dis then return att.dis end
		if alive(att.unit) and data.m_pos then return mvector3.distance(data.m_pos, att.unit:position()) end
		return math.huge
	end
	-- Burglar Ghost (7.00): in loud, enemies further than the Burglar's current range can't see or target them
	-- (15 m, 8 m crouched, 2 m during Slip Away / Fade Out, 5 m after a Wraith dodge; 0 while exposed)
	local function burglar_unseen(data, att, k)
		if not (B.burglar_ghost_of and alive(att.unit)) then return false end
		local r = B.burglar_ghost_of(att.unit)
		return r > 0 and dist(data, att) > r
	end

	local orig = CopLogicIdle._get_priority_attention

	local function call_neutral(data, objects, reaction_func, ...)
		local stash
		for _, att in pairs(objects) do
			if (att.is_local_player or att.is_husk_player) and att.settings and att.settings.weight_mul then
				stash = stash or {}
				stash[att.settings] = att.settings.weight_mul
				att.settings.weight_mul = nil
			end
		end
		B._tgt_neutral = true
		local ok, a, b, c = pcall(orig, data, objects, reaction_func, ...)
		B._tgt_neutral = nil
		if stash then
			for settings, w in pairs(stash) do settings.weight_mul = w end
		end
		if not ok then error(a, 0) end
		return a, b, c
	end

	function CopLogicIdle._get_priority_attention(data, attention_objects, reaction_func, ...)
		if not (Network:is_server() and attention_objects and data and data.key) then
			return orig(data, attention_objects, reaction_func, ...)
		end
		local state = managers.groupai and managers.groupai:state()
		if not state or not state:enemy_weapons_hot() or state:force_attention_data(data.unit) or data.is_converted then
			return orig(data, attention_objects, reaction_func, ...)
		end

		local filtered, preferred
		local is_cloaker = T.has_tag_spooc(data)
		local ok = pcall(function()
			for k, att in pairs(attention_objects) do
				if (att.is_local_player or att.is_husk_player) and is_cloaker and is_burglar(att) then
					-- Cloakers see straight through a Burglar's stealth and go for them first
					if att.identified and att.verified and math.random() < T.cloaker_burglar_pull then
						preferred = preferred or {}
						preferred[k] = att
						live("burglar cloaker", "a Cloaker went for a Burglar")
					end
				elseif att.is_local_player or att.is_husk_player then
					local mul = unit_mul(att)
					local hide = burglar_unseen(data, att, k)
					if hide and not provoked(data.key, k) then
						if not filtered then
							filtered = {}
							for k2, a2 in pairs(attention_objects) do filtered[k2] = a2 end
						end
						filtered[k] = nil
						live("burglar ghost hide", "an enemy %.1f m away can't see a Burglar (Ghost range %.1f m)",
							dist(data, att) / 100, B.burglar_ghost_of(att.unit) / 100)
					elseif mul < 1 then
						local ignore = pair_value(data.key, k) < math.min(1 - mul, T.max_pass)
						if ignore and not provoked(data.key, k) and not too_close(data, att) then
							if not filtered then
								filtered = {}
								for k2, a2 in pairs(attention_objects) do filtered[k2] = a2 end
							end
							filtered[k] = nil
							live("targeting ignore", "an enemy ignores a player (targeted x%.2f)", mul)
						end
					elseif mul > 1 and att.identified and att.verified then
						if pair_value(data.key, k) < math.min(mul - 1, T.max_pull) then
							preferred = preferred or {}
							preferred[k] = att
							live("targeting pull", "an enemy goes for a player first (targeted x%.2f)", mul)
						end
					end
				end
			end
		end)
		if not ok then
			filtered, preferred = nil, nil
		end

		if preferred then
			local alt, alt_slot, alt_reaction = call_neutral(data, preferred, reaction_func, ...)
			if alt and alt_reaction and alt_reaction >= AIAttentionObject.REACT_AIM then
				return alt, alt_slot, alt_reaction
			end
		end
		return call_neutral(data, filtered or attention_objects, reaction_func, ...)
	end

elseif script == "lib/units/enemies/cop/copdamage" then
	-- shooting or hitting an enemy makes it stop ignoring you for a while
	Hooks:PostHook(CopDamage, "_on_damage_received", "GilzaDSBuffs_targeting_provoke", function(self, damage_info)
		if not Network:is_server() then return end
		local attacker = damage_info and damage_info.attacker_unit
		if not alive(attacker) or not alive(self._unit) then return end
		local base = attacker:base()
		if not (base and (base.is_local_player or base.is_husk_player)) then return end
		-- Burglar card 5: melee and silenced shots don't give them away
		if B.burglar_unit_tier and B.burglar_unit_tier(attacker) >= 5 then
			if damage_info.variant == "melee" then return end
			local wpn = damage_info.weapon_unit
			local wb = alive(wpn) and wpn:base()
			if wb and wb.got_silencer and wb:got_silencer() then return end
		end
		B._tgt_provoked = B._tgt_provoked or {}
		local key = self._unit:key()
		local p = B._tgt_provoked[key]
		if not p then
			p = {}
			B._tgt_provoked[key] = p
		end
		p[attacker:key()] = TimerManager:game():time() + B.TARGETING.provoke_time
	end)
end
